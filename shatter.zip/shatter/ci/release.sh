#!/bin/bash
# Builds Superhot (.3dsx + .cia) and publishes the "latest" release with a QR code.
# Run from the repo root by the GitHub workflow.
set -euo pipefail

ROOT="$PWD"
VER="$(tr -d ' \r\n' < shatter/VERSION)"
TAG="v$VER"
IFS=. read -r V1 V2 V3 <<< "$VER"
BASE="https://github.com/$GITHUB_REPOSITORY/releases/download/$TAG"
mkdir -p out

docker run --rm -v "$ROOT/shatter:/w" -w /w devkitpro/devkitarm:latest make
cp shatter/Superhot.3dsx out/

git clone -q --depth 1 --branch makerom-v0.18.4 https://github.com/3DSGuy/Project_CTR /tmp/ctr
make -C /tmp/ctr/makerom deps
make -C /tmp/ctr/makerom

cd shatter/cia
/tmp/ctr/makerom/bin/makerom -f cia -o "$ROOT/out/Superhot.cia" \
  -elf ../Superhot.elf -rsf app.rsf -target t -exefslogo \
  -icon icon.icn -banner banner.bnr -logo logo.bcma.lz \
  -major "${V1:-1}" -minor "${V2:-0}" -micro "${V3:-0}" \
  -DAPP_TITLE="Superhot" -DAPP_PRODUCT_CODE="CTR-P-SHTT" -DAPP_UNIQUE_ID="0xB4057" \
  -DAPP_SYSTEM_MODE="64MB" -DAPP_SYSTEM_MODE_EXT="Legacy" -DAPP_CATEGORY="Application" \
  -DAPP_USE_ON_SD="true" -DAPP_MEMORY_TYPE="Application" -DAPP_CPU_SPEED="804MHz" \
  -DAPP_ENABLE_L2_CACHE="true" -DAPP_VERSION_MAJOR="${V1:-1}" -DAPP_ENCRYPTED=false
cd "$ROOT"

pip install --quiet "qrcode[pil]"
python3 -c "import qrcode,sys; qrcode.make(sys.argv[1], box_size=8, border=3).save('out/qr.png')" "$BASE/Superhot.cia"

cat > notes.md <<NOTES
## Superhot $VER

Scan with FBI on your 2DS/3DS (Remote Install > Scan QR Code). It installs over the old version and keeps your progress.

![QR code]($BASE/qr.png)

Or put [Superhot.3dsx]($BASE/Superhot.3dsx) in /3ds/ on your SD card.

NOTES

# one release per version: building the same version again replaces it
gh release delete "$TAG" --yes --cleanup-tag || true
gh release delete latest --yes --cleanup-tag || true
gh release create "$TAG" out/Superhot.cia out/qr.png out/Superhot.3dsx \
  --title "Superhot $VER" --notes-file notes.md --target "$GITHUB_SHA" --latest
