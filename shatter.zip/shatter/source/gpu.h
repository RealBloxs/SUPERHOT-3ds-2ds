#ifndef GPU_H
#define GPU_H
#include "engine.h"
int gpu_init(void); /* 1 = ready */
/* builds the 3D scene with build(ctx) (it calls the engine's draw functions), then draws it
 * (in stereo when the slider is up) with the 400x240 RGBA4444 text layer on top */
void gpu_frame(void (*build)(void *), void *ctx, const Cam *cam, const unsigned short *hud, int hasHud,
               unsigned clearRGB, float slider);
void gpu_exit(void);
void gpu_set_aa(int on); /* 2x2 supersampling when the 3D slider is off */
#endif
