/* SUPERHOT - every sound is synthesized at startup (no audio files) and mixed in software. */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"

#define R AUDIO_RATE
#define MAX_VOICES 24

typedef struct { short *data; int len; } Sample;
typedef struct { const Sample *s; float pos, rate, gl, gr; int world; } Voice;
typedef struct { float gain, pan, curL, curR; int pos; } Loop;

static Sample sfx[SFX_COUNT];
static Sample loops[LOOP_COUNT];
static Voice voices[MAX_VOICES];
static Loop loopState[LOOP_COUNT];
static unsigned seed = 7;
static float timeTarget = 1, timeRate = 1;   /* world sounds slow down with game time */

static float rnd(void) {
    seed = seed * 1664525u + 1013904223u;
    return ((seed >> 9) & 0x7FFF) / 16384.0f - 1.0f;
}
static float *fbuf(float sec, int *len) {
    *len = (int)(sec * R);
    return (float *)calloc(*len, sizeof(float));
}
static void finish(Sample *s, float *f, int len, float vol) {
    if (!f) return;
    float peak = 0.0001f;
    for (int i = 0; i < len; i++) if (fabsf(f[i]) > peak) peak = fabsf(f[i]);
    s->data = (short *)malloc(len * sizeof(short));
    if (!s->data) { free(f); return; }
    s->len = len;
    for (int i = 0; i < len; i++) {
        float v = f[i] / peak * vol;
        s->data[i] = (short)((v > 1 ? 1 : (v < -1 ? -1 : v)) * 32000);
    }
    free(f);
}
static void lowpass(float *f, int len, float cut) {
    float a = 1.0f - expf(-2 * PI * cut / R), y = 0;
    for (int i = 0; i < len; i++) { y += a * (f[i] - y); f[i] = y; }
}
static void highpass(float *f, int len, float cut) {
    float a = 1.0f - expf(-2 * PI * cut / R), y = 0;
    for (int i = 0; i < len; i++) { y += a * (f[i] - y); f[i] -= y; }
}
static void seam(float *f, int len) {
    int m = R / 50;
    if (len < 2 * m) return;
    for (int i = 0; i < m; i++) {
        float k = (float)i / m;
        /* crossfade the end into the start */
        f[i] = f[i] * k + f[len - m + i] * (1 - k);
    }
}

/* a small room: four combs and two allpasses (Schroeder). wet 0..1 */
static void reverb(float *f, int len, float wet, float size) {
    static const int cd[4] = {1116, 1188, 1277, 1356}, ad[2] = {556, 341};
    float *dry = (float *)malloc(len * sizeof(float));
    if (!dry) return;
    memcpy(dry, f, len * sizeof(float));
    float *out = (float *)calloc(len, sizeof(float));
    if (!out) { free(dry); return; }
    for (int c = 0; c < 4; c++) {
        int d = (int)(cd[c] * size * R / 44100.0f);
        if (d < 8) d = 8;
        float *buf = (float *)calloc(d, sizeof(float));
        if (!buf) continue;
        float fb = 0.78f, lp = 0;
        for (int i = 0, k = 0; i < len; i++, k = (k + 1) % d) {
            float y = buf[k];
            lp = y * 0.7f + lp * 0.3f;            /* darker each time round */
            buf[k] = dry[i] + lp * fb;
            out[i] += y * 0.25f;
        }
        free(buf);
    }
    for (int a = 0; a < 2; a++) {
        int d = (int)(ad[a] * size * R / 44100.0f);
        if (d < 4) d = 4;
        float *buf = (float *)calloc(d, sizeof(float));
        if (!buf) continue;
        for (int i = 0, k = 0; i < len; i++, k = (k + 1) % d) {
            float b = buf[k], x = out[i];
            float y = -x * 0.5f + b;
            buf[k] = x + b * 0.5f;
            out[i] = y;
        }
        free(buf);
    }
    for (int i = 0; i < len; i++) f[i] = dry[i] * (1 - wet * 0.5f) + out[i] * wet;
    free(dry); free(out);
}

/* a two-pole resonator (band pass) with its state, for voices and ringing glass */
typedef struct { float a1, a2, b0, y1, y2; } Reso;
static void reso_set(Reso *r, float fr, float bw) {
    float rr = expf(-PI * bw / R), th = 2 * PI * fr / R;
    r->a1 = 2 * rr * cosf(th); r->a2 = -rr * rr; r->b0 = (1 - rr) * 1.2f;
}
static float reso_run(Reso *r, float x) {
    float y = r->b0 * x + r->a1 * r->y1 + r->a2 * r->y2;
    r->y2 = r->y1; r->y1 = y;
    return y;
}

/* ---------- one-shots ---------- */
static void make_punch(Sample *s) {
    int n; float *f = fbuf(0.25f, &n);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R;
        f[i] = rnd() * expf(-t * 70) * 0.8f + sinf(2 * PI * (110 - 120 * t) * t) * expf(-t * 22);
    }
    lowpass(f, n, 2500);
    finish(s, f, n, 0.95f);
}
/* glass breaking: a hard crack with a low thump under it, a burst of bright inharmonic rings,
 * then a long fall of pieces tinkling down, all in a small room */
static void make_shatter_v(Sample *s, float dur, int pieces, float body, float vol) {
    int n; float *f = fbuf(dur, &n);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R;
        float crack = rnd() * expf(-t * 55) * 1.3f;
        float thump = sinf(2 * PI * (body * expf(-t * 6)) * t) * expf(-t * 18) * 0.9f;
        f[i] = crack + thump;
    }
    highpass(f, n, 180);
    /* the first break: several glassy modes ringing together */
    static const float modes[6] = {1.0f, 2.32f, 3.17f, 4.41f, 5.73f, 7.12f};
    float base = 1650 + 300 * rnd();
    for (int m = 0; m < 6; m++) {
        float fr = base * modes[m], dec = 9 + m * 6;
        for (int i = 0; i < n && i < R; i++) { float t = (float)i / R; f[i] += sinf(2 * PI * fr * t + m) * expf(-t * dec) * (0.22f - m * 0.025f); }
    }
    /* then the pieces: each a short ping, more of them early, landing later on */
    for (int k = 0; k < pieces; k++) {
        float u = rnd() * 0.5f + 0.5f;
        float t0 = 0.03f + u * u * (dur * 0.75f);
        float fr = 2400 + (rnd() * 0.5f + 0.5f) * 7000, dec = 30 + (rnd() * 0.5f + 0.5f) * 70;
        float amp = (0.12f + (rnd() * 0.5f + 0.5f) * 0.3f) * expf(-t0 * 1.2f);
        int st = (int)(t0 * R);
        for (int i = st; i < n && i < st + R / 5; i++) {
            float t = (float)(i - st) / R;
            f[i] += (sinf(2 * PI * fr * t) + 0.4f * sinf(2 * PI * fr * 1.51f * t)) * expf(-t * dec) * amp + rnd() * expf(-t * 600) * amp * 0.5f;
        }
    }
    reverb(f, n, 0.35f, 0.8f);
    finish(s, f, n, vol);
}
static void make_shatter(Sample *s) { make_shatter_v(s, 1.9f, 110, 70, 0.9f); }

/* a gunshot: a click, a crack of noise, a deep body thump, and the room answering */
static void make_gun(Sample *s, float dur, float body, float crackDec, float bodyDec, float noiseCut, float verb, float vol) {
    int n; float *f = fbuf(dur, &n);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R;
        float click = (i < 40) ? (1 - i / 40.0f) * (i & 1 ? 1 : -1) : 0;
        float crack = rnd() * expf(-t * crackDec) * 1.4f;
        float thump = sinf(2 * PI * (body * expf(-t * 9) + 30) * t) * expf(-t * bodyDec) * 1.1f;
        f[i] = click + crack + thump;
    }
    lowpass(f, n, noiseCut);
    reverb(f, n, verb, 1.0f);
    /* a touch of grit on the attack */
    for (int i = 0; i < n; i++) { float v = f[i] * 1.6f; f[i] = v / (1 + fabsf(v)); }
    finish(s, f, n, vol);
}
static void make_shot(Sample *s, float body, float vol) { make_gun(s, 1.1f, body * 1.4f, 45, 14, 6000, 0.3f, vol); }

/* a katana: a rising metal hiss through the air with a thin ring on top */
static void make_slice(Sample *s) {
    int n; float *f = fbuf(0.45f, &n);
    Reso r; reso_set(&r, 3200, 600);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R, k = t / 0.45f;
        float env = sinf(PI * powf(k, 0.6f));
        reso_set(&r, 1800 + 4200 * k, 700);
        f[i] = reso_run(&r, rnd()) * env * 1.6f + sinf(2 * PI * (5200 + 900 * k) * t) * env * env * 0.12f;
    }
    reverb(f, n, 0.2f, 0.6f);
    finish(s, f, n, 0.7f);
}

/* an empty gun: a dry hammer click twice, and a hollow low knock */
static void make_noammo(Sample *s) {
    int n; float *f = fbuf(0.3f, &n);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R, v = 0;
        float t2 = t - 0.11f;
        v += (rnd() * 0.7f + sinf(2 * PI * 2300 * t)) * expf(-t * 260);
        if (t2 > 0) v += (rnd() * 0.5f + sinf(2 * PI * 1900 * t2)) * expf(-t2 * 300) * 0.7f;
        v += sinf(2 * PI * 140 * t) * expf(-t * 30) * 0.4f;
        f[i] = v;
    }
    finish(s, f, n, 0.7f);
}

/* ---- a deep machine voice for the two words ----
 * A buzzing source at a low pitch, shaped by three resonances (the vowel), with hissing noise for
 * s/h, silence-then-pop for p/t. The sounds are listed per word below and glide into one another. */
typedef struct { char kind; float dur, f1, f2, f3, amp; } Phone;   /* kind: v voiced, s hiss, h breath, p stop */
static void speak(Sample *s, const Phone *ph, int np, float pitch, float vol) {
    float total = 0.12f;
    for (int i = 0; i < np; i++) total += ph[i].dur;
    int n; float *f = fbuf(total, &n);
    Reso r1, r2, r3, rs;
    memset(&r1, 0, sizeof r1); memset(&r2, 0, sizeof r2); memset(&r3, 0, sizeof r3); memset(&rs, 0, sizeof rs);
    float phase = 0, t0 = 0, F1 = ph[0].f1, F2 = ph[0].f2, F3 = ph[0].f3, amp = 0;
    int idx = 0;
    for (int i = 0; i < n; i++) {
        float t = (float)i / R;
        while (idx < np - 1 && t > t0 + ph[idx].dur) { t0 += ph[idx].dur; idx++; }
        const Phone *P = &ph[idx];
        float u = (t - t0) / P->dur;
        if (u > 1) u = 1;
        /* glide the resonances towards this sound */
        float gl = 1 - expf(-1.0f / (0.018f * R));
        F1 += (P->f1 - F1) * gl; F2 += (P->f2 - F2) * gl; F3 += (P->f3 - F3) * gl;
        reso_set(&r1, F1, 90); reso_set(&r2, F2, 120); reso_set(&r3, F3, 170);
        float target = P->amp;
        if (P->kind == 'p') target = u < 0.7f ? 0 : P->amp;      /* hold the breath, then let it go */
        amp += (target - amp) * (1 - expf(-1.0f / (0.01f * R)));
        float pit = pitch * (1.08f - 0.16f * (t / total));        /* the pitch falls across the word */
        phase += pit / R;
        if (phase >= 1) phase -= 1;
        float src = 0;
        /* buzz: a band-limited saw */
        for (int h = 1; h <= 28; h++) { if (pit * h > 7000) break; src += sinf(2 * PI * h * phase) / h; }
        float noise = rnd();
        float v = 0;
        if (P->kind == 'v') v = reso_run(&r1, src) + 0.7f * reso_run(&r2, src) + 0.35f * reso_run(&r3, src);
        else if (P->kind == 'h') v = (reso_run(&r1, noise) + 0.8f * reso_run(&r2, noise) + 0.5f * reso_run(&r3, noise)) * 0.6f;
        else if (P->kind == 's') { reso_set(&rs, P->f1, 2500); v = reso_run(&rs, noise) * 0.8f; }
        else if (P->kind == 'p') { reso_set(&rs, P->f1, 3000); v = u > 0.7f ? reso_run(&rs, noise) * expf(-(u - 0.7f) * 25) * 1.5f : 0; }
        f[i] = v * amp;
    }
    /* weight: an octave below, a little grit, and a big empty hall */
    float lp = 0;
    for (int i = 0; i < n; i++) { lp += 0.08f * (f[i] - lp); float v = f[i] + lp * 0.6f; v *= 2.2f; f[i] = v / (1 + fabsf(v)); }
    lowpass(f, n, 5200);
    reverb(f, n, 0.45f, 1.35f);
    finish(s, f, n, vol);
}
static void make_words(void) {
    static const Phone wa[] = {
        {'s', 0.13f, 5200, 0, 0, 0.55f},
        {'v', 0.15f, 320, 870, 2250, 1.0f},
        {'p', 0.07f, 1500, 0, 0, 0.6f},
        {'v', 0.26f, 470, 1300, 1650, 1.0f},
    };
    static const Phone wb[] = {
        {'h', 0.09f, 720, 1100, 2450, 0.7f},
        {'v', 0.27f, 740, 1120, 2500, 1.0f},
        {'p', 0.08f, 4200, 0, 0, 0.7f},
    };
    speak(&sfx[SFX_WORD_A], wa, 4, 82, 0.95f);
    speak(&sfx[SFX_WORD_B], wb, 3, 78, 0.95f);
}

static void make_click(Sample *s, float fr, float vol) {
    int n; float *f = fbuf(0.06f, &n);
    for (int i = 0; i < n; i++) { float t = (float)i / R; f[i] = (rnd() * 0.6f + sinf(2 * PI * fr * t)) * expf(-t * 140); }
    finish(s, f, n, vol);
}
static void make_whoosh(Sample *s, float dur, float lo, float hi, float vol) {
    int n; float *f = fbuf(dur, &n);
    for (int i = 0; i < n; i++) { float t = (float)i / R, k = t / dur; f[i] = rnd() * sinf(PI * k) * sinf(PI * k); }
    lowpass(f, n, hi);
    highpass(f, n, lo);
    finish(s, f, n, vol);
}
static void make_step(Sample *s) {
    int n; float *f = fbuf(0.1f, &n);
    for (int i = 0; i < n; i++) { float t = (float)i / R; f[i] = rnd() * expf(-t * 70) * 0.5f + sinf(2 * PI * 80 * t) * expf(-t * 45); }
    lowpass(f, n, 700);
    finish(s, f, n, 0.5f);
}
static void make_death(Sample *s) {
    /* a falling low tone with a heartbeat thud */
    int n; float *f = fbuf(1.4f, &n);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R;
        f[i] = sinf(2 * PI * (220 * expf(-t * 1.6f)) * t) * expf(-t * 2) * 0.7f + sinf(2 * PI * 50 * t) * expf(-t * 8);
    }
    lowpass(f, n, 1500);
    finish(s, f, n, 0.8f);
}
static void make_tone(Sample *s, float dur, float fr, float dec, float vol) {
    int n; float *f = fbuf(dur, &n);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R;
        f[i] = (sinf(2 * PI * fr * t) + 0.3f * sinf(2 * PI * fr * 2 * t)) * (1 - expf(-t * 900)) * expf(-t * dec);
    }
    finish(s, f, n, vol);
}
static void make_flash(Sample *s) {
    /* the level-clear hit: a deep boom with a hiss on top */
    int n; float *f = fbuf(0.45f, &n);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R;
        f[i] = sinf(2 * PI * (70 - 30 * t) * t) * expf(-t * 7) + rnd() * expf(-t * 18) * 0.35f;
    }
    lowpass(f, n, 3000);
    finish(s, f, n, 0.9f);
}
static void make_whiz(Sample *s) {
    int n; float *f = fbuf(0.35f, &n);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R, k = t / 0.35f;
        f[i] = rnd() * sinf(PI * k) + 0.4f * sinf(2 * PI * (1800 - 900 * k) * t) * sinf(PI * k);
    }
    highpass(f, n, 1200);
    lowpass(f, n, 5000);
    finish(s, f, n, 0.6f);
}
static void make_ricochet(Sample *s) {
    int n; float *f = fbuf(0.4f, &n);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R;
        f[i] = rnd() * expf(-t * 60) * 0.6f + sinf(2 * PI * (3200 - 2400 * t) * t) * expf(-t * 9) * 0.5f;
    }
    finish(s, f, n, 0.6f);
}

/* ---------- loops ---------- */
static void make_drone(Sample *s) {
    /* slow time: a deep, slightly unsettled pad - detuned low tones through a slowly breathing filter,
     * a soft pulse under it like a held breath */
    int n; float *f = fbuf(6.0f, &n);
    static const float fr[5] = {41.2f, 41.6f, 61.8f, 82.4f, 123.3f};
    float ph[5] = {0};
    float lp = 0;
    for (int i = 0; i < n; i++) {
        float t = (float)i / R, v = 0;
        for (int k = 0; k < 5; k++) {
            ph[k] += fr[k] / R; if (ph[k] > 1) ph[k] -= 1;
            v += (2 * ph[k] - 1) * (k < 2 ? 0.5f : 0.25f);          /* soft saws */
        }
        float cut = 0.012f + 0.01f * sinf(2 * PI * t / 6.0f);       /* the filter breathes once per loop */
        lp += cut * (v - lp);
        float pulse = 0.5f + 0.5f * sinf(2 * PI * t * 0.5f);
        f[i] = lp * (0.75f + 0.25f * pulse) + sinf(2 * PI * 41.2f * t) * 0.35f;
    }
    seam(f, n);
    finish(s, f, n, 0.6f);
}
static void make_rush(Sample *s) {
    /* fast time: air streaming past, rising and falling a little */
    int n; float *f = fbuf(4.0f, &n);
    Reso r; memset(&r, 0, sizeof r);
    for (int i = 0; i < n; i++) {
        float t = (float)i / R;
        reso_set(&r, 500 + 250 * sinf(2 * PI * t * 0.5f) + 120 * sinf(2 * PI * t * 1.25f), 600);
        f[i] = reso_run(&r, rnd()) + rnd() * 0.08f;
    }
    lowpass(f, n, 2500);
    highpass(f, n, 90);
    seam(f, n);
    finish(s, f, n, 0.45f);
}
static void make_hum(Sample *s) {
    /* an old computer: fan noise and mains hum */
    int n; float *f = fbuf(2.0f, &n);
    for (int i = 0; i < n; i++) { float t = (float)i / R; f[i] = rnd() * 0.25f + sinf(2 * PI * 60 * t) * 0.4f + sinf(2 * PI * 120 * t) * 0.15f; }
    lowpass(f, n, 1500);
    seam(f, n);
    finish(s, f, n, 0.35f);
}

static void make_tink(Sample *s) {
    /* a small piece of glass hitting the floor: a few bright, quickly dying partials */
    int n; float *f = fbuf(0.18f, &n);
    static const float fr[4] = {3100, 4700, 6900, 8800};
    for (int i = 0; i < n; i++) {
        float t = (float)i / R, v = rnd() * expf(-t * 400) * 0.4f;
        for (int k = 0; k < 4; k++) v += sinf(2 * PI * fr[k] * t) * expf(-t * (30 + k * 18)) * (0.5f - k * 0.08f);
        f[i] = v;
    }
    finish(s, f, n, 0.6f);
}

void audio_init(void) {
    make_tink(&sfx[SFX_TINK]);
    make_punch(&sfx[SFX_PUNCH]);
    make_shatter(&sfx[SFX_SHATTER]);
    make_shot(&sfx[SFX_SHOT], 95, 0.95f);
    make_click(&sfx[SFX_EMPTY], 1400, 0.5f);
    make_click(&sfx[SFX_PICKUP], 600, 0.7f);
    make_whoosh(&sfx[SFX_THROW], 0.3f, 300, 2500, 0.7f);
    make_step(&sfx[SFX_STEP]);
    make_death(&sfx[SFX_DEATH]);
    make_click(&sfx[SFX_KEY], 2600, 0.45f);
    make_tone(&sfx[SFX_BEEP], 0.12f, 880, 30, 0.45f);
    make_flash(&sfx[SFX_FLASH]);
    make_whiz(&sfx[SFX_WHIZ]);
    make_ricochet(&sfx[SFX_RICOCHET]);
    make_whoosh(&sfx[SFX_SWING], 0.2f, 500, 3000, 0.5f);
    make_gun(&sfx[SFX_ENEMY_SHOT], 1.0f, 95, 50, 16, 4200, 0.4f, 0.8f);
    make_gun(&sfx[SFX_SHOTGUN], 1.5f, 80, 22, 8, 4500, 0.4f, 1.0f);
    make_gun(&sfx[SFX_SMG], 0.45f, 150, 70, 26, 6500, 0.18f, 0.8f);
    make_shatter_v(&sfx[SFX_BREAK], 1.1f, 45, 120, 0.8f);
    make_slice(&sfx[SFX_SLICE]);
    make_noammo(&sfx[SFX_NOAMMO]);
    make_words();
    make_drone(&loops[LOOP_DRONE]);
    make_rush(&loops[LOOP_RUSH]);
    make_hum(&loops[LOOP_HUM]);
    memset(voices, 0, sizeof(voices));
    memset(loopState, 0, sizeof(loopState));
}

void audio_play_rate(int id, float gain, float pan, float rate) {
    if (id < 0 || id >= SFX_COUNT || gain <= 0.001f || !sfx[id].data) return;
    if (gain > 1) gain = 1;
    if (pan < -1) pan = -1;
    if (pan > 1) pan = 1;
    if (rate < 0.2f) rate = 0.2f;
    int slot = 0;
    float best = -1;
    for (int i = 0; i < MAX_VOICES; i++) {
        if (!voices[i].s) { slot = i; break; }
        if (voices[i].pos > best) { best = voices[i].pos; slot = i; }
    }
    Voice *v = &voices[slot];
    v->s = &sfx[id];
    v->pos = 0;
    v->rate = rate;
    v->gl = gain * sqrtf((1 - pan) * 0.5f);
    v->gr = gain * sqrtf((1 + pan) * 0.5f);
    /* menu clicks and the shouted words keep their pitch; everything in the world bends with time */
    v->world = !(id == SFX_KEY || id == SFX_BEEP || id == SFX_FLASH || id == SFX_WORD_A || id == SFX_WORD_B);
}

void audio_set_time(float ts) {
    if (ts < 0) ts = 0;
    if (ts > 1) ts = 1;
    timeTarget = 0.55f + 0.45f * ts;
}
void audio_play(int id, float gain, float pan) { audio_play_rate(id, gain, pan, 1); }

void audio_loop(int id, float gain, float pan) {
    if (id < 0 || id >= LOOP_COUNT) return;
    loopState[id].gain = gain < 0 ? 0 : (gain > 1 ? 1 : gain);
    loopState[id].pan = pan < -1 ? -1 : (pan > 1 ? 1 : pan);
}

void audio_mix(short *out, int frames) {
    static float acc[2 * 4096];
    if (frames > 4096) frames = 4096;
    memset(acc, 0, frames * 2 * sizeof(float));
    timeRate += (timeTarget - timeRate) * 0.25f;
    for (int i = 0; i < MAX_VOICES; i++) {
        Voice *v = &voices[i];
        if (!v->s) continue;
        const Sample *s = v->s;
        float rate = v->rate * (v->world ? timeRate : 1);
        for (int k = 0; k < frames; k++) {
            int p = (int)v->pos;
            if (p >= s->len - 1) { v->s = 0; break; }
            float fr = v->pos - p;
            float smp = (s->data[p] + (s->data[p + 1] - s->data[p]) * fr) * (1.0f / 32768.0f);
            acc[k * 2] += smp * v->gl;
            acc[k * 2 + 1] += smp * v->gr;
            v->pos += rate;
        }
    }
    for (int i = 0; i < LOOP_COUNT; i++) {
        Loop *l = &loopState[i];
        const Sample *s = &loops[i];
        if (!s->data) continue;
        float tl = l->gain * sqrtf((1 - l->pan) * 0.5f), tr = l->gain * sqrtf((1 + l->pan) * 0.5f);
        if (tl < 0.0005f && tr < 0.0005f && l->curL < 0.0005f && l->curR < 0.0005f) {
            l->curL = l->curR = 0;
            l->pos = (l->pos + frames) % s->len;
            continue;
        }
        float dl = (tl - l->curL) / frames, dr = (tr - l->curR) / frames;
        for (int k = 0; k < frames; k++) {
            float smp = s->data[l->pos] * (1.0f / 32768.0f);
            l->curL += dl;
            l->curR += dr;
            acc[k * 2] += smp * l->curL;
            acc[k * 2 + 1] += smp * l->curR;
            if (++l->pos >= s->len) l->pos = 0;
        }
    }
    for (int k = 0; k < frames * 2; k++) {
        float v = acc[k] * 0.8f;
        v = v / (1 + fabsf(v) * 0.3f);
        out[k] = (short)((v > 1 ? 1 : (v < -1 ? -1 : v)) * 32000);
    }
}

int audio_sample_len(int id) { return id >= 0 && id < SFX_COUNT ? sfx[id].len : 0; }
/* for tools: the raw samples */
const short *audio_sample_data(int id, int *len) { if (id < 0 || id >= SFX_COUNT) { *len = 0; return 0; } *len = sfx[id].len; return sfx[id].data; }
