/* SUPERHOT - sounds are synthesized ahead of time (tools/make_sounds.py -> sounds.c; the two spoken
 * words are still made here at startup) and mixed in software. */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"
#include "sounds.h"

#define R AUDIO_RATE
#define MAX_VOICES 24

typedef struct { const short *data; int len; } Sample;
typedef struct { const Sample *s; float pos, rate, gl, gr; int world; } Voice;
typedef struct { float gain, pan, curL, curR; int pos; } Loop;

static Sample sfx[SFX_COUNT];
static Sample sfxVar[SFX_COUNT][SND_MAX_VARIANTS];   /* the ready-made versions of each sound */
static int sfxNVar[SFX_COUNT], sfxLastVar[SFX_COUNT];
static Sample loops[LOOP_COUNT];
static Voice voices[MAX_VOICES];
static Loop loopState[LOOP_COUNT];
static unsigned seed = 7;
static float timeTarget = 1, timeRate = 1;   /* world sounds slow down with game time */

static float rnd(void) {
    seed = seed * 1664525u + 1013904223u;
    return ((seed >> 9) & 0x7FFF) / 16384.0f - 1.0f;
}
static float *fbuf(float sec, int *len) {
    *len = (int)(sec * R);
    return (float *)calloc(*len, sizeof(float));
}
static void finish(Sample *s, float *f, int len, float vol) {
    if (!f) return;
    float peak = 0.0001f;
    for (int i = 0; i < len; i++) if (fabsf(f[i]) > peak) peak = fabsf(f[i]);
    short *d = (short *)malloc(len * sizeof(short));
    if (!d) { free(f); return; }
    s->len = len;
    for (int i = 0; i < len; i++) {
        float v = f[i] / peak * vol;
        d[i] = (short)((v > 1 ? 1 : (v < -1 ? -1 : v)) * 32000);
    }
    s->data = d;
    free(f);
}
static void lowpass(float *f, int len, float cut) {
    float a = 1.0f - expf(-2 * PI * cut / R), y = 0;
    for (int i = 0; i < len; i++) { y += a * (f[i] - y); f[i] = y; }
}

/* a small room: four combs and two allpasses (Schroeder). wet 0..1 */
static void reverb(float *f, int len, float wet, float size) {
    static const int cd[4] = {1116, 1188, 1277, 1356}, ad[2] = {556, 341};
    float *dry = (float *)malloc(len * sizeof(float));
    if (!dry) return;
    memcpy(dry, f, len * sizeof(float));
    float *out = (float *)calloc(len, sizeof(float));
    if (!out) { free(dry); return; }
    for (int c = 0; c < 4; c++) {
        int d = (int)(cd[c] * size * R / 44100.0f);
        if (d < 8) d = 8;
        float *buf = (float *)calloc(d, sizeof(float));
        if (!buf) continue;
        float fb = 0.78f, lp = 0;
        for (int i = 0, k = 0; i < len; i++, k = (k + 1) % d) {
            float y = buf[k];
            lp = y * 0.7f + lp * 0.3f;            /* darker each time round */
            buf[k] = dry[i] + lp * fb;
            out[i] += y * 0.25f;
        }
        free(buf);
    }
    for (int a = 0; a < 2; a++) {
        int d = (int)(ad[a] * size * R / 44100.0f);
        if (d < 4) d = 4;
        float *buf = (float *)calloc(d, sizeof(float));
        if (!buf) continue;
        for (int i = 0, k = 0; i < len; i++, k = (k + 1) % d) {
            float b = buf[k], x = out[i];
            float y = -x * 0.5f + b;
            buf[k] = x + b * 0.5f;
            out[i] = y;
        }
        free(buf);
    }
    for (int i = 0; i < len; i++) f[i] = dry[i] * (1 - wet * 0.5f) + out[i] * wet;
    free(dry); free(out);
}

/* a two-pole resonator (band pass) with its state, for voices and ringing glass */
typedef struct { float a1, a2, b0, y1, y2; } Reso;
static void reso_set(Reso *r, float fr, float bw) {
    float rr = expf(-PI * bw / R), th = 2 * PI * fr / R;
    r->a1 = 2 * rr * cosf(th); r->a2 = -rr * rr; r->b0 = (1 - rr) * 1.2f;
    r->y1 = r->y2 = 0;
}
static float reso_run(Reso *r, float x) {
    float y = r->b0 * x + r->a1 * r->y1 + r->a2 * r->y2;
    r->y2 = r->y1; r->y1 = y;
    return y;
}

/* ---------- one-shots ---------- */
/* glass breaking: a hard crack with a low thump under it, a burst of bright inharmonic rings,
 * then a long fall of pieces tinkling down, all in a small room */

/* a gunshot: a click, a crack of noise, a deep body thump, and the room answering */

/* a katana: a rising metal hiss through the air with a thin ring on top */

/* an empty gun: a dry hammer click twice, and a hollow low knock */

/* ---- a deep machine voice for the two words ----
 * A buzzing source at a low pitch, shaped by three resonances (the vowel), with hissing noise for
 * s/h, silence-then-pop for p/t. The sounds are listed per word below and glide into one another. */
typedef struct { char kind; float dur, f1, f2, f3, amp; } Phone;   /* kind: v voiced, s hiss, h breath, p stop */
static void speak(Sample *s, const Phone *ph, int np, float pitch, float vol) {
    float total = 0.12f;
    for (int i = 0; i < np; i++) total += ph[i].dur;
    int n; float *f = fbuf(total, &n);
    Reso r1, r2, r3, rs;
    memset(&r1, 0, sizeof r1); memset(&r2, 0, sizeof r2); memset(&r3, 0, sizeof r3); memset(&rs, 0, sizeof rs);
    float phase = 0, t0 = 0, F1 = ph[0].f1, F2 = ph[0].f2, F3 = ph[0].f3, amp = 0;
    int idx = 0;
    for (int i = 0; i < n; i++) {
        float t = (float)i / R;
        while (idx < np - 1 && t > t0 + ph[idx].dur) { t0 += ph[idx].dur; idx++; }
        const Phone *P = &ph[idx];
        float u = (t - t0) / P->dur;
        if (u > 1) u = 1;
        /* glide the resonances towards this sound */
        float gl = 1 - expf(-1.0f / (0.018f * R));
        F1 += (P->f1 - F1) * gl; F2 += (P->f2 - F2) * gl; F3 += (P->f3 - F3) * gl;
        reso_set(&r1, F1, 90); reso_set(&r2, F2, 120); reso_set(&r3, F3, 170);
        float target = P->amp;
        if (P->kind == 'p') target = u < 0.7f ? 0 : P->amp;      /* hold the breath, then let it go */
        amp += (target - amp) * (1 - expf(-1.0f / (0.01f * R)));
        float pit = pitch * (1.08f - 0.16f * (t / total));        /* the pitch falls across the word */
        phase += pit / R;
        if (phase >= 1) phase -= 1;
        float src = 0;
        /* buzz: a band-limited saw */
        for (int h = 1; h <= 28; h++) { if (pit * h > 7000) break; src += sinf(2 * PI * h * phase) / h; }
        float noise = rnd();
        float v = 0;
        if (P->kind == 'v') v = reso_run(&r1, src) + 0.7f * reso_run(&r2, src) + 0.35f * reso_run(&r3, src);
        else if (P->kind == 'h') v = (reso_run(&r1, noise) + 0.8f * reso_run(&r2, noise) + 0.5f * reso_run(&r3, noise)) * 0.6f;
        else if (P->kind == 's') { reso_set(&rs, P->f1, 2500); v = reso_run(&rs, noise) * 0.8f; }
        else if (P->kind == 'p') { reso_set(&rs, P->f1, 3000); v = u > 0.7f ? reso_run(&rs, noise) * expf(-(u - 0.7f) * 25) * 1.5f : 0; }
        f[i] = v * amp;
    }
    /* weight: an octave below, a little grit, and a big empty hall */
    float lp = 0;
    for (int i = 0; i < n; i++) { lp += 0.08f * (f[i] - lp); float v = f[i] + lp * 0.6f; v *= 2.2f; f[i] = v / (1 + fabsf(v)); }
    lowpass(f, n, 5200);
    reverb(f, n, 0.45f, 1.35f);
    finish(s, f, n, vol);
}
static void make_words(void) {
    static const Phone wa[] = {
        {'s', 0.13f, 5200, 0, 0, 0.55f},
        {'v', 0.15f, 320, 870, 2250, 1.0f},
        {'p', 0.07f, 1500, 0, 0, 0.6f},
        {'v', 0.26f, 470, 1300, 1650, 1.0f},
    };
    static const Phone wb[] = {
        {'h', 0.09f, 720, 1100, 2450, 0.7f},
        {'v', 0.27f, 740, 1120, 2500, 1.0f},
        {'p', 0.08f, 4200, 0, 0, 0.7f},
    };
    speak(&sfx[SFX_WORD_A], wa, 4, 82, 0.95f);
    speak(&sfx[SFX_WORD_B], wb, 3, 78, 0.95f);
}


/* ---------- loops ---------- */


void audio_init(void) {
    /* the ready-made sounds, each with a few versions so repeats never sound the same */
    for (int id = 0; id < SFX_COUNT; id++) {
        SndClip c[SND_MAX_VARIANTS];
        int n = snd_variants(id, c);
        for (int k = 0; k < n; k++) { sfxVar[id][k].data = c[k].data; sfxVar[id][k].len = c[k].len; }
        sfxNVar[id] = n;
        if (n) sfx[id] = sfxVar[id][0];
    }
    /* the two shouted words are spoken by the little formant voice */
    make_words();
    for (int i = 0; i < LOOP_COUNT; i++) {
        SndClip c;
        if (snd_loop(i, &c)) { loops[i].data = c.data; loops[i].len = c.len; }
    }
    memset(voices, 0, sizeof(voices));
    memset(loopState, 0, sizeof(loopState));
}

void audio_play_rate(int id, float gain, float pan, float rate) {
    if (id < 0 || id >= SFX_COUNT || gain <= 0.001f || !sfx[id].data) return;
    if (gain > 1) gain = 1;
    if (pan < -1) pan = -1;
    if (pan > 1) pan = 1;
    if (rate < 0.2f) rate = 0.2f;
    int slot = 0;
    float best = -1;
    for (int i = 0; i < MAX_VOICES; i++) {
        if (!voices[i].s) { slot = i; break; }
        if (voices[i].pos > best) { best = voices[i].pos; slot = i; }
    }
    Voice *v = &voices[slot];
    v->s = &sfx[id];
    if (sfxNVar[id] > 1) {
        /* a different version from last time */
        int k = (int)((rnd() * 0.5f + 0.5f) * sfxNVar[id]);
        if (k >= sfxNVar[id]) k = sfxNVar[id] - 1;
        if (k == sfxLastVar[id]) k = (k + 1) % sfxNVar[id];
        sfxLastVar[id] = k;
        v->s = &sfxVar[id][k];
    }
    v->pos = 0;
    v->rate = rate;
    v->gl = gain * sqrtf((1 - pan) * 0.5f);
    v->gr = gain * sqrtf((1 + pan) * 0.5f);
    /* menu clicks and the shouted words keep their pitch; everything in the world bends with time */
    v->world = !(id == SFX_KEY || id == SFX_BEEP || id == SFX_FLASH || id == SFX_WORD_A || id == SFX_WORD_B ||
                 id == SFX_WIPE || id == SFX_DIVE || id == SFX_DEATH);
}

void audio_set_time(float ts) {
    if (ts < 0) ts = 0;
    if (ts > 1) ts = 1;
    timeTarget = 0.55f + 0.45f * ts;
}
void audio_play(int id, float gain, float pan) { audio_play_rate(id, gain, pan, 1); }

void audio_loop(int id, float gain, float pan) {
    if (id < 0 || id >= LOOP_COUNT) return;
    loopState[id].gain = gain < 0 ? 0 : (gain > 1 ? 1 : gain);
    loopState[id].pan = pan < -1 ? -1 : (pan > 1 ? 1 : pan);
}

void audio_mix(short *out, int frames) {
    static float acc[2 * 4096];
    if (frames > 4096) frames = 4096;
    memset(acc, 0, frames * 2 * sizeof(float));
    timeRate += (timeTarget - timeRate) * 0.25f;
    for (int i = 0; i < MAX_VOICES; i++) {
        Voice *v = &voices[i];
        if (!v->s) continue;
        const Sample *s = v->s;
        float rate = v->rate * (v->world ? timeRate : 1);
        for (int k = 0; k < frames; k++) {
            int p = (int)v->pos;
            if (p >= s->len - 1) { v->s = 0; break; }
            float fr = v->pos - p;
            float smp = (s->data[p] + (s->data[p + 1] - s->data[p]) * fr) * (1.0f / 32768.0f);
            acc[k * 2] += smp * v->gl;
            acc[k * 2 + 1] += smp * v->gr;
            v->pos += rate;
        }
    }
    for (int i = 0; i < LOOP_COUNT; i++) {
        Loop *l = &loopState[i];
        const Sample *s = &loops[i];
        if (!s->data) continue;
        float tl = l->gain * sqrtf((1 - l->pan) * 0.5f), tr = l->gain * sqrtf((1 + l->pan) * 0.5f);
        if (tl < 0.0005f && tr < 0.0005f && l->curL < 0.0005f && l->curR < 0.0005f) {
            l->curL = l->curR = 0;
            l->pos = (l->pos + frames) % s->len;
            continue;
        }
        float dl = (tl - l->curL) / frames, dr = (tr - l->curR) / frames;
        for (int k = 0; k < frames; k++) {
            float smp = s->data[l->pos] * (1.0f / 32768.0f);
            l->curL += dl;
            l->curR += dr;
            acc[k * 2] += smp * l->curL;
            acc[k * 2 + 1] += smp * l->curR;
            if (++l->pos >= s->len) l->pos = 0;
        }
    }
    for (int k = 0; k < frames * 2; k++) {
        float v = acc[k] * 0.8f;
        v = v / (1 + fabsf(v) * 0.3f);
        out[k] = (short)((v > 1 ? 1 : (v < -1 ? -1 : v)) * 32000);
    }
}

int audio_sample_len(int id) { return id >= 0 && id < SFX_COUNT ? sfx[id].len : 0; }
/* for tools: the raw samples */
const short *audio_sample_data(int id, int *len) { if (id < 0 || id >= SFX_COUNT) { *len = 0; return 0; } *len = sfx[id].len; return sfx[id].data; }
