/* SUPERHOT - screens: the boot, the file commander, the chat, the HUD, the flash, the ending.
 * The computer screens are bent like an old CRT tube. */
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "game.h"

/* terminal colours */
#define TR 196
#define TG 236
#define TB 255
#define RED_R 230
#define RED_G 28
#define RED_B 34

static unsigned hrand(unsigned x) {
    x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15; x *= 0x846ca68bu; x ^= x >> 16;
    return x;
}
static float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }

/* ---------- text helpers ---------- */

/* text with a soft CRT glow round it */
static void glow_text(Canvas *c, int x, int y, const char *s, int big, int r, int g, int b, int a) {
    cv_text(c, x - 1, y, s, big, r, g, b, a / 5);
    cv_text(c, x + 1, y, s, big, r, g, b, a / 5);
    cv_text(c, x, y - 1, s, big, r, g, b, a / 6);
    cv_text(c, x, y + 1, s, big, r, g, b, a / 6);
    cv_text(c, x, y, s, big, r, g, b, a);
}
static void glow_text_c(Canvas *c, int cx, int y, const char *s, int big, int r, int g, int b, int a) {
    glow_text(c, cx - text_width(s, big) / 2, y, s, big, r, g, b, a);
}

/* the computer is going wrong: swap letters for junk, more as it gets worse */
static void corrupt_str(const char *in, char *out, int max, float k, unsigned seed) {
    static const char junk[] = "#%&@$*!?/\\|=+<>01_~^";
    int n = 0;
    for (; *in && n < max - 1; in++, n++) {
        unsigned h = hrand(seed * 131u + (unsigned)n * 7919u);
        if (*in != ' ' && (h & 1023) < (unsigned)(k * 1024 * 0.55f)) out[n] = junk[(h >> 10) % (sizeof(junk) - 1)];
        else out[n] = *in;
    }
    out[n] = 0;
}

/* big text drawn at 2x (or more) from the big font */
static int big_width(const char *s, int scale) { return text_width(s, 1) * scale; }
static void big_text(Canvas *c, int x, int y, const char *s, int scale, int r, int g, int b, int a) {
    for (; *s; s++) {
        int ch = (unsigned char)*s;
        if (ch < 32 || ch > 126) ch = '?';
        int i = ch - 32;
        const unsigned char *g0 = fontB_px + fontB_off[i];
        int w = fontB_w[i];
        for (int yy = 0; yy < FONT_B_H; yy++)
            for (int xx = 0; xx < w; xx++) {
                int v = g0[yy * w + xx];
                if (v) cv_fill(c, x + xx * scale, y + yy * scale, scale, scale, r, g, b, a * v / 15);
            }
        x += fontB_adv[i] * scale;
    }
}
/* centred big text with a dark outline so it reads over the white world */
static void big_text_c(Canvas *c, int cx, int y, const char *s, int scale, int r, int g, int b, int a, int outline) {
    int x = cx - big_width(s, scale) / 2;
    if (outline) {
        for (int d = 0; d < 4; d++) {
            static const int ox[4] = {-2, 2, 0, 0}, oy[4] = {0, 0, -2, 2};
            big_text(c, x + ox[d], y + oy[d], s, scale, 20, 24, 30, a * 2 / 3);
        }
    }
    big_text(c, x, y, s, scale, r, g, b, a);
}

/* faint horizontal scanlines over a terminal screen */
static void scanlines(Canvas *c, int y0, int y1) {
    for (int y = y0; y < y1; y += 2) cv_fill(c, 0, y, c->w, 1, 0, 0, 0, 70);
}

/* glitch: shift strips of the picture sideways and drop in bright blocks */
static void glitch(Canvas *c, float k, unsigned seed) {
    if (k <= 0.01f) return;
    unsigned h = hrand(seed);
    int strips = (int)(k * 9);
    for (int i = 0; i < strips; i++) {
        h = hrand(h + i);
        if ((h & 255) > 90 + (int)(k * 140)) continue;
        int y = (h >> 8) % c->h, hgt = 2 + ((h >> 16) & 7), sh = (int)(((h >> 20) & 31) - 16) * (1 + (int)(k * 3));
        if (y + hgt > c->h) hgt = c->h - y;
        for (int yy = y; yy < y + hgt; yy++) {
            unsigned short row[400];
            int w = c->w;
            memcpy(row, c->px + yy * w, w * 2);
            for (int x = 0; x < w; x++) {
                int sx = x - sh;
                if (sx < 0) sx += w;
                if (sx >= w) sx -= w;
                c->px[yy * w + x] = row[sx];
            }
        }
    }
    int blocks = (int)(k * k * 14);
    for (int i = 0; i < blocks; i++) {
        h = hrand(h ^ 0x9e37u);
        int bx = h % c->w, by = (h >> 9) % c->h, bw = 4 + ((h >> 3) & 31), bh = 2 + ((h >> 17) & 7);
        if ((h >> 25) & 1) cv_fill(c, bx, by, bw, bh, TR, TG, TB, 220);
        else cv_fill(c, bx, by, bw, bh, RED_R, RED_G, RED_B, 200);
    }
}

/* the frame round a CRT screen */
static void crt_frame(Canvas *c, int x, int y, int w, int h) {
    cv_frame(c, x, y, w, h, TR, TG, TB, 200);
    cv_frame(c, x - 1, y - 1, w + 2, h + 2, TR, TG, TB, 50);
    cv_frame(c, x + 1, y + 1, w - 2, h - 2, TR, TG, TB, 40);
}

/* a stuttering seed: changes a few times a second, faster when more broken */
static unsigned tick_seed(const Game *g, float rate) { return (unsigned)(g->time * rate) * 2654435761u; }


static int crtOn = 1, glowOn = 1;   /* from the settings folder, set before each frame */

/* ---------- the thin big font, for words over the game ---------- */
static int thin_width(const char *s) {
    int w = 0;
    for (; *s; s++) { int ch = (unsigned char)*s; if (ch < 32 || ch > 126) ch = '?'; w += fontT_adv[ch - 32]; }
    return w;
}
static void thin_text(Canvas *c, int x, int y, const char *s, int r, int g, int b, int a) {
    for (; *s; s++) {
        int ch = (unsigned char)*s;
        if (ch < 32 || ch > 126) ch = '?';
        int i = ch - 32;
        const unsigned char *g0 = fontT_px + fontT_off[i];
        int w = fontT_w[i];
        for (int yy = 0; yy < FONT_T_H; yy++)
            for (int xx = 0; xx < w; xx++) {
                int v = g0[yy * w + xx];
                if (v) cv_fill(c, x + xx, y + yy, 1, 1, r, g, b, a * v / 15);
            }
        x += fontT_adv[i];
    }
}
/* white words with a cyan glow and a soft shadow, so they read over the white rooms */
static void thin_glow_c(Canvas *c, int cx, int y, const char *s, int a) {
    int x = cx - thin_width(s) / 2;
    thin_text(c, x + 2, y + 2, s, 40, 70, 90, a * 40 / 100);
    if (glowOn)
        for (int d = 0; d < 8; d++) {
            static const int ox[8] = {-4, 4, 0, 0, -2, 2, -2, 2}, oy[8] = {0, 0, -4, 4, -2, -2, 2, 2};
            thin_text(c, x + ox[d], y + oy[d], s, 140, 230, 255, a / 6);
        }
    thin_text(c, x, y, s, 255, 255, 255, a);
}

/* ---------- the CRT: bend the picture, darken the edges, round the corners ---------- */
static int crtTop[HW * HH], crtBot[BW * BH];
static unsigned char crtTopS[HW * HH], crtBotS[BW * BH];
static int crtReady;

static void crt_build(int w, int h, int *map, unsigned char *shade) {
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            float u = (x + 0.5f) / w * 2 - 1, v = (y + 0.5f) / h * 2 - 1;
            /* zoom out a touch, then bulge */
            u *= 1.03f; v *= 1.04f;
            float cu = u * (1 + 0.075f * v * v), cv = v * (1 + 0.11f * u * u);
            int i = y * w + x;
            if (fabsf(cu) >= 1 || fabsf(cv) >= 1) { map[i] = -1; shade[i] = 0; continue; }
            int sx = (int)((cu + 1) * 0.5f * w), sy = (int)((cv + 1) * 0.5f * h);
            if (sx >= w) sx = w - 1;
            if (sy >= h) sy = h - 1;
            map[i] = sy * w + sx;
            float vig = powf((1 - cu * cu) * (1 - cv * cv), 0.22f);
            float edge = fminf(1 - fabsf(cu), 1 - fabsf(cv)) / 0.018f;
            float k = clampf(vig * 1.08f, 0, 1) * clampf(edge, 0, 1);
            shade[i] = (unsigned char)(k * 16 + 0.5f);
        }
}

static void crt_apply(Canvas *c) {
    static unsigned short tmp[HW * HH];
    if (!crtOn) return;
    if (!crtReady) { crt_build(HW, HH, crtTop, crtTopS); crt_build(BW, BH, crtBot, crtBotS); crtReady = 1; }
    int n = c->w * c->h;
    const int *map = c->w == HW ? crtTop : crtBot;
    const unsigned char *sh = c->w == HW ? crtTopS : crtBotS;
    memcpy(tmp, c->px, n * 2);
    for (int i = 0; i < n; i++) {
        int m = map[i];
        if (m < 0) { c->px[i] = c->fmt ? 0x000F : 0; continue; }
        unsigned p = tmp[m];
        int k = sh[i];
        if (k < 16) {
            if (c->fmt) p = ((((p >> 12) * k) >> 4) << 12) | (((((p >> 8) & 15) * k) >> 4) << 8) | (((((p >> 4) & 15) * k) >> 4) << 4) | 15;
            else p = ((((p >> 11) * k) >> 4) << 11) | (((((p >> 5) & 63) * k) >> 4) << 5) | (((p & 31) * k) >> 4);
        }
        c->px[i] = (unsigned short)p;
    }
}

/* a faint light-blue haze at the edges of the view while playing */
/* the glow: a bright cyan-white haze that blooms in from the edges, like light flooding the lens */
static unsigned short vigTop[HW * HH];
static int vigReady;
static void vignette(Canvas *c) {
    if (!glowOn) return;
    if (!vigReady) {
        for (int y = 0; y < HH; y++)
            for (int x = 0; x < HW; x++) {
                float u = (x + 0.5f) / HW * 2 - 1, v = (y + 0.5f) / HH * 2 - 1;
                float r = sqrtf(u * u * 0.75f + v * v * 1.1f);
                float k = clampf((r - 0.45f) / 0.75f, 0, 1);
                /* strongest at the top, where the light comes from; the gun at the bottom stays dark */
                float top = clampf(0.55f - 0.45f * v, 0.15f, 1);
                int a = (int)(1 + k * k * 8 * top);
                vigTop[y * HW + x] = col4444(228, 248, 255, a * 17);
            }
        vigReady = 1;
    }
    memcpy(c->px, vigTop, sizeof vigTop);
}

/* ================= boot ================= */

static void boot_screen(Canvas *c, const Game *g) {
    cv_fill(c, 0, 0, c->w, c->h, 0, 0, 0, 255);
    float k = corruption(g), t = g->modeT;
    char b[96];
    unsigned sd = tick_seed(g, 8);
    static const char *lines[] = {"Initializing Shatter-OS v1.0", "Disk check: okay.", "Memory: 128K okay.", "Network: connected."};
    int shown = (int)(t * 6);
    for (int i = 0; i < 4 && i * 4 < shown; i++) {
        const char *s = lines[i];
        if (i == 1 && k > 0.3f) s = k > 0.7f ? "Disk check: 4096 errors. ignoring." : "Disk check: 3 errors.";
        corrupt_str(s, b, sizeof b, k * 0.6f, sd + i);
        cv_text(c, 34, 14 + i * 14, b, 0, TR, TG, TB, 180);
    }
    if (t > 1.2f) {
        /* the logo, flickering on like an old tube */
        float on = clampf((t - 1.2f) * 2, 0, 1);
        if (t < 1.8f && ((int)(t * 30) & 1)) on *= 0.4f;
        const char *logo = k > 0.7f ? WORD_A WORD_B : "Shatter-OS";
        int x = (c->w - thin_width(logo)) / 2, y = 78;
        for (int d = 3; d >= 1; d--) {
            thin_text(c, x - d, y, logo, 90, 190, 255, (int)(40 * on));
            thin_text(c, x + d, y, logo, 90, 190, 255, (int)(40 * on));
            thin_text(c, x, y - d, logo, 90, 190, 255, (int)(40 * on));
            thin_text(c, x, y + d, logo, 90, 190, 255, (int)(40 * on));
        }
        thin_text(c, x, y, logo, TR, TG, TB, (int)(255 * on));
        const char *tag = k > 0.7f ? WORD_A " " WORD_B " " WORD_A " " WORD_B : "\"the operating system you can trust (TM)\"";
        corrupt_str(tag, b, sizeof b, k * 0.4f, sd + 9);
        glow_text_c(c, c->w / 2, 146, b, 0, TR, TG, TB, (int)(220 * on));
    }
    if (t > 2.6f) {
        int dots = (int)(t * 3) % 4;
        snprintf(b, sizeof b, "launching file commander%.*s", dots, "...");
        glow_text_c(c, c->w / 2, 196, b, 0, TR, TG, TB, 220);
    }
    scanlines(c, 0, c->h);
    glitch(c, k * 0.8f, sd);
}

/* ================= file commander ================= */

#define MENU_VIS 10
static int list_top(const Game *g, int vis) {
    int rows = menu_rows(g);
    int top = g->menuSel - vis / 2;
    if (top > rows - vis) top = rows - vis;
    if (top < 0) top = 0;
    return top;
}

static const char *dir_path(const Game *g) {
    return g->menuDir == DIR_LEVELS ? "C:\\LEVELS.ULT\\" : (g->menuDir == DIR_REPLAYS ? "C:\\REPLAYS\\" : (g->menuDir == DIR_SETTINGS ? "C:\\SETTINGS\\" : "C:\\"));
}

static void row_text(const Game *g, int r, char *name, char *kind, int max) {
    int arg, k = menu_row(g, r, &arg);
    switch (k) {
    case ROW_UP: snprintf(name, max, "/.."); snprintf(kind, max, "<UP-FOL>"); break;
    case ROW_EXE: snprintf(name, max, "%s", EXE_NAME); snprintf(kind, max, "-STORY->"); break;
    case ROW_LEVELS: snprintf(name, max, "levels.ult"); snprintf(kind, max, "-FILE->   %d/%d beaten", levels_done(g), levelCount); break;
    case ROW_REPLAYS: snprintf(name, max, "replays"); snprintf(kind, max, ">FOLDER<"); break;
    case ROW_CHAT: snprintf(name, max, "chat.exe"); snprintf(kind, max, "-CHAT->"); break;
    case ROW_SETTINGS: snprintf(name, max, "settings"); snprintf(kind, max, ">FOLDER<"); break;
    case ROW_SET: snprintf(name, max, "%s", setting_text(g, arg, 0)); snprintf(kind, max, "-SET->    %s", setting_text(g, arg, 1)); break;
    case ROW_LEVEL:
        snprintf(name, max, "%s", levels[arg].file);
        if (g->best[arg] > 0) snprintf(kind, max, "-LEVEL->  %5.1fs", g->best[arg]);
        else snprintf(kind, max, "-LEVEL->");
        break;
    default:
        snprintf(name, max, "replay%02d.rpl", arg + 1);
        snprintf(kind, max, "-%s-> %.1fs", levels[g->replays[arg].level].title, g->replays[arg].secs);
        break;
    }
}

static void menu_screen(Canvas *c, const Game *g) {
    cv_fill(c, 0, 0, c->w, c->h, 0, 0, 0, 255);
    float k = corruption(g);
    unsigned sd = tick_seed(g, 4 + 10 * k);
    char b[96], name[48], kind[48], cb[48];
    crt_frame(c, 10, 10, c->w - 20, c->h - 20);
    /* title bar and clock */
    corrupt_str("FILE COMMANDER", b, sizeof b, k * 0.5f, sd);
    glow_text(c, 20, 13, b, 0, TR, TG, TB, 230);
    int secs = (int)g->time;
    if (k > 0.5f) secs = 5999 - secs; /* the clock runs backwards */
    if (secs < 0) secs = 0;
    snprintf(b, sizeof b, "%02d:%02d", (secs / 60) % 100, secs % 60);
    glow_text(c, c->w - 20 - text_width(b, 0), 13, b, 0, TR, TG, TB, 230);
    cv_fill(c, 11, 30, c->w - 22, 1, TR, TG, TB, 120);
    int top = list_top(g, MENU_VIS), rows = menu_rows(g);
    for (int i = 0; i < MENU_VIS && top + i < rows; i++) {
        int r = top + i, y = 34 + i * 16;
        row_text(g, r, name, kind, sizeof name);
        int sel = r == g->menuSel;
        if (sel) cv_fill(c, 14, y, c->w - 28, 15, RED_R, RED_G, RED_B, 200 + (int)(40 * sinf(g->time * 6)));
        corrupt_str(name, cb, sizeof cb, k * 0.25f, sd + r);
        if (sel) { cv_text(c, 22, y, cb, 0, 255, 255, 255, 255); cv_text(c, 196, y, kind, 0, 255, 255, 255, 255); }
        else { glow_text(c, 22, y, cb, 0, TR, TG, TB, 235); glow_text(c, 196, y, kind, 0, TR, TG, TB, 200); }
    }
    if (rows == 1) glow_text(c, 22, 34 + 16, g->menuDir == DIR_REPLAYS ? "(empty - press X after a win to keep one)" : "(empty)", 0, TR, TG, TB, 140);
    if (top + MENU_VIS < rows) glow_text(c, 22, 34 + MENU_VIS * 16, "-MORE-MORE-MORE-", 0, TR, TG, TB, 150);
    cv_fill(c, 11, c->h - 32, c->w - 22, 1, TR, TG, TB, 120);
    corrupt_str(dir_path(g), b, sizeof b, k * 0.5f, sd + 3);
    glow_text(c, 20, c->h - 29, b, 0, TR, TG, TB, 220);
    const char *os = k > 0.85f ? WORD_A "-" WORD_B : "Shatter-OS v1.0";
    glow_text(c, c->w - 20 - text_width(os, 0), c->h - 29, os, 0, TR, TG, TB, 220);
    scanlines(c, 0, c->h);
    glitch(c, k, sd);
    crt_apply(c);
}

/* bottom screen: a touchable copy of the list and the info pane */
static int bottomTop;
int ui_menu_row(int ty) {
    if (ty < 24) return -1;
    int i = (ty - 24) / 19;
    if (i >= 10) return -1;
    return bottomTop + i;
}

static void info_lines(Canvas *c, int x, int y, const char *d, float k, unsigned sd) {
    char line[48], b[96];
    while (*d) {
        const char *e = strchr(d, '|');
        int n = e ? (int)(e - d) : (int)strlen(d);
        if (n > 40) n = 40;
        memcpy(line, d, n); line[n] = 0;
        corrupt_str(line, b, sizeof b, k * 0.3f, sd + (unsigned)y);
        cv_text(c, x, y, b, 0, TR, TG, TB, 220);
        y += 15;
        d += n;
        if (*d == '|') d++;
    }
}

static void menu_bottom(Canvas *c, const Game *g) {
    cv_fill(c, 0, 0, c->w, c->h, 0, 0, 0, 255);
    float k = corruption(g);
    unsigned sd = tick_seed(g, 3 + 8 * k);
    char b[96], name[48], kind[48];
    crt_frame(c, 8, 8, c->w - 16, c->h - 16);
    glow_text(c, 16, 8, "FILES", 0, TR, TG, TB, 220);
    glow_text(c, 178, 8, "INFO", 0, TR, TG, TB, 220);
    cv_fill(c, 170, 10, 1, c->h - 20, TR, TG, TB, 100);
    int rows = menu_rows(g);
    int top = list_top(g, 10);
    bottomTop = top;
    for (int i = 0; i < 10 && top + i < rows; i++) {
        int r = top + i, y = 24 + i * 19;
        row_text(g, r, name, kind, sizeof name);
        if (r == g->menuSel) cv_fill(c, 12, y, 156, 18, RED_R, RED_G, RED_B, 220);
        cv_text(c, 16, y + 2, name, 0, TR, TG, TB, 240);
    }
    int x = 178, y = 28;
    int arg, kd = menu_row(g, g->menuSel, &arg);
    switch (kd) {
    case ROW_UP: cv_wrap(c, x, y, 128, g->menuDir == DIR_ROOT ? "restart the computer." : "go back up to C:\\", 0, TR, TG, TB, 220); break;
    case ROW_EXE: {
        glow_text(c, x, y, WORD_A WORD_B, 1, TR, TG, TB, 240);
        int nx = 0;
        while (nx < levelCount && ((g->completed >> nx) & 1)) nx++;
        if (nx >= levelCount) snprintf(b, sizeof b, "every level beaten. play it all again.");
        else snprintf(b, sizeof b, "story mode. next: %s", levels[nx].title);
        cv_wrap(c, x, y + 36, 128, b, 0, TR, TG, TB, 220);
        break;
    }
    case ROW_LEVELS:
        snprintf(b, sizeof b, "every level you have beaten, %d so far. play any of them again.", levels_done(g));
        cv_wrap(c, x, y, 128, b, 0, TR, TG, TB, 220);
        break;
    case ROW_REPLAYS: cv_wrap(c, x, y, 128, "your saved replays. press X on the win screen to keep one.", 0, TR, TG, TB, 220); break;
    case ROW_CHAT: cv_wrap(c, x, y, 128, "open the chat with your friend.", 0, TR, TG, TB, 220); break;
    case ROW_SETTINGS: cv_wrap(c, x, y, 128, "graphics, smooth edges, shattering, glow, the curved screen and look speed.", 0, TR, TG, TB, 220); break;
    case ROW_SET: {
        static const char *help[SET_COUNT] = {
            "HIGH: full detail men, ceilings, lamps, pipes. LOW: lighter models and plain rooms, for speed.",
            "smooth edges: draws at 4x the pixels and shrinks it. Off when the 3D slider is up.",
            "REAL: solid glass chunks that stay on the floor. SIMPLE: fewer pieces that fade. OFF: just a flash of glitter.",
            "the bright haze round the edges and the glow on big words.",
            "bend the computer screens like an old tube.",
            "how fast the view turns.",
        };
        glow_text(c, x, y, setting_text(g, arg, 1), 1, TR, TG, TB, 240);
        cv_wrap(c, x, y + 36, 128, help[arg], 0, TR, TG, TB, 220);
        cv_wrap(c, x, y + 120, 128, "A or left/right to change", 0, TR, TG, TB, 150);
        break;
    }
    case ROW_LEVEL:
        glow_text(c, x, y, levels[arg].title, 1, TR, TG, TB, 240);
        info_lines(c, x, y + 36, levels[arg].desc, k, sd);
        if (g->best[arg] > 0) { snprintf(b, sizeof b, "best: %.1fs", g->best[arg]); cv_text(c, x, y + 100, b, 0, TR, TG, TB, 200); }
        break;
    default: {
        const ReplayInfo *r = &g->replays[arg];
        glow_text(c, x, y, "REPLAY", 1, TR, TG, TB, 240);
        snprintf(b, sizeof b, "%s  %.1fs", levels[r->level].file, r->secs);
        cv_wrap(c, x, y + 36, 128, b, 0, TR, TG, TB, 220);
        cv_wrap(c, x, y + 70, 128, "B or START stops it.", 0, TR, TG, TB, 160);
        break;
    }
    }
    cv_text(c, 178, c->h - 40, "A: open  B: back", 0, TR, TG, TB, 170);
    cv_text(c, 178, c->h - 26, "tap twice: open", 0, TR, TG, TB, 170);
    scanlines(c, 0, c->h);
    glitch(c, k * 0.7f, sd);
    crt_apply(c);
}

/* ================= the chat ================= */

typedef struct { int who, lines; char text[4][48]; } Bubble;

/* wrap a message into at most 4 lines of about 26 characters */
static int wrap_msg(const char *s, char out[4][48], int width) {
    int n = 0;
    while (*s && n < 4) {
        int len = (int)strlen(s), cut = len;
        if (text_width(s, 0) > width) {
            /* longest prefix that fits, broken at a space if we can */
            cut = 0;
            char tmp[96];
            for (int i = 1; i <= len && i < 95; i++) {
                memcpy(tmp, s, i); tmp[i] = 0;
                if (text_width(tmp, 0) > width) break;
                cut = i;
            }
            int sp = cut;
            while (sp > 0 && s[sp] != ' ') sp--;
            if (sp > cut / 2) cut = sp;
            if (cut < 1) cut = 1;
        }
        if (cut > 47) cut = 47;
        memcpy(out[n], s, cut); out[n][cut] = 0;
        n++;
        s += cut;
        while (*s == ' ') s++;
    }
    return n ? n : 1;
}

static void chat_screen(Canvas *c, const Game *g) {
    cv_fill(c, 0, 0, c->w, c->h, 0, 0, 0, 255);
    float k = corruption(g);
    unsigned sd = tick_seed(g, 5 + 10 * k);
    const ChatScript *S = &chats[g->chatId];
    char b[128];
    crt_frame(c, 10, 10, c->w - 20, c->h - 20);
    corrupt_str("buddyCHAT", b, sizeof b, k * 0.5f, sd);
    glow_text(c, 18, 2, b, 0, TR, TG, TB, 240);
    /* gather the messages shown so far, newest last */
    Bubble bub[16];
    int nb = 0;
    int last = g->chatLine < S->n ? g->chatLine : S->n - 1;
    for (int i = 0; i <= last && nb < 16; i++) {
        const ChatLine *L = &S->line[i];
        int typing = i == g->chatLine;
        if (typing && (L->who == CH_FRIEND || L->who == CH_SYSTEM)) break; /* not arrived yet */
        chat_typed_text(g, i, typing ? g->chatChars : 999, b, sizeof b);
        if (typing && !b[0]) break;
        Bubble *u = &bub[nb++];
        u->who = L->who;
        u->lines = wrap_msg(b, u->text, L->who == CH_SYSTEM ? 330 : 220);
    }
    /* lay them out from the bottom up */
    int y = c->h - 46;
    int pending = g->chatLine < S->n;
    const ChatLine *cur = pending ? &S->line[g->chatLine] : NULL;
    int needType = cur && (cur->who == CH_YOU || cur->who == CH_SPAM) && g->chatChars == 0;
    int needWait = cur && (cur->who == CH_FRIEND || cur->who == CH_SYSTEM);
    if (needType || needWait) y -= 24;
    for (int i = nb - 1; i >= 0 && y > 22; i--) {
        Bubble *u = &bub[i];
        int h = u->lines * 14 + 8;
        int w = 0;
        for (int l = 0; l < u->lines; l++) { int tw = text_width(u->text[l], 0); if (tw > w) w = tw; }
        w += 14;
        y -= h;
        if (y < 22) break;
        int x;
        if (u->who == CH_FRIEND) x = c->w - 22 - w;       /* friend on the right */
        else if (u->who == CH_SYSTEM) x = (c->w - w) / 2;
        else x = 22;                                      /* you on the left */
        int spam = u->who == CH_SPAM;
        int col[3] = {TR, TG, TB};
        if (spam && i == nb - 1 && ((int)(g->time * 12) & 1)) { col[0] = RED_R; col[1] = 80; col[2] = 80; }
        if (u->who != CH_SYSTEM) cv_frame(c, x, y, w, h, col[0], col[1], col[2], 220);
        for (int l = 0; l < u->lines; l++) {
            char cb[64];
            corrupt_str(u->text[l], cb, sizeof cb, k * (spam ? 0.1f : 0.2f), sd + (unsigned)(i * 9 + l));
            glow_text(c, x + 7, y + 4 + l * 14, cb, 0, col[0], col[1], col[2], u->who == CH_SYSTEM ? 170 : 240);
        }
        y -= 8;
    }
    /* the TYPE box (your turn) or the WAIT box (theirs) */
    if (needType) {
        int blink = ((int)(g->time * 3)) & 1;
        cv_frame(c, 22, c->h - 64, 26, 18, TR, TG, TB, 220);
        if (blink) cv_fill(c, 27, c->h - 59, 8, 9, TR, TG, TB, 220);
        cv_text(c, 54, c->h - 63, "TYPE", 0, TR, TG, TB, 180);
    } else if (needWait) {
        cv_frame(c, c->w - 48, c->h - 64, 26, 18, TR, TG, TB, 220);
        cv_text(c, c->w - 90, c->h - 63, "WAIT", 0, TR, TG, TB, (int)(140 + 100 * sinf(g->time * 6)));
    }
    if (!pending) glow_text_c(c, c->w / 2, c->h - 44, "-- end of chat --", 0, TR, TG, TB, 180);
    glow_text(c, c->w - 26 - text_width("press-START-to-leave-chat", 0), c->h - 27, "press-START-to-leave-chat", 0, TR, TG, TB, 200);
    scanlines(c, 0, c->h);
    glitch(c, k, sd);
}

static void chat_bottom(Canvas *c, const Game *g) {
    cv_fill(c, 0, 0, c->w, c->h, 0, 0, 0, 255);
    float k = corruption(g);
    crt_frame(c, 3, 3, c->w - 6, c->h - 6);
    glow_text_c(c, c->w / 2, 40, "KEYBOARD", 1, TR, TG, TB, 230);
    cv_wrap(c, 40, 90, 240, "press any button to type. when your message is finished, press again to send it.", 0, TR, TG, TB, 200);
    /* a little keyboard picture */
    for (int r = 0; r < 3; r++)
        for (int i = 0; i < 10 - r; i++) {
            int x = 40 + r * 10 + i * 24, y = 150 + r * 22;
            int lit = (hrand((unsigned)(i + r * 10) + (unsigned)(g->time * (k > 0.6f ? 20 : 2))) & 7) == 0;
            cv_frame(c, x, y, 20, 18, TR, TG, TB, lit ? 255 : 120);
        }
    scanlines(c, 0, c->h);
    glitch(c, k * 0.8f, tick_seed(g, 6));
}

/* ================= in the level ================= */

static int enemies_alive(const Game *g) {
    int n = 0;
    for (int i = 0; i < g->nen; i++) n += g->en[i].alive;
    return n;
}

static void play_hud(Canvas *c, const Game *g) {
    float k = corruption(g);
    vignette(c);
    /* crosshair */
    int cx = HW / 2, cy = HH / 2;
    cv_circle(c, cx, cy, 4, 30, 40, 50, 140);
    cv_circle(c, cx, cy, 2, 255, 255, 255, 230);
    if (g->pl.hasGun && WP_IS_GUN(g->pl.weapon)) {
        /* one pip per round; a submachine gun's run in two rows */
        int max = weapon_ammo(g->pl.weapon);
        for (int i = 0; i < max; i++) {
            int on = i < g->pl.ammo;
            int px = cx + 10 + (i % 6) * 6, py = cy + 8 + (i / 6) * 6;
            cv_fill(c, px, py, 4, 4, on ? 20 : 150, on ? 20 : 150, on ? 24 : 150, on ? 220 : 120);
        }
    }
    /* out of ammo: the words flash up big and blink, with a quick white pulse when it happens */
    if (g->noAmmoT > 0 && g->mode == MODE_PLAY) {
        float t = 1.4f - g->noAmmoT;
        if (t < 0.12f) cv_fill(c, 0, 0, HW, HH, 255, 255, 255, (int)(110 * (1 - t / 0.12f)));
        if (((int)(t * 7)) % 2 == 0) {
            int a = (int)(250 * clampf(g->noAmmoT * 3, 0, 1));
            thin_glow_c(c, HW / 2, HH / 2 + 30, "NO AMMO", a);
        }
    }
    /* how fast time is going right now */
    int w = (int)(g->ts * 120);
    cv_fill(c, HW / 2 - 60, 6, 120, 2, 40, 50, 60, 70);
    cv_fill(c, HW / 2 - w / 2, 6, w, 2, RED_R, RED_G, RED_B, 220);
    /* the big words */
    if (g->msgT > 0 && g->msg[0]) {
        float a = clampf(g->msgT > 90 ? 1 : g->msgT * 3, 0, 1);
        const char *m = g->msg;
        if (thin_width(m) < HW - 16) thin_glow_c(c, HW / 2, 26, m, (int)(250 * a));
        else {
            /* long lines: two lines, or three if they still don't fit */
            char l[3][64];
            int nl = 0, len = (int)strlen(m), start = 0;
            while (start < len && nl < 3) {
                int end = len;
                while (end > start) {
                    char t[64];
                    int n = end - start < 63 ? end - start : 63;
                    memcpy(t, m + start, n); t[n] = 0;
                    if (thin_width(t) < HW - 16) break;
                    end--;
                    while (end > start && m[end] != ' ') end--;
                }
                if (end <= start) end = len;
                int n = end - start < 63 ? end - start : 63;
                memcpy(l[nl], m + start, n); l[nl][n] = 0;
                nl++;
                start = end;
                while (m[start] == ' ') start++;
            }
            for (int i = 0; i < nl; i++) thin_glow_c(c, HW / 2, 10 + i * 46, l[i], (int)(250 * a));
        }
    }
    if (g->replaying) {
        if (((int)(g->time * 2)) & 1) cv_circle(c, 18, 20, 5, RED_R, RED_G, RED_B, 255);
        cv_text_sh(c, 28, 13, "REPLAY", 0, 255, 255, 255);
    }
    /* once the machine is hacked, the game talks to you mid-fight */
    if (k > 0.6f) {
        unsigned h = hrand((unsigned)(g->time * 6));
        if ((h & 15) < (unsigned)(k * 3)) {
            const char *w2 = (h >> 5) & 1 ? WORD_A : WORD_B;
            thin_text(c, HW / 2 - thin_width(w2) / 2 + (int)((h >> 8) % 60) - 30, 60 + (int)((h >> 14) % 80), w2, 255, 255, 255, 150);
        }
        glitch(c, (k - 0.6f) * 0.8f, tick_seed(g, 10));
    }
}

static void dead_hud(Canvas *c, const Game *g) {
    /* a hard white flash on the hit, then the frozen black-and-white frame washes out,
     * with the signal tearing for a moment; no big words, just how to go again */
    float t = g->modeT;
    float flash = clampf(1 - t * 5, 0, 1);
    float wash = clampf((t - 0.15f) * 0.6f, 0, 0.45f);
    int a = (int)(255 * (flash > wash ? flash : wash));
    if (a > 0) cv_fill(c, 0, 0, HW, HH, 255, 255, 255, a);
    if (t < 0.5f) glitch(c, (0.5f - t) * 1.6f, tick_seed(g, 21));
    if (!g->replaying && t > 0.6f) {
        float k = clampf((t - 0.6f) * 4, 0, 1);
        cv_text_c(c, HW / 2, HH - 26, "A  restart", 0, 40, 40, 40, (int)(230 * k));
    }
}

/* the level-clear flash: the two words, black and white, until you press A */
static void win_flash(Canvas *c, const Game *g) {
    int ph = (int)(g->modeT / 0.42f) & 1;
    const unsigned char *m = ph ? flashWord1 : flashWord0;
    int bgc = ph ? 255 : 0, fgc = ph ? 0 : 255;
    unsigned short bg = col4444(bgc, bgc, bgc, 255);
    for (int i = 0; i < HW * HH; i++) c->px[i] = bg;
    for (int y = 0; y < HH; y++) {
        const unsigned char *row = m + y * (HW / 2);
        unsigned short *o = c->px + y * HW;
        for (int x = 0; x < HW; x += 2) {
            int v0 = row[x >> 1] >> 4, v1 = row[x >> 1] & 15;
            if (v0) { int v = bgc + (fgc - bgc) * v0 / 15; o[x] = col4444(v, v, v, 255); }
            if (v1) { int v = bgc + (fgc - bgc) * v1 / 15; o[x + 1] = col4444(v, v, v, 255); }
        }
    }
    if (g->modeT > 0.6f) {
        const char *t = g->replaying ? "press A" : (g->replaySaved ? "press A to continue" : "A: continue     X: save replay");
        cv_text_c(c, HW / 2, HH - 20, t, 0, 128, 128, 128, 255);
    }
    if (g->replayMsgT > 0) cv_text_c(c, HW / 2, 8, g->replayMsg, 0, 128, 128, 128, 255);
}

static void pause_hud(Canvas *c, const Game *g) {
    cv_fill(c, 0, 0, HW, HH, 0, 0, 0, 170);
    thin_glow_c(c, HW / 2, 26, "PAUSED", 250);
    static const char *opt[3] = {"RESUME", "RESTART LEVEL", "FILE COMMANDER"};
    for (int i = 0; i < 3; i++) {
        int y = 104 + i * 30;
        if (i == g->pauseSel) cv_fill(c, HW / 2 - 90, y - 2, 180, 20, RED_R, RED_G, RED_B, 230);
        glow_text_c(c, HW / 2, y, opt[i], 0, 255, 255, 255, 240);
    }
}

/* the ending: the game owns the machine now */
static void hack_screen(Canvas *c, const Game *g) {
    float t = g->modeT;
    int inv = t < 8 && ((int)(t / 0.3f) & 1);
    int bgc = inv ? 230 : 0, fgc = inv ? 0 : 230;
    cv_fill(c, 0, 0, c->w, c->h, bgc, bgc, bgc, 255);
    static const char spam[] = WORD_A " " WORD_B " " WORD_A " " WORD_B " " WORD_A " " WORD_B " " WORD_A " " WORD_B " ";
    int rows = t < 8 ? (int)(t * 4) + 1 : 16;
    for (int r = 0; r < rows && r < 16; r++) {
        unsigned h = hrand((unsigned)r * 977u + (unsigned)(t * 4));
        int off = (int)(h % 120);
        cv_text(c, -off, 2 + r * 15, spam, 0, fgc, fgc, fgc, 220);
    }
    if (t > 8) {
        float a = clampf((t - 8) * 1.5f, 0, 1);
        cv_fill(c, 0, 70, c->w, 100, 0, 0, 0, (int)(230 * a));
        big_text_c(c, c->w / 2, 74, WORD_A " " WORD_B, 1, 255, 255, 255, (int)(255 * a), 0);
        cv_text_c(c, c->w / 2, 112, "this machine belongs to the game now.", 0, TR, TG, TB, (int)(230 * a));
        if (t > 10) cv_text_c(c, c->w / 2, 140, "thank you for playing. press A.", 0, TR, TG, TB, 230);
    }
    glitch(c, t < 8 ? 0.9f : 0.3f, tick_seed(g, 14));
}

/* opening a level: blue pixels fly in and lock into a tall rectangle with a black hole in it,
 * then the view dives into the hole five times, each dive faster, and the last hole is the level */
#define WIPE_BUILD 0.45f
static const float wipeDive[5] = {0.42f, 0.32f, 0.24f, 0.17f, 0.12f};
float wipe_length(void) { float t = WIPE_BUILD; for (int i = 0; i < 5; i++) t += wipeDive[i]; return t; }

/* one rectangle of blue pixels, centred on the screen, half-size hw x hh (pixels) */
static void wipe_rect(Canvas *c, float hw, float hh, float build, unsigned seed, int holeClear) {
    const int NX = 12, NY = 20;                       /* pixels across and down */
    const float HOLE = 0.5f;                          /* the hole is half the rectangle each way */
    float cw = hw * 2 / NX, ch = hh * 2 / NY;
    float x0 = HW * 0.5f - hw, y0 = HH * 0.5f - hh;
    float hx0 = HW * 0.5f - hw * HOLE, hx1 = HW * 0.5f + hw * HOLE, hy0 = HH * 0.5f - hh * HOLE, hy1 = HH * 0.5f + hh * HOLE;
    /* the hole: black, or open onto the level for the last one */
    {
        int ax = (int)hx0, bx = (int)(hx1 + 0.999f), ay = (int)hy0, by = (int)(hy1 + 0.999f);
        if (ax < 0) ax = 0; if (ay < 0) ay = 0; if (bx > HW) bx = HW; if (by > HH) by = HH;
        unsigned short hv = holeClear ? 0 : col4444(0, 0, 0, 255);
        for (int y = ay; y < by; y++)
            for (int x = ax; x < bx; x++) c->px[y * HW + x] = hv;
    }
    for (int gy = 0; gy < NY; gy++)
        for (int gx = 0; gx < NX; gx++) {
            float cx0 = x0 + gx * cw, cy0 = y0 + gy * ch;
            if (gx >= NX / 4 && gx < NX - NX / 4 && gy >= NY / 4 && gy < NY - NY / 4) continue;   /* the hole */
            if (cx0 > HW || cy0 > HH || cx0 + cw < 0 || cy0 + ch < 0) continue;
            unsigned h = hrand((unsigned)(gy * 37 + gx) * 2654435761u + seed);
            float ox = 0, oy = 0;
            int lit = 0;
            if (build < 1) {
                float arrive = 0.75f * ((h & 255) / 255.0f);
                float k = (build - arrive) / 0.25f;
                if (k <= 0) continue;
                if (k > 1) k = 1;
                float e = 1 - (1 - k) * (1 - k);
                ox = (float)((int)((h >> 8) % 241) - 120) * (1 - e);
                oy = (float)((int)((h >> 16) % 181) - 90) * (1 - e);
                lit = k < 1;
            }
            int sh = (int)((h >> 24) % 60);
            int r = lit ? 150 : 30 + sh / 2, g = lit ? 210 : 110 + sh, b = lit ? 255 : 215 + sh * 2 / 3;
            if (b > 255) b = 255;
            int px = (int)floorf(cx0 + ox), py = (int)floorf(cy0 + oy);
            int pw = (int)floorf(cx0 + ox + cw) - px, ph = (int)floorf(cy0 + oy + ch) - py;
            if (pw < 1) pw = 1; if (ph < 1) ph = 1;
            cv_fill(c, px, py, pw, ph, r, g, b, 255);
        }
}

static void load_wipe(Canvas *c, const Game *g) {
    if (loadWipeT <= 0 || g->modeT >= loadWipeT) return;
    float t = g->modeT * wipe_length() / loadWipeT;   /* on the wipe's own clock */
    const float HW0 = 46, HH0 = 84;                   /* the first rectangle: tall, not wide */
    const float Q = 0.5f * 0.78f;                     /* each inner rectangle sits inside the hole with a black gap */
    cv_fill(c, 0, 0, HW, HH, 0, 0, 0, 255);
    if (t < WIPE_BUILD) {
        wipe_rect(c, HW0, HH0, t / WIPE_BUILD, 11u, 0);
        return;
    }
    /* which dive we are in, and how far through it (speeding up as it goes) */
    float u = t - WIPE_BUILD;
    int step = 0;
    while (step < 4 && u > wipeDive[step]) { u -= wipeDive[step]; step++; }
    float f = u / wipeDive[step];
    if (f > 1) f = 1;
    f = f * f * (1.6f - 0.6f * f);                    /* eases in: it pulls you in harder at the end */
    /* each dive brings the next rectangle in to the size the one before it had */
    float zoom = powf(1 / Q, (float)step + f);
    if (step == 4) {
        /* the last dive does not stop: it goes on until the last hole fills the screen */
        float sEnd = 2.3f * (HW / HW0 > HH / HH0 ? HW / HW0 : HH / HH0);
        zoom = Q * powf(sEnd / Q, f) / powf(Q, 5);
    }
    /* draw from the outside in: rectangles 0..step+1; the innermost hole of the last dive is the level */
    int last = step + 1;
    for (int k = 0; k <= last; k++) {
        float s = zoom * powf(Q, (float)k);
        float hw = HW0 * s, hh = HH0 * s;
        if (hw * 0.5f > HW && hh * 0.5f > HH) continue;   /* its hole already covers the whole screen */
        wipe_rect(c, hw, hh, 1, 11u + (unsigned)k * 101u, step == 4 && k == last);
    }
    /* a flicker of static at the start of each dive */
    if (f < 0.12f) glitch(c, 0.5f, tick_seed(g, 33) + (unsigned)step);
}

int render_hud(const Game *g, unsigned short *hud) {
    Canvas c = {hud, HW, HH, 1};
    crtOn = g->setCrt; glowOn = g->setGlow;
    memset(hud, 0, HW * HH * 2);
    switch (g->mode) {
    case MODE_BOOT: boot_screen(&c, g); crt_apply(&c); break;
    case MODE_MENU: menu_screen(&c, g); break;
    case MODE_CHAT: chat_screen(&c, g); crt_apply(&c); break;
    case MODE_HACK: hack_screen(&c, g); crt_apply(&c); break;
    case MODE_PLAY: play_hud(&c, g); load_wipe(&c, g); break;
    case MODE_DEAD: dead_hud(&c, g); break;
    case MODE_WIN: win_flash(&c, g); break;
    case MODE_PAUSE: play_hud(&c, g); pause_hud(&c, g); break;
    }
    return 1;
}

/* ================= bottom screen ================= */

static void play_bottom(Canvas *c, const Game *g) {
    cv_fill(c, 0, 0, c->w, c->h, 0, 0, 0, 255);
    float k = corruption(g);
    char b[96];
    crt_frame(c, 8, 8, c->w - 16, c->h - 16);
    glow_text(c, 16, 12, levels[g->level].file, 0, TR, TG, TB, 230);
    if (g->replaying) glow_text(c, 200, 12, "REPLAY", 0, RED_R, 90, 90, 240);
    else if (g->story) glow_text(c, 200, 12, EXE_NAME, 0, TR, TG, TB, 200);
    snprintf(b, sizeof b, "targets left: %d", enemies_alive(g));
    glow_text(c, 16, 30, b, 0, TR, TG, TB, 220);
    if (g->pl.hasGun && WP_IS_GUN(g->pl.weapon)) snprintf(b, sizeof b, "%s: %d/%d", weapon_name(g->pl.weapon), g->pl.ammo, weapon_ammo(g->pl.weapon));
    else snprintf(b, sizeof b, "%s", weapon_name(g->pl.hasGun ? g->pl.weapon : WP_NONE));
    glow_text(c, 200, 30, b, 0, TR, TG, TB, 220);
    glow_text(c, 16, 52, "TIME", 0, TR, TG, TB, 200);
    cv_frame(c, 62, 54, 236, 10, TR, TG, TB, 160);
    cv_fill(c, 64, 56, (int)(232 * g->ts), 6, RED_R, RED_G, RED_B, 230);
    static const char *help[] = {
        "circle pad   walk",
        "ABXY / d-pad   look   (or drag here)",
        "R   punch / shoot / swing",
        "L   grab / throw what you hold",
        "START   pause     SELECT   restart",
    };
    if (g->replaying) {
        cv_text(c, 18, 86, "watching a replay.", 0, TR, TG, TB, 200);
        cv_text(c, 18, 102, "B or START: stop", 0, TR, TG, TB, 200);
    } else
        for (int i = 0; i < 5; i++) {
            corrupt_str(help[i], b, sizeof b, k * 0.3f, tick_seed(g, 3) + (unsigned)i);
            cv_text(c, 18, 82 + i * 16, b, 0, TR, TG, TB, 170);
        }
    cv_text(c, 18, 172, "stand still and time nearly stops.", 0, TR, TG, TB, 130);
    cv_text(c, 18, 188, "black and red break. white does not.", 0, TR, TG, TB, 130);
    scanlines(c, 0, c->h);
    glitch(c, k * 0.6f, tick_seed(g, 5));
    crt_apply(c);
}

static void pause_bottom(Canvas *c, const Game *g) {
    cv_fill(c, 0, 0, c->w, c->h, 0, 0, 0, 255);
    crt_frame(c, 8, 8, c->w - 16, c->h - 16);
    glow_text_c(c, c->w / 2, 18, "PAUSED", 1, TR, TG, TB, 230);
    static const char *opt[3] = {"RESUME", "RESTART LEVEL", "FILE COMMANDER"};
    for (int i = 0; i < 3; i++) {
        int y = 62 + i * 48;
        if (i == g->pauseSel) cv_fill(c, 40, y, 240, 40, RED_R, RED_G, RED_B, 230);
        else cv_frame(c, 40, y, 240, 40, TR, TG, TB, 200);
        glow_text_c(c, c->w / 2, y + 12, opt[i], 0, 255, 255, 255, 240);
    }
    crt_apply(c);
}

static void plain_bottom(Canvas *c, const Game *g, const char *s) {
    cv_fill(c, 0, 0, c->w, c->h, 0, 0, 0, 255);
    crt_frame(c, 8, 8, c->w - 16, c->h - 16);
    glow_text_c(c, c->w / 2, c->h / 2 - 8, s, 0, TR, TG, TB, 220);
    scanlines(c, 0, c->h);
    glitch(c, corruption(g) * 0.7f, tick_seed(g, 5));
    crt_apply(c);
}

void render_bottom(const Game *g, unsigned short *buf) {
    Canvas c = {buf, BW, BH, 0};
    crtOn = g->setCrt; glowOn = g->setGlow;
    switch (g->mode) {
    case MODE_BOOT: plain_bottom(&c, g, "Shatter-OS"); break;
    case MODE_MENU: menu_bottom(&c, g); break;
    case MODE_CHAT: chat_bottom(&c, g); crt_apply(&c); break;
    case MODE_HACK: plain_bottom(&c, g, WORD_A " " WORD_B); break;
    case MODE_PAUSE: pause_bottom(&c, g); break;
    case MODE_WIN: plain_bottom(&c, g, g->replaying ? "press A" : "A: continue    X: save replay"); break;
    case MODE_DEAD: plain_bottom(&c, g, g->replaying ? "" : "press A to try again"); break;
    default: play_bottom(&c, g); break;
    }
}
