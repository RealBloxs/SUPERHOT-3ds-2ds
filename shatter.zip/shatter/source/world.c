/* SUPERHOT - drawing the 3D world: white rooms with sun through the windows,
 * red glass men, black glass guns and bottles, red bullet trails, your black arms. */
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "game.h"
#include "decor.h"

static const Game *G;
static Cam cam;

static void col3(float *c, float r, float g, float b) { c[0] = r; c[1] = g; c[2] = b; }
static float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }

static int in_world(const Game *g) { return g->mode == MODE_PLAY || g->mode == MODE_DEAD || g->mode == MODE_WIN || g->mode == MODE_PAUSE; }

/* sunlight comes in through the windows on the low-x wall and travels this way */
/* what each kind of place has */
#define TB(t) (1u << (t))
#define WINDOWED (TB(TH_WHITE) | TB(TH_LOBBY) | TB(TH_BAR) | TB(TH_OFFICE) | TB(TH_STAIRS) | TB(TH_GALLERY) | TB(TH_ELEVATOR))
#define OWNSHELL (TB(TH_TRAIN) | TB(TH_GARAGE) | TB(TH_STREET))
static int theme_of(const Game *g) { return levels[g->level].theme; }
static int has(const Game *g, unsigned mask) { return (mask & TB(theme_of(g))) != 0; }

static V3 sun_dir(void) { return vnorm(v3(0.62f, -0.62f, 0.3f)); }

/* ================= camera, sky, lights ================= */

void world_camera(const Game *g, Cam *c) {
    V3 eye; float yaw, pitch;
    player_view(g, &eye, &yaw, &pitch);
    cam_look(c, eye, yaw, pitch);
}

unsigned world_clear(const Game *g) {
    if (!in_world(g)) return 0x000000;
    return 0xe6f4fa;
}

static int window_spots(const Game *g, float zs[], int max);
void world_lights(const Game *g) {
    memset(&LT, 0, sizeof(LT));
    LT.sunDir = sun_dir();
    col3(LT.sun, 0.2f, 0.19f, 0.17f);
    col3(LT.sky, 0.93f, 0.97f, 1.0f);
    col3(LT.ground, 0.68f, 0.77f, 0.84f);
    col3(LT.fog, 0.88f, 0.95f, 0.98f);
    LT.fogNear = 7;
    LT.fogFar = 34;
    if (in_world(g)) {
        switch (theme_of(g)) {
        case TH_STREET: col3(LT.sun, 0.3f, 0.28f, 0.25f); LT.fogNear = 14; LT.fogFar = 60; break;
        case TH_GARAGE: col3(LT.sun, 0.1f, 0.1f, 0.09f); col3(LT.sky, 0.86f, 0.9f, 0.95f); col3(LT.ground, 0.66f, 0.72f, 0.8f); break;
        case TH_SERVERS: col3(LT.sun, 0.1f, 0.1f, 0.1f); col3(LT.sky, 0.84f, 0.92f, 1.0f); col3(LT.ground, 0.62f, 0.72f, 0.84f); break;
        case TH_GALLERY: col3(LT.sun, 0.14f, 0.13f, 0.12f); break;
        }
    }
    /* the windows pour warm light into the room around them (the nearest few) */
    if (in_world(g)) {
        float zs[16];
        int n = window_spots(g, zs, 16);
        const Level *L = &levels[g->level];
        for (int k = 0; k < 4; k++) {
            int best = -1; float bd = 1e9f;
            for (int i = 0; i < n; i++) {
                float d = fabsf(zs[i] - g->pl.pos.z);
                int used = 0;
                for (int j = 0; j < LT.n; j++) if (fabsf(LT.lp[j].z - zs[i]) < 0.01f) used = 1;
                if (!used && d < bd) { bd = d; best = i; }
            }
            if (best < 0) break;
            LT.lp[LT.n] = v3(L->x0 + 0.9f, 1.4f, zs[best]);
            col3(LT.lc[LT.n], 0.42f, 0.4f, 0.34f);
            LT.lr[LT.n] = 4.5f;
            LT.n++;
        }
    }
    if (g->flashT > 0 && LT.n < MAX_LIGHTS) {
        LT.n++;
        LT.lp[LT.n - 1] = v3(g->pl.pos.x + cosf(g->pl.yaw) * 0.6f, 1.5f, g->pl.pos.z + sinf(g->pl.yaw) * 0.6f);
        col3(LT.lc[LT.n - 1], 0.6f, 0.45f, 0.3f);
        LT.lr[LT.n - 1] = 5;
    }
}

/* ================= glass shading ================= */

enum { SH_RED, SH_BLACK };
static void quad_col(V3 a, V3 b, V3 c, V3 d, const float col[3], float aa, float ab, float ac, float ad, int flags);

/* one flat colour per facet: lit body, facet sparkle, bright rims, a hard white glint,
 * and (for red) light shining through from the far side */
static void glass_light(V3 n, V3 view, V3 half, const float alb[3], int style, unsigned facet, float out[3]) {
    float sd = -vdot(n, LT.sunDir), back = sd < 0 ? -sd : 0;
    sd = sd < 0 ? 0 : sd;
    float hy = n.y * 0.5f + 0.5f;
    float fv = ((facet * 2654435761u) >> 24) / 255.0f;
    float sp = vdot(n, half);
    sp = sp < 0 ? 0 : sp;
    sp *= sp; sp *= sp; sp *= sp; sp *= sp; sp *= sp; /* ^32 */
    float nv = fabsf(vdot(n, view)), fr = 1 - nv;
    fr = fr * fr * fr;
    if (style == SH_RED) {
        float l = (0.5f + 0.2f * hy + 0.38f * sd) * (0.82f + 0.32f * fv);
        out[0] = alb[0] * l + 0.42f * back + 0.55f * fr + sp * 0.9f;
        out[1] = alb[1] * l + 0.04f * back + 0.32f * fr + sp * 0.85f;
        out[2] = alb[2] * l + 0.03f * back + 0.3f * fr + sp * 0.85f;
    } else {
        float l = (0.6f + 0.6f * sd) * (0.7f + 0.6f * fv);
        out[0] = alb[0] * l + 0.07f * hy + 0.3f * fr + sp * 0.75f;
        out[1] = alb[1] * l + 0.08f * hy + 0.36f * fr + sp * 0.75f;
        out[2] = alb[2] * l + 0.1f * hy + 0.44f * fr + sp * 0.78f;
    }
}

/* what a glass surface reflects: the room around it. Windows down the low-x wall (bright, with
 * glazing bars), lamp strips on the ceiling, the pale floor below, white walls in between.
 * Strongest at grazing angles (Fresnel), like real glass. Adds to out[]. */
static void env_reflect(V3 n, V3 view, int style, float out[3]) {
    float nv = vdot(n, view);
    if (nv < 0) { n = vmul(n, -1); nv = -nv; }
    V3 r = vsub(vmul(n, 2 * nv), view);
    float e;
    if (r.y > 0.55f) {
        /* ceiling with rows of lamps */
        float s = sinf(r.z * 7.0f + r.x * 3.0f);
        e = s > 0.55f ? 1.7f : 0.5f;
    } else if (r.x < -0.25f && r.y > -0.15f) {
        /* the windows, criss-crossed by bars */
        float a = atan2f(r.z, -r.x) * 9.0f, b = r.y * 14.0f;
        float bar = (fabsf(sinf(a)) > 0.93f || fabsf(sinf(b)) > 0.95f) ? 0.55f : 1.0f;
        e = 2.4f * bar;
    } else if (r.y < -0.12f) {
        e = 0.28f + 0.12f * -r.y;         /* floor */
    } else {
        e = 0.34f + 0.2f * fmaxf(0, 1 - fabsf(r.y) * 4);  /* walls, a bright band at the horizon */
    }
    float f = 1 - nv;
    float f5 = f * f; f5 = f5 * f5 * f;
    float wgt = style == SH_RED ? (0.12f + 0.7f * f5) : (0.07f + 0.7f * f5);
    out[0] += e * 0.9f * wgt;
    out[1] += e * 0.97f * wgt;
    out[2] += e * 1.0f * wgt;
}

static void emit_tri(V3 a, V3 b, V3 c, const float o[3], float alpha, int flags) {
    EV e[3];
    V3 P[3] = {a, b, c};
    for (int i = 0; i < 3; i++) { e[i].p = P[i]; e[i].s = e[i].t = 0; e[i].r = o[0]; e[i].g = o[1]; e[i].b = o[2]; e[i].a = alpha; }
    eng_tri(&e[0], &e[1], &e[2], -1, flags);
}

/* smooth glass: one colour per vertex, so the GPU blends across each face */
static void smooth_light(V3 p, V3 n, const float alb[3], int style, float out[3]) {
    V3 view = vsub(cam.eye, p);
    float vl = vlen(view);
    view = vl > 1e-5f ? vmul(view, 1 / vl) : v3(0, 0, 1);
    V3 half = vnorm(vsub(view, LT.sunDir));
    float sd = -vdot(n, LT.sunDir), back = sd < 0 ? -sd : 0;
    sd = sd < 0 ? 0 : sd;
    float hy = n.y * 0.5f + 0.5f;
    float sp = vdot(n, half);
    sp = sp < 0 ? 0 : sp;
    sp *= sp; sp *= sp; sp *= sp; sp *= sp; sp *= sp;
    float fr = 1 - fabsf(vdot(n, view));
    fr *= fr;
    if (style == SH_RED) {
        /* red glass, not plastic: a deep core, light glowing through the thin parts from behind,
         * pale edges where the surface turns away, the room mirrored in it, and a hard hot glint */
        float l = 0.2f + 0.16f * hy + 0.72f * sd;
        float sp2 = sp * sp;
        out[0] = alb[0] * l + 0.03f + 0.5f * back + 0.5f * fr + 1.3f * sp2;
        out[1] = alb[1] * l + 0.03f * back + 0.34f * fr + 1.15f * sp2;
        out[2] = alb[2] * l + 0.04f * back + 0.36f * fr + 1.15f * sp2;
        env_reflect(n, view, style, out);
    } else {
        float l = 0.7f + 0.5f * sd;
        sp *= sp;   /* black glass: a tighter, smaller highlight so it stays black */
        out[0] = alb[0] * l + 0.6f * sp;
        out[1] = alb[1] * l + 0.6f * sp;
        out[2] = alb[2] * l + 0.65f * sp;
    }
}

/* draw a part mesh (normal per corner) with transform x; cull faces turned away */
static void mesh_draw_m(const Mesh *M, const Xf *x, const float alb[3], int style, float alpha, int cull) {
    V3 lo = v3(M->lo[0], M->lo[1], M->lo[2]), hi = v3(M->hi[0], M->hi[1], M->hi[2]);
    V3 cw = xf_point(x, vmul(vadd(lo, hi), 0.5f));
    float rad = vlen(vsub(hi, lo)) * 0.5f * x->s;
    if (!eng_visible(cw, rad)) return;
    int flags = alpha < 0.99f ? E_TRANS : 0;
    for (int t = 0; t < M->nt; t++) {
        const float *q = M->v + t * 9;
        const signed char *nn = M->n + t * 9;
        EV e[3];
        for (int i = 0; i < 3; i++) {
            V3 p = xf_point(x, v3(q[i * 3], q[i * 3 + 1], q[i * 3 + 2]));
            V3 n = xf_dir(x, v3(nn[i * 3] / 127.0f, nn[i * 3 + 1] / 127.0f, nn[i * 3 + 2] / 127.0f));
            float o[3];
            smooth_light(p, n, alb, style, o);
            e[i].p = p; e[i].s = e[i].t = 0; e[i].r = o[0]; e[i].g = o[1]; e[i].b = o[2]; e[i].a = alpha;
        }
        V3 fn = vcross(vsub(e[1].p, e[0].p), vsub(e[2].p, e[0].p));
        if (cull && vdot(fn, vsub(cam.eye, e[0].p)) < 0) continue;
        float fl = vlen(fn);
        if (fl > 1e-12f) {
            fn = vmul(fn, 1 / fl);
            /* the reflection seen from each corner, so it slides across a face as you move */
            float lift = style == SH_BLACK ? 0.01f + 0.035f * (((unsigned)t * 2654435761u >> 24) / 255.0f) : 0;
            for (int k = 0; k < 3; k++) {
                float rf[3] = {0, 0, 0};
                V3 ve = vnorm(vsub(cam.eye, e[k].p));
                env_reflect(fn, ve, style, rf);
                V3 half = vnorm(vsub(ve, LT.sunDir));
                float gl = vdot(fn, half);
                gl = gl < 0 ? 0 : gl;
                gl *= gl; gl *= gl; gl *= gl; gl *= gl; gl *= gl; gl *= gl;
                gl *= 0.55f;
                e[k].r += rf[0] + lift + gl; e[k].g += rf[1] + lift + gl; e[k].b += rf[2] + lift * 1.2f + gl;
            }
        }
        eng_tri(&e[0], &e[1], &e[2], -1, flags);
    }
}

static void mesh_draw(int id, const Xf *x, const float alb[3], int style, float alpha, int cull) {
    mesh_draw_m(&meshes[id], x, alb, style, alpha, cull);
}

/* the built weapons, made smooth like the pistol: each corner gets the average normal of the faces
 * meeting there, unless the edge between them is sharper than about 50 degrees */
static Mesh wmesh[WP_KINDS];
static const Mesh *weapon_mesh(int kind) {
    Mesh *M = &wmesh[kind];
    if (M->nt) return M;
    static V3 w[400 * 3];
    Xf id; xf_ident(&id);
    int nt = weapon_tris(kind, 0, 0, 0, &id, w, 400 * 3);
    float *v = (float *)malloc(sizeof(float) * 9 * nt);
    signed char *nn = (signed char *)malloc(9 * nt);
    V3 *fn = (V3 *)malloc(sizeof(V3) * nt);
    if (!v || !nn || !fn) { free(v); free(nn); free(fn); return NULL; }
    for (int t = 0; t < nt; t++) fn[t] = vnorm(vcross(vsub(w[t * 3 + 1], w[t * 3]), vsub(w[t * 3 + 2], w[t * 3])));
    V3 lo = w[0], hi = w[0];
    const float crease = 0.64f;   /* cos 50 degrees */
    for (int t = 0; t < nt; t++)
        for (int c = 0; c < 3; c++) {
            V3 p = w[t * 3 + c], sum = v3(0, 0, 0);
            for (int u = 0; u < nt; u++) {
                if (vdot(fn[u], fn[t]) < crease) continue;
                for (int k = 0; k < 3; k++) {
                    V3 d = vsub(w[u * 3 + k], p);
                    if (vdot(d, d) < 1e-9f) {
                        /* weight by the face's corner angle so thin slivers do not dominate */
                        V3 e1 = vnorm(vsub(w[u * 3 + (k + 1) % 3], p)), e2 = vnorm(vsub(w[u * 3 + (k + 2) % 3], p));
                        float ang = acosf(clampf(vdot(e1, e2), -1, 1));
                        sum = vadd(sum, vmul(fn[u], ang));
                        break;
                    }
                }
            }
            V3 n = vlen(sum) > 1e-6f ? vnorm(sum) : fn[t];
            v[(t * 3 + c) * 3] = p.x; v[(t * 3 + c) * 3 + 1] = p.y; v[(t * 3 + c) * 3 + 2] = p.z;
            nn[(t * 3 + c) * 3] = (signed char)(n.x * 127); nn[(t * 3 + c) * 3 + 1] = (signed char)(n.y * 127); nn[(t * 3 + c) * 3 + 2] = (signed char)(n.z * 127);
            lo = v3(fminf(lo.x, p.x), fminf(lo.y, p.y), fminf(lo.z, p.z));
            hi = v3(fmaxf(hi.x, p.x), fmaxf(hi.y, p.y), fmaxf(hi.z, p.z));
        }
    free(fn);
    M->v = v; M->n = nn;
    M->lo[0] = lo.x; M->lo[1] = lo.y; M->lo[2] = lo.z;
    M->hi[0] = hi.x; M->hi[1] = hi.y; M->hi[2] = hi.z;
    M->nt = nt;
    return M;
}

/* the whole glass man, bent into a pose: a smooth gradient across the body, and every facet
 * catching the light a little differently, with hard glints, like cut glass.
 * first/last part: draw only those parts (first person arms), or 0..BODY_PARTS for all. */
static V3 skinP[8192], skinN[8192];
static int glassDeep = 1;
/* each enemy is posed once per frame and the result shared by its shadow and its body */
static Pose framePose[MAX_ENEMIES];
static Xf frameParts[MAX_ENEMIES][BODY_PARTS];
static unsigned char framePosed[MAX_ENEMIES];
static void enemy_posed(const Game *g, const Enemy *e, Pose *p, Xf parts[BODY_PARTS]) {
    int i = (int)(e - g->en);
    if (i < 0 || i >= MAX_ENEMIES) { pose_of_enemy(e, p); pose_parts(p, parts); return; }
    if (!framePosed[i]) {
        pose_of_enemy(e, &framePose[i]);
        pose_parts(&framePose[i], frameParts[i]);
        framePosed[i] = 1;
    }
    *p = framePose[i];
    memcpy(parts, frameParts[i], sizeof(Xf) * BODY_PARTS);
}
static void draw_weapon(int kind, int sub, float r, float h, const Xf *x, unsigned seed);
static void body_draw_parts(const Xf parts[BODY_PARTS], int lod, const float alb[3], int style, float alpha, int p0, int p1, int noFog) {
    /* The model is drawn exactly as it was made, solid and smooth-shaded, lit as one piece -
     * no random brightness per face, no see-through shell, no glints. Only the pose changes. */
    const Body *B = &bodies[lod];
    /* the triangles to draw for each part, worked out once (the few hand-to-thigh bridges left out) */
    static unsigned short keep[BODY_LODS][16384];
    static int keepStart[BODY_LODS][BODY_PARTS + 1], ready[BODY_LODS];
    if (!ready[lod]) {
        int n = 0;
        for (int p = 0; p <= BODY_PARTS; p++) {
            keepStart[lod][p] = n;
            if (p == BODY_PARTS) break;
            for (int t = B->partStart[p]; t < B->partStart[p + 1] && n < 16384; t++)
                if (!body_tri_bridge(lod, t)) keep[lod][n++] = (unsigned short)t;
        }
        ready[lod] = 1;
    }
    body_skin(lod, parts, skinP, skinN);     /* bend the model's own normals with the pose */
    int flags = (alpha < 0.99f ? E_TRANS : 0) | (noFog ? E_EMIT : 0);
    int k0 = keepStart[lod][p0], k1 = keepStart[lod][p1];
    V3 eye = cam.eye;
    /* light each corner once, from the model's smooth normal, so the GPU blends the colour across
     * every face and no single triangle stands out */
    static float vcol[8192][3];
    static unsigned vstamp[8192], stamp;
    if (++stamp == 0) { memset(vstamp, 0, sizeof(vstamp)); stamp = 1; }
    for (int k = k0; k < k1; k++) {
        int t = keep[lod][k];
        const unsigned short *ix = B->idx + t * 3;
        V3 a = skinP[ix[0]], b = skinP[ix[1]], c = skinP[ix[2]];
        V3 fn = vcross(vsub(b, a), vsub(c, a));
        if (vdot(fn, vsub(eye, a)) < 0) continue;              /* the far side is hidden by the near side */
        if (vdot(fn, fn) < 1e-24f) continue;
        EV e[3];
        for (int j = 0; j < 3; j++) {
            int vi = ix[j];
            if (vstamp[vi] != stamp) { smooth_light(skinP[vi], skinN[vi], alb, style, vcol[vi]); vstamp[vi] = stamp; }
            e[j].p = skinP[vi]; e[j].s = e[j].t = 0;
            e[j].r = vcol[vi][0]; e[j].g = vcol[vi][1]; e[j].b = vcol[vi][2]; e[j].a = alpha;
        }
        eng_tri(&e[0], &e[1], &e[2], -1, flags);
    }
}

static void body_draw(const Xf parts[BODY_PARTS], int lod, const float alb[3], int style, float alpha) {
    body_draw_parts(parts, lod, alb, style, alpha, 0, BODY_PARTS, style == SH_RED);
}

/* ================= shadows ================= */

static const float SHADOW[3] = {0.6f, 0.68f, 0.79f};

/* flatten a posed body onto the floor along the sunlight */
static void body_shadow(const Xf parts[BODY_PARTS], float floorY) {
    static V3 sp[4096];
    const Body *B = &bodies[BODY_LODS - 1];
    V3 sd = sun_dir();
    body_skin(BODY_LODS - 1, parts, sp, NULL);
    for (int i = 0; i < B->nv; i++) {
        float h = sp[i].y - floorY;
        if (h < 0) h = 0;
        sp[i] = vadd(sp[i], vmul(sd, h / -sd.y));
        sp[i].y = floorY + 0.006f;
    }
    EV e[3];
    for (int k = 0; k < 3; k++) { e[k].s = e[k].t = 0; e[k].r = SHADOW[0]; e[k].g = SHADOW[1]; e[k].b = SHADOW[2]; e[k].a = 1; }
    for (int t = 0; t < B->nt; t++) {
        if (body_tri_bridge(BODY_LODS - 1, t)) continue;
        const unsigned short *ix = B->idx + t * 3;
        e[0].p = sp[ix[0]]; e[1].p = sp[ix[1]]; e[2].p = sp[ix[2]];
        /* only one winding faces up after flattening: that is enough to cover the shape */
        if (vcross(vsub(e[1].p, e[0].p), vsub(e[2].p, e[0].p)).y <= 0) continue;
        eng_tri(&e[0], &e[1], &e[2], -1, 0);
    }
}

/* a cheap shadow for people further off: each limb a rounded stroke on the floor */
static void body_shadow_lite(const Xf parts[BODY_PARTS], float floorY) {
    V3 sd = sun_dir();
    for (int i = 0; i < BODY_PARTS; i++) {
        const Mesh *M = &meshes[i];
        V3 lo = v3(M->lo[0], M->lo[1], M->lo[2]), hi = v3(M->hi[0], M->hi[1], M->hi[2]);
        V3 ext = vsub(hi, lo), mid = vmul(vadd(lo, hi), 0.5f);
        /* the part's long axis and its thickness */
        int ax = ext.x > ext.y ? (ext.x > ext.z ? 0 : 2) : (ext.y > ext.z ? 1 : 2);
        float e[3] = {ext.x, ext.y, ext.z};
        float r = (e[0] + e[1] + e[2] - e[ax]) * 0.25f * parts[i].s;
        V3 a = mid, b = mid;
        float half = e[ax] * 0.5f - (e[0] + e[1] + e[2] - e[ax]) * 0.25f;
        if (half < 0) half = 0;
        if (ax == 0) { a.x -= half; b.x += half; } else if (ax == 1) { a.y -= half; b.y += half; } else { a.z -= half; b.z += half; }
        a = xf_point(&parts[i], a); b = xf_point(&parts[i], b);
        float ha = a.y - floorY, hb = b.y - floorY;
        a = vadd(a, vmul(sd, (ha < 0 ? 0 : ha) / -sd.y)); b = vadd(b, vmul(sd, (hb < 0 ? 0 : hb) / -sd.y));
        a.y = b.y = floorY + 0.006f;
        V3 d = vsub(b, a);
        float l = sqrtf(d.x * d.x + d.z * d.z);
        V3 u = l > 1e-4f ? v3(d.x / l, 0, d.z / l) : v3(1, 0, 0), w = v3(-u.z, 0, u.x);
        /* an octagon-ended stroke: 6 points round each end */
        V3 P[12];
        for (int k = 0; k < 6; k++) {
            float t = PI * 0.5f + PI * k / 5;
            V3 o = vadd(vmul(w, sinf(t) * r), vmul(u, cosf(t) * r));
            P[k] = vadd(a, o);
            V3 o2 = vadd(vmul(w, -sinf(t) * r), vmul(u, -cosf(t) * r));
            P[6 + k] = vadd(b, o2);
        }
        EV ev[3];
        for (int k = 0; k < 3; k++) { ev[k].s = ev[k].t = 0; ev[k].r = SHADOW[0]; ev[k].g = SHADOW[1]; ev[k].b = SHADOW[2]; ev[k].a = 1; }
        ev[0].p = P[0];
        for (int k = 1; k < 11; k++) { ev[1].p = P[k]; ev[2].p = P[k + 1]; eng_tri(&ev[0], &ev[1], &ev[2], -1, E_NOCULL); }
    }
}

/* a box's shadow: the hull of its footprint and its top pushed along the sunlight */
static void box_shadow(const Box *b) {
    V3 sd = sun_dir();
    float k = b->h / -sd.y;
    float px[8], pz[8];
    float xs[2] = {b->x0, b->x1}, zs[2] = {b->z0, b->z1};
    int n = 0;
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++) {
            px[n] = xs[i]; pz[n] = zs[j]; n++;
            px[n] = xs[i] + sd.x * k; pz[n] = zs[j] + sd.z * k; n++;
        }
    /* gift-wrap the 8 points */
    int hull[9], hn = 0, start = 0;
    for (int i = 1; i < 8; i++) if (px[i] < px[start] || (px[i] == px[start] && pz[i] < pz[start])) start = i;
    int p = start;
    do {
        hull[hn++] = p;
        int q = (p + 1) % 8;
        for (int i = 0; i < 8; i++) {
            float cr = (px[q] - px[p]) * (pz[i] - pz[p]) - (pz[q] - pz[p]) * (px[i] - px[p]);
            if (cr < 0) q = i;
        }
        p = q;
    } while (p != start && hn < 9);
    EV e[3];
    for (int k2 = 0; k2 < 3; k2++) { e[k2].s = e[k2].t = 0; e[k2].r = SHADOW[0]; e[k2].g = SHADOW[1]; e[k2].b = SHADOW[2]; e[k2].a = 1; }
    e[0].p = v3(px[hull[0]], 0.005f, pz[hull[0]]);
    for (int i = 1; i + 1 < hn; i++) {
        e[1].p = v3(px[hull[i]], 0.005f, pz[hull[i]]);
        e[2].p = v3(px[hull[i + 1]], 0.005f, pz[hull[i + 1]]);
        eng_tri(&e[0], &e[1], &e[2], -1, E_NOCULL);
    }
    /* soft edge: a fading band round the outside */
    float cx = 0, cz = 0;
    for (int i = 0; i < hn; i++) { cx += px[hull[i]]; cz += pz[hull[i]]; }
    cx /= hn; cz /= hn;
    for (int i = 0; i < hn; i++) {
        int j = (i + 1) % hn;
        V3 a = v3(px[hull[i]], 0.0055f, pz[hull[i]]), b2 = v3(px[hull[j]], 0.0055f, pz[hull[j]]);
        V3 oa = vnorm(v3(a.x - cx, 0, a.z - cz)), ob = vnorm(v3(b2.x - cx, 0, b2.z - cz));
        quad_col(a, b2, vadd(b2, vmul(ob, 0.22f)), vadd(a, vmul(oa, 0.22f)), SHADOW, 0.85f, 0.85f, 0, 0, E_TRANS | E_NOCULL);
    }
}

static void draw_shadows(const Game *g) {
    const Level *L = &levels[g->level];
    for (int i = 0; i < g->nbox; i++) {
        const Box *b = &g->box[i];
        /* the outer walls frame the room; their shadows would only fall outside it */
        if (b->x1 <= L->x0 + 0.01f || b->x0 >= L->x1 - 0.01f || b->z1 <= L->z0 + 0.01f || b->z0 >= L->z1 - 0.01f) continue;
        V3 c = v3((b->x0 + b->x1) * 0.5f, 0, (b->z0 + b->z1) * 0.5f);
        if (b->kind == BOX_POLE || b->kind == BOX_PLANT) continue;
        Box sb = *b;
        if (sb.h > 3.4f) sb.h = 3.4f;      /* tall buildings: keep the shade near their feet */
        if (!eng_visible(c, (b->x1 - b->x0) + (b->z1 - b->z0) + sb.h * 1.5f)) continue;
        box_shadow(&sb);
    }
    if (!g->setQuality) return;
    for (int i = 0; i < g->nen; i++) {
        const Enemy *e = &g->en[i];
        if (!e->alive || e->delay > 0) continue;
        if (!eng_visible(v3(e->pos.x + 0.6f, 0, e->pos.z + 0.3f), 1.6f)) continue;
        Pose p; Xf parts[BODY_PARTS];
        enemy_posed(g, e, &p, parts);
        if (vlen(vsub(e->pos, cam.eye)) < 7.5f) body_shadow(parts, 0);
        else body_shadow_lite(parts, 0);
    }
    /* your own shadow, walking with you */
    if (g->mode != MODE_DEAD) {
        Pose p; memset(&p, 0, sizeof p);
        p.pos = g->pl.pos; p.yaw = g->pl.yaw; p.walk = g->pl.bob * 0.5f; p.walkAmt = g->pl.moveAmt;
        p.armed = g->pl.hasGun && WP_IS_GUN(g->pl.weapon); p.aim = p.armed; p.weapon = g->pl.hasGun ? g->pl.weapon : WP_NONE;
        Xf parts[BODY_PARTS]; pose_parts(&p, parts);
        body_shadow(parts, 0);
    }
}

/* world triangles (3 V3 each), flat glass shading */
static void tris_draw(const V3 *w, int nt, const float alb[3], int style, unsigned seed) {
    for (int t = 0; t < nt; t++) {
        V3 a = w[t * 3], b = w[t * 3 + 1], c = w[t * 3 + 2];
        V3 n = vcross(vsub(b, a), vsub(c, a));
        float l = vlen(n);
        if (l < 1e-9f) continue;
        n = vmul(n, 1 / l);
        V3 view = vnorm(vsub(cam.eye, a));
        if (vdot(n, view) < 0) n = vmul(n, -1);
        V3 half = vnorm(vsub(view, LT.sunDir));
        float o[3];
        glass_light(n, view, half, alb, style, seed + (unsigned)t, o);
        EV e[3];
        V3 P[3] = {a, b, c};
        for (int k = 0; k < 3; k++) {
            float r[3] = {o[0], o[1], o[2]};
            env_reflect(n, vnorm(vsub(cam.eye, P[k])), style, r);
            e[k].p = P[k]; e[k].s = e[k].t = 0; e[k].r = r[0]; e[k].g = r[1]; e[k].b = r[2]; e[k].a = 1;
        }
        eng_tri(&e[0], &e[1], &e[2], -1, E_NOCULL);
    }
}

static const float ENEMY_RED[3] = {0.95f, 0.14f, 0.09f};
static const float GLASS_BLACK[3] = {0.07f, 0.07f, 0.08f};

/* a flat-shaded box in a transform's space */
static void xbox(const Xf *x, V3 lo, V3 hi, const float alb[3], int style) {
    static const int F[6][4] = {{0, 2, 3, 1}, {4, 5, 7, 6}, {0, 1, 5, 4}, {2, 6, 7, 3}, {0, 4, 6, 2}, {1, 3, 7, 5}};
    V3 P[8];
    for (int i = 0; i < 8; i++) P[i] = xf_point(x, v3(i & 1 ? hi.x : lo.x, i & 2 ? hi.y : lo.y, i & 4 ? hi.z : lo.z));
    V3 cw = vmul(vadd(P[0], P[7]), 0.5f);
    V3 view = vnorm(vsub(cam.eye, cw));
    V3 half = vnorm(vsub(view, LT.sunDir));
    for (int f = 0; f < 6; f++) {
        V3 a = P[F[f][0]], b = P[F[f][1]], c = P[F[f][2]], d = P[F[f][3]];
        V3 n = vnorm(vcross(vsub(b, a), vsub(d, a)));
        if (vdot(n, vsub(cam.eye, a)) <= 0) continue;
        float o[3];
        glass_light(n, view, half, alb, style, (unsigned)f, o);
        emit_tri(a, b, c, o, 1, 0);
        emit_tri(a, c, d, o, 1, 0);
    }
}

/* ================= people ================= */

static void draw_enemy(const Game *g, const Enemy *e) {
    if (!e->alive || e->delay > 0) return;
    V3 c = v3(e->pos.x, 1.0f, e->pos.z);
    if (!eng_visible(c, 1.1f)) return;
    float dist = vlen(vsub(cam.eye, c));
    Pose p;
    Xf parts[BODY_PARTS];
    enemy_posed(g, e, &p, parts);
    float alpha = e->appear < 1 ? 0.25f + 0.75f * e->appear : 1;
    /* full detail up close; the lighter model far away or on low graphics */
    int lod = (!g->setQuality || dist > 7) ? BODY_LODS - 1 : 0;
    body_draw(parts, lod, ENEMY_RED, SH_RED, alpha);
    if (e->armed) {
        Xf gx = pose_weapon(&p, parts);
        if (e->armed == WP_PISTOL) mesh_draw(M_GUN, &gx, GLASS_BLACK, SH_BLACK, alpha, 0);
        else draw_weapon(e->armed, 0, 0, 0, &gx, (unsigned)(e - g->en) * 17u);
        if (e->flashT > 0) {
            static const float fc[3] = {1.0f, 0.92f, 0.75f};
            V3 mm = weapon_muzzle(e->armed);
            mm.z += 0.04f;
            V3 m = xf_point(&gx, mm);
            draw_billboard(m, 0.22f, 0.22f, fc, 0.95f, E_EMIT);
        }
    }
    draw_blob(v3(e->pos.x, 0.008f, e->pos.z), 0.3f, 0.3f, 0.22f);
}

/* ================= the rooms: white walls, sun through the windows ================= */

/* windows on the low-x wall, where nothing else is built against it */
static int window_spots(const Game *g, float zs[], int max) {
    const Level *L = &levels[g->level];
    int n = 0;
    if (!has(g, WINDOWED)) return 0;
    for (float z = L->z0 + 1.6f; z < L->z1 - 1.4f && n < max; z += 3.2f) {
        int clear = 1;
        for (int i = 0; i < g->nbox && clear; i++) {
            const Box *b = &g->box[i];
            if (b->x0 <= L->x0 + 0.05f && b->x1 > L->x0 + 0.05f && b->z1 > z - 0.9f && b->z0 < z + 0.9f && b->h > 0.8f) clear = 0;
        }
        if (clear) zs[n++] = z;
    }
    return n;
}

#define WIN_Y0 0.85f
#define WIN_Y1 2.65f
#define WIN_HW 0.75f

static void quad_col(V3 a, V3 b, V3 c, V3 d, const float col[3], float aa, float ab, float ac, float ad, int flags) {
    EV e[4];
    V3 P[4] = {a, b, c, d};
    float A[4] = {aa, ab, ac, ad};
    for (int i = 0; i < 4; i++) { e[i].p = P[i]; e[i].s = e[i].t = 0; e[i].r = col[0]; e[i].g = col[1]; e[i].b = col[2]; e[i].a = A[i]; }
    eng_tri(&e[0], &e[1], &e[2], -1, flags);
    eng_tri(&e[0], &e[2], &e[3], -1, flags);
}

static void wbox(V3 lo, V3 hi, const float col[3], int faces) { draw_box_tex(lo, hi, T_PANEL, 1.0f, col, faces); }

static void draw_windows(const Game *g) {
    const Level *L = &levels[g->level];
    float zs[16];
    int n = window_spots(g, zs, 16);
    float x = L->x0 + 0.012f;
    V3 sd = sun_dir();
    static const float sky[3] = {1.0f, 1.0f, 1.0f};
    static const float frame[3] = {0.78f, 0.82f, 0.86f};
    static const float beam[3] = {1.0f, 0.99f, 0.95f};
    for (int i = 0; i < n; i++) {
        float z = zs[i];
        V3 c = v3(x, (WIN_Y0 + WIN_Y1) * 0.5f, z);
        if (!eng_visible(v3(x + 1.2f, 1.2f, z + 0.6f), 2.6f)) continue;
        V3 A = v3(x, WIN_Y0, z - WIN_HW), B = v3(x, WIN_Y0, z + WIN_HW), C = v3(x, WIN_Y1, z + WIN_HW), D = v3(x, WIN_Y1, z - WIN_HW);
        /* the bright sky beyond */
        quad_col(A, B, C, D, sky, 1, 1, 1, 1, E_EMIT | E_NOCULL);
        float fx = x + 0.01f, t = 0.04f;
        (void)t; (void)frame;
        /* the city outside: pale towers fading into the glare */
        if (g->setQuality) {
            unsigned h = (unsigned)(i * 7919 + g->level * 104729) * 2654435761u;
            static const float far1[3] = {0.84f, 0.91f, 0.96f}, far2[3] = {0.76f, 0.85f, 0.92f};
            for (int b = 0; b < 6; b++) {
                h = h * 1664525u + 1013904223u;
                float bz0 = z - WIN_HW + (b / 6.0f) * 2 * WIN_HW + ((h >> 8) & 15) * 0.004f;
                float bw = 0.16f + ((h >> 12) & 15) * 0.012f;
                float bh = WIN_Y0 + 0.15f + ((h >> 16) & 255) / 255.0f * 0.85f;
                float bz1 = bz0 + bw > z + WIN_HW ? z + WIN_HW : bz0 + bw;
                const float *bc = (b & 1) ? far1 : far2;
                quad_col(v3(x + 0.013f, WIN_Y0, bz0), v3(x + 0.013f, WIN_Y0, bz1), v3(x + 0.013f, bh, bz1), v3(x + 0.013f, bh, bz0), bc, 1, 1, 1, 1, E_EMIT | E_NOCULL);
            }
        }
        /* a deep frame: jambs, a lintel and a grid of glazing bars */
        static const float jamb[3] = {0.96f, 0.98f, 1.0f};
        float d = 0.16f;
        wbox(v3(x, WIN_Y0, z - WIN_HW - 0.08f), v3(x + d, WIN_Y1, z - WIN_HW), jamb, BX_PX | BX_PZ);
        wbox(v3(x, WIN_Y0, z + WIN_HW), v3(x + d, WIN_Y1, z + WIN_HW + 0.08f), jamb, BX_PX | BX_NZ);
        wbox(v3(x, WIN_Y1, z - WIN_HW - 0.08f), v3(x + d, WIN_Y1 + 0.1f, z + WIN_HW + 0.08f), jamb, BX_PX | BX_NY);
        static const float bar[3] = {0.82f, 0.86f, 0.9f};
        for (int k = 1; k < 3; k++) {
            float bz = z - WIN_HW + 2 * WIN_HW * k / 3;
            wbox(v3(x, WIN_Y0, bz - 0.018f), v3(x + 0.05f, WIN_Y1, bz + 0.018f), bar, BX_PX | BX_PZ | BX_NZ);
        }
        for (int k = 1; k < 3; k++) {
            float by = WIN_Y0 + (WIN_Y1 - WIN_Y0) * k / 3;
            wbox(v3(x, by - 0.018f, z - WIN_HW), v3(x + 0.05f, by + 0.018f, z + WIN_HW), bar, BX_PX | BX_PY | BX_NY);
        }
        /* glow round the window, bleeding onto the wall */
        float gw = 0.55f;
        V3 A2 = v3(fx, WIN_Y0 - gw, z - WIN_HW - gw), B2 = v3(fx, WIN_Y0 - gw, z + WIN_HW + gw), C2 = v3(fx, WIN_Y1 + gw, z + WIN_HW + gw), D2 = v3(fx, WIN_Y1 + gw, z - WIN_HW - gw);
        quad_col(A, B, B2, A2, sky, 0.7f, 0.7f, 0, 0, E_TRANS | E_EMIT | E_NOCULL);
        quad_col(B, C, C2, B2, sky, 0.7f, 0.7f, 0, 0, E_TRANS | E_EMIT | E_NOCULL);
        quad_col(C, D, D2, C2, sky, 0.7f, 0.7f, 0, 0, E_TRANS | E_EMIT | E_NOCULL);
        quad_col(D, A, A2, D2, sky, 0.7f, 0.7f, 0, 0, E_TRANS | E_EMIT | E_NOCULL);
        /* where the sun lands on the floor */
        V3 W[4] = {A, B, C, D}, F[4];
        for (int k = 0; k < 4; k++) {
            float s = W[k].y / -sd.y;
            F[k] = vadd(W[k], vmul(sd, s));
            F[k].y = 0.006f;
            if (F[k].x > L->x1) F[k].x = L->x1;
        }
        quad_col(F[0], F[1], F[2], F[3], beam, 0.55f, 0.55f, 0.55f, 0.55f, E_TRANS | E_EMIT | E_NOCULL);
        /* dust drifting in the sunbeam: it only moves when time does */
        if (g->setQuality) {
            static const float mote[3] = {1.0f, 1.0f, 0.97f};
            for (int m = 0; m < 10; m++) {
                unsigned h = (unsigned)(m * 7919 + i * 104729 + 13) * 2654435761u;
                float u = ((h >> 8) & 255) / 255.0f, v = ((h >> 16) & 255) / 255.0f, s = ((h >> 24) & 255) / 255.0f;
                float t = g->gtime * 0.05f + s;
                t -= floorf(t);
                V3 top = vlerp(vlerp(A, B, u), vlerp(D, C, u), v);
                V3 bot = vlerp(vlerp(F[0], F[1], u), vlerp(F[3], F[2], u), v);
                V3 p = vlerp(top, bot, 0.15f + 0.7f * t);
                p.y += sinf(g->gtime * 0.7f + m) * 0.05f;
                draw_billboard(p, 0.014f, 0.014f, mote, 1, E_EMIT);
            }
        }
        /* the shaft of light through the air: brightest at the window */
        for (int k = 0; k < 4; k++) {
            int k2 = (k + 1) & 3;
            quad_col(W[k], W[k2], F[k2], F[k], beam, 0.2f, 0.2f, 0.02f, 0.02f, E_TRANS | E_EMIT | E_NOCULL);
        }
        (void)c;
    }
}

/* soft shade where walls meet the floor */
static void base_shade(V3 a, V3 b, V3 out) {
    static const float sc[3] = {0.32f, 0.38f, 0.48f};
    V3 a2 = vadd(a, out), b2 = vadd(b, out);
    a.y = b.y = a2.y = b2.y = 0.004f;
    quad_col(a, b, b2, a2, sc, 0.26f, 0.26f, 0, 0, E_TRANS | E_NOCULL);
}

/* a lit cylinder from a to b (pipes) */
static void pipe(V3 a, V3 b, float r, const float col[3]) {
    V3 d = vnorm(vsub(b, a));
    V3 u = fabsf(d.y) < 0.9f ? v3(0, 1, 0) : v3(1, 0, 0);
    V3 s1 = vnorm(vcross(d, u)), s2 = vcross(s1, d);
    const int N = 8;
    for (int i = 0; i < N; i++) {
        float a0 = 2 * PI * i / N, a1 = 2 * PI * (i + 1) / N;
        V3 o0 = vadd(vmul(s1, cosf(a0) * r), vmul(s2, sinf(a0) * r)), o1 = vadd(vmul(s1, cosf(a1) * r), vmul(s2, sinf(a1) * r));
        draw_quad(vadd(a, o0), vadd(b, o0), vadd(b, o1), vadd(a, o1), -1, 0, 0, 1, 1, col, 0);
    }
}

static void lbox(V3 lo, V3 hi, const float col[3], int faces) { draw_box_tex(lo, hi, T_PANEL, 1.0f, col, faces); }

/* ceiling, beams and lamps, pipes, radiators under the windows, a doorway: it should feel like a building */
static void draw_details(const Game *g) {
    const Level *L = &levels[g->level];
    static const float white[3] = {0.98f, 0.99f, 1.0f};
    static const float ceil[3] = {0.95f, 0.97f, 1.0f};
    static const float lamp[3] = {1.0f, 1.0f, 1.0f};
    static const float pipeC[3] = {0.92f, 0.95f, 0.98f};
    static const float door[3] = {0.5f, 0.58f, 0.66f};
    float WH = 3.2f;
    int indoor = !has(g, OWNSHELL);
    int th = theme_of(g);
    /* ceiling */
    if (indoor) draw_box_tex(v3(L->x0 - 0.3f, WH, L->z0 - 0.3f), v3(L->x1 + 0.3f, WH + 0.1f, L->z1 + 0.3f), T_PANEL, 0.5f, ceil, BX_NY);
    if (!g->setQuality) return;
    /* beams across the room, lamps between them */
    int beams = has(g, TB(TH_WHITE) | TB(TH_OFFICE) | TB(TH_STAIRS) | TB(TH_SERVERS) | TB(TH_ELEVATOR));
    for (float z = L->z0 + 2.0f; beams && z < L->z1 - 0.5f; z += 4.0f) {
        if (!eng_visible(v3((L->x0 + L->x1) * 0.5f, WH, z), (L->x1 - L->x0) * 0.5f + 1)) continue;
        lbox(v3(L->x0, WH - 0.32f, z - 0.15f), v3(L->x1, WH, z + 0.15f), white, BX_NY | BX_PZ | BX_NZ);
        for (float x = L->x0 + 1.5f; x < L->x1 - 1.0f; x += 3.0f) {
            V3 c = v3(x, WH - 0.01f, z + 2.0f);
            if (c.z > L->z1 - 0.6f) continue;
            V3 A = v3(c.x - 0.5f, c.y, c.z - 0.25f), B = v3(c.x + 0.5f, c.y, c.z - 0.25f), C = v3(c.x + 0.5f, c.y, c.z + 0.25f), D = v3(c.x - 0.5f, c.y, c.z + 0.25f);
            quad_col(A, B, C, D, lamp, 1, 1, 1, 1, E_EMIT | E_NOCULL);
            /* soft glow round each lamp */
            float k = 0.35f;
            V3 A2 = v3(A.x - k, c.y, A.z - k), B2 = v3(B.x + k, c.y, B.z - k), C2 = v3(C.x + k, c.y, C.z + k), D2 = v3(D.x - k, c.y, D.z + k);
            quad_col(A, B, B2, A2, lamp, 0.6f, 0.6f, 0, 0, E_TRANS | E_EMIT | E_NOCULL);
            quad_col(B, C, C2, B2, lamp, 0.6f, 0.6f, 0, 0, E_TRANS | E_EMIT | E_NOCULL);
            quad_col(C, D, D2, C2, lamp, 0.6f, 0.6f, 0, 0, E_TRANS | E_EMIT | E_NOCULL);
            quad_col(D, A, A2, D2, lamp, 0.6f, 0.6f, 0, 0, E_TRANS | E_EMIT | E_NOCULL);
        }
    }
    /* two pipes along the wall across from the windows, with a drop to the floor */
    float px = L->x1 - 0.14f;
    if (has(g, TB(TH_WHITE) | TB(TH_STAIRS) | TB(TH_SERVERS)) && eng_visible(v3(px, 2.8f, (L->z0 + L->z1) * 0.5f), (L->z1 - L->z0) * 0.5f + 1)) {
        pipe(v3(px, 2.85f, L->z0), v3(px, 2.85f, L->z1), 0.07f, pipeC);
        pipe(v3(px + 0.02f, 2.62f, L->z0), v3(px + 0.02f, 2.62f, L->z1), 0.045f, pipeC);
        float zd = L->z0 + (L->z1 - L->z0) * 0.62f;
        pipe(v3(px, 2.85f, zd), v3(px, 0, zd), 0.06f, pipeC);
        lbox(v3(px - 0.1f, 1.0f, zd - 0.1f), v3(px + 0.08f, 1.2f, zd + 0.1f), white, BX_ALL & ~BX_PX);
    }
    /* radiators under the windows */
    float zs[16];
    int n = window_spots(g, zs, 16);
    for (int i = 0; i < n; i++) {
        float z = zs[i], x = L->x0;
        if (!eng_visible(v3(x + 0.1f, 0.45f, z), 0.8f)) continue;
        int rad = has(g, TB(TH_WHITE) | TB(TH_OFFICE) | TB(TH_STAIRS));
        if (rad) lbox(v3(x + 0.04f, 0.14f, z - 0.55f), v3(x + 0.16f, 0.7f, z + 0.55f), white, BX_PX | BX_PY | BX_PZ | BX_NZ);
        for (int f = 0; rad && f < 9; f++) {
            float fz = z - 0.5f + f * 0.125f;
            lbox(v3(x + 0.16f, 0.17f, fz - 0.02f), v3(x + 0.19f, 0.67f, fz + 0.02f), white, BX_PX | BX_PZ | BX_NZ);
        }
        /* window sill */
        lbox(v3(x, WIN_Y0 - 0.06f, z - WIN_HW - 0.1f), v3(x + 0.14f, WIN_Y0, z + WIN_HW + 0.1f), white, BX_PX | BX_PY | BX_PZ | BX_NZ);
    }
    /* a doorway in the far wall, where they come in */
    float dx = (L->x0 + L->x1) * 0.5f, dz = L->z1 - 0.012f;
    if (indoor && eng_visible(v3(dx, 1.1f, dz), 1.5f)) {
        quad_col(v3(dx + 0.65f, 0, dz), v3(dx - 0.65f, 0, dz), v3(dx - 0.65f, 2.3f, dz), v3(dx + 0.65f, 2.3f, dz), door, 1, 1, 1, 1, E_NOCULL);
        lbox(v3(dx - 0.8f, 0, dz - 0.06f), v3(dx - 0.65f, 2.45f, dz), white, BX_NZ | BX_PX | BX_NX);
        lbox(v3(dx + 0.65f, 0, dz - 0.06f), v3(dx + 0.8f, 2.45f, dz), white, BX_NZ | BX_PX | BX_NX);
        lbox(v3(dx - 0.8f, 2.3f, dz - 0.06f), v3(dx + 0.8f, 2.45f, dz), white, BX_NZ | BX_NY | BX_PY);
    }
    /* pilasters: shallow columns running up the long walls, framing each window */
    for (float z = L->z0 + 1.6f - 1.6f; has(g, WINDOWED) && z <= L->z1 - 0.2f; z += 3.2f) {
        if (z < L->z0 + 0.2f) continue;
        if (eng_visible(v3(L->x0 + 0.1f, 1.6f, z), 1.7f)) lbox(v3(L->x0, 0, z - 0.14f), v3(L->x0 + 0.1f, WH, z + 0.14f), white, BX_PX | BX_PZ | BX_NZ);
        if (eng_visible(v3(L->x1 - 0.1f, 1.6f, z), 1.7f)) lbox(v3(L->x1 - 0.1f, 0, z - 0.14f), v3(L->x1, WH, z + 0.14f), white, BX_NX | BX_PZ | BX_NZ);
    }
    /* a cable tray hanging along the ceiling */
    if (has(g, TB(TH_WHITE) | TB(TH_SERVERS))) {
        float cx = L->x0 + (L->x1 - L->x0) * 0.3f;
        if (eng_visible(v3(cx, 2.85f, (L->z0 + L->z1) * 0.5f), (L->z1 - L->z0) * 0.5f + 1)) {
            lbox(v3(cx - 0.18f, 2.78f, L->z0), v3(cx + 0.18f, 2.82f, L->z1), white, BX_NY | BX_PX | BX_NX);
            lbox(v3(cx - 0.18f, 2.82f, L->z0), v3(cx - 0.16f, 2.9f, L->z1), white, BX_NX | BX_PX);
            lbox(v3(cx + 0.16f, 2.82f, L->z0), v3(cx + 0.18f, 2.9f, L->z1), white, BX_NX | BX_PX);
            for (float z = L->z0 + 1.0f; z < L->z1; z += 2.0f)
                lbox(v3(cx - 0.01f, 2.9f, z - 0.01f), v3(cx + 0.01f, WH, z + 0.01f), white, BX_PX | BX_NX | BX_PZ | BX_NZ);
        }
    }
    /* furniture round the counters: stools along them, a lamp hanging over each */
    static const float shade[3] = {0.96f, 0.98f, 1.0f};
    for (int i = 0; i < g->nbox; i++) {
        const Box *b = &g->box[i];
        if (b->kind != BOX_PROP || !indoor || th == TH_OFFICE) continue;
        V3 c = v3((b->x0 + b->x1) * 0.5f, b->h, (b->z0 + b->z1) * 0.5f);
        if (!eng_visible(c, (b->x1 - b->x0) + (b->z1 - b->z0) + 1.5f)) continue;
        /* pendant lamp: a cord, a cone shade and a glowing bottom */
        pipe(v3(c.x, WH, c.z), v3(c.x, 2.2f, c.z), 0.006f, shade);
        draw_quad(v3(c.x - 0.1f, 2.2f, c.z - 0.1f), v3(c.x + 0.1f, 2.2f, c.z - 0.1f), v3(c.x + 0.22f, 1.98f, c.z - 0.22f), v3(c.x - 0.22f, 1.98f, c.z - 0.22f), -1, 0, 0, 1, 1, shade, E_NOCULL);
        draw_quad(v3(c.x + 0.1f, 2.2f, c.z + 0.1f), v3(c.x - 0.1f, 2.2f, c.z + 0.1f), v3(c.x - 0.22f, 1.98f, c.z + 0.22f), v3(c.x + 0.22f, 1.98f, c.z + 0.22f), -1, 0, 0, 1, 1, shade, E_NOCULL);
        draw_quad(v3(c.x - 0.1f, 2.2f, c.z + 0.1f), v3(c.x - 0.1f, 2.2f, c.z - 0.1f), v3(c.x - 0.22f, 1.98f, c.z - 0.22f), v3(c.x - 0.22f, 1.98f, c.z + 0.22f), -1, 0, 0, 1, 1, shade, E_NOCULL);
        draw_quad(v3(c.x + 0.1f, 2.2f, c.z - 0.1f), v3(c.x + 0.1f, 2.2f, c.z + 0.1f), v3(c.x + 0.22f, 1.98f, c.z + 0.22f), v3(c.x + 0.22f, 1.98f, c.z - 0.22f), -1, 0, 0, 1, 1, shade, E_NOCULL);
        quad_col(v3(c.x - 0.21f, 1.985f, c.z - 0.21f), v3(c.x + 0.21f, 1.985f, c.z - 0.21f), v3(c.x + 0.21f, 1.985f, c.z + 0.21f), v3(c.x - 0.21f, 1.985f, c.z + 0.21f), lamp, 1, 1, 1, 1, E_EMIT | E_NOCULL);
        draw_billboard(v3(c.x, 1.95f, c.z), 0.7f, 0.5f, lamp, 0.45f, E_EMIT);
        /* stools along the long side facing you (only beside tall counters) */
        if (b->h < 0.9f || !has(g, TB(TH_BAR) | TB(TH_LOBBY) | TB(TH_WHITE))) continue;
        int alongX = (b->x1 - b->x0) > (b->z1 - b->z0);
        float len = alongX ? b->x1 - b->x0 : b->z1 - b->z0;
        for (float t = 0.45f; t < len - 0.2f; t += 0.75f) {
            V3 s = alongX ? v3(b->x0 + t, 0, b->z0 - 0.35f) : v3(b->x0 - 0.35f, 0, b->z0 + t);
            pipe(s, v3(s.x, 0.72f, s.z), 0.025f, shade);
            pipe(v3(s.x, 0.72f, s.z), v3(s.x, 0.78f, s.z), 0.17f, shade);
            pipe(v3(s.x, 0.02f, s.z), v3(s.x, 0.04f, s.z), 0.16f, shade);
            draw_blob(v3(s.x, 0.006f, s.z), 0.22f, 0.22f, 0.15f);
        }
    }
    /* server racks: rows of tiny status lights */
    static const float led1[3] = {0.4f, 0.95f, 1.0f}, led2[3] = {1.0f, 0.3f, 0.25f};
    for (int i = 0; i < g->nbox; i++) {
        const Box *b = &g->box[i];
        if (b->kind != BOX_DARK || th == TH_SERVERS) continue;
        if (!eng_visible(v3((b->x0 + b->x1) * 0.5f, 1.1f, (b->z0 + b->z1) * 0.5f), (b->z1 - b->z0) * 0.5f + 1.2f)) continue;
        for (int side = 0; side < 2; side++) {
            float x = side ? b->x1 + 0.004f : b->x0 - 0.004f;
            for (float z = b->z0 + 0.2f; z < b->z1 - 0.1f; z += 0.45f)
                for (float y = 0.4f; y < b->h - 0.2f; y += 0.28f) {
                    unsigned h = (unsigned)((int)(z * 31) * 7 + (int)(y * 17) + side * 3) * 2654435761u;
                    int on = ((h >> 20) + (unsigned)(g->gtime * 3)) % 5 != 0;
                    if (!on) continue;
                    const float *lc = ((h >> 8) & 7) == 0 ? led2 : led1;
                    float sz = 0.018f;
                    quad_col(v3(x, y, z), v3(x, y, z + sz), v3(x, y + sz, z + sz), v3(x, y + sz, z), lc, 1, 1, 1, 1, E_EMIT | E_NOCULL);
                }
        }
    }
    /* skirting along the long walls */
    if (indoor) lbox(v3(L->x1 - 0.03f, 0, L->z0), v3(L->x1, 0.12f, L->z1), white, BX_NX | BX_PY);
}

static void draw_rooms(const Game *g) {
    const Level *L = &levels[g->level];
    static const float floorC[3] = {0.94f, 0.96f, 0.98f};
    static const float wallC[3] = {1.0f, 1.0f, 1.0f};
    static const float propC[3] = {0.98f, 0.99f, 1.0f};
    static const float pillarC[3] = {1.0f, 1.0f, 1.0f};
    static const float greyC[3] = {0.72f, 0.78f, 0.84f};
    int th = theme_of(g);
    {
        /* the floor: pale tiles indoors, concrete in the car park, asphalt outside, raised tiles by the servers */
        static const float concC[3] = {0.85f, 0.87f, 0.9f}, roadC[3] = {0.8f, 0.83f, 0.87f}, trainC[3] = {0.83f, 0.87f, 0.91f}, srvC[3] = {0.88f, 0.92f, 0.97f};
        int tex = T_FLOOR; float rep = 0.5f; const float *fc = floorC;
        if (th == TH_GARAGE) { tex = -1; fc = concC; }
        else if (th == TH_STREET) { tex = -1; fc = roadC; }
        else if (th == TH_TRAIN) { tex = -1; fc = trainC; }
        else if (th == TH_SERVERS) { rep = 1.0f; fc = srvC; }
        draw_box_tex(v3(L->x0 - 0.3f, -0.2f, L->z0 - 0.3f), v3(L->x1 + 0.3f, 0, L->z1 + 0.3f), tex, rep, fc, BX_PY);
    }
    for (int i = 0; i < g->nbox; i++) {
        const Box *b = &g->box[i];
        if (b->kind >= BOX_CAR) {
            decor_box(g, b, i);
            /* contact shade round things that stand on the floor */
            if (b->kind == BOX_POLE || b->kind == BOX_PLANT || b->kind == BOX_FACADE || b->kind == BOX_STAIRS) continue;
            if (!eng_visible(v3((b->x0 + b->x1) * 0.5f, 0, (b->z0 + b->z1) * 0.5f), (b->x1 - b->x0) + (b->z1 - b->z0))) continue;
            float w = 0.2f;
            base_shade(v3(b->x0, 0, b->z0), v3(b->x1, 0, b->z0), v3(0, 0, -w));
            base_shade(v3(b->x1, 0, b->z1), v3(b->x0, 0, b->z1), v3(0, 0, w));
            base_shade(v3(b->x0, 0, b->z1), v3(b->x0, 0, b->z0), v3(-w, 0, 0));
            base_shade(v3(b->x1, 0, b->z0), v3(b->x1, 0, b->z1), v3(w, 0, 0));
            continue;
        }
        V3 lo = v3(b->x0, 0, b->z0), hi = v3(b->x1, b->h, b->z1);
        V3 c = vmul(vadd(lo, hi), 0.5f);
        if (!eng_visible(c, vlen(vsub(hi, lo)) * 0.5f + 0.4f)) continue;
        int faces = BX_ALL & ~BX_NY;
        switch (b->kind) {
        case BOX_WALL: draw_box_tex(lo, hi, T_WALL, 0.5f, wallC, faces); break;
        case BOX_PROP:
            if (g->setQuality) {
                /* a counter: an overhanging top, the body set back, a shadowed kick plate */
                static const float kick[3] = {0.7f, 0.76f, 0.83f};
                float in = 0.05f;
                draw_box_tex(v3(lo.x, hi.y - 0.07f, lo.z), hi, T_PANEL, 1.0f, propC, faces);
                draw_box_tex(v3(lo.x + in, 0.1f, lo.z + in), v3(hi.x - in, hi.y - 0.07f, hi.z - in), T_PANEL, 1.0f, propC, faces & ~BX_PY);
                draw_box_tex(v3(lo.x + in + 0.04f, 0, lo.z + in + 0.04f), v3(hi.x - in - 0.04f, 0.1f, hi.z - in - 0.04f), T_PANEL, 1.0f, kick, faces & ~BX_PY);
            } else draw_box_tex(lo, hi, T_PANEL, 1.0f, propC, faces);
            break;
        case BOX_PILLAR:
            draw_box_tex(lo, hi, T_WALL, 0.5f, pillarC, faces);
            if (g->setQuality) {
                /* a plinth and a capital */
                float e = 0.06f;
                draw_box_tex(v3(lo.x - e, 0, lo.z - e), v3(hi.x + e, 0.22f, hi.z + e), T_PANEL, 1.0f, pillarC, faces);
                draw_box_tex(v3(lo.x - e, hi.y - 0.3f, lo.z - e), v3(hi.x + e, hi.y - 0.18f, hi.z + e), T_PANEL, 1.0f, pillarC, faces | BX_NY);
            }
            break;
        default:
            if (th == TH_SERVERS) decor_rack(g, b);
            else draw_box_tex(lo, hi, T_GRID, 0.5f, greyC, faces);   /* grey: not glass, does not break */
            break;
        }
        /* contact shade round the bottom */
        float w = b->kind == BOX_PROP ? 0.25f : 0.38f;
        base_shade(v3(b->x0, 0, b->z0), v3(b->x1, 0, b->z0), v3(0, 0, -w));
        base_shade(v3(b->x1, 0, b->z1), v3(b->x0, 0, b->z1), v3(0, 0, w));
        base_shade(v3(b->x0, 0, b->z1), v3(b->x0, 0, b->z0), v3(-w, 0, 0));
        base_shade(v3(b->x1, 0, b->z0), v3(b->x1, 0, b->z1), v3(w, 0, 0));
    }
    draw_windows(g);
    draw_details(g);
    decor_shell(g);
}

/* ================= glass things, guns, bullets ================= */

static void draw_props(const Game *g) {
    V3 w[300];
    for (int i = 0; i < g->nprop; i++) {
        const Prop *p = &g->prop[i];
        if (!p->active) continue;
        if (!eng_visible(vadd(p->pos, v3(0, p->h * 0.5f, 0)), p->h)) continue;
        int nt = prop_tris(p, w, 300);
        tris_draw(w, nt, GLASS_BLACK, SH_BLACK, (unsigned)i * 97u);
        draw_blob(v3(p->pos.x, p->pos.y + 0.004f, p->pos.z), p->r * 1.6f, p->r * 1.6f, 0.2f);
    }
}

/* any weapon (or a held bottle) at x: the pistol is the smooth uploaded model, the rest are faceted */
static void draw_weapon(int kind, int sub, float r, float h, const Xf *x, unsigned seed) {
    if (kind == WP_PISTOL || kind == WP_NONE) { mesh_draw(M_GUN, x, GLASS_BLACK, SH_BLACK, 1, 0); return; }
    if (kind != WP_PROP) {
        const Mesh *M = weapon_mesh(kind);
        if (M) { mesh_draw_m(M, x, GLASS_BLACK, SH_BLACK, 1, 0); return; }
    }
    static V3 w[400 * 3];
    V3 c = x->t;
    if (!eng_visible(c, 1.0f)) return;
    int nt = weapon_tris(kind, sub, r, h, x, w, 400 * 3);
    tris_draw(w, nt, GLASS_BLACK, SH_BLACK, seed);
}

static void draw_pickups(const Game *g) {
    for (int i = 0; i < MAX_PICKUPS; i++) {
        const Pickup *k = &g->pk[i];
        if (!k->active) continue;
        Xf x;
        pickup_xf(g, k, &x);
        if (!k->flying) {
            /* a soft pulse under it so you can spot it */
            float pulse = 0.18f + 0.1f * sinf(g->time * 4 + i);
            draw_blob(v3(k->pos.x, k->rest - 0.025f, k->pos.z), 0.3f, 0.3f, pulse);
        }
        draw_weapon(k->kind, k->sub, k->r, k->h, &x, (unsigned)i * 31u);
    }
}

static void draw_casings(const Game *g) {
    static const float cc[3] = {0.16f, 0.15f, 0.12f};
    for (int i = 0; i < MAX_CASINGS; i++) {
        const Casing *c = &g->cas[i];
        if (!c->active || !eng_visible(c->pos, 0.05f)) continue;
        Xf x = xf_at(c->pos, c->yaw + PI * 0.5f, 1), r, s;
        xf_rot(&r, v3(1, 0, 0), c->ang);
        xf_mul(&s, &x, &r);
        xbox(&s, v3(-0.006f, -0.006f, -0.014f), v3(0.006f, 0.006f, 0.014f), cc, SH_BLACK);
    }
}

/* a camera-facing ribbon from a to b, fading from aa at a to ab at b */
static void ribbon(V3 a, V3 b, float wa, float wb, const float col[3], float aa, float ab) {
    V3 d = vsub(b, a);
    V3 mid = vmul(vadd(a, b), 0.5f);
    V3 side = vcross(d, vsub(cam.eye, mid));
    float l = vlen(side);
    if (l < 1e-6f) return;
    side = vmul(side, 1 / l);
    quad_col(vadd(a, vmul(side, wa)), vsub(a, vmul(side, wa)), vsub(b, vmul(side, wb)), vadd(b, vmul(side, wb)), col, aa, aa, ab, ab, E_TRANS | E_EMIT | E_NOCULL);
}

static void draw_bullets(const Game *g) {
    static const float trail[3] = {1.0f, 0.12f, 0.06f};
    static const float hot[3] = {1.0f, 0.55f, 0.4f};
    static const float slug[3] = {0.1f, 0.09f, 0.09f};
    for (int i = 0; i < MAX_BULLETS; i++) {
        const Bullet *b = &g->bul[i];
        if (!b->active) continue;
        V3 dir = vnorm(b->vel);
        float travelled = vlen(vsub(b->pos, b->start));
        float len = travelled < 6.0f ? travelled : 6.0f;
        V3 tail = vsub(b->pos, vmul(dir, len));
        V3 midp = vsub(b->pos, vmul(dir, len * 0.3f));
        /* the red trail: long and faint, bright near the bullet, a hot core right behind it */
        ribbon(tail, midp, 0.005f, 0.02f, trail, 0.0f, 0.55f);
        ribbon(midp, b->pos, 0.02f, 0.028f, trail, 0.55f, 0.95f);
        ribbon(vsub(b->pos, vmul(dir, 0.35f)), b->pos, 0.004f, 0.01f, hot, 0.0f, 0.9f);
        /* the bullet: a small dark slug that spins along its path */
        float yaw = atan2f(dir.z, dir.x), pitch = -asinf(clampf(dir.y, -1, 1));
        Xf x = xf_at(b->pos, yaw, 1), p, r, o;
        xf_rot(&p, v3(1, 0, 0), pitch);
        xf_rot(&r, v3(0, 0, 1), g->gtime * 40 + i);
        Xf t; xf_mul(&t, &x, &p); xf_mul(&o, &t, &r);
        xbox(&o, v3(-0.012f, -0.012f, -0.03f), v3(0.012f, 0.012f, 0.025f), slug, SH_BLACK);
    }
}

static void draw_shards(const Game *g) {
    for (int i = 0; i < MAX_SHARDS; i++) {
        const Shard *s = &g->sh[i];
        if (!s->active) continue;
        if (!eng_visible(s->c, 0.4f)) continue;
        float sc = s->life < 1.5f ? s->life / 1.5f : 1;
        Xf x;
        xf_rot(&x, s->axis, s->ang);
        x.t = s->c;
        x.s = sc;
        const float *q = g->shardTri + s->t0 * 9;
        V3 w[SHARD_MAX_TRIS * 3];
        int n = 0;
        for (int t = 0; t < s->nt && t < SHARD_MAX_TRIS; t++, q += 9) {
            w[n++] = xf_point(&x, v3(q[0], q[1], q[2]));
            w[n++] = xf_point(&x, v3(q[3], q[4], q[5]));
            w[n++] = xf_point(&x, v3(q[6], q[7], q[8]));
        }
        int style = s->col[0] > 0.3f ? SH_RED : SH_BLACK;
        tris_draw(w, n / 3, s->col, style, (unsigned)i * 31u);
    }
}

/* glitter: tiny spinning splinters that catch the light, and the flash where glass breaks */
static void draw_sparks(const Game *g) {
    for (int i = 0; i < MAX_SPARKS; i++) {
        const Spark *p = &g->spark[i];
        if (!p->active || !eng_visible(p->pos, 0.3f)) continue;
        if (p->flash) {
            float k = p->life / 0.16f;
            static const float fc[3] = {1.0f, 0.97f, 0.95f};
            draw_billboard(p->pos, p->size * (1.6f - 0.6f * k), p->size * (1.6f - 0.6f * k), fc, 0.8f * k, E_EMIT);
            continue;
        }
        /* a little triangle, turning, flashing white as it faces the light */
        float tw = 0.5f + 0.5f * sinf(p->spin * 2.3f);
        float c[3] = {p->col[0] + (1 - p->col[0]) * tw * tw * 0.8f, p->col[1] + (1 - p->col[1]) * tw * tw * 0.8f, p->col[2] + (1 - p->col[2]) * tw * tw * 0.8f};
        V3 r = vmul(cam.r, p->size), u = vmul(cam.u, p->size);
        float a = p->spin;
        V3 A = vadd(p->pos, vadd(vmul(r, cosf(a)), vmul(u, sinf(a))));
        V3 B = vadd(p->pos, vadd(vmul(r, cosf(a + 2.2f) * 0.7f), vmul(u, sinf(a + 2.2f) * 0.7f)));
        V3 C = vadd(p->pos, vadd(vmul(r, cosf(a + 4.0f) * 0.9f), vmul(u, sinf(a + 4.0f) * 0.9f)));
        emit_tri(A, B, C, c, 1, E_EMIT | E_NOCULL);
    }
}

static void draw_dust(const Game *g) {
    static const float dc[3] = {0.85f, 0.87f, 0.9f};
    for (int i = 0; i < MAX_DUST; i++) {
        const Dust *d = &g->dust[i];
        if (!d->active) continue;
        draw_billboard(d->pos, d->size * (2 - d->life), d->size * (2 - d->life), dc, 0.7f * d->life, 0);
    }
}

/* ================= your arms: the same glass man, in black ================= */

/* a transform whose local -y (down the forearm) points along d */
static Xf along(V3 at, V3 d, V3 upHint) {
    Xf x;
    xf_ident(&x);
    V3 y = vmul(vnorm(d), -1);
    V3 z = vsub(upHint, vmul(y, vdot(upHint, y)));
    z = vnorm(z);
    V3 xx = vcross(y, z);
    /* columns are the images of the local axes */
    x.m[0] = xx.x; x.m[3] = xx.y; x.m[6] = xx.z;
    x.m[1] = y.x;  x.m[4] = y.y;  x.m[7] = y.z;
    x.m[2] = z.x;  x.m[5] = z.y;  x.m[8] = z.z;
    x.t = at;
    x.s = 1;
    return x;
}

/* the tip of a forearm mesh (its hand end), relative to the elbow joint */
static V3 mesh_tip(int id) {
    static V3 tip[M_COUNT];
    static int done[M_COUNT];
    if (done[id]) return tip[id];
    const Mesh *M = &meshes[id];
    V3 s = v3(0, 0, 0);
    int n = 0;
    for (int i = 0; i < M->nt * 3; i++)
        if (M->v[i * 3 + 1] < M->lo[1] + 0.05f) { s = vadd(s, v3(M->v[i * 3], M->v[i * 3 + 1], M->v[i * 3 + 2])); n++; }
    tip[id] = n ? vmul(s, 1.0f / n) : v3(0, -0.35f, 0);
    done[id] = 1;
    return tip[id];
}

/* forearm and hand ending at 'hand' (view space), coming from the direction of 'from' */
static void view_arm(const Xf *view, int id, V3 hand, V3 from, float roll, int fist) {
    V3 d = vnorm(vsub(hand, from));
    V3 up = vnorm(v3(sinf(roll), cosf(roll), 0.2f));
    /* turn the mesh so its elbow-to-hand line lies along d, with the hand right on 'hand' */
    V3 tip = mesh_tip(id);
    V3 la = vnorm(tip), lb = vnorm(vsub(v3(0, 0, 1), vmul(la, la.z))), lc = vcross(la, lb);
    V3 wa = d, wb = vnorm(vsub(up, vmul(wa, vdot(up, wa)))), wc = vcross(wa, wb);
    Xf l;
    xf_ident(&l);
    /* R = W * L^T: maps la->wa, lb->wb, lc->wc */
    float L[3][3] = {{la.x, lb.x, lc.x}, {la.y, lb.y, lc.y}, {la.z, lb.z, lc.z}};
    float W[3][3] = {{wa.x, wb.x, wc.x}, {wa.y, wb.y, wc.y}, {wa.z, wb.z, wc.z}};
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) l.m[i * 3 + j] = W[i][0] * L[j][0] + W[i][1] * L[j][1] + W[i][2] * L[j][2];
    l.s = 1;
    l.t = v3(0, 0, 0);
    V3 rt = xf_point(&l, tip);
    l.t = vsub(hand, rt);
    Xf o;
    xf_mul(&o, view, &l);
    mesh_draw(id, &o, GLASS_BLACK, SH_BLACK, 1, 0);
    if (!fist) return;
    /* a clenched fist on the end, faceted like the rest of the body */
    Xf f = along(hand, d, up), fo;
    xf_mul(&fo, view, &f);
    xbox(&fo, v3(-0.03f, -0.045f, -0.026f), v3(0.03f, 0.012f, 0.028f), GLASS_BLACK, SH_BLACK);
    xbox(&fo, v3(-0.027f, -0.056f, -0.014f), v3(0.027f, -0.04f, 0.032f), GLASS_BLACK, SH_BLACK);
}

static V3 vlerp3(V3 a, V3 b, float t) { return vadd(a, vmul(vsub(b, a), t)); }

static void draw_held(const Game *g) {
    if (g->mode == MODE_DEAD) return;
    const Player *P = &g->pl;
    /* your own glass body in black: only the arms, from the shoulders down */
    Xf parts[BODY_PARTS];
    player_fp_parts(g, parts);
    skinFists = 1;
    body_draw_parts(parts, g->setQuality ? 0 : BODY_LODS - 1, GLASS_BLACK, SH_BLACK, 1, M_UARM_L, M_FARM_R + 1, 1);
    skinFists = 0;
    if (!P->hasGun) return;
    Xf gx = player_gun_xf(g);
    draw_weapon(P->weapon, P->sub, P->heldR, P->heldH, &gx, 7u);
    /* the slide snaps back after a shot */
    if (P->weapon == WP_PISTOL && P->slide > 0.01f) {
        static const float sc[3] = {0.12f, 0.12f, 0.13f};
        xbox(&gx, v3(-0.011f, 0.018f, 0.02f - 0.035f * P->slide), v3(0.011f, 0.036f, 0.16f - 0.035f * P->slide), sc, SH_BLACK);
    }
    if (g->flashT > 0) {
        static const float fc[3] = {1.0f, 0.95f, 0.8f};
        V3 m = weapon_muzzle(P->weapon);
        m.z += 0.05f;
        V3 mz = xf_point(&gx, m);
        float fs = P->weapon == WP_SHOTGUN ? 0.3f : 0.18f;
        draw_billboard(mz, fs, fs, fc, 0.95f, E_EMIT);
    }
}

/* ================= the frame ================= */

void world_build(void *ctx) {
    G = (const Game *)ctx;
    const Game *g = G;
    world_camera(g, &cam);
    /* dying: the frozen moment drains to black and white */
    eng_set_desat(g->mode == MODE_DEAD ? clampf(g->modeT * 4, 0, 1) : 0);
    if (!in_world(g)) return;
    glassDeep = g->setQuality != 0;
    memset(framePosed, 0, sizeof framePosed);
#ifdef NODEEP
    glassDeep = 0;
#endif
#ifdef HOST
    extern int bench_phases;
    clock_t k0 = clock();
    int t0 = engTris;
    draw_rooms(g);
    clock_t k1 = clock(); int t1 = engTris;
    draw_shadows(g);
    clock_t k2 = clock(); int t2 = engTris;
    for (int i = 0; i < g->nen; i++) draw_enemy(g, &g->en[i]);
    clock_t k3 = clock(); int t3 = engTris;
    if (bench_phases) {
        /* time one more round of each, many times, for stable numbers */
        int N = 100;
        clock_t a = clock(); for (int i = 0; i < N; i++) draw_rooms(g);
        clock_t b = clock(); for (int i = 0; i < N; i++) draw_shadows(g);
        clock_t c = clock(); for (int i = 0; i < N; i++) for (int e = 0; e < g->nen; e++) draw_enemy(g, &g->en[e]);
        clock_t d = clock();
        printf("  rooms %.3f ms (%d tris)  shadows %.3f ms (%d)  enemies %.3f ms (%d)\n",
               (double)(b - a) / CLOCKS_PER_SEC / N * 1000, t1 - t0, (double)(c - b) / CLOCKS_PER_SEC / N * 1000, t2 - t1,
               (double)(d - c) / CLOCKS_PER_SEC / N * 1000, t3 - t2);
    }
    (void)k0; (void)k1; (void)k2; (void)k3;
#else
    draw_rooms(g);
    draw_shadows(g);
    for (int i = 0; i < g->nen; i++) draw_enemy(g, &g->en[i]);
#endif
    draw_props(g);
    draw_pickups(g);
    draw_casings(g);
    /* your arms, the gun and bullets first: if a huge burst of glass ever fills the triangle
     * budget, it is the furthest-down shards that get left out, never these */
    draw_held(g);
    draw_bullets(g);
    draw_sparks(g);
    draw_dust(g);
    draw_shards(g);
}

void render_sw_top(const Game *g, unsigned short *out) {
    Cam c;
    world_lights(g);
    world_camera(g, &c);
    eng_begin(&c, 0);
    unsigned cl = world_clear(g);
    unsigned short bg = col565((cl >> 16) & 255, (cl >> 8) & 255, cl & 255);
    for (int i = 0; i < RW * RH; i++) swTop[i] = bg;
    world_build((void *)g);
    for (int y = 0; y < 240; y++)
        for (int x = 0; x < 400; x++) out[y * 400 + x] = swTop[(y >> 1) * RW + (x >> 1)];
}
