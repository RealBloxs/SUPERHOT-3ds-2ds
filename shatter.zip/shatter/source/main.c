/* SUPERHOT - 3DS platform layer: screens (with stereoscopic 3D), input, sound, saving.
 * Works on Old 3DS, New 3DS and 2DS (2DS just shows the normal picture). */
#include <3ds.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include "game.h"
#include "gpu.h"

#define AFRAMES 512
#define ABUFS 4

static unsigned short topBuf[400 * 240];
static unsigned short botBuf[BW * BH];
static unsigned short hudBuf[HW * HH];
static Game game;

/* 400x240 image -> framebuffer (rotated: pixel (x,y) at fb[x*240 + 239-y]) */
static void blit_top(gfx3dSide_t side, int hudOn) {
    u16 *fb = (u16 *)gfxGetFramebuffer(GFX_TOP, side, NULL, NULL);
    for (int x = 0; x < 400; x++) {
        u16 *col = fb + x * 240;
        for (int y = 0; y < 240; y++) {
            u16 p = topBuf[y * 400 + x];
            if (hudOn) {
                unsigned short h = hudBuf[y * 400 + x];
                int a = h & 15;
                if (a) {
                    int hr = (h >> 12) * 17, hg = ((h >> 8) & 15) * 17, hb = ((h >> 4) & 15) * 17;
                    int r = ((p >> 11) & 31) << 3, g = ((p >> 5) & 63) << 2, b = (p & 31) << 3;
                    r += (hr - r) * a / 15;
                    g += (hg - g) * a / 15;
                    b += (hb - b) * a / 15;
                    p = (u16)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
                }
            }
            col[239 - y] = p;
        }
    }
}

static void blit_bottom(void) {
    u16 *fb = (u16 *)gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, NULL, NULL);
    for (int x = 0; x < BW; x++) {
        u16 *col = fb + x * 240;
        for (int y = 0; y < BH; y++) col[239 - y] = botBuf[y * BW + x];
    }
}

static unsigned map_keys(u32 k) {
    unsigned b = 0;
    if (k & KEY_A) b |= BTN_A;
    if (k & KEY_B) b |= BTN_B;
    if (k & KEY_X) b |= BTN_X;
    if (k & KEY_Y) b |= BTN_Y;
    if (k & KEY_L) b |= BTN_L;
    if (k & KEY_R) b |= BTN_R;
    if (k & KEY_START) b |= BTN_START;
    if (k & KEY_SELECT) b |= BTN_SELECT;
    if (k & KEY_DLEFT) b |= BTN_DLEFT;
    if (k & KEY_DRIGHT) b |= BTN_DRIGHT;
    if (k & KEY_DUP) b |= BTN_DUP;
    if (k & KEY_DDOWN) b |= BTN_DDOWN;
    if (k & KEY_ZL) b |= BTN_ZL;
    if (k & KEY_ZR) b |= BTN_ZR;
    if (k & KEY_TOUCH) b |= BTN_TOUCH;
    return b;
}

/* ---- saving ----
 * Progress lives in the game's own save data when installed as a CIA ("save:/"),
 * otherwise in sdmc:/3ds/shatter/. A tiny settings file on the SD card remembers the
 * renderer: if the hardware renderer never showed a picture last time, use the classic one. */
#define CFG_PATH "sdmc:/3ds/shatter_gpu.bin"
static int saveTrying, cfgGpuPref = 1, useSaveData;
static char savePath[64];

static void write_cfg(void) {
    mkdir("sdmc:/3ds", 0777);
    FILE *f = fopen(CFG_PATH, "wb");
    if (!f) return;
    int v[2] = {saveTrying, cfgGpuPref};
    fwrite(v, sizeof(int), 2, f);
    fclose(f);
}

static void read_cfg(void) {
    FILE *f = fopen(CFG_PATH, "rb");
    if (!f) return;
    int v[2] = {0, 1};
    if (fread(v, sizeof(int), 2, f) == 2) {
        saveTrying = v[0] == 1;
        cfgGpuPref = v[1] != 0;
    }
    fclose(f);
}

static void storage_init(void) {
    mkdir("sdmc:/3ds", 0777);
    if (R_SUCCEEDED(archiveMount(ARCHIVE_SAVEDATA, fsMakePath(PATH_EMPTY, ""), "save"))) {
        useSaveData = 1;
        strcpy(savePath, "save:/progress.bin");
    } else {
        mkdir("sdmc:/3ds/shatter", 0777);
        strcpy(savePath, "sdmc:/3ds/shatter/progress.bin");
    }
}

static void load_progress(Game *g) {
    unsigned char buf[256];
    FILE *f = fopen(savePath, "rb");
    if (!f) return;
    int n = (int)fread(buf, 1, sizeof buf, f);
    fclose(f);
    game_load_bytes(g, buf, n);
}

static void save_progress(Game *g) {
    if (!g->saveDirty) return;
    g->saveDirty = 0;
    unsigned char buf[256];
    int n = game_save_bytes(g, buf, sizeof buf);
    if (n <= 0) return;
    FILE *f = fopen(savePath, "wb");
    if (!f) return;
    fwrite(buf, 1, n, f);
    fclose(f);
    if (useSaveData) archiveCommitSaveData("save");
}

static int top_has_picture(void) {
    u16 *fb = (u16 *)gfxGetFramebuffer(GFX_TOP, GFX_LEFT, NULL, NULL);
    if (!fb) return 0;
    GSPGPU_InvalidateDataCache(fb, 240 * 400 * 2);
    int lit = 0;
    for (int i = 0; i < 240 * 400; i += 97)
        if (fb[i]) lit++;
    return lit > 20;
}

int main(void) {
    gfxInit(GSP_RGB565_OES, GSP_RGB565_OES, false);
    gfxSetDoubleBuffering(GFX_TOP, true);
    gfxSetDoubleBuffering(GFX_BOTTOM, true);
    gfxSet3D(false);
    bool stereoOn = false;
    osSetSpeedupEnable(true);

    audio_init();
    bool soundOk = R_SUCCEEDED(ndspInit());
    ndspWaveBuf wbuf[ABUFS];
    s16 *abuf = NULL;
    if (soundOk) {
        ndspSetOutputMode(NDSP_OUTPUT_STEREO);
        ndspChnReset(0);
        ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
        ndspChnSetRate(0, AUDIO_RATE);
        ndspChnSetFormat(0, NDSP_FORMAT_STEREO_PCM16);
        float mix[12];
        memset(mix, 0, sizeof(mix));
        mix[0] = mix[1] = 1.0f;
        ndspChnSetMix(0, mix);
        abuf = (s16 *)linearAlloc(ABUFS * AFRAMES * 2 * sizeof(s16));
        if (!abuf) soundOk = false;
    }
    if (soundOk) {
        memset(wbuf, 0, sizeof(wbuf));
        for (int i = 0; i < ABUFS; i++) {
            wbuf[i].data_pcm16 = abuf + i * AFRAMES * 2;
            wbuf[i].nsamples = AFRAMES;
            audio_mix(wbuf[i].data_pcm16, AFRAMES);
            DSP_FlushDataCache(wbuf[i].data_pcm16, AFRAMES * 2 * sizeof(s16));
            ndspChnWaveBufAdd(0, &wbuf[i]);
        }
    }

    storage_init();
    read_cfg();
    /* replays can be big, so they live on the SD card */
    mkdir("sdmc:/3ds/shatter", 0777);
    mkdir("sdmc:/3ds/shatter/replays", 0777);
    strcpy(game.replayDir, "sdmc:/3ds/shatter/replays/");
    game_boot(&game, (unsigned)osGetTime() | 1);
    load_progress(&game);

    hidScanInput();
    if (saveTrying) cfgGpuPref = 0;
    int useGpu = cfgGpuPref && !(hidKeysHeld() & KEY_L);
    if (useGpu) {
        saveTrying = 1;
        write_cfg();
        gfxSetDoubleBuffering(GFX_BOTTOM, false);
        if (!gpu_init()) {
            useGpu = 0;
            gfxSetDoubleBuffering(GFX_BOTTOM, true);
        }
    }
    if (!useGpu && saveTrying) {
        saveTrying = 0;
        cfgGpuPref = 0;
        write_cfg();
    }
    int gpuChecked = 0, gpuFrames = 0, blackFrames = 0;
    game.gpu = useGpu;

    u64 last = osGetTime();
    int frame = 0;
    unsigned prevHeld = 0;
    while (aptMainLoop()) {
        hidScanInput();
        u32 held = hidKeysHeld();
        circlePosition cp;
        hidCircleRead(&cp);

        Input in;
        in.held = map_keys(held);
        in.pressed = in.held & ~prevHeld;
        in.released = prevHeld & ~in.held;
        prevHeld = in.held;
        float sx = cp.dx / 150.0f, sy = cp.dy / 150.0f;
        if (sx > 1) sx = 1;
        if (sx < -1) sx = -1;
        if (sy > 1) sy = 1;
        if (sy < -1) sy = -1;
        if (sx > -0.12f && sx < 0.12f) sx = 0;
        if (sy > -0.12f && sy < 0.12f) sy = 0;
        in.sx = sx;
        in.sy = sy;
        static int lastTx, lastTy;
        if (held & KEY_TOUCH) {
            touchPosition tp;
            hidTouchRead(&tp);
            lastTx = tp.px;
            lastTy = tp.py;
        }
        in.tx = lastTx;
        in.ty = lastTy;

        u64 now = osGetTime();
        float dt = (now - last) / 1000.0f;
        last = now;
        if (dt <= 0) dt = 1.0f / 60;

        game_update(&game, &in, dt);
        save_progress(&game);
        if (game.quit) break;

        float slider = osGet3DSliderState();
        bool want3D = slider > 0.02f;
        if (want3D != stereoOn) {
            gfxSet3D(want3D);
            stereoOn = want3D;
        }
        int hudOn = render_hud(&game, hudBuf);
        if (useGpu) {
            if ((frame & 1) == 0) {
                render_bottom(&game, botBuf);
                blit_bottom();
                u16 *fb = (u16 *)gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, NULL, NULL);
                GSPGPU_FlushDataCache(fb, 320 * 240 * 2);
            }
            frame++;
            Cam cam;
            world_lights(&game);
            world_camera(&game, &cam);
            gpu_set_aa(game.setAA);
            gpu_frame(world_build, &game, &cam, hudBuf, hudOn, world_clear(&game), stereoOn ? slider : 0);
            if (!gpuChecked && ++gpuFrames > 3) {
                if (top_has_picture()) {
                    gpuChecked = 1;
                    saveTrying = 0;
                    write_cfg();
                } else if (++blackFrames > 45) {
                    gpu_exit();
                    useGpu = 0;
                    game.gpu = 0;
                    cfgGpuPref = 0;
                    saveTrying = 0;
                    write_cfg();
                    gfxSetDoubleBuffering(GFX_TOP, true);
                    gfxSetDoubleBuffering(GFX_BOTTOM, true);
                }
            }
        } else {
            render_sw_top(&game, topBuf);
            blit_top(GFX_LEFT, hudOn);
            if (stereoOn) blit_top(GFX_RIGHT, hudOn);
            if ((frame & 1) == 0) render_bottom(&game, botBuf);
            blit_bottom();
            frame++;
        }

        if (soundOk) {
            for (int i = 0; i < ABUFS; i++) {
                if (wbuf[i].status == NDSP_WBUF_DONE) {
                    audio_mix(wbuf[i].data_pcm16, AFRAMES);
                    DSP_FlushDataCache(wbuf[i].data_pcm16, AFRAMES * 2 * sizeof(s16));
                    ndspChnWaveBufAdd(0, &wbuf[i]);
                }
            }
        }

        if (!useGpu) {
            gfxFlushBuffers();
            gfxSwapBuffers();
            gspWaitForVBlank();
        }
    }
    save_progress(&game);
    if (useSaveData) archiveUnmount("save");
    if (useGpu) gpu_exit();
    if (soundOk) {
        ndspChnWaveBufClear(0);
        ndspExit();
    }
    if (abuf) linearFree(abuf);
    gfxExit();
    return 0;
}
