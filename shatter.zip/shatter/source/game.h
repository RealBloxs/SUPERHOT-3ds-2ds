/* SUPERHOT - a first-person "time moves only when you move" shooter for 2DS/3DS.
 * Everyone is made of glass: one hit and they shatter. */
#ifndef GAME_H
#define GAME_H
#include "engine.h"
#include "models.h"
#include "assets.h"

#define PI 3.14159265f

/* screens */
#define HW 400
#define HH 240
#define BW 320
#define BH 240

/* buttons */
enum {
    BTN_A = 1, BTN_B = 2, BTN_X = 4, BTN_Y = 8, BTN_L = 16, BTN_R = 32, BTN_START = 64, BTN_SELECT = 128,
    BTN_DLEFT = 256, BTN_DRIGHT = 512, BTN_DUP = 1024, BTN_DDOWN = 2048, BTN_TOUCH = 4096, BTN_ZL = 8192, BTN_ZR = 16384
};
typedef struct { unsigned held, pressed, released; float sx, sy; int tx, ty; } Input;

/* how long a level takes to build itself in from pixels when it opens */
extern float loadWipeT;
enum { MODE_BOOT, MODE_MENU, MODE_PLAY, MODE_DEAD, MODE_WIN, MODE_PAUSE, MODE_CHAT, MODE_HACK };

/* ---------------- levels ---------------- */
/* everything solid in a level is an upright box; the kind says what it looks like.
 * dir is where its front faces (sofa seat, car nose, stairs going up, shelf front): 0 +z, 1 -z, 2 +x, 3 -x */
enum { BOX_WALL, BOX_PROP, BOX_PILLAR, BOX_DARK, BOX_CAR, BOX_SOFA, BOX_DESK, BOX_SHELF, BOX_PLANT, BOX_CRATE,
       BOX_PEDESTAL, BOX_STAIRS, BOX_PART, BOX_POLE, BOX_FACADE, BOX_KINDS };
typedef struct { float x0, z0, x1, z1, h; int kind, dir; } Box;
/* the kind of place a level is set in */
enum { TH_WHITE, TH_LOBBY, TH_BAR, TH_TRAIN, TH_ELEVATOR, TH_OFFICE, TH_GARAGE, TH_STREET, TH_STAIRS, TH_SERVERS, TH_GALLERY };
/* what someone holds. Enemies' "armed" is one of these (0: bare fists) */
enum { WP_NONE, WP_PISTOL, WP_SHOTGUN, WP_SMG, WP_KATANA, WP_BAT, WP_PROP, WP_KINDS };
#define WP_IS_GUN(k) ((k) >= WP_PISTOL && (k) <= WP_SMG)
#define WP_IS_MELEE(k) ((k) == WP_KATANA || (k) == WP_BAT)
typedef struct { float x, z, yaw; int armed; float delay; } EnemyDef;   /* delay: comes in after this much game time */
typedef struct { float x, z; int kind; } GunDef;   /* kind 0 means a pistol */
typedef struct {
    const char *file;           /* name in the level list, like 01KICK.lvl */
    const char *title;          /* shown big when the level starts */
    const char *desc;           /* the info pane */
    float px, pz, pyaw;         /* where you start */
    float x0, z0, x1, z1;       /* floor */
    int nbox; const Box *box;
    int nen; const EnemyDef *en;
    int ngun; const GunDef *gun;
    int tutorial;
    int theme;
} Level;
/* can glass land and stay on top of this box? */
int box_is_surface(const Box *b);
extern const Level levels[];
extern const int levelCount;

/* ---------------- things in the world ---------------- */
#define MAX_ENEMIES 14
#define MAX_BULLETS 48
#define MAX_PICKUPS 16
#define MAX_SHARDS 1400
#define MAX_SHARD_TRIS 10000
#define MAX_DUST 64
#define GUN_AMMO 3

typedef struct {
    V3 pos; float yaw;
    float walk, walkAmt;        /* walk cycle phase and how much */
    float punch;                /* 0..1 punch swing */
    float aim;                  /* 0..1 gun arm raised */
    float lean;
    float windup;               /* 0..1 pulling the fist back before a punch */
    float kick;                 /* 0..1 recoil after a shot */
    int armed;                  /* holding a gun (arms aim) */
    int weapon;                 /* what is in the hands (WP_), held properly with both */
} Pose;

enum { EN_WAIT, EN_CHASE, EN_AIM, EN_PUNCH };
typedef struct {
    int alive, armed, state;
    V3 pos; float yaw;
    float delay;                /* > 0: not here yet */
    float appear;               /* fade-in after arriving */
    float t, shootT, punchT, walk, walkAmt, aim, punch;
    float speed;
    int punchHit;
    int burst;                  /* shots left in a submachine gun burst */
    float stunT;                /* knocked off balance by something thrown */
    float kick, flashT;         /* shooting: arm recoil and muzzle flash (game time) */
} Enemy;

/* black glass things on tables: bottles, boxes, vases. Black or red breaks; white does not. */
enum { PR_BOTTLE, PR_BOX, PR_VASE, PR_KINDS, PR_MONITOR = PR_KINDS, PR_MUG,
       PR_WINEGLASS, PR_CAN, PR_TUMBLER, PR_ASHTRAY, PR_PHONE, PR_PLATE, PR_ALL };
typedef struct { int active, kind; V3 pos; float r, h, yaw; } Prop;
#define MAX_PROPS 72

/* spent shells flying out of a gun */
typedef struct { int active; V3 pos, vel; float ang, angV, life, yaw; } Casing;
#define MAX_CASINGS 16

/* the file commander's folders */
enum { DIR_ROOT, DIR_LEVELS, DIR_REPLAYS, DIR_SETTINGS };
enum { ROW_UP, ROW_EXE, ROW_LEVELS, ROW_REPLAYS, ROW_SETTINGS, ROW_CHAT, ROW_LEVEL, ROW_REPLAY, ROW_SET };
enum { SET_QUALITY, SET_AA, SET_SHATTER, SET_GLOW, SET_CRT, SET_LOOK, SET_COUNT };
enum { SHATTER_REAL, SHATTER_SIMPLE, SHATTER_OFF };
#define MAX_REPLAYS 12
typedef struct { int exists, level, serial; float secs; } ReplayInfo;

typedef struct { int active, fromPlayer; V3 pos, vel, start; float life; int whizzed; } Bullet;

/* a gun lying on the floor, or flying after a throw / a death */
/* a weapon (or a thrown bottle) lying about or in the air. kind is a WP_; sub, r, h describe a prop */
typedef struct { int active, flying, ammo, thrown, kind, sub; V3 pos, vel; float yaw, spin, spinV, rest, r, h; } Pickup;

typedef struct { int active, rest; V3 c, vel, axis; float ang, angV, life, rad; int t0, nt; float col[3]; } Shard;
#define SHARD_MAX_TRIS 24   /* the biggest chunk, with its broken inside faces */

/* glitter: tiny bright splinters and the flash where something breaks */
typedef struct { int active, flash; V3 pos, vel; float life, size, spin; float col[3]; } Spark;
#define MAX_SPARKS 200

typedef struct { int active; V3 pos, vel; float life, size; } Dust;

typedef struct {
    V3 pos; float yaw, pitch;
    int hasGun, ammo;               /* holding something, and the shots left in it */
    int weapon, sub;                /* what you hold (WP_), and which prop if it is one */
    float heldR, heldH;             /* size of a held prop */
    float punchT; int punchSide;    /* punch (or sword/bat swing) animation */
    float shootT, kick;             /* recoil */
    float bob, moveAmt;
    float throwT, grabT;
    float swayX, swayY;             /* the gun lags a little behind when you turn */
    float slide;                    /* pistol slide kicked back */
} Player;

typedef struct {
    int mode, prevMode;
    float modeT;
    float time;                 /* real seconds since start */
    float gtime;                /* game seconds in this level (slowed) */
    float ts, tsTarget;         /* time scale: 1 when you move, nearly 0 when you don't */
    float actT;                 /* acting (punch/shoot/throw) keeps time going a moment */
    unsigned rng;
    /* level */
    int level;
    int nbox; Box box[64];
    Enemy en[MAX_ENEMIES]; int nen;
    Bullet bul[MAX_BULLETS];
    Pickup pk[MAX_PICKUPS];
    Shard sh[MAX_SHARDS]; int shardNext;
    float shardTri[MAX_SHARD_TRIS * 9]; int shardTriNext;
    Dust dust[MAX_DUST];
    Spark spark[MAX_SPARKS]; int sparkNext;
    Player pl;
    float flashT;               /* muzzle flash */
    int tutStage; float tutT;
    char msg[64]; float msgT;   /* big centre text */
    float noAmmoT;              /* > 0: NO AMMO is flashing on screen */
    float deathT; V3 deathPos; float deathYaw; V3 deathDir;
    int killedBy;               /* 0 bullet, 1 punch */
    float levelT;               /* real seconds in this level */
    /* menu */
    int menuSel, menuTop;
    int pauseSel;
    int completed;              /* bit per level */
    float best[32];             /* best clear time per level (real seconds) */
    int saveDirty, quit, gpu;
    float bootT;
    int flashCount;
    int touchLook; int lastTx, lastTy;
    /* the story: a chat with your friend between levels */
    int chatId, chatLine, chatChars, chatDone, lastChat, introSeen, pendingChat;
    float chatT;
    /* black glass props and shells */
    Prop prop[MAX_PROPS]; int nprop;
    Casing cas[MAX_CASINGS];
    /* file commander folders, story mode, replays */
    int menuDir;
    int story, storyNext;       /* playing through superhot.exe: levels follow each other */
    int replaying, replayFrame, replayLen, replaySaved, replaySlot;
    float replayMsgT; char replayMsg[48];
    ReplayInfo replays[MAX_REPLAYS];
    char replayDir[80];         /* where replay files live (set by the platform) */
    /* settings folder */
    int setQuality;             /* 0 low, 1 high: model detail, room detail */
    int setAA;                  /* smooth edges (2x2 supersampling on the GPU) */
    int setShatter;             /* SHATTER_REAL / SIMPLE / OFF */
    float tinkT;                /* limits how often landing glass tinkles */
    int setGlow;                /* the bright haze round the edges */
    int setCrt;                 /* bend the computer screens like an old tube */
    int setLook;                /* look speed 1..3 */
    int replayLook;             /* the look speed a replay was recorded with */
} Game;

/* chat scripts (game.c) */
enum { CH_FRIEND, CH_YOU, CH_SPAM, CH_SYSTEM };
typedef struct { int who; const char *text; } ChatLine;
typedef struct { const char *title; int n; const ChatLine *line; } ChatScript;
extern const ChatScript chats[];
extern const int chatCount;
int chat_typed_text(const Game *g, int line, int chars, char *out, int max); /* the text as it stands on screen */
float corruption(const Game *g);   /* 0 clean .. 1 fully hacked */
int levels_done(const Game *g);
int menu_rows(const Game *g);
int menu_row(const Game *g, int r, int *arg);   /* ROW_* for row r; arg = level, replay slot or setting */
const char *setting_text(const Game *g, int s, int value_only);
void replays_scan(Game *g);
void prop_xf(const Prop *p, Xf *x);
int prop_tris(const Prop *p, V3 *out, int max);  /* world triangles, 3 V3 each; returns the count */
void pickup_xf(const Game *g, const Pickup *k, Xf *x);
/* weapons: their triangles (3 V3 each) placed by x, the muzzle in their own space, how they sit in a hand */
int weapon_tris(int kind, int sub, float r, float h, const Xf *x, V3 *out, int max);
V3 weapon_muzzle(int kind);
Xf weapon_hold(Xf hand, int kind);
int weapon_ammo(int kind);
const char *weapon_name(int kind);

void game_boot(Game *g, unsigned seed);
void game_update(Game *g, const Input *in, float dt);
void start_level(Game *g, int lv);
int level_unlocked(const Game *g, int lv);
int game_save_bytes(const Game *g, unsigned char *buf, int max);
int game_load_bytes(Game *g, const unsigned char *buf, int n);
float frand(Game *g);
int blocked(const Game *g, float x, float z, float r);
int seg_hits_wall(const Game *g, V3 a, V3 b, float *tHit);
void pose_of_enemy(const Enemy *e, Pose *p);
void pose_parts(const Pose *p, Xf out[BODY_PARTS]);
Xf hand_gun(const Xf parts[BODY_PARTS]);
/* where a posed body holds its weapon (world), and the arms reaching for it */
Xf pose_weapon(const Pose *p, const Xf parts[BODY_PARTS]);
void player_view(const Game *g, V3 *eye, float *yaw, float *pitch);
void player_fp_parts(const Game *g, Xf out[BODY_PARTS]);
Xf player_gun_xf(const Game *g);
extern int skinFists;
int body_skin(int lod, const Xf parts[BODY_PARTS], V3 *pos, V3 *nrm);
int body_tri_bridge(int lod, int t);
void shatter_body(Game *g, const Pose *p, const float col[3], V3 hitDir, V3 hitPoint);

/* world.c */
void world_camera(const Game *g, Cam *c);
void world_lights(const Game *g);
unsigned world_clear(const Game *g);
void world_build(void *ctx);
void render_sw_top(const Game *g, unsigned short *out);

/* ui.c */
int render_hud(const Game *g, unsigned short *hud);
void render_bottom(const Game *g, unsigned short *buf);
int ui_menu_row(int ty);

/* audio.c */
enum { SFX_PUNCH, SFX_SHATTER, SFX_SHOT, SFX_EMPTY, SFX_PICKUP, SFX_THROW, SFX_STEP, SFX_DEATH, SFX_KEY,
       SFX_BEEP, SFX_FLASH, SFX_WHIZ, SFX_RICOCHET, SFX_SWING, SFX_ENEMY_SHOT, SFX_TINK,
       SFX_SHOTGUN, SFX_SMG, SFX_SLICE, SFX_NOAMMO, SFX_WORD_A, SFX_WORD_B, SFX_BREAK, SFX_COUNT };
enum { LOOP_DRONE, LOOP_RUSH, LOOP_HUM, LOOP_COUNT };
#define AUDIO_RATE 22050
void audio_init(void);
void audio_play(int id, float gain, float pan);
void audio_play_rate(int id, float gain, float pan, float rate);
void audio_loop(int id, float gain, float pan);
void audio_mix(short *out, int frames);
/* how fast game time runs (0..1): sounds in the world slow down and drop in pitch with it */
void audio_set_time(float ts);
int audio_sample_len(int id);
const short *audio_sample_data(int id, int *len);

#endif
