/* SUPERHOT - furniture, cars and the shells of the places the levels are set in.
 * Everything here is white or grey: it never breaks. Only black and red things are glass. */
#include "game.h"
#include "decor.h"
#include <string.h>
#include <math.h>

static const Game *DG;

/* ---------------- small drawing helpers ---------------- */

/* a plain lit box, one quad per face (decor is small; no need to split faces up) */
static void dbox(V3 lo, V3 hi, const float c[3], int faces) {
    if (faces & BX_PY) draw_quad(v3(lo.x, hi.y, hi.z), v3(hi.x, hi.y, hi.z), v3(hi.x, hi.y, lo.z), v3(lo.x, hi.y, lo.z), -1, 0, 0, 1, 1, c, 0);
    if (faces & BX_NY) draw_quad(v3(lo.x, lo.y, lo.z), v3(hi.x, lo.y, lo.z), v3(hi.x, lo.y, hi.z), v3(lo.x, lo.y, hi.z), -1, 0, 0, 1, 1, c, 0);
    if (faces & BX_PZ) draw_quad(v3(lo.x, lo.y, hi.z), v3(hi.x, lo.y, hi.z), v3(hi.x, hi.y, hi.z), v3(lo.x, hi.y, hi.z), -1, 0, 0, 1, 1, c, 0);
    if (faces & BX_NZ) draw_quad(v3(hi.x, lo.y, lo.z), v3(lo.x, lo.y, lo.z), v3(lo.x, hi.y, lo.z), v3(hi.x, hi.y, lo.z), -1, 0, 0, 1, 1, c, 0);
    if (faces & BX_PX) draw_quad(v3(hi.x, lo.y, hi.z), v3(hi.x, lo.y, lo.z), v3(hi.x, hi.y, lo.z), v3(hi.x, hi.y, hi.z), -1, 0, 0, 1, 1, c, 0);
    if (faces & BX_NX) draw_quad(v3(lo.x, lo.y, lo.z), v3(lo.x, lo.y, hi.z), v3(lo.x, hi.y, hi.z), v3(lo.x, hi.y, lo.z), -1, 0, 0, 1, 1, c, 0);
}

/* a flat coloured quad that is not lit: glowing lamps, painted lines, the sky */
static void qcol(V3 a, V3 b, V3 c, V3 d, const float col[3], float alpha, int flags) {
    EV e[4];
    V3 P[4] = {a, b, c, d};
    for (int i = 0; i < 4; i++) { e[i].p = P[i]; e[i].s = e[i].t = 0; e[i].r = col[0]; e[i].g = col[1]; e[i].b = col[2]; e[i].a = alpha; }
    int fl = flags | (alpha < 0.99f ? E_TRANS : 0);
    eng_tri(&e[0], &e[1], &e[2], -1, fl);
    eng_tri(&e[0], &e[2], &e[3], -1, fl);
}
/* same, with alpha per corner (glows that fade out) */
static void qfade(V3 a, V3 b, V3 c, V3 d, const float col[3], float aa, float ab, float ac, float ad, int flags) {
    EV e[4];
    V3 P[4] = {a, b, c, d};
    float A[4] = {aa, ab, ac, ad};
    for (int i = 0; i < 4; i++) { e[i].p = P[i]; e[i].s = e[i].t = 0; e[i].r = col[0]; e[i].g = col[1]; e[i].b = col[2]; e[i].a = A[i]; }
    eng_tri(&e[0], &e[1], &e[2], -1, flags | E_TRANS);
    eng_tri(&e[0], &e[2], &e[3], -1, flags | E_TRANS);
}
/* a flat mark on the floor (paint, a rug, a sun patch) */
static void floor_rect(float x0, float z0, float x1, float z1, float y, const float col[3], float alpha) {
    qcol(v3(x0, y, z1), v3(x1, y, z1), v3(x1, y, z0), v3(x0, y, z0), col, alpha, E_NOCULL);
}

/* one lit triangle, dropped if it faces away */
static void ltri(V3 a, V3 b, V3 c, const float col[3]) {
    V3 n = vcross(vsub(b, a), vsub(c, a));
    float l = vlen(n);
    if (l < 1e-9f) return;
    n = vmul(n, 1 / l);
    if (vdot(n, vsub(cam_eye(), a)) <= 0) return;
    EV e[3];
    V3 P[3] = {a, b, c};
    for (int i = 0; i < 3; i++) {
        float o[3];
        light_vertex(P[i], n, col, o);
        e[i].p = P[i]; e[i].s = e[i].t = 0; e[i].r = o[0]; e[i].g = o[1]; e[i].b = o[2]; e[i].a = 1;
    }
    eng_tri(&e[0], &e[1], &e[2], -1, 0);
}

/* a lit cylinder from a to b, with end caps if asked */
static void cyl(V3 a, V3 b, float r, int n, const float col[3], int caps) {
    V3 d = vnorm(vsub(b, a));
    V3 u = fabsf(d.y) < 0.9f ? v3(0, 1, 0) : v3(1, 0, 0);
    V3 s1 = vnorm(vcross(d, u)), s2 = vcross(s1, d);
    for (int i = 0; i < n; i++) {
        float a0 = 2 * PI * i / n, a1 = 2 * PI * (i + 1) / n;
        V3 o0 = vadd(vmul(s1, cosf(a0) * r), vmul(s2, sinf(a0) * r)), o1 = vadd(vmul(s1, cosf(a1) * r), vmul(s2, sinf(a1) * r));
        /* wind each side quad so it faces outwards */
        V3 q0 = vadd(a, o0), q1 = vadd(b, o0), q2 = vadd(b, o1), q3 = vadd(a, o1);
        if (vdot(vcross(vsub(q1, q0), vsub(q3, q0)), vadd(o0, o1)) < 0) draw_quad(q0, q3, q2, q1, -1, 0, 0, 1, 1, col, 0);
        else draw_quad(q0, q1, q2, q3, -1, 0, 0, 1, 1, col, 0);
        if (caps) {
            ltri(b, vadd(b, o0), vadd(b, o1), col); ltri(b, vadd(b, o1), vadd(b, o0), col);
            ltri(a, vadd(a, o0), vadd(a, o1), col); ltri(a, vadd(a, o1), vadd(a, o0), col);
        }
    }
}

/* any six-sided solid from 8 corners: 0-3 round the bottom, 4-7 the top above them; faces turn themselves outward */
static void hexa(const V3 c[8], const float col[3], int skipBottom) {
    static const int F[6][4] = {{4, 5, 6, 7}, {0, 3, 2, 1}, {0, 1, 5, 4}, {1, 2, 6, 5}, {2, 3, 7, 6}, {3, 0, 4, 7}};
    V3 m = v3(0, 0, 0);
    for (int i = 0; i < 8; i++) m = vadd(m, c[i]);
    m = vmul(m, 1.0f / 8);
    for (int f = 0; f < 6; f++) {
        if (f == 1 && skipBottom) continue;
        V3 a = c[F[f][0]], b = c[F[f][1]], cc = c[F[f][2]], d = c[F[f][3]];
        V3 fc = vmul(vadd(vadd(a, b), vadd(cc, d)), 0.25f);
        V3 n = vcross(vsub(b, a), vsub(d, a));
        if (vlen(n) < 1e-9f) n = vcross(vsub(cc, b), vsub(a, b));
        if (vdot(n, vsub(fc, m)) < 0) draw_quad(a, d, cc, b, -1, 0, 0, 1, 1, col, 0);
        else draw_quad(a, b, cc, d, -1, 0, 0, 1, 1, col, 0);
    }
}

static unsigned hash32(unsigned x) { x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15; x *= 0x846ca68bu; x ^= x >> 16; return x; }
static float hf(unsigned h, int k) { return ((hash32(h + (unsigned)k * 7919u) >> 8) & 1023) / 1023.0f; }

/* ---------------- a box's own frame: u along its front, v across, y up ---------------- */

typedef struct { V3 c, f, s; float hd, hw, h; } Frame;

static Frame frame_of(const Box *b) {
    Frame F;
    F.c = v3((b->x0 + b->x1) * 0.5f, 0, (b->z0 + b->z1) * 0.5f);
    float hx = (b->x1 - b->x0) * 0.5f, hz = (b->z1 - b->z0) * 0.5f;
    switch (b->dir & 3) {
    case 0: F.f = v3(0, 0, 1); F.s = v3(1, 0, 0); F.hd = hz; F.hw = hx; break;
    case 1: F.f = v3(0, 0, -1); F.s = v3(-1, 0, 0); F.hd = hz; F.hw = hx; break;
    case 2: F.f = v3(1, 0, 0); F.s = v3(0, 0, -1); F.hd = hx; F.hw = hz; break;
    default: F.f = v3(-1, 0, 0); F.s = v3(0, 0, 1); F.hd = hx; F.hw = hz; break;
    }
    F.h = b->h;
    return F;
}
static V3 fp(const Frame *F, float u, float y, float v) { return vadd(F->c, vadd(vmul(F->f, u), vadd(vmul(F->s, v), v3(0, y, 0)))); }
/* a box given in the frame's own coordinates */
static void fbox(const Frame *F, float u0, float u1, float y0, float y1, float v0, float v1, const float col[3]) {
    V3 a = fp(F, u0, y0, v0), b = fp(F, u1, y1, v1);
    V3 lo = v3(fminf(a.x, b.x), y0, fminf(a.z, b.z)), hi = v3(fmaxf(a.x, b.x), y1, fmaxf(a.z, b.z));
    dbox(lo, hi, col, BX_ALL & ~BX_NY);
}

/* ---------------- colours ---------------- */

static const float WHITE[3] = {0.97f, 0.98f, 1.0f};
static const float OFFW[3] = {0.9f, 0.92f, 0.95f};
static const float LIGHTG[3] = {0.8f, 0.84f, 0.88f};
static const float MIDG[3] = {0.62f, 0.67f, 0.73f};
static const float DARKG[3] = {0.36f, 0.4f, 0.45f};
static const float LAMP[3] = {1.0f, 1.0f, 1.0f};
static const float GLASSC[3] = {0.55f, 0.66f, 0.78f};    /* car and building windows: grey-blue, not breakable */

/* ---------------- the things ---------------- */

static void draw_car(const Box *b, int idx) {
    Frame F = frame_of(b);
    float L = F.hd, W = F.hw;
    unsigned h = hash32((unsigned)idx * 977u + 5u);
    float tint = 0.92f + 0.07f * hf(h, 1);
    float body[3] = {tint, tint + 0.01f, tint + 0.03f};
    if (body[2] > 1) body[2] = 1;
    /* lower body, a little narrower at the bumpers */
    fbox(&F, -L + 0.12f, L - 0.12f, 0.3f, 0.8f, -W, W, body);
    fbox(&F, L - 0.12f, L, 0.28f, 0.62f, -W + 0.1f, W - 0.1f, OFFW);
    fbox(&F, -L, -L + 0.12f, 0.28f, 0.62f, -W + 0.1f, W - 0.1f, OFFW);
    /* a dark strip along the sill, the shadow under the body */
    fbox(&F, -L + 0.5f, L - 0.5f, 0.22f, 0.3f, -W + 0.08f, W - 0.08f, DARKG);
    /* the cabin: sloped windscreen and rear window */
    float uf0 = L - 1.25f, ub0 = -L + 0.85f, uf1 = L - 1.85f, ub1 = -L + 1.3f;
    float wb = W - 0.06f, wt = W - 0.24f, yb = 0.8f, yt = 1.36f;
    V3 C[8] = {fp(&F, ub0, yb, -wb), fp(&F, uf0, yb, -wb), fp(&F, uf0, yb, wb), fp(&F, ub0, yb, wb),
               fp(&F, ub1, yt, -wt), fp(&F, uf1, yt, -wt), fp(&F, uf1, yt, wt), fp(&F, ub1, yt, wt)};
    hexa(C, body, 1);
    /* windows: set just proud of each cabin face */
    float e = 0.012f, inset = 0.07f;
    for (int side = -1; side <= 1; side += 2) {
        float vb = side * (wb + e), vt = side * (wt + e);
        /* front and rear side windows split by a pillar */
        float um = (ub0 + uf0) * 0.5f + 0.05f;
        V3 q[4] = {fp(&F, ub0 + 0.35f, yb + inset, vb), fp(&F, um - 0.05f, yb + inset, vb), fp(&F, um - 0.05f, yt - inset, vt), fp(&F, ub1 + 0.18f, yt - inset, vt)};
        V3 r[4] = {fp(&F, um + 0.05f, yb + inset, vb), fp(&F, uf0 - 0.3f, yb + inset, vb), fp(&F, uf1 - 0.12f, yt - inset, vt), fp(&F, um + 0.05f, yt - inset, vt)};
        qcol(q[0], q[1], q[2], q[3], GLASSC, 1, E_NOCULL);
        qcol(r[0], r[1], r[2], r[3], GLASSC, 1, E_NOCULL);
    }
    {
        /* windscreen and rear window */
        V3 n0 = fp(&F, uf0 + e, yb + 0.04f, -wb + 0.1f), n1 = fp(&F, uf0 + e, yb + 0.04f, wb - 0.1f);
        V3 n2 = fp(&F, uf1 + e, yt - 0.04f, wt - 0.08f), n3 = fp(&F, uf1 + e, yt - 0.04f, -wt + 0.08f);
        qcol(n0, n1, n2, n3, GLASSC, 1, E_NOCULL);
        V3 m0 = fp(&F, ub0 - e, yb + 0.06f, -wb + 0.1f), m1 = fp(&F, ub0 - e, yb + 0.06f, wb - 0.1f);
        V3 m2 = fp(&F, ub1 - e, yt - 0.05f, wt - 0.08f), m3 = fp(&F, ub1 - e, yt - 0.05f, -wt + 0.08f);
        qcol(m0, m1, m2, m3, GLASSC, 1, E_NOCULL);
    }
    /* head and tail lights */
    static const float tail[3] = {1.0f, 0.78f, 0.6f};
    for (int side = -1; side <= 1; side += 2) {
        float v0 = side * (W - 0.12f), v1 = side * (W - 0.45f);
        qcol(fp(&F, L + 0.005f, 0.55f, v0), fp(&F, L + 0.005f, 0.55f, v1), fp(&F, L + 0.005f, 0.7f, v1), fp(&F, L + 0.005f, 0.7f, v0), LAMP, 1, E_EMIT | E_NOCULL);
        qcol(fp(&F, -L - 0.005f, 0.6f, v0), fp(&F, -L - 0.005f, 0.6f, v1), fp(&F, -L - 0.005f, 0.72f, v1), fp(&F, -L - 0.005f, 0.72f, v0), tail, 1, E_EMIT | E_NOCULL);
    }
    /* grille */
    fbox(&F, L - 0.01f, L + 0.01f, 0.36f, 0.5f, -W * 0.45f, W * 0.45f, MIDG);
    /* wheels: tyres with pale hubs */
    static const float tyre[3] = {0.3f, 0.32f, 0.36f};
    for (int fr = -1; fr <= 1; fr += 2)
        for (int side = -1; side <= 1; side += 2) {
            float u = fr * (L - 0.78f);
            V3 a = fp(&F, u, 0.33f, side * (W - 0.24f)), c = fp(&F, u, 0.33f, side * (W + 0.02f));
            cyl(a, c, 0.33f, 10, tyre, 1);
            V3 hb = fp(&F, u, 0.33f, side * (W + 0.03f));
            cyl(c, hb, 0.18f, 8, LIGHTG, 1);
        }
    /* mirrors */
    for (int side = -1; side <= 1; side += 2)
        fbox(&F, uf0 - 0.12f, uf0, 0.86f, 0.98f, side > 0 ? W : -W - 0.12f, side > 0 ? W + 0.12f : -W, body);
    draw_blob(v3(F.c.x, 0.006f, F.c.z), (b->x1 - b->x0) * 0.62f, (b->z1 - b->z0) * 0.62f, 0.32f);
}

static void draw_sofa(const Box *b, int th) {
    Frame F = frame_of(b);
    float D = F.hd, W = F.hw;
    const float *fab = th == TH_TRAIN ? (const float[3]){0.74f, 0.79f, 0.86f} : OFFW;
    const float *cush = th == TH_TRAIN ? (const float[3]){0.8f, 0.85f, 0.91f} : WHITE;
    if (th == TH_GALLERY || D * 2 < 0.55f) {
        /* a backless bench: a slab on two legs */
        fbox(&F, -D, D, 0.38f, 0.46f, -W, W, WHITE);
        fbox(&F, -D + 0.06f, D - 0.06f, 0, 0.38f, -W + 0.1f, -W + 0.18f, LIGHTG);
        fbox(&F, -D + 0.06f, D - 0.06f, 0, 0.38f, W - 0.18f, W - 0.1f, LIGHTG);
        return;
    }
    float arm = th == TH_TRAIN ? 0.06f : 0.16f;
    float seatY = th == TH_TRAIN ? 0.46f : 0.4f;
    fbox(&F, -D + 0.04f, D - 0.04f, 0.06f, seatY - 0.08f, -W + 0.04f, W - 0.04f, fab);   /* base */
    fbox(&F, -D, -D + 0.2f, seatY - 0.08f, th == TH_TRAIN ? 1.05f : 0.86f, -W, W, fab);   /* back */
    fbox(&F, -D, D, seatY - 0.08f, seatY + 0.18f, -W, -W + arm, fab);                    /* arms */
    fbox(&F, -D, D, seatY - 0.08f, seatY + 0.18f, W - arm, W, fab);
    int n = (int)((W * 2 - arm * 2) / 0.62f + 0.5f);
    if (n < 1) n = 1;
    float span = (W - arm) * 2 / n;
    for (int i = 0; i < n; i++) {
        float v0 = -W + arm + span * i + 0.015f, v1 = v0 + span - 0.03f;
        fbox(&F, -D + 0.2f, D - 0.02f, seatY - 0.08f, seatY + 0.04f, v0, v1, cush);
        fbox(&F, -D + 0.2f, -D + 0.32f, seatY + 0.04f, (th == TH_TRAIN ? 1.0f : 0.8f), v0, v1, cush);
    }
    /* little feet */
    static const float foot[3] = {0.5f, 0.54f, 0.6f};
    for (int a = -1; a <= 1; a += 2)
        for (int c = -1; c <= 1; c += 2) fbox(&F, a * (D - 0.1f) - 0.03f, a * (D - 0.1f) + 0.03f, 0, 0.06f, c * (W - 0.1f) - 0.03f, c * (W - 0.1f) + 0.03f, foot);
}

static void draw_desk(const Box *b) {
    Frame F = frame_of(b);
    float D = F.hd, W = F.hw, H = F.h;
    fbox(&F, -D, D, H - 0.04f, H, -W, W, WHITE);
    static const float leg[3] = {0.72f, 0.76f, 0.82f};
    for (int a = -1; a <= 1; a += 2)
        for (int c = -1; c <= 1; c += 2) fbox(&F, a * (D - 0.06f) - 0.025f, a * (D - 0.06f) + 0.025f, 0, H - 0.04f, c * (W - 0.06f) - 0.025f, c * (W - 0.06f) + 0.025f, leg);
    /* a modesty panel at the back, and a set of drawers on one side */
    fbox(&F, -D + 0.04f, -D + 0.06f, 0.3f, H - 0.04f, -W + 0.1f, W - 0.1f, OFFW);
    if (W > 0.5f) {
        float v0 = W - 0.5f, v1 = W - 0.1f;
        fbox(&F, -D + 0.1f, D - 0.06f, 0.04f, H - 0.06f, v0, v1, OFFW);
        for (int k = 1; k < 3; k++) {
            float y = 0.04f + (H - 0.1f) * k / 3;
            fbox(&F, D - 0.06f, D - 0.05f, y - 0.008f, y + 0.008f, v0 + 0.02f, v1 - 0.02f, MIDG);
            fbox(&F, D - 0.06f, D - 0.045f, y + 0.08f, y + 0.1f, (v0 + v1) * 0.5f - 0.06f, (v0 + v1) * 0.5f + 0.06f, MIDG);
        }
    }
}

static void draw_shelf(const Box *b, int idx, int th) {
    Frame F = frame_of(b);
    float D = F.hd, W = F.hw, H = F.h;
    const float *fr = th == TH_BAR ? OFFW : WHITE;
    fbox(&F, -D, D, 0, 0.08f, -W, W, LIGHTG);                       /* plinth */
    fbox(&F, -D, D, H - 0.04f, H, -W, W, fr);                       /* top */
    fbox(&F, -D, D, 0.08f, H - 0.04f, -W, -W + 0.03f, fr);          /* sides */
    fbox(&F, -D, D, 0.08f, H - 0.04f, W - 0.03f, W, fr);
    fbox(&F, -D, -D + 0.02f, 0.08f, H - 0.04f, -W, W, OFFW);         /* back */
    /* uprights every metre or so */
    int nb = (int)(W * 2 / 1.0f);
    for (int k = 1; k < nb; k++) { float v = -W + W * 2 * k / nb; fbox(&F, -D, D, 0.08f, H - 0.04f, v - 0.015f, v + 0.015f, fr); }
    int ns = (int)((H - 0.12f) / 0.38f);
    unsigned h = hash32((unsigned)idx * 31u + 7u);
    for (int s = 0; s < ns; s++) {
        float y = 0.08f + (H - 0.12f) * s / ns;
        if (s) fbox(&F, -D + 0.02f, D, y - 0.015f, y + 0.015f, -W + 0.03f, W - 0.03f, fr);
        if (!DG->setQuality || !eng_visible(fp(&F, 0, y + 0.15f, 0), W + 0.3f)) continue;
        int near = vlen(vsub(fp(&F, 0, y, 0), cam_eye())) < W + 6.0f;
        /* what is on the shelf: books and folders, or bottles behind a bar */
        float v = -W + 0.06f;
        int k = 0;
        while (v < W - 0.1f && k < 24) {
            unsigned q = h + (unsigned)(s * 97 + k * 13);
            k++;
            if (th == TH_BAR) {
                float r = 0.035f + 0.015f * hf(q, 1), bh = 0.18f + 0.12f * hf(q, 2);
                if (hf(q, 3) < 0.2f) { v += 0.1f; continue; }
                static const float bott[3] = {0.82f, 0.88f, 0.92f};
                V3 p0 = fp(&F, 0.02f, y + 0.015f, v + r), p1 = fp(&F, 0.02f, y + 0.015f + bh, v + r);
                cyl(p0, p1, r, 6, bott, 1);
                cyl(p1, vadd(p1, v3(0, 0.08f, 0)), r * 0.35f, 5, bott, 1);
                v += r * 2 + 0.04f;
                continue;
            }
            /* a run of books of about the same height, drawn as one block */
            float w = 0.1f + 0.35f * hf(q, 1), bh = 0.18f + 0.14f * hf(q, 2);
            if (hf(q, 3) < 0.18f) { v += 0.1f + 0.2f * hf(q, 5); continue; }
            if (v + w > W - 0.06f) w = W - 0.06f - v;
            if (w < 0.04f) break;
            float g = 0.62f + 0.36f * hf(q, 4);
            float col[3] = {g, g + 0.02f, g + 0.05f};
            if (col[2] > 1) col[2] = 1;
            float dep = D * 2 - 0.08f;
            fbox(&F, D - 0.02f - dep, D - 0.04f, y + 0.015f, y + 0.015f + bh, v, v + w, col);
            /* the spines: thin dark gaps between the books of a run (only close enough to see) */
            if (near) {
                float col2[3] = {col[0] * 0.72f, col[1] * 0.74f, col[2] * 0.78f};
                float bv = v + 0.03f + 0.03f * hf(q, 6);
                while (bv < v + w - 0.015f) {
                    float bt = y + 0.015f + bh * (0.9f + 0.1f * hf(q, (int)(bv * 100)));
                    V3 a0 = fp(&F, D - 0.035f, y + 0.02f, bv), a1 = fp(&F, D - 0.035f, y + 0.02f, bv + 0.007f);
                    V3 a2 = fp(&F, D - 0.035f, bt, bv + 0.007f), a3 = fp(&F, D - 0.035f, bt, bv);
                    qcol(a0, a1, a2, a3, col2, 1, E_NOCULL | E_UNLIT);
                    bv += 0.03f + 0.04f * hf(q, (int)(bv * 1000));
                }
            }
            v += w + 0.012f;
        }
    }
}

static void draw_plant(const Box *b, int idx) {
    V3 c = v3((b->x0 + b->x1) * 0.5f, 0, (b->z0 + b->z1) * 0.5f);
    float r = fminf(b->x1 - b->x0, b->z1 - b->z0) * 0.5f;
    float ph = fminf(0.55f, b->h * 0.4f);
    /* a tapered pot */
    V3 P[8] = {v3(c.x - r * 0.75f, 0, c.z - r * 0.75f), v3(c.x + r * 0.75f, 0, c.z - r * 0.75f), v3(c.x + r * 0.75f, 0, c.z + r * 0.75f), v3(c.x - r * 0.75f, 0, c.z + r * 0.75f),
               v3(c.x - r, ph, c.z - r), v3(c.x + r, ph, c.z - r), v3(c.x + r, ph, c.z + r), v3(c.x - r, ph, c.z + r)};
    hexa(P, WHITE, 1);
    static const float soil[3] = {0.55f, 0.58f, 0.62f};
    qcol(v3(c.x - r + 0.03f, ph - 0.04f, c.z + r - 0.03f), v3(c.x + r - 0.03f, ph - 0.04f, c.z + r - 0.03f), v3(c.x + r - 0.03f, ph - 0.04f, c.z - r + 0.03f), v3(c.x - r + 0.03f, ph - 0.04f, c.z - r + 0.03f), soil, 1, 0);
    /* a stem and a fan of long pale leaves */
    static const float leaf[3] = {0.9f, 0.96f, 0.92f}, leaf2[3] = {0.8f, 0.9f, 0.84f};
    float top = b->h;
    if (top > 2.5f) {
        /* a street tree: a trunk in a grate and a cluster of faceted crowns */
        static const float bark[3] = {0.78f, 0.8f, 0.84f}, grate[3] = {0.7f, 0.74f, 0.79f};
        floor_rect(c.x - 0.6f, c.z - 0.6f, c.x + 0.6f, c.z + 0.6f, 0.108f, grate, 1);
        cyl(v3(c.x, 0.1f, c.z), v3(c.x, top * 0.55f, c.z), 0.09f, 6, bark, 0);
        cyl(v3(c.x, top * 0.45f, c.z), v3(c.x + 0.5f, top * 0.7f, c.z + 0.2f), 0.05f, 5, bark, 0);
        unsigned h = hash32((unsigned)idx * 131u + 3u);
        for (int k = 0; k < 5; k++) {
            float a = k * 1.3f + hf(h, k) * 0.6f;
            float rr = k == 0 ? 0 : 0.6f + 0.2f * hf(h, k + 9);
            V3 o = v3(c.x + cosf(a) * rr, top * (0.72f + 0.1f * hf(h, k + 20)) + (k == 0 ? 0.25f : 0), c.z + sinf(a) * rr);
            float s = 0.75f + 0.25f * hf(h, k + 30);
            /* an octahedron squashed into a rough crown */
            V3 P6[6] = {v3(o.x + s, o.y, o.z), v3(o.x, o.y, o.z + s), v3(o.x - s, o.y, o.z), v3(o.x, o.y, o.z - s), v3(o.x, o.y + s * 0.8f, o.z), v3(o.x, o.y - s * 0.6f, o.z)};
            for (int q = 0; q < 4; q++) {
                ltri(P6[4], P6[(q + 1) & 3], P6[q], (q & 1) ? leaf : leaf2);
                ltri(P6[5], P6[q], P6[(q + 1) & 3], (q & 1) ? leaf2 : leaf);
            }
        }
        draw_blob(v3(c.x + 1.0f, 0.112f, c.z + 0.5f), 1.6f, 1.4f, 0.25f);
        return;
    }
    cyl(v3(c.x, ph - 0.04f, c.z), v3(c.x, top * 0.8f, c.z), 0.025f, 5, leaf2, 0);
    unsigned h = hash32((unsigned)idx * 131u + 3u);
    int n = DG->setQuality ? 14 : 6;
    for (int i = 0; i < n; i++) {
        float a = 2 * PI * (i + 0.37f * hf(h, i)) / n * 2.0f;      /* two turns of a spiral */
        float y0 = ph + (top * 0.8f - ph) * ((float)i / n);
        float len = 0.22f + 0.2f * hf(h, i + 40) + r * 0.5f;
        float droop = -0.15f + 0.45f * hf(h, i + 80);
        V3 d = v3(cosf(a), 0, sinf(a));
        V3 base = v3(c.x, y0, c.z);
        V3 mid = vadd(base, vadd(vmul(d, len * 0.5f), v3(0, len * 0.35f, 0)));
        V3 tip = vadd(base, vadd(vmul(d, len), v3(0, len * droop, 0)));
        V3 sd = vmul(v3(-d.z, 0, d.x), 0.04f + 0.025f * hf(h, i + 120));
        const float *lc = (i & 1) ? leaf : leaf2;
        draw_quad(base, vadd(mid, sd), tip, vsub(mid, sd), -1, 0, 0, 1, 1, lc, E_NOCULL);
    }
    draw_blob(v3(c.x, 0.006f, c.z), r * 1.5f, r * 1.5f, 0.3f);
}

static void draw_crate(const Box *b, int idx, int th) {
    V3 lo = v3(b->x0, 0, b->z0), hi = v3(b->x1, b->h, b->z1);
    if (th == TH_STREET) {
        /* a dumpster: a steel bin with a lid, ribs and little wheels */
        static const float bin[3] = {0.72f, 0.78f, 0.8f}, lid[3] = {0.6f, 0.66f, 0.7f};
        dbox(v3(lo.x + 0.04f, 0.14f, lo.z + 0.04f), v3(hi.x - 0.04f, hi.y - 0.06f, hi.z - 0.04f), bin, BX_ALL & ~BX_NY);
        dbox(v3(lo.x, hi.y - 0.06f, lo.z), v3(hi.x, hi.y, hi.z), lid, BX_ALL);
        int alongX = (hi.x - lo.x) > (hi.z - lo.z);
        float len = alongX ? hi.x - lo.x : hi.z - lo.z;
        for (int k = 1; k < 4; k++) {
            float t = len * k / 4;
            if (alongX) dbox(v3(lo.x + t - 0.03f, 0.14f, lo.z), v3(lo.x + t + 0.03f, hi.y - 0.06f, hi.z), lid, BX_ALL & ~BX_NY);
            else dbox(v3(lo.x, 0.14f, lo.z + t - 0.03f), v3(hi.x, hi.y - 0.06f, lo.z + t + 0.03f), lid, BX_ALL & ~BX_NY);
        }
        for (int a = 0; a < 2; a++)
            for (int c = 0; c < 2; c++) {
                float x = a ? hi.x - 0.15f : lo.x + 0.15f, z = c ? hi.z - 0.15f : lo.z + 0.15f;
                cyl(v3(x - 0.04f, 0.07f, z), v3(x + 0.04f, 0.07f, z), 0.07f, 6, DARKG, 1);
            }
        return;
    }
    if (th == TH_SERVERS) {
        /* an air conditioner: a cabinet with a grille and a fan */
        dbox(lo, hi, OFFW, BX_ALL & ~BX_NY);
        float cx = (lo.x + hi.x) * 0.5f, cz = (lo.z + hi.z) * 0.5f;
        int alongX = (hi.x - lo.x) > (hi.z - lo.z);
        for (int k = 0; k < 10; k++) {
            float y = 0.2f + k * (hi.y - 0.5f) / 10;
            if (alongX) {
                float z = lo.z - 0.005f;
                if (b->dir == 0) z = hi.z + 0.005f;
                qcol(v3(lo.x + 0.1f, y, z), v3(hi.x - 0.1f, y, z), v3(hi.x - 0.1f, y + 0.03f, z), v3(lo.x + 0.1f, y + 0.03f, z), MIDG, 1, E_NOCULL);
            } else {
                float x = lo.x - 0.005f;
                if (b->dir == 2) x = hi.x + 0.005f;
                qcol(v3(x, y, lo.z + 0.1f), v3(x, y, hi.z - 0.1f), v3(x, y + 0.03f, hi.z - 0.1f), v3(x, y + 0.03f, lo.z + 0.1f), MIDG, 1, E_NOCULL);
            }
        }
        cyl(v3(cx, hi.y, cz), v3(cx, hi.y + 0.05f, cz), fminf(hi.x - lo.x, hi.z - lo.z) * 0.35f, 10, LIGHTG, 1);
        (void)idx;
        return;
    }
    /* wooden-looking crates, painted white: a frame round every face and boards between */
    static const float board[3] = {0.92f, 0.92f, 0.9f}, edge[3] = {0.8f, 0.82f, 0.84f};
    dbox(v3(lo.x + 0.02f, 0, lo.z + 0.02f), v3(hi.x - 0.02f, hi.y - 0.02f, hi.z - 0.02f), board, BX_ALL & ~BX_NY);
    float e = 0.07f;
    /* the frame: twelve edges */
    dbox(v3(lo.x, 0, lo.z), v3(lo.x + e, hi.y, lo.z + e), edge, BX_ALL & ~BX_NY);
    dbox(v3(hi.x - e, 0, lo.z), v3(hi.x, hi.y, lo.z + e), edge, BX_ALL & ~BX_NY);
    dbox(v3(lo.x, 0, hi.z - e), v3(lo.x + e, hi.y, hi.z), edge, BX_ALL & ~BX_NY);
    dbox(v3(hi.x - e, 0, hi.z - e), v3(hi.x, hi.y, hi.z), edge, BX_ALL & ~BX_NY);
    dbox(v3(lo.x, hi.y - e, lo.z), v3(hi.x, hi.y, lo.z + e), edge, BX_ALL);
    dbox(v3(lo.x, hi.y - e, hi.z - e), v3(hi.x, hi.y, hi.z), edge, BX_ALL);
    dbox(v3(lo.x, hi.y - e, lo.z), v3(lo.x + e, hi.y, hi.z), edge, BX_ALL);
    dbox(v3(hi.x - e, hi.y - e, lo.z), v3(hi.x, hi.y, hi.z), edge, BX_ALL);
    /* a diagonal brace on the sides */
    for (int s = 0; s < 2; s++) {
        float z = s ? hi.z + 0.004f : lo.z - 0.004f;
        V3 a0 = v3(lo.x + e, e, z), a1 = v3(lo.x + e + 0.1f, e, z), a2 = v3(hi.x - e, hi.y - e, z), a3 = v3(hi.x - e - 0.1f, hi.y - e, z);
        draw_quad(a0, a1, a2, a3, -1, 0, 0, 1, 1, edge, E_NOCULL);
    }
    (void)idx;
}

static void draw_pedestal(const Box *b) {
    V3 lo = v3(b->x0, 0, b->z0), hi = v3(b->x1, b->h, b->z1);
    dbox(v3(lo.x + 0.04f, 0.1f, lo.z + 0.04f), v3(hi.x - 0.04f, hi.y - 0.06f, hi.z - 0.04f), WHITE, BX_ALL & ~BX_NY & ~BX_PY);
    dbox(v3(lo.x, 0, lo.z), v3(hi.x, 0.1f, hi.z), OFFW, BX_ALL & ~BX_NY);
    dbox(v3(lo.x, hi.y - 0.06f, lo.z), v3(hi.x, hi.y, hi.z), WHITE, BX_ALL);
}

static void draw_stairs(const Box *b) {
    Frame F = frame_of(b);
    float D = F.hd, W = F.hw, H = F.h;
    int n = (int)(H / 0.18f + 0.5f);
    if (n < 1) n = 1;
    float run = D * 2 / n, rise = H / n;
    /* each step a block down to the floor, a darker nosing on its edge; you climb towards the front */
    for (int i = 0; i < n; i++) {
        float u0 = -D + run * i, y1 = rise * (i + 1);
        fbox(&F, u0, -D + run * (i + 1), 0, y1, -W, W, WHITE);
        fbox(&F, u0 - 0.01f, u0 + 0.03f, y1 - 0.02f, y1 + 0.004f, -W, W, LIGHTG);
    }
    /* a handrail up each side on posts */
    for (int side = -1; side <= 1; side += 2) {
        float v = side * (W - 0.05f);
        V3 a = fp(&F, -D, 0.95f, v), c = fp(&F, D, H + 0.95f, v);
        cyl(a, c, 0.025f, 6, LIGHTG, 1);
        for (int k = 0; k <= 4; k++) {
            float t = k / 4.0f;
            float u = -D + 2 * D * t;
            int si = (int)(t * n - 0.001f);
            if (si < 0) si = 0;
            cyl(fp(&F, u, rise * (si + 1), v), fp(&F, u, rise * (si + 1) + 0.95f - rise, v), 0.016f, 5, LIGHTG, 0);
        }
    }
}

static void draw_partition(const Box *b) {
    static const float fab[3] = {0.8f, 0.85f, 0.9f};
    V3 lo = v3(b->x0, 0, b->z0), hi = v3(b->x1, b->h, b->z1);
    dbox(v3(lo.x, 0.05f, lo.z), v3(hi.x, hi.y - 0.03f, hi.z), fab, BX_ALL & ~BX_NY & ~BX_PY);
    dbox(v3(lo.x - 0.01f, hi.y - 0.03f, lo.z - 0.01f), v3(hi.x + 0.01f, hi.y, hi.z + 0.01f), WHITE, BX_ALL);
    dbox(v3(lo.x, 0, lo.z), v3(hi.x, 0.05f, hi.z), MIDG, BX_ALL & ~BX_NY);
}

static void draw_pole(const Box *b, int th) {
    V3 c = v3((b->x0 + b->x1) * 0.5f, 0, (b->z0 + b->z1) * 0.5f);
    float r = fminf(b->x1 - b->x0, b->z1 - b->z0) * 0.5f;
    if (th == TH_STREET) {
        const Level *L = &levels[DG->level];
        static const float pole[3] = {0.7f, 0.75f, 0.8f};
        cyl(v3(c.x, 0, c.z), v3(c.x, 0.35f, c.z), r * 1.6f, 8, pole, 1);
        cyl(v3(c.x, 0, c.z), v3(c.x, b->h, c.z), r, 8, pole, 1);
        if (b->dir == 1) {
            /* traffic signal: a box of three lamps on the pole, the middle one lit */
            static const float hous[3] = {0.5f, 0.55f, 0.62f}, lit[3] = {0.85f, 1.0f, 0.9f}, off[3] = {0.65f, 0.7f, 0.76f};
            float y0 = b->h - 1.0f;
            dbox(v3(c.x - 0.16f, y0, c.z - 0.13f), v3(c.x + 0.16f, y0 + 0.85f, c.z + 0.13f), hous, BX_ALL);
            for (int k = 0; k < 3; k++) {
                float y = y0 + 0.14f + k * 0.27f;
                const float *lc = k == 0 ? lit : off;
                qcol(v3(c.x - 0.09f, y, c.z - 0.135f), v3(c.x + 0.09f, y, c.z - 0.135f), v3(c.x + 0.09f, y + 0.18f, c.z - 0.135f), v3(c.x - 0.09f, y + 0.18f, c.z - 0.135f), lc, 1, E_EMIT | E_NOCULL);
                qcol(v3(c.x + 0.09f, y, c.z + 0.135f), v3(c.x - 0.09f, y, c.z + 0.135f), v3(c.x - 0.09f, y + 0.18f, c.z + 0.135f), v3(c.x + 0.09f, y + 0.18f, c.z + 0.135f), lc, 1, E_EMIT | E_NOCULL);
            }
            return;
        }
        /* street lamp: an arm out over the road and a head glowing underneath */
        float mx = (L->x0 + L->x1) * 0.5f, dx = mx > c.x ? 1.0f : -1.0f;
        if (fabsf(mx - c.x) < 1) dx = 0;
        float dz = dx == 0 ? ((L->z0 + L->z1) * 0.5f > c.z ? 1.0f : -1.0f) : 0;
        V3 top = v3(c.x, b->h, c.z), end = v3(c.x + dx * 1.4f, b->h + 0.2f, c.z + dz * 1.4f);
        cyl(top, end, r * 0.7f, 6, pole, 1);
        V3 hlo = v3(fminf(end.x, end.x + dx * 0.6f) - (dx == 0 ? 0.15f : 0), end.y - 0.12f, fminf(end.z, end.z + dz * 0.6f) - (dz == 0 ? 0.15f : 0));
        V3 hhi = v3(fmaxf(end.x, end.x + dx * 0.6f) + (dx == 0 ? 0.15f : 0), end.y + 0.02f, fmaxf(end.z, end.z + dz * 0.6f) + (dz == 0 ? 0.15f : 0));
        dbox(hlo, hhi, pole, BX_ALL);
        qcol(v3(hlo.x + 0.03f, hlo.y - 0.004f, hlo.z + 0.03f), v3(hhi.x - 0.03f, hlo.y - 0.004f, hlo.z + 0.03f), v3(hhi.x - 0.03f, hlo.y - 0.004f, hhi.z - 0.03f), v3(hlo.x + 0.03f, hlo.y - 0.004f, hhi.z - 0.03f), LAMP, 1, E_EMIT | E_NOCULL);
        return;
    }
    static const float steel[3] = {0.82f, 0.86f, 0.9f};
    float top = th == TH_TRAIN ? 2.4f : b->h;
    cyl(v3(c.x, 0, c.z), v3(c.x, top, c.z), r, 8, steel, 0);
    cyl(v3(c.x, 0, c.z), v3(c.x, 0.05f, c.z), r * 2.2f, 8, steel, 1);
    cyl(v3(c.x, top - 0.05f, c.z), v3(c.x, top, c.z), r * 2.2f, 8, steel, 1);
}

/* a building front: shop windows at street level, rows of windows above, a ledge at every floor */
static void draw_facade(const Box *b) {
    const Level *L = &levels[DG->level];
    V3 lo = v3(b->x0, 0, b->z0), hi = v3(b->x1, b->h, b->z1);
    draw_box_tex(lo, hi, T_WALL, 0.25f, WHITE, BX_ALL & ~BX_NY);
    static const float ledge[3] = {0.88f, 0.91f, 0.95f}, frameC[3] = {0.82f, 0.86f, 0.9f}, shop[3] = {0.7f, 0.79f, 0.88f};
    for (int face = 0; face < 4; face++) {
        /* only the sides that look onto the street */
        V3 o, du, n;
        float len;
        if (face == 0) { if (hi.x >= L->x1 - 0.05f) continue; o = v3(hi.x, 0, lo.z); du = v3(0, 0, 1); n = v3(1, 0, 0); len = hi.z - lo.z; }
        else if (face == 1) { if (lo.x <= L->x0 + 0.05f) continue; o = v3(lo.x, 0, hi.z); du = v3(0, 0, -1); n = v3(-1, 0, 0); len = hi.z - lo.z; }
        else if (face == 2) { if (hi.z >= L->z1 - 0.05f) continue; o = v3(hi.x, 0, hi.z); du = v3(-1, 0, 0); n = v3(0, 0, 1); len = hi.x - lo.x; }
        else { if (lo.z <= L->z0 + 0.05f) continue; o = v3(lo.x, 0, lo.z); du = v3(1, 0, 0); n = v3(0, 0, -1); len = hi.x - lo.x; }
        /* clip the face to the part inside the level */
        float t0 = 0, t1 = len;
        for (int k = 0; k < 2; k++) {
            V3 p = vadd(o, vmul(du, k ? t1 : t0));
            (void)p;
        }
        if (face < 2) {
            float za = fmaxf(lo.z, L->z0), zb = fminf(hi.z, L->z1);
            if (face == 0) { t0 = za - lo.z; t1 = zb - lo.z; } else { t0 = hi.z - zb; t1 = hi.z - za; }
        } else {
            float xa = fmaxf(lo.x, L->x0), xb = fminf(hi.x, L->x1);
            if (face == 3) { t0 = xa - lo.x; t1 = xb - lo.x; } else { t0 = hi.x - xb; t1 = hi.x - xa; }
        }
        if (t1 - t0 < 0.5f) continue;
        V3 mid = vadd(o, vmul(du, (t0 + t1) * 0.5f));
        if (!eng_visible(vadd(mid, v3(0, b->h * 0.5f, 0)), (t1 - t0) * 0.5f + b->h * 0.5f)) continue;
        V3 e = vmul(n, 0.012f);
#define FP(t, y) vadd(vadd(o, vmul(du, (t))), vadd(e, v3(0, (y), 0)))
        /* street level: tall shop windows between piers */
        float bay = 3.0f;
        int nb = (int)((t1 - t0) / bay);
        if (nb < 1) nb = 1;
        float bw = (t1 - t0) / nb;
        for (int i = 0; i < nb; i++) {
            float a = t0 + bw * i + 0.35f, c = t0 + bw * (i + 1) - 0.35f;
            qcol(FP(a, 0.35f), FP(c, 0.35f), FP(c, 2.75f), FP(a, 2.75f), shop, 1, E_NOCULL);
            /* a mullion and a transom */
            V3 m = vmul(n, 0.03f);
            float mm = (a + c) * 0.5f;
            draw_quad(vadd(FP(mm - 0.03f, 0.35f), m), vadd(FP(mm + 0.03f, 0.35f), m), vadd(FP(mm + 0.03f, 2.75f), m), vadd(FP(mm - 0.03f, 2.75f), m), -1, 0, 0, 1, 1, frameC, E_NOCULL);
            draw_quad(vadd(FP(a, 2.2f), m), vadd(FP(c, 2.2f), m), vadd(FP(c, 2.26f), m), vadd(FP(a, 2.26f), m), -1, 0, 0, 1, 1, frameC, E_NOCULL);
        }
        /* the storey line above the shops */
        {
            V3 p0 = FP(t0, 3.0f), p1 = FP(t1, 3.25f);
            V3 lo2 = v3(fminf(p0.x, p1.x), 3.0f, fminf(p0.z, p1.z)), hi2 = v3(fmaxf(p0.x, p1.x), 3.25f, fmaxf(p0.z, p1.z));
            lo2 = vadd(lo2, v3(n.x < 0 ? -0.18f : 0, 0, n.z < 0 ? -0.18f : 0));
            hi2 = vadd(hi2, v3(n.x > 0 ? 0.18f : 0, 0, n.z > 0 ? 0.18f : 0));
            dbox(lo2, hi2, ledge, BX_ALL);
        }
        /* upper floors */
        float wsp = 2.1f;
        int nw = (int)((t1 - t0) / wsp);
        if (nw < 1) nw = 1;
        float ws = (t1 - t0) / nw;
        for (float y = 3.9f; y + 1.7f < b->h - 0.4f; y += 3.1f) {
            for (int i = 0; i < nw; i++) {
                float a = t0 + ws * i + (ws - 1.2f) * 0.5f, c = a + 1.2f;
                qcol(FP(a, y), FP(c, y), FP(c, y + 1.75f), FP(a, y + 1.75f), GLASSC, 1, E_NOCULL);
                /* sill */
                V3 s0 = FP(a - 0.08f, y - 0.08f), s1 = FP(c + 0.08f, y);
                V3 lo3 = v3(fminf(s0.x, s1.x), y - 0.08f, fminf(s0.z, s1.z)), hi3 = v3(fmaxf(s0.x, s1.x), y, fmaxf(s0.z, s1.z));
                lo3 = vadd(lo3, v3(n.x < 0 ? -0.1f : 0, 0, n.z < 0 ? -0.1f : 0));
                hi3 = vadd(hi3, v3(n.x > 0 ? 0.1f : 0, 0, n.z > 0 ? 0.1f : 0));
                dbox(lo3, hi3, ledge, BX_ALL & ~BX_NY);
            }
        }
        /* the clutter of a real building: air conditioners hung under windows, a drainpipe, vents */
        if (DG->setQuality) {
            unsigned hb = hash32((unsigned)(b->x0 * 7 + b->z0 * 13) + (unsigned)face * 101u);
            for (float y = 3.9f; y + 1.7f < b->h - 0.4f; y += 3.1f) {
                for (int i = 0; i < nw; i++) {
                    unsigned q = hash32(hb + (unsigned)(i * 31) + (unsigned)(y * 10));
                    if (hf(q, 7) > 0.45f) continue;
                    float a = t0 + ws * i + (ws - 1.2f) * 0.5f + 0.15f + 0.4f * hf(q, 1);
                    V3 p0 = FP(a, y - 0.75f), p1 = FP(a + 0.75f, y - 0.2f);
                    V3 lo4 = v3(fminf(p0.x, p1.x), y - 0.75f, fminf(p0.z, p1.z)), hi4 = v3(fmaxf(p0.x, p1.x), y - 0.2f, fmaxf(p0.z, p1.z));
                    lo4 = vadd(lo4, v3(n.x < 0 ? -0.42f : 0, 0, n.z < 0 ? -0.42f : 0));
                    hi4 = vadd(hi4, v3(n.x > 0 ? 0.42f : 0, 0, n.z > 0 ? 0.42f : 0));
                    dbox(lo4, hi4, OFFW, BX_ALL);
                    /* the fan grille on its front */
                    V3 fc = vadd(FP(a + 0.4f, y - 0.475f), vmul(n, 0.425f));
                    V3 u = du;
                    for (int k = 0; k < 8; k++) {
                        float a0 = 2 * PI * k / 8, a1 = 2 * PI * (k + 1) / 8;
                        V3 q0 = vadd(fc, vadd(vmul(u, cosf(a0) * 0.2f), v3(0, sinf(a0) * 0.2f, 0)));
                        V3 q1 = vadd(fc, vadd(vmul(u, cosf(a1) * 0.2f), v3(0, sinf(a1) * 0.2f, 0)));
                        qcol(fc, q0, q1, fc, MIDG, 1, E_NOCULL);
                    }
                    for (int k = 0; k < 3; k++) {
                        float ang = k * 1.047f;
                        V3 d0 = vadd(vmul(u, cosf(ang) * 0.19f), v3(0, sinf(ang) * 0.19f, 0));
                        V3 pf = vmul(n, 0.004f), w2 = vadd(vmul(u, -sinf(ang) * 0.02f), v3(0, cosf(ang) * 0.02f, 0));
                        qcol(vadd(vsub(vadd(fc, pf), d0), w2), vadd(vadd(vadd(fc, pf), d0), w2), vsub(vadd(vadd(fc, pf), d0), w2), vsub(vsub(vadd(fc, pf), d0), w2), LIGHTG, 1, E_NOCULL);
                    }
                }
            }
            /* a drainpipe down one end of the front */
            V3 dp = vadd(FP(t1 - 0.4f, 0), vmul(n, 0.1f));
            cyl(v3(dp.x, 0.1f, dp.z), v3(dp.x, b->h - 0.3f, dp.z), 0.06f, 6, LIGHTG, 0);
            for (float y = 1.5f; y < b->h - 0.5f; y += 3.1f) dbox(v3(dp.x - 0.08f, y, dp.z - 0.08f), v3(dp.x + 0.08f, y + 0.06f, dp.z + 0.08f), LIGHTG, BX_ALL);
        }
        /* parapet at the top */
        {
            V3 p0 = FP(t0, b->h - 0.35f), p1 = FP(t1, b->h);
            V3 lo2 = v3(fminf(p0.x, p1.x), b->h - 0.35f, fminf(p0.z, p1.z)), hi2 = v3(fmaxf(p0.x, p1.x), b->h, fmaxf(p0.z, p1.z));
            lo2 = vadd(lo2, v3(n.x < 0 ? -0.22f : 0, 0, n.z < 0 ? -0.22f : 0));
            hi2 = vadd(hi2, v3(n.x > 0 ? 0.22f : 0, 0, n.z > 0 ? 0.22f : 0));
            dbox(lo2, hi2, ledge, BX_ALL);
        }
#undef FP
    }
}

int decor_box(const Game *g, const Box *b, int idx) {
    DG = g;
    int th = levels[g->level].theme;
    V3 lo = v3(b->x0, 0, b->z0), hi = v3(b->x1, b->h, b->z1);
    V3 c = vmul(vadd(lo, hi), 0.5f);
    float rad = vlen(vsub(hi, lo)) * 0.5f + 0.5f;
    if (b->kind == BOX_POLE && th == TH_STREET) rad += 1.6f;
    switch (b->kind) {
    case BOX_CAR: if (eng_visible(c, rad)) draw_car(b, idx); return 1;
    case BOX_SOFA: if (eng_visible(c, rad)) draw_sofa(b, th); return 1;
    case BOX_DESK: if (eng_visible(c, rad)) draw_desk(b); return 1;
    case BOX_SHELF: if (eng_visible(c, rad)) draw_shelf(b, idx, th); return 1;
    case BOX_PLANT: if (eng_visible(v3(c.x, b->h * 0.6f, c.z), rad + (b->h > 2.5f ? 1.8f : 0.4f))) draw_plant(b, idx); return 1;
    case BOX_CRATE: if (eng_visible(c, rad)) draw_crate(b, idx, th); return 1;
    case BOX_PEDESTAL: if (eng_visible(c, rad)) draw_pedestal(b); return 1;
    case BOX_STAIRS: if (eng_visible(c, rad)) draw_stairs(b); return 1;
    case BOX_PART: if (eng_visible(c, rad)) draw_partition(b); return 1;
    case BOX_POLE: if (eng_visible(c, rad)) draw_pole(b, th); return 1;
    case BOX_FACADE: draw_facade(b); return 1;
    }
    return 0;
}

/* ================= the shells of special places ================= */

/* a train carriage: low curved ceiling, windows down both sides with the city sliding past
 * (it only slides when time moves), grab rails and hanging straps */
static void shell_train(const Game *g) {
    const Level *L = &levels[g->level];
    float x0 = L->x0, x1 = L->x1, z0 = L->z0, z1 = L->z1;
    const float CH = 2.4f;
    static const float ceilC[3] = {0.95f, 0.97f, 1.0f};
    /* ceiling: a flat middle and two sloped sides */
    draw_quad(v3(x0, CH - 0.25f, z0), v3(x0, CH - 0.25f, z1), v3(x0 + 0.6f, CH, z1), v3(x0 + 0.6f, CH, z0), -1, 0, 0, 1, 1, ceilC, E_NOCULL);
    draw_quad(v3(x1 - 0.6f, CH, z0), v3(x1 - 0.6f, CH, z1), v3(x1, CH - 0.25f, z1), v3(x1, CH - 0.25f, z0), -1, 0, 0, 1, 1, ceilC, E_NOCULL);
    draw_quad(v3(x0 + 0.6f, CH, z0), v3(x0 + 0.6f, CH, z1), v3(x1 - 0.6f, CH, z1), v3(x1 - 0.6f, CH, z0), -1, 0, 0, 1, 1, ceilC, E_NOCULL);
    /* a strip of light down the middle */
    for (float z = z0 + 0.6f; z < z1 - 0.6f; z += 2.4f) {
        V3 a = v3(-0.22f + (x0 + x1) * 0.5f, CH - 0.012f, z), b2 = v3(0.22f + (x0 + x1) * 0.5f, CH - 0.012f, z + 2.0f);
        if (!eng_visible(v3((x0 + x1) * 0.5f, CH, z + 1), 1.6f)) continue;
        qcol(v3(a.x, a.y, b2.z), v3(b2.x, a.y, b2.z), v3(b2.x, a.y, a.z), v3(a.x, a.y, a.z), LAMP, 1, E_EMIT | E_NOCULL);
        qfade(v3(a.x, a.y, a.z), v3(a.x, a.y, b2.z), v3(a.x - 0.3f, a.y - 0.02f, b2.z), v3(a.x - 0.3f, a.y - 0.02f, a.z), LAMP, 0.5f, 0.5f, 0, 0, E_EMIT | E_NOCULL);
        qfade(v3(b2.x, a.y, b2.z), v3(b2.x, a.y, a.z), v3(b2.x + 0.3f, a.y - 0.02f, a.z), v3(b2.x + 0.3f, a.y - 0.02f, b2.z), LAMP, 0.5f, 0.5f, 0, 0, E_EMIT | E_NOCULL);
    }
    /* windows both sides, the world outside streaming past */
    static const float sky[3] = {1.0f, 1.0f, 1.0f}, far1[3] = {0.82f, 0.9f, 0.96f}, far2[3] = {0.72f, 0.82f, 0.9f};
    static const float frameC[3] = {0.78f, 0.83f, 0.88f};
    float shift = g->gtime * 9.0f;
    for (int side = 0; side < 2; side++) {
        float x = side ? x1 - 0.012f : x0 + 0.012f;
        float xo = side ? -0.004f : 0.004f;
        for (float z = z0 + 1.0f; z < z1 - 1.0f; z += 2.6f) {
            float za = z, zb = z + 1.8f, y0 = 1.0f, y1 = 1.9f;
            if (!eng_visible(v3(x, 1.45f, (za + zb) * 0.5f), 1.3f)) continue;
            V3 A = v3(x, y0, za), B = v3(x, y0, zb), C = v3(x, y1, zb), D = v3(x, y1, za);
            qcol(A, B, C, D, sky, 1, E_EMIT | E_NOCULL);
            /* towers sliding past: their x position wraps with time */
            if (g->setQuality) {
                for (int k = 0; k < 6; k++) {
                    unsigned h = hash32((unsigned)k * 77u + (unsigned)side * 13u);
                    float w = 0.25f + 0.4f * hf(h, 1), period = 1.8f + 0.9f;
                    float off = fmodf(hf(h, 2) * period + shift * (0.5f + 0.5f * hf(h, 4)) + z * 0.37f, period);
                    float s0 = za + off - w, s1 = za + off;
                    if (s1 <= za || s0 >= zb) continue;
                    if (s0 < za) s0 = za;
                    if (s1 > zb) s1 = zb;
                    float top = y0 + 0.1f + 0.75f * hf(h, 3);
                    qcol(v3(x + xo, y0, s0), v3(x + xo, y0, s1), v3(x + xo, top, s1), v3(x + xo, top, s0), (k & 1) ? far1 : far2, 1, E_EMIT | E_NOCULL);
                }
            }
            /* a rounded frame */
            float dx = side ? -0.06f : 0.06f, xf = side ? x - 0.06f : x;
            dbox(v3(fminf(x, x + dx), y0 - 0.06f, za - 0.06f), v3(fmaxf(x, x + dx), y0, zb + 0.06f), frameC, BX_ALL);
            dbox(v3(fminf(x, x + dx), y1, za - 0.06f), v3(fmaxf(x, x + dx), y1 + 0.06f, zb + 0.06f), frameC, BX_ALL);
            dbox(v3(fminf(x, x + dx), y0, za - 0.06f), v3(fmaxf(x, x + dx), y1, za), frameC, BX_ALL);
            dbox(v3(fminf(x, x + dx), y0, zb), v3(fmaxf(x, x + dx), y1, zb + 0.06f), frameC, BX_ALL);
            (void)xf;
            /* daylight falling across the aisle from the near-side windows */
            if (!side) {
                static const float beam[3] = {1.0f, 0.99f, 0.95f};
                float s = 0.9f;
                floor_rect(x0 + 0.6f + s * 0.3f, za + 0.3f, x0 + 1.2f + s * 0.6f, zb + 0.5f, 0.006f, beam, 0.35f);
            }
        }
        /* a grab rail along the ceiling, straps hanging from it */
        float rx = side ? x1 - 0.55f : x0 + 0.55f;
        if (eng_visible(v3(rx, 2.1f, (z0 + z1) * 0.5f), (z1 - z0) * 0.5f + 0.5f)) {
            cyl(v3(rx, 2.12f, z0), v3(rx, 2.12f, z1), 0.02f, 6, frameC, 0);
            for (float z = z0 + 0.8f; z < z1 - 0.5f; z += 0.7f) {
                if (!eng_visible(v3(rx, 1.95f, z), 0.3f)) continue;
                float sw = sinf(g->gtime * 1.3f + z) * 0.03f;
                cyl(v3(rx, 2.12f, z), v3(rx, 1.86f, z + sw), 0.008f, 4, LIGHTG, 0);
                dbox(v3(rx - 0.006f, 1.76f, z + sw - 0.05f), v3(rx + 0.006f, 1.86f, z + sw + 0.05f), WHITE, BX_ALL);
            }
            for (float z = z0 + 0.4f; z < z1; z += 3.0f) cyl(v3(rx, 2.12f, z), v3(rx + (side ? 0.4f : -0.4f), CH - 0.12f, z), 0.015f, 4, frameC, 0);
        }
        /* a kick strip along the bottom of the wall */
        dbox(v3(side ? x1 - 0.03f : x0, 0, z0), v3(side ? x1 : x0 + 0.03f, 0.12f, z1), MIDG, side ? BX_NX | BX_PY : BX_PX | BX_PY);
    }
    /* the end walls: a door through to the next carriage */
    static const float door[3] = {0.7f, 0.76f, 0.83f};
    for (int e = 0; e < 2; e++) {
        float z = e ? z1 - 0.012f : z0 + 0.012f, d = e ? -0.03f : 0.03f;
        float cx = (x0 + x1) * 0.5f;
        if (!eng_visible(v3(cx, 1.1f, z), 1.4f)) continue;
        dbox(v3(cx - 0.5f, 0, fminf(z, z + d)), v3(cx + 0.5f, 2.05f, fmaxf(z, z + d)), door, BX_ALL);
        qcol(v3(cx - 0.3f, 1.2f, z + d * 1.2f), v3(cx + 0.3f, 1.2f, z + d * 1.2f), v3(cx + 0.3f, 1.85f, z + d * 1.2f), v3(cx - 0.3f, 1.85f, z + d * 1.2f), sky, 1, E_EMIT | E_NOCULL);
    }
    /* yellow-free safety line: a pale strip where the doors open */
    for (float z = z0 + 3.6f; z < z1 - 2; z += 7.2f) {
        floor_rect(x0, z - 0.7f, x0 + 0.25f, z + 0.7f, 0.003f, LIGHTG, 1);
        floor_rect(x1 - 0.25f, z - 0.7f, x1, z + 0.7f, 0.003f, LIGHTG, 1);
    }
}

/* a car park: grey concrete, low ceiling with deep beams, strip lights, painted bays,
 * and long openings on one side letting the daylight in */
static void shell_garage(const Game *g) {
    const Level *L = &levels[g->level];
    float x0 = L->x0, x1 = L->x1, z0 = L->z0, z1 = L->z1;
    const float CH = 2.9f;
    static const float conc[3] = {0.86f, 0.88f, 0.9f}, beamC[3] = {0.9f, 0.92f, 0.94f}, paint[3] = {1.0f, 1.0f, 1.0f};
    draw_box_tex(v3(x0 - 0.3f, CH, z0 - 0.3f), v3(x1 + 0.3f, CH + 0.1f, z1 + 0.3f), T_PANEL, 0.5f, conc, BX_NY);
    for (float z = z0 + 2.0f; z < z1 - 0.5f; z += 4.0f) {
        if (!eng_visible(v3((x0 + x1) * 0.5f, CH, z), (x1 - x0) * 0.5f + 1)) continue;
        dbox(v3(x0, CH - 0.5f, z - 0.25f), v3(x1, CH, z + 0.25f), beamC, BX_NY | BX_PZ | BX_NZ);
        /* tube lights hanging between the beams */
        for (float x = x0 + 2.0f; x < x1 - 1.5f; x += 4.0f) {
            float zc = z + 2.0f;
            if (zc > z1 - 0.5f) continue;
            dbox(v3(x - 0.08f, CH - 0.12f, zc - 0.7f), v3(x + 0.08f, CH - 0.06f, zc + 0.7f), WHITE, BX_ALL);
            qcol(v3(x - 0.05f, CH - 0.125f, zc - 0.66f), v3(x + 0.05f, CH - 0.125f, zc - 0.66f), v3(x + 0.05f, CH - 0.125f, zc + 0.66f), v3(x - 0.05f, CH - 0.125f, zc + 0.66f), LAMP, 1, E_EMIT | E_NOCULL);
            V3 p = v3(x, CH - 0.2f, zc);
            draw_billboard(p, 1.4f, 0.5f, LAMP, 0.35f, E_EMIT);
        }
    }
    /* parking bays down both sides: lines on the floor, a number-less kerb stop in each */
    for (int side = 0; side < 2; side++) {
        float xa = side ? x1 - 4.6f : x0, xb = side ? x1 : x0 + 4.6f;
        for (float z = z0 + 1.0f; z <= z1 - 1.0f; z += 2.5f) {
            if (!eng_visible(v3((xa + xb) * 0.5f, 0, z), 2.6f)) continue;
            floor_rect(xa + (side ? 0 : 0.2f), z - 0.05f, xb - (side ? 0.2f : 0), z + 0.05f, 0.003f, paint, 1);
            float sx = side ? xb - 0.5f : xa + 0.5f;
            dbox(v3(sx - 0.1f, 0, z + 0.4f), v3(sx + 0.1f, 0.1f, z + 2.1f), LIGHTG, BX_ALL & ~BX_NY);
        }
    }
    /* a dashed line and arrows down the driving lane */
    float cx = (x0 + x1) * 0.5f;
    for (float z = z0 + 0.5f; z < z1 - 0.5f; z += 2.0f) floor_rect(cx - 0.06f, z, cx + 0.06f, z + 1.0f, 0.003f, paint, 1);
    for (float z = z0 + 3.0f; z < z1 - 2.0f; z += 8.0f) {
        float ax = cx - 1.4f;
        floor_rect(ax - 0.08f, z, ax + 0.08f, z + 0.9f, 0.003f, paint, 1);
        qcol(v3(ax - 0.3f, 0.003f, z + 0.9f), v3(ax, 0.003f, z + 1.35f), v3(ax + 0.3f, 0.003f, z + 0.9f), v3(ax, 0.003f, z + 0.9f), paint, 1, 0);
    }
    /* openings along the low-x wall: a concrete parapet and the bright day beyond */
    static const float sky[3] = {1.0f, 1.0f, 1.0f}, far1[3] = {0.84f, 0.91f, 0.96f}, far2[3] = {0.75f, 0.84f, 0.92f};
    float x = x0 + 0.014f;
    for (float z = z0 + 0.4f; z < z1 - 0.4f; z += 4.0f) {
        float za = z + 0.3f, zb = fminf(z + 3.7f, z1 - 0.3f);
        if (!eng_visible(v3(x, 1.6f, (za + zb) * 0.5f), 2.2f)) continue;
        qcol(v3(x, 1.0f, za), v3(x, 1.0f, zb), v3(x, 2.35f, zb), v3(x, 2.35f, za), sky, 1, E_EMIT | E_NOCULL);
        for (int k = 0; k < 5; k++) {
            unsigned h = hash32((unsigned)(z * 10) + (unsigned)k * 31u);
            float s0 = za + (zb - za) * k / 5 + 0.05f, s1 = s0 + (zb - za) / 5 * (0.5f + 0.4f * hf(h, 1));
            float top = 1.1f + 0.9f * hf(h, 2);
            qcol(v3(x + 0.003f, 1.0f, s0), v3(x + 0.003f, 1.0f, s1), v3(x + 0.003f, top, s1), v3(x + 0.003f, top, s0), (k & 1) ? far1 : far2, 1, E_EMIT | E_NOCULL);
        }
        qfade(v3(x + 0.006f, 1.0f, za), v3(x + 0.006f, 1.0f, zb), v3(x + 0.006f, 0.6f, zb), v3(x + 0.006f, 0.6f, za), sky, 0.6f, 0.6f, 0, 0, E_EMIT | E_NOCULL);
        /* the sun through it, across the floor */
        static const float beam[3] = {1.0f, 0.99f, 0.95f};
        qcol(v3(x0 + 1.0f, 0.006f, zb + 0.6f), v3(x0 + 2.4f, 0.006f, zb + 1.0f), v3(x0 + 2.4f, 0.006f, za + 1.0f), v3(x0 + 1.0f, 0.006f, za + 0.6f), beam, 0.4f, E_EMIT);
    }
    /* pipes and a sprinkler line */
    static const float pipeC[3] = {0.88f, 0.9f, 0.93f};
    if (eng_visible(v3(x1 - 0.3f, CH - 0.2f, (z0 + z1) * 0.5f), (z1 - z0) * 0.5f + 1)) {
        cyl(v3(x1 - 0.25f, CH - 0.2f, z0), v3(x1 - 0.25f, CH - 0.2f, z1), 0.09f, 8, pipeC, 0);
        cyl(v3(x1 - 0.5f, CH - 0.15f, z0), v3(x1 - 0.5f, CH - 0.15f, z1), 0.05f, 6, pipeC, 0);
    }
    (void)far2;
}

/* outdoors: no ceiling, pavements along the buildings, a road down the middle */
static void shell_street(const Game *g) {
    const Level *L = &levels[g->level];
    float x0 = L->x0, x1 = L->x1, z0 = L->z0, z1 = L->z1;
    static const float paveC[3] = {0.93f, 0.95f, 0.97f}, kerb[3] = {0.84f, 0.87f, 0.9f}, paint[3] = {1.0f, 1.0f, 1.0f};
    /* pavements in front of every building, with a kerb */
    for (int i = 0; i < g->nbox; i++) {
        const Box *b = &g->box[i];
        if (b->kind != BOX_FACADE) continue;
        float pw = 1.6f;
        float ax = fmaxf(b->x0 - pw, x0), bx = fminf(b->x1 + pw, x1), az = fmaxf(b->z0 - pw, z0), bz = fminf(b->z1 + pw, z1);
        if (!eng_visible(v3((ax + bx) * 0.5f, 0, (az + bz) * 0.5f), fmaxf(bx - ax, bz - az) * 0.6f + 1)) continue;
        draw_box_tex(v3(ax, 0, az), v3(bx, 0.1f, bz), T_FLOOR, 0.6f, paveC, BX_PY);
        if (ax > x0 + 0.01f) dbox(v3(ax, 0, az), v3(ax + 0.15f, 0.12f, bz), kerb, BX_NX | BX_PY);
        if (bx < x1 - 0.01f) dbox(v3(bx - 0.15f, 0, az), v3(bx, 0.12f, bz), kerb, BX_PX | BX_PY);
        if (az > z0 + 0.01f) dbox(v3(ax, 0, az), v3(bx, 0.12f, az + 0.15f), kerb, BX_NZ | BX_PY);
        if (bz < z1 - 0.01f) dbox(v3(ax, 0, bz - 0.15f), v3(bx, 0.12f, bz), kerb, BX_PZ | BX_PY);
    }
    /* lane markings: dashes along whichever way the road runs, zebra stripes where roads cross */
    int cross = !strcmp(L->title, "CROSSING");
    float cx = (x0 + x1) * 0.5f;
    if (!cross) {
        for (float z = z0 + 0.5f; z < z1 - 0.5f; z += 3.0f) floor_rect(cx - 0.07f, z, cx + 0.07f, z + 1.5f, 0.003f, paint, 1);
        for (float x = cx - 2.5f; x < cx + 2.6f; x += 0.9f) floor_rect(x, z1 - 4.2f, x + 0.5f, z1 - 2.6f, 0.003f, paint, 1);
    } else {
        for (float z = z0 + 0.5f; z < 4.5f; z += 2.0f) floor_rect(cx - 0.07f, z, cx + 0.07f, z + 1.0f, 0.003f, paint, 1);
        for (float x = x0 + 0.5f; x < -4.5f; x += 2.0f) floor_rect(x, 9.43f, x + 1.0f, 9.57f, 0.003f, paint, 1);
        for (float x = 4.5f; x < x1 - 0.5f; x += 2.0f) floor_rect(x, 9.43f, x + 1.0f, 9.57f, 0.003f, paint, 1);
        for (float z = 14.5f; z < z1 - 0.5f; z += 2.0f) floor_rect(cx - 0.07f, z, cx + 0.07f, z + 1.0f, 0.003f, paint, 1);
        /* zebra crossings on all four sides of the junction */
        for (float x = -3.0f; x < 3.0f; x += 0.8f) { floor_rect(x, 5.0f, x + 0.45f, 6.4f, 0.003f, paint, 1); floor_rect(x, 12.6f, x + 0.45f, 14.0f, 0.003f, paint, 1); }
        for (float z = 7.4f; z < 12.0f; z += 0.8f) { floor_rect(-4.9f, z, -3.5f, z + 0.45f, 0.003f, paint, 1); floor_rect(3.5f, z, 4.9f, z + 0.45f, 0.003f, paint, 1); }
    }
    /* manholes and drains */
    static const float iron[3] = {0.8f, 0.83f, 0.87f};
    for (int k = 0; k < 3; k++) {
        float z = z0 + (z1 - z0) * (0.25f + 0.3f * k), x = cx + (k & 1 ? 1.5f : -1.2f);
        if (!eng_visible(v3(x, 0, z), 0.6f)) continue;
        for (int i = 0; i < 8; i++) {
            float a0 = 2 * PI * i / 8, a1 = 2 * PI * (i + 1) / 8;
            qcol(v3(x, 0.003f, z), v3(x + cosf(a1) * 0.35f, 0.003f, z + sinf(a1) * 0.35f), v3(x + cosf(a0) * 0.35f, 0.003f, z + sinf(a0) * 0.35f), v3(x, 0.003f, z), iron, 1, E_NOCULL);
        }
    }
    /* the buildings' shade: a cool band beside the sunward fronts, over the pavement and onto the road */
    static const float shade[3] = {0.6f, 0.68f, 0.79f};
    for (int i = 0; i < g->nbox; i++) {
        const Box *b = &g->box[i];
        if (b->kind != BOX_FACADE || b->x1 > x0 + 0.05f) continue;
        float za = fmaxf(b->z0, z0), zb = fminf(b->z1, z1);
        if (zb - za < 0.5f) continue;
        float xa = b->x1, xm = b->x1 + 1.6f, xe = b->x1 + 2.8f;
        if (!eng_visible(v3(xm, 0, (za + zb) * 0.5f), (zb - za) * 0.5f + 2)) continue;
        qcol(v3(xa, 0.104f, zb), v3(xm, 0.104f, zb), v3(xm, 0.104f, za), v3(xa, 0.104f, za), shade, 0.5f, E_NOCULL);
        qfade(v3(xm, 0.006f, zb), v3(xe, 0.006f, zb), v3(xe, 0.006f, za), v3(xm, 0.006f, za), shade, 0.5f, 0, 0, 0.5f, E_NOCULL);
    }
}

/* server racks: cabinets of stacked machines, a white frame between each, rows of vents and lights */
void decor_rack(const Game *g, const Box *b) {
    static const float frameC[3] = {0.93f, 0.95f, 0.98f}, unitA[3] = {0.66f, 0.72f, 0.8f}, unitB[3] = {0.74f, 0.8f, 0.87f}, vent[3] = {0.55f, 0.6f, 0.68f};
    static const float led1[3] = {0.4f, 0.95f, 1.0f}, led2[3] = {1.0f, 0.55f, 0.3f};
    V3 lo = v3(b->x0, 0, b->z0), hi = v3(b->x1, b->h, b->z1);
    /* the cabinet body and its top */
    dbox(v3(lo.x + 0.02f, 0, lo.z), v3(hi.x - 0.02f, hi.y, hi.z), frameC, BX_PY | BX_PZ | BX_NZ);
    float seg = 0.62f;
    int alongZ = (hi.z - lo.z) > (hi.x - lo.x);
    float len = alongZ ? hi.z - lo.z : hi.x - lo.x;
    int n = (int)(len / seg);
    if (n < 1) n = 1;
    seg = len / n;
    if (!g->setQuality) {
        /* low graphics: plain cabinets with a band of lights */
        dbox(v3(lo.x, 0, lo.z), v3(lo.x + 0.02f, hi.y, hi.z), unitA, BX_NX);
        dbox(v3(hi.x - 0.02f, 0, lo.z), v3(hi.x, hi.y, hi.z), unitA, BX_PX);
        return;
    }
    for (int side = 0; side < 2; side++) {
        float x = side ? hi.x : lo.x, o = side ? 0.004f : -0.004f;
        for (int i = 0; i < n; i++) {
            float z0 = lo.z + seg * i, z1 = z0 + seg;
            V3 mid = v3(x, b->h * 0.5f, (z0 + z1) * 0.5f);
            if (!eng_visible(mid, b->h * 0.6f)) continue;
            float dist = vlen(vsub(mid, cam_eye()));
            if (dist > 16) {
                /* far away: one flat panel per cabinet */
                qcol(v3(x + o, 0.1f, side ? z1 : z0), v3(x + o, 0.1f, side ? z0 : z1), v3(x + o, b->h - 0.1f, side ? z0 : z1), v3(x + o, b->h - 0.1f, side ? z1 : z0), unitA, 1, E_NOCULL);
                continue;
            }
            /* frame round the cabinet door */
            V3 fl = v3(fminf(x, x + o * 10), 0, z0), fh = v3(fmaxf(x, x + o * 10), b->h, z0 + 0.04f);
            dbox(fl, fh, frameC, side ? BX_PX | BX_PZ | BX_NZ : BX_NX | BX_PZ | BX_NZ);
            /* the machines: bands of two greys, with a vent or a row of lights on each */
            unsigned h = hash32((unsigned)(i * 37 + side * 11) + (unsigned)(b->x0 * 13));
            float y = 0.12f;
            int k = 0;
            while (y < b->h - 0.12f && k < 12) {
                float uh = 0.09f + 0.09f * (float)((hash32(h + (unsigned)k) >> 8) & 3);
                if (y + uh > b->h - 0.1f) uh = b->h - 0.1f - y;
                const float *uc = (k & 1) ? unitA : unitB;
                V3 a = v3(x + o, y + 0.006f, side ? z1 - 0.02f : z0 + 0.06f), c2 = v3(x + o, y + uh - 0.006f, side ? z0 + 0.06f : z1 - 0.02f);
                qcol(a, v3(a.x, a.y, c2.z), c2, v3(a.x, c2.y, a.z), uc, 1, E_NOCULL);
                if (uh > 0.12f && dist < 9) {
                    float vz0 = z0 + 0.12f, vz1 = z0 + seg * 0.55f;
                    qcol(v3(x + o * 2, y + uh * 0.3f, vz0), v3(x + o * 2, y + uh * 0.3f, vz1), v3(x + o * 2, y + uh * 0.7f, vz1), v3(x + o * 2, y + uh * 0.7f, vz0), vent, 1, E_NOCULL);
                }
                /* status lights, blinking as time passes */
                for (int l = 0; l < (dist < 10 ? 3 : 1); l++) {
                    unsigned hh = hash32(h + (unsigned)(k * 7 + l));
                    if (((hh >> 4) + (unsigned)(g->gtime * 3 + l)) % 4 == 0) continue;
                    float lz = z1 - 0.1f - l * 0.05f, ly = y + uh * 0.5f - 0.01f;
                    const float *lc = ((hh >> 9) & 7) == 0 ? led2 : led1;
                    qcol(v3(x + o * 3, ly, lz), v3(x + o * 3, ly, lz + 0.02f), v3(x + o * 3, ly + 0.02f, lz + 0.02f), v3(x + o * 3, ly + 0.02f, lz), lc, 1, E_EMIT | E_NOCULL);
                }
                y += uh;
                k++;
            }
        }
    }
    /* a glow of cold light down each aisle floor */
    (void)alongZ;
}

/* a lobby or gallery: round downlights set into a plain ceiling */
static void downlights(const Game *g, float spacing) {
    const Level *L = &levels[g->level];
    for (float z = L->z0 + spacing * 0.5f; z < L->z1; z += spacing)
        for (float x = L->x0 + spacing * 0.5f; x < L->x1; x += spacing) {
            V3 c = v3(x, 3.188f, z);
            if (!eng_visible(c, 0.6f)) continue;
            for (int i = 0; i < 8; i++) {
                float a0 = 2 * PI * i / 8, a1 = 2 * PI * (i + 1) / 8;
                qcol(c, v3(x + cosf(a0) * 0.16f, c.y, z + sinf(a0) * 0.16f), v3(x + cosf(a1) * 0.16f, c.y, z + sinf(a1) * 0.16f), c, LAMP, 1, E_EMIT | E_NOCULL);
                qfade(v3(x + cosf(a0) * 0.16f, c.y, z + sinf(a0) * 0.16f), v3(x + cosf(a0) * 0.45f, c.y, z + sinf(a0) * 0.45f),
                      v3(x + cosf(a1) * 0.45f, c.y, z + sinf(a1) * 0.45f), v3(x + cosf(a1) * 0.16f, c.y, z + sinf(a1) * 0.16f), LAMP, 0.5f, 0, 0, 0.5f, E_EMIT | E_NOCULL);
            }
        }
}

/* a gallery: track lights and blank canvases in thin frames along the walls */
static void gallery_walls(const Game *g) {
    const Level *L = &levels[g->level];
    static const float canvas[3] = {0.94f, 0.95f, 0.97f}, frameC[3] = {0.66f, 0.7f, 0.76f}, paint1[3] = {0.78f, 0.83f, 0.89f}, paint2[3] = {0.86f, 0.9f, 0.94f};
    float x = L->x1 - 0.012f;
    int k = 0;
    for (float z = L->z0 + 2.0f; z < L->z1 - 2.0f; z += 3.6f, k++) {
        if (!eng_visible(v3(x, 1.6f, z), 1.5f)) continue;
        float w = 0.7f + 0.3f * (k % 3), hgt = 0.9f + 0.25f * ((k + 1) % 2);
        dbox(v3(x - 0.05f, 1.55f - hgt * 0.5f - 0.05f, z - w * 0.5f - 0.05f), v3(x, 1.55f + hgt * 0.5f + 0.05f, z + w * 0.5f + 0.05f), frameC, BX_NX | BX_PY | BX_NY | BX_PZ | BX_NZ);
        qcol(v3(x - 0.052f, 1.55f - hgt * 0.5f, z + w * 0.5f), v3(x - 0.052f, 1.55f - hgt * 0.5f, z - w * 0.5f), v3(x - 0.052f, 1.55f + hgt * 0.5f, z - w * 0.5f), v3(x - 0.052f, 1.55f + hgt * 0.5f, z + w * 0.5f), canvas, 1, 0);
        /* some quiet abstract shapes painted on it */
        float cz = z + (k & 1 ? -0.1f : 0.12f) * w, cy = 1.55f + 0.08f;
        qcol(v3(x - 0.054f, cy - hgt * 0.25f, cz + w * 0.2f), v3(x - 0.054f, cy - hgt * 0.25f, cz - w * 0.25f), v3(x - 0.054f, cy + hgt * 0.2f, cz - w * 0.25f), v3(x - 0.054f, cy + hgt * 0.2f, cz + w * 0.2f), (k & 1) ? paint1 : paint2, 1, 0);
        qcol(v3(x - 0.056f, cy - hgt * 0.38f, cz - w * 0.05f), v3(x - 0.056f, cy - hgt * 0.38f, cz - w * 0.35f), v3(x - 0.056f, cy - hgt * 0.05f, cz - w * 0.35f), v3(x - 0.056f, cy - hgt * 0.05f, cz - w * 0.05f), paint1, 1, 0);
        /* a spotlight washing it from above */
        qfade(v3(x - 0.02f, 3.0f, z - w * 0.4f), v3(x - 0.02f, 3.0f, z + w * 0.4f), v3(x - 0.02f, 1.5f, z + w * 0.8f), v3(x - 0.02f, 1.5f, z - w * 0.8f), LAMP, 0.35f, 0.35f, 0, 0, E_EMIT | E_NOCULL);
    }
    /* free-standing display walls carry a picture on each face */
    for (int i = 0; i < g->nbox; i++) {
        const Box *b = &g->box[i];
        if (b->kind != BOX_WALL || b->h > 3.0f) continue;
        float cx = (b->x0 + b->x1) * 0.5f;
        if (b->x1 >= L->x1 - 0.05f) cx = b->x0 + (b->x1 - b->x0) * 0.4f;
        else if (b->x0 <= L->x0 + 0.05f) cx = b->x0 + (b->x1 - b->x0) * 0.6f;
        for (int f = 0; f < 2; f++) {
            float z = f ? b->z1 + 0.012f : b->z0 - 0.012f, d = f ? 1.0f : -1.0f;
            if (!eng_visible(v3(cx, 1.5f, z), 1.2f)) continue;
            float w = 1.1f + 0.3f * ((i + f) % 2), hh = 0.8f + 0.2f * ((i + f + 1) % 2);
            V3 lo = v3(cx - w * 0.5f - 0.05f, 1.45f - hh * 0.5f - 0.05f, fminf(z, z + d * 0.04f)), hi = v3(cx + w * 0.5f + 0.05f, 1.45f + hh * 0.5f + 0.05f, fmaxf(z, z + d * 0.04f));
            dbox(lo, hi, frameC, BX_ALL & ~(f ? BX_NZ : BX_PZ));
            float zz = z + d * 0.042f;
            qcol(v3(cx - w * 0.5f, 1.45f - hh * 0.5f, zz), v3(cx + w * 0.5f, 1.45f - hh * 0.5f, zz), v3(cx + w * 0.5f, 1.45f + hh * 0.5f, zz), v3(cx - w * 0.5f, 1.45f + hh * 0.5f, zz), canvas, 1, E_NOCULL);
            float zz2 = zz + d * 0.002f;
            /* a pale horizon line and a block of colour: something like a landscape */
            qcol(v3(cx - w * 0.45f, 1.3f, zz2), v3(cx + w * 0.45f, 1.3f, zz2), v3(cx + w * 0.45f, 1.36f, zz2), v3(cx - w * 0.45f, 1.36f, zz2), paint1, 1, E_NOCULL);
            qcol(v3(cx - w * 0.2f, 1.36f, zz2), v3(cx + w * 0.05f, 1.36f, zz2), v3(cx + w * 0.05f, 1.36f + hh * 0.28f, zz2), v3(cx - w * 0.2f, 1.36f + hh * 0.28f, zz2), paint2, 1, E_NOCULL);
        }
    }
    /* a track of spotlights along the ceiling */
    float tx = L->x1 - 1.4f;
    if (eng_visible(v3(tx, 3.1f, (L->z0 + L->z1) * 0.5f), (L->z1 - L->z0) * 0.5f + 1)) {
        dbox(v3(tx - 0.04f, 3.13f, L->z0), v3(tx + 0.04f, 3.2f, L->z1), LIGHTG, BX_ALL & ~BX_PY);
        for (float z = L->z0 + 2.0f; z < L->z1 - 2.0f; z += 3.6f) {
            V3 a = v3(tx, 3.12f, z), b2 = v3(tx + 0.2f, 2.95f, z);
            cyl(a, b2, 0.05f, 6, WHITE, 1);
        }
    }
}

/* behind the bar: a mirror strip and a glow along the counter's foot */
static void bar_back(const Game *g) {
    (void)g;
}

/* the inside of the elevator you start in: brushed steel walls, a rail, a panel of buttons */
static void elevator_car(const Game *g) {
    const Level *L = &levels[g->level];
    static const float steel[3] = {0.78f, 0.82f, 0.87f}, steel2[3] = {0.7f, 0.75f, 0.8f}, btn[3] = {0.95f, 1.0f, 1.0f};
    float x0 = -1.2f, x1 = 1.2f, z0 = L->z0, z1 = 1.8f;
    if (!eng_visible(v3(0, 1.4f, (z0 + z1) * 0.5f), 2.6f)) return;
    /* panels on the back wall */
    for (int i = 0; i < 3; i++) {
        float a = x0 + 0.1f + i * 0.75f, b = a + 0.68f;
        dbox(v3(a, 0.1f, z0), v3(b, 2.5f, z0 + 0.02f), (i & 1) ? steel : steel2, BX_PZ);
    }
    /* side walls: the rail at hip height */
    for (int s = 0; s < 2; s++) {
        float x = s ? 1.2f - 0.08f : -1.2f + 0.08f;
        cyl(v3(x, 0.92f, z0 + 0.3f), v3(x, 0.92f, z1 - 0.4f), 0.025f, 6, steel, 1);
        for (float z = z0 + 0.35f; z < z1 - 0.3f; z += 2.6f) cyl(v3(x, 0.92f, z), v3(s ? 1.2f : -1.2f, 0.92f, z), 0.015f, 4, steel, 0);
    }
    /* button panel beside the doors */
    dbox(v3(0.9f, 0.9f, z1 - 0.32f), v3(1.0f, 1.6f, z1 - 0.14f), steel2, BX_NX);
    for (int r = 0; r < 5; r++)
        for (int c = 0; c < 2; c++) {
            float y = 1.0f + r * 0.11f, z = z1 - 0.28f + c * 0.08f;
            qcol(v3(0.895f, y, z + 0.04f), v3(0.895f, y, z), v3(0.895f, y + 0.05f, z), v3(0.895f, y + 0.05f, z + 0.04f), btn, 1, E_EMIT | E_NOCULL);
        }
    /* the doors, slid open into the wall */
    dbox(v3(x0, 0, z1 - 0.06f), v3(x0 + 0.55f, 2.3f, z1), steel, BX_NZ);
    dbox(v3(x1 - 0.55f, 0, z1 - 0.06f), v3(x1, 2.3f, z1), steel, BX_NZ);
    /* a light panel overhead and a threshold strip */
    qcol(v3(-0.7f, 2.6f, z0 + 0.4f), v3(0.7f, 2.6f, z0 + 0.4f), v3(0.7f, 2.6f, z1 - 0.4f), v3(-0.7f, 2.6f, z1 - 0.4f), LAMP, 1, E_EMIT | E_NOCULL);
    dbox(v3(-1.2f, 2.6f, z0), v3(1.2f, 2.62f, z1), WHITE, BX_NY);
    floor_rect(-1.2f, z1 - 0.12f, 1.2f, z1 + 0.12f, 0.006f, steel2, 1);
    (void)x1;
}

void decor_shell(const Game *g) {
    DG = g;
    switch (levels[g->level].theme) {
    case TH_TRAIN: shell_train(g); break;
    case TH_GARAGE: shell_garage(g); break;
    case TH_STREET: shell_street(g); break;
    case TH_LOBBY: if (g->setQuality) downlights(g, 3.0f); break;
    case TH_GALLERY: if (g->setQuality) { downlights(g, 4.0f); gallery_walls(g); } break;
    case TH_BAR: bar_back(g); if (g->setQuality) downlights(g, 3.5f); break;
    case TH_ELEVATOR: elevator_car(g); break;
    }
}
