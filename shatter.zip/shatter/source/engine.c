/* FIX IT SHOP - engine: maths, lighting, mesh drawing, the software rasterizer and 2D drawing. */
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "engine.h"

#define ZNEAR 0.02f

Lights LT;
int engTris;
unsigned short swTop[RW * RH];
static float zbuf[RW * RH];
static Cam CAM;
static int useGpu;
static GpuSink sink;

/* ================= maths ================= */

float vlen(V3 a) { return sqrtf(vdot(a, a)); }
V3 vnorm(V3 a) {
    float l = vlen(a);
    return l > 1e-8f ? vmul(a, 1.0f / l) : v3(0, 1, 0);
}
V3 vlerp(V3 a, V3 b, float t) { return vadd(a, vmul(vsub(b, a), t)); }

void xf_ident(Xf *x) {
    memset(x, 0, sizeof(*x));
    x->m[0] = x->m[4] = x->m[8] = 1;
    x->s = 1;
}
void xf_rot(Xf *x, V3 a, float ang) {
    a = vnorm(a);
    float c = cosf(ang), s = sinf(ang), C = 1 - c;
    xf_ident(x);
    x->m[0] = c + a.x * a.x * C;       x->m[1] = a.x * a.y * C - a.z * s; x->m[2] = a.x * a.z * C + a.y * s;
    x->m[3] = a.y * a.x * C + a.z * s; x->m[4] = c + a.y * a.y * C;       x->m[5] = a.y * a.z * C - a.x * s;
    x->m[6] = a.z * a.x * C - a.y * s; x->m[7] = a.z * a.y * C + a.x * s; x->m[8] = c + a.z * a.z * C;
}
void xf_mul(Xf *o, const Xf *p, const Xf *c) {
    Xf r;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) r.m[i * 3 + j] = p->m[i * 3] * c->m[j] + p->m[i * 3 + 1] * c->m[3 + j] + p->m[i * 3 + 2] * c->m[6 + j];
    r.s = p->s * c->s;
    r.t = xf_point(p, c->t);
    *o = r;
}
void xf_ypr(Xf *x, float yaw, float pitch, float roll) {
    Xf a, b, c, t;
    /* yaw: turning so local +z faces (cos yaw, 0, sin yaw)... we use: local +z forward -> world (sin, 0, cos)? keep simple: rotate about y by -yaw+pi/2 handled by callers */
    xf_rot(&a, v3(0, 1, 0), yaw);
    xf_rot(&b, v3(1, 0, 0), pitch);
    xf_rot(&c, v3(0, 0, 1), roll);
    xf_mul(&t, &a, &b);
    xf_mul(x, &t, &c);
}
V3 xf_point(const Xf *x, V3 p) {
    p = vmul(p, x->s);
    return v3(x->m[0] * p.x + x->m[1] * p.y + x->m[2] * p.z + x->t.x,
              x->m[3] * p.x + x->m[4] * p.y + x->m[5] * p.z + x->t.y,
              x->m[6] * p.x + x->m[7] * p.y + x->m[8] * p.z + x->t.z);
}
V3 xf_dir(const Xf *x, V3 d) {
    return v3(x->m[0] * d.x + x->m[1] * d.y + x->m[2] * d.z,
              x->m[3] * d.x + x->m[4] * d.y + x->m[5] * d.z,
              x->m[6] * d.x + x->m[7] * d.y + x->m[8] * d.z);
}
/* models face +z; 'yaw' here is the heading in the game's convention (0 = +x), so turn by (pi/2 - yaw) */
Xf xf_at(V3 pos, float yaw, float scale) {
    Xf x;
    xf_rot(&x, v3(0, 1, 0), 1.5707963f - yaw);
    x.t = pos;
    x.s = scale;
    return x;
}

void cam_look(Cam *c, V3 eye, float yaw, float pitch) {
    c->eye = eye;
    c->f = v3(cosf(yaw) * cosf(pitch), -sinf(pitch), sinf(yaw) * cosf(pitch));
    c->r = vnorm(vcross(c->f, v3(0, 1, 0)));
    c->u = vcross(c->r, c->f);
    c->focal = 151.5f;
}
void cam_look_at(Cam *c, V3 eye, V3 target) {
    V3 d = vsub(target, eye);
    float yaw = atan2f(d.z, d.x);
    float pitch = -atan2f(d.y, sqrtf(d.x * d.x + d.z * d.z));
    cam_look(c, eye, yaw, pitch);
}

/* ================= lighting ================= */

/* toy-like lighting: a soft-banded sun (cel look), bright hemisphere fill,
 * a gentle rim light round the edges and a little extra colour saturation */
void light_vertex(V3 p, V3 n, const float alb[3], float out[3]) {
    /* soft, bright lighting: sky from above, bounce from below, a gentle sun */
    float hy = n.y * 0.5f + 0.5f;
    float sd = -vdot(n, LT.sunDir);
    sd = sd < 0 ? 0 : sd;
    float l[3];
    for (int k = 0; k < 3; k++) l[k] = LT.ground[k] + (LT.sky[k] - LT.ground[k]) * hy + LT.sun[k] * sd;
    for (int i = 0; i < LT.n; i++) {
        V3 d = vsub(LT.lp[i], p);
        float dist = vlen(d);
        if (dist > LT.lr[i]) continue;
        float att = 1 - dist / LT.lr[i];
        att *= att;
        float k = dist > 1e-4f ? vdot(n, d) / dist : 1;
        k = 0.3f + 0.7f * (k > 0 ? k : 0);
        for (int c = 0; c < 3; c++) l[c] += LT.lc[i][c] * att * k;
    }
    /* walls get darker where they meet the floor and the ceiling (cheap ambient occlusion) */
    float ao = 1;
    if (n.y < 0.5f && n.y > -0.5f) {
        if (p.y < 0.6f) ao *= 0.8f + 0.2f * (p.y / 0.6f);
        if (p.y > 2.7f && p.y < 3.3f) ao *= 1 - 0.15f * ((p.y - 2.7f) / 0.5f);
    }
    for (int k = 0; k < 3; k++) { float x = alb[k] * l[k] * ao; out[k] = x < 0 ? 0 : x; }
}

/* a soft round shadow on the ground under something */
void draw_blob(V3 p, float rx, float rz, float alpha) {
    static const float k[3] = {0.05f, 0.05f, 0.05f};
    draw_blob_col(p, rx, rz, alpha, k);
}

void draw_blob_col(V3 p, float rx, float rz, float alpha, const float col[3]) {
    EV c, in[9], out[9];
    p.y += 0.012f;
    c.p = p; c.s = c.t = 0; c.r = col[0]; c.g = col[1]; c.b = col[2]; c.a = alpha;
    for (int i = 0; i <= 8; i++) {
        float a = 2 * 3.14159265f * i / 8;
        float cx = cosf(a), sz = sinf(a);
        in[i] = c; in[i].p = vadd(p, v3(cx * rx * 0.6f, 0, sz * rz * 0.6f)); in[i].a = alpha * 0.85f;
        out[i] = c; out[i].p = vadd(p, v3(cx * rx, 0, sz * rz)); out[i].a = 0;
    }
    for (int i = 0; i < 8; i++) {
        eng_tri(&c, &in[i + 1], &in[i], -1, E_TRANS | E_UNLIT | E_NOCULL);
        eng_tri(&in[i], &in[i + 1], &out[i + 1], -1, E_TRANS | E_UNLIT | E_NOCULL);
        eng_tri(&in[i], &out[i + 1], &out[i], -1, E_TRANS | E_UNLIT | E_NOCULL);
    }
}

/* ================= emission ================= */

void eng_set_gpu_sink(GpuSink s) { sink = s; }

void eng_begin(const Cam *c, int gpu) {
    CAM = *c;
    useGpu = gpu;
    engTris = 0;
    if (!gpu) {
        for (int i = 0; i < RW * RH; i++) zbuf[i] = 0;
    }
}

static float fogk(V3 p) {
    if (LT.fogFar <= LT.fogNear) return 0;
    V3 v = vsub(p, CAM.eye);
    float d2 = v.x * v.x + v.y * v.y + v.z * v.z;
    if (d2 <= LT.fogNear * LT.fogNear) return 0;      /* inside the clear zone: same answer, no sqrt */
    float d = sqrtf(d2);
    float f = (d - LT.fogNear) / (LT.fogFar - LT.fogNear);
    return f < 0 ? 0 : (f > 1 ? 1 : f);
}

/* ---- software rasterizer: gouraud colour, 1/z depth, dithered transparency ---- */
typedef struct { float x, y, z, r, g, b; } CVt;     /* camera space */
typedef struct { float sx, sy, iz, r, g, b; } PVt;  /* screen */

static const unsigned char bayer4[4][4] = {{0, 8, 2, 10}, {12, 4, 14, 6}, {3, 11, 1, 9}, {15, 7, 13, 5}};

static void raster(const PVt *v0, const PVt *v1, const PVt *v2, int alpha16) {
    /* sort by y */
    const PVt *t;
    if (v1->sy < v0->sy) { t = v0; v0 = v1; v1 = t; }
    if (v2->sy < v0->sy) { t = v0; v0 = v2; v2 = t; }
    if (v2->sy < v1->sy) { t = v1; v1 = v2; v2 = t; }
    float area = (v1->sx - v0->sx) * (v2->sy - v0->sy) - (v2->sx - v0->sx) * (v1->sy - v0->sy);
    if (fabsf(area) < 1e-6f) return;
    float ia = 1.0f / area;
    /* attribute gradients */
    float dx1 = v1->sx - v0->sx, dy1 = v1->sy - v0->sy, dx2 = v2->sx - v0->sx, dy2 = v2->sy - v0->sy;
#define G(a, gx, gy) float gx = ((v1->a - v0->a) * dy2 - (v2->a - v0->a) * dy1) * ia; \
                     float gy = ((v2->a - v0->a) * dx1 - (v1->a - v0->a) * dx2) * ia;
    G(iz, izx, izy) G(r, rx, ry) G(g, gx_, gy_) G(b, bx, by)
#undef G
    int y0 = (int)ceilf(v0->sy - 0.5f), y2 = (int)ceilf(v2->sy - 0.5f);
    if (y0 < 0) y0 = 0;
    if (y2 > RH) y2 = RH;
    float invLong = 1.0f / (v2->sy - v0->sy);
    for (int y = y0; y < y2; y++) {
        float yc = y + 0.5f;
        float xl = v0->sx + (yc - v0->sy) * (v2->sx - v0->sx) * invLong;
        float xr;
        if (yc < v1->sy) {
            float h = v1->sy - v0->sy;
            xr = h > 1e-6f ? v0->sx + (yc - v0->sy) * (v1->sx - v0->sx) / h : v1->sx;
        } else {
            float h = v2->sy - v1->sy;
            xr = h > 1e-6f ? v1->sx + (yc - v1->sy) * (v2->sx - v1->sx) / h : v1->sx;
        }
        if (xl > xr) { float q = xl; xl = xr; xr = q; }
        int xs = (int)ceilf(xl - 0.5f), xe = (int)ceilf(xr - 0.5f);
        if (xs < 0) xs = 0;
        if (xe > RW) xe = RW;
        if (xs >= xe) continue;
        float ox = xs + 0.5f - v0->sx, oy = yc - v0->sy;
        float iz = v0->iz + izx * ox + izy * oy;
        float r = v0->r + rx * ox + ry * oy, g = v0->g + gx_ * ox + gy_ * oy, b = v0->b + bx * ox + by * oy;
        unsigned short *row = swTop + y * RW;
        float *zr = zbuf + y * RW;
        const unsigned char *br = bayer4[y & 3];
        for (int x = xs; x < xe; x++, iz += izx, r += rx, g += gx_, b += bx) {
            if (iz <= zr[x]) continue;
            if (alpha16 < 16 && br[x & 3] >= alpha16) continue;
            if (alpha16 >= 16) zr[x] = iz;
            int d = br[x & 3] - 8;
            int R = (int)r + d, Gc = (int)g + (d >> 1), B = (int)b + d;
            R = R < 0 ? 0 : (R > 255 ? 255 : R);
            Gc = Gc < 0 ? 0 : (Gc > 255 ? 255 : Gc);
            B = B < 0 ? 0 : (B > 255 ? 255 : B);
            row[x] = (unsigned short)(((R >> 3) << 11) | ((Gc >> 2) << 5) | (B >> 3));
        }
    }
}

static void sw_tri(const EV *e[3], int tex, int flags, float alpha) {
    CVt in[3], poly[5];
    for (int i = 0; i < 3; i++) {
        V3 d = vsub(e[i]->p, CAM.eye);
        in[i].x = vdot(d, CAM.r);
        in[i].y = vdot(d, CAM.u);
        in[i].z = vdot(d, CAM.f);
        float m[3] = {1, 1, 1};
        if (tex >= 0) { m[0] = texAvg[tex * 3] / 255.0f; m[1] = texAvg[tex * 3 + 1] / 255.0f; m[2] = texAvg[tex * 3 + 2] / 255.0f; }
        in[i].r = e[i]->r * m[0] * 255;
        in[i].g = e[i]->g * m[1] * 255;
        in[i].b = e[i]->b * m[2] * 255;
    }
    if (in[0].z < ZNEAR && in[1].z < ZNEAR && in[2].z < ZNEAR) return;
    int n = 0;
    for (int i = 0; i < 3; i++) {
        const CVt *a = &in[i], *b = &in[(i + 1) % 3];
        int ai = a->z >= ZNEAR, bi = b->z >= ZNEAR;
        if (ai) poly[n++] = *a;
        if (ai != bi) {
            float t = (ZNEAR - a->z) / (b->z - a->z);
            CVt c;
            c.x = a->x + (b->x - a->x) * t; c.y = a->y + (b->y - a->y) * t; c.z = ZNEAR;
            c.r = a->r + (b->r - a->r) * t; c.g = a->g + (b->g - a->g) * t; c.b = a->b + (b->b - a->b) * t;
            poly[n++] = c;
        }
    }
    if (n < 3) return;
    PVt p[5];
    float f = CAM.focal;
    int left = 0, right = 0, top = 0, bot = 0;
    for (int i = 0; i < n; i++) {
        float iz = 1.0f / poly[i].z;
        p[i].sx = RW / 2.0f + poly[i].x * f * iz;
        p[i].sy = RH / 2.0f - poly[i].y * f * iz;
        p[i].iz = iz;
        p[i].r = poly[i].r; p[i].g = poly[i].g; p[i].b = poly[i].b;
        left += p[i].sx < 0; right += p[i].sx > RW; top += p[i].sy < 0; bot += p[i].sy > RH;
    }
    if (left == n || right == n || top == n || bot == n) return;
    int a16 = (int)(alpha * 16 + 0.5f);
    (void)flags;
    for (int i = 1; i + 1 < n; i++) raster(&p[0], &p[i], &p[i + 1], a16);
}

static float desatK;   /* 0 = full colour, 1 = black and white (the moment you die) */
void eng_set_desat(float k) { desatK = k < 0 ? 0 : (k > 1 ? 1 : k); }

void eng_tri(const EV *a, const EV *b, const EV *c, int tex, int flags) {
    const EV *e[3] = {a, b, c};
    EV f[3];
    /* distance fog toward the sky colour */
    if (LT.fogFar > LT.fogNear && !(flags & E_EMIT)) {
        for (int i = 0; i < 3; i++) {
            float k = fogk(e[i]->p);
            if (k <= 0) continue;          /* unfogged corners are passed through untouched */
            f[i] = *e[i];
            {
                float m[3] = {1, 1, 1};
                if (tex >= 0) { m[0] = texAvg[tex * 3] / 255.0f; m[1] = texAvg[tex * 3 + 1] / 255.0f; m[2] = texAvg[tex * 3 + 2] / 255.0f; }
                /* fog the final colour: (col*tex)*(1-k) + fog*k, expressed on the vertex colour */
                f[i].r = f[i].r * (1 - k) + (m[0] > 0.05f ? LT.fog[0] / m[0] : LT.fog[0]) * k;
                f[i].g = f[i].g * (1 - k) + (m[1] > 0.05f ? LT.fog[1] / m[1] : LT.fog[1]) * k;
                f[i].b = f[i].b * (1 - k) + (m[2] > 0.05f ? LT.fog[2] / m[2] : LT.fog[2]) * k;
            }
            e[i] = &f[i];
        }
    }
    if (desatK > 0) {
        for (int i = 0; i < 3; i++) {
            if (e[i] != &f[i]) { f[i] = *e[i]; e[i] = &f[i]; }
            float l = f[i].r * 0.3f + f[i].g * 0.55f + f[i].b * 0.15f;
            f[i].r += (l - f[i].r) * desatK; f[i].g += (l - f[i].g) * desatK; f[i].b += (l - f[i].b) * desatK;
        }
    }
    engTris++;
    if (useGpu) {
        if (!sink) return;
        GVert g[3];
        for (int i = 0; i < 3; i++) {
            g[i].x = e[i]->p.x; g[i].y = e[i]->p.y; g[i].z = e[i]->p.z;
            g[i].s = e[i]->s; g[i].t = 1.0f - e[i]->t;
            g[i].r = e[i]->r > 1 ? 1 : (e[i]->r < 0 ? 0 : e[i]->r);
            g[i].g = e[i]->g > 1 ? 1 : (e[i]->g < 0 ? 0 : e[i]->g);
            g[i].b = e[i]->b > 1 ? 1 : (e[i]->b < 0 ? 0 : e[i]->b);
            g[i].a = e[i]->a;
        }
        sink(g, tex, (flags & E_TRANS) != 0);
        return;
    }
    sw_tri(e, tex, flags, (flags & E_TRANS) ? a->a : 1.0f);
}

/* ================= meshes and shapes ================= */

#define MAXV 1024
static V3 wp[MAXV];
static EV ev[MAXV];

/* is a sphere (roughly) in view? used to skip whole groups of quads */
int eng_visible(V3 cw, float rad) {
    V3 d = vsub(cw, CAM.eye);
    float zf = vdot(d, CAM.f);
    if (zf < -rad) return 0;
    if (fabsf(vdot(d, CAM.r)) > zf * 0.72f + rad * 1.3f) return 0;
    if (fabsf(vdot(d, CAM.u)) > zf * 0.45f + rad * 1.3f) return 0;
    return 1;
}


void draw_quad(V3 a, V3 b, V3 c, V3 d, int tex, float u0, float v0, float u1, float v1, const float col[3], int flags) {
    V3 n = vnorm(vcross(vsub(b, a), vsub(d, a)));
    if (!(flags & E_NOCULL) && vdot(n, vsub(CAM.eye, a)) <= 0) return;
    V3 P[4] = {a, b, c, d};
    float U[4] = {u0, u1, u1, u0}, V[4] = {v1, v1, v0, v0};
    EV e[4];
    for (int i = 0; i < 4; i++) {
        e[i].p = P[i];
        e[i].s = U[i];
        e[i].t = V[i];
        float out[3];
        if (flags & (E_EMIT | E_UNLIT)) { out[0] = col[0]; out[1] = col[1]; out[2] = col[2]; }
        else light_vertex(P[i], n, col, out);
        e[i].r = out[0]; e[i].g = out[1]; e[i].b = out[2]; e[i].a = 1;
    }
    eng_tri(&e[0], &e[1], &e[2], tex, flags);
    eng_tri(&e[0], &e[2], &e[3], tex, flags);
}

/* one face of a box, split into a grid so vertex lighting/fog look smooth */
static void face_grid(V3 o, V3 du, V3 dv, int nu, int nv, int tex, float ru, float rv, const float col[3], int flags) {
    for (int j = 0; j < nv; j++)
        for (int i = 0; i < nu; i++) {
            V3 a = vadd(o, vadd(vmul(du, (float)i / nu), vmul(dv, (float)j / nv)));
            V3 b = vadd(a, vmul(du, 1.0f / nu));
            V3 c = vadd(b, vmul(dv, 1.0f / nv));
            V3 d = vadd(a, vmul(dv, 1.0f / nv));
            float u0 = ru * i / nu, u1 = ru * (i + 1) / nu, v0 = rv * j / nv, v1 = rv * (j + 1) / nv;
            /* texture v grows downward in the image; faces are built bottom-up */
            draw_quad(a, b, c, d, tex, u0, rv - v1, u1, rv - v0, col, flags);
        }
}

static int segs(float len) {
    int n = (int)(len / 1.2f) + 1;
    return n > 10 ? 10 : n;
}

void draw_box_tex(V3 lo, V3 hi, int tex, float rep, const float col[3], int faces) {
    float sx = hi.x - lo.x, sy = hi.y - lo.y, sz = hi.z - lo.z;
    if (faces & BX_PY) face_grid(v3(lo.x, hi.y, hi.z), v3(sx, 0, 0), v3(0, 0, -sz), segs(sx), segs(sz), tex, sx * rep, sz * rep, col, 0);
    if (faces & BX_NY) face_grid(v3(lo.x, lo.y, lo.z), v3(sx, 0, 0), v3(0, 0, sz), segs(sx), segs(sz), tex, sx * rep, sz * rep, col, 0);
    if (faces & BX_PZ) face_grid(v3(lo.x, lo.y, hi.z), v3(sx, 0, 0), v3(0, sy, 0), segs(sx), segs(sy), tex, sx * rep, sy * rep, col, 0);
    if (faces & BX_NZ) face_grid(v3(hi.x, lo.y, lo.z), v3(-sx, 0, 0), v3(0, sy, 0), segs(sx), segs(sy), tex, sx * rep, sy * rep, col, 0);
    if (faces & BX_PX) face_grid(v3(hi.x, lo.y, hi.z), v3(0, 0, -sz), v3(0, sy, 0), segs(sz), segs(sy), tex, sz * rep, sy * rep, col, 0);
    if (faces & BX_NX) face_grid(v3(lo.x, lo.y, lo.z), v3(0, 0, sz), v3(0, sy, 0), segs(sz), segs(sy), tex, sz * rep, sy * rep, col, 0);
}

void draw_billboard(V3 p, float w, float h, const float col[3], float alpha, int flags) {
    V3 r = vmul(CAM.r, w * 0.5f), u = vmul(CAM.u, h * 0.5f);
    if (alpha < 0.999f) {
        /* soft round puff: solid centre fading to clear at the rim */
        EV c, in[7], out[7];
        c.p = p; c.s = c.t = 0; c.r = col[0]; c.g = col[1]; c.b = col[2]; c.a = alpha;
        for (int i = 0; i <= 6; i++) {
            float a = 2 * 3.14159265f * i / 6 + 0.26f;
            V3 d = vadd(vmul(r, cosf(a)), vmul(u, sinf(a)));
            in[i] = c; in[i].p = vadd(p, vmul(d, 0.55f)); in[i].a = alpha * 0.8f;
            out[i] = c; out[i].p = vadd(p, d); out[i].a = 0;
        }
        int fl = flags | E_TRANS;
        for (int i = 0; i < 6; i++) {
            eng_tri(&c, &in[i], &in[i + 1], -1, fl);
            eng_tri(&in[i], &out[i], &out[i + 1], -1, fl);
            eng_tri(&in[i], &out[i + 1], &in[i + 1], -1, fl);
        }
        return;
    }
    EV e[4];
    V3 P[4] = {vsub(vsub(p, r), u), vsub(vadd(p, r), u), vadd(vadd(p, r), u), vadd(vsub(p, r), u)};
    for (int i = 0; i < 4; i++) {
        e[i].p = P[i];
        e[i].s = e[i].t = 0;
        e[i].r = col[0]; e[i].g = col[1]; e[i].b = col[2]; e[i].a = alpha;
    }
    eng_tri(&e[0], &e[1], &e[2], -1, flags);
    eng_tri(&e[0], &e[2], &e[3], -1, flags);
}

/* a flickering flame tongue: yellow at the root, orange, then a clear red tip */
void draw_flame(V3 p, float w, float h, float phase, float alpha) {
    static const float hy[5] = {-0.06f, 0.12f, 0.4f, 0.7f, 1.0f};
    static const float wd[5] = {0.3f, 0.5f, 0.42f, 0.24f, 0.0f};
    static const float cl[5][4] = {{1, 0.9f, 0.5f, 0}, {1, 0.92f, 0.55f, 0.95f}, {1, 0.62f, 0.15f, 0.85f}, {0.95f, 0.32f, 0.06f, 0.55f}, {0.8f, 0.15f, 0.03f, 0}};
    EV L[5], R[5], C[5];
    for (int i = 0; i < 5; i++) {
        float sway = sinf(phase * 2.1f + i * 1.3f) * 0.14f * hy[i] * w + sinf(phase * 5.3f + i) * 0.05f * w * hy[i];
        V3 c = vadd(vadd(p, vmul(CAM.u, hy[i] * h)), vmul(CAM.r, sway));
        float hw = wd[i] * w * (1 + 0.12f * sinf(phase * 7 + i * 2));
        C[i].p = c;
        L[i].p = vsub(c, vmul(CAM.r, hw));
        R[i].p = vadd(c, vmul(CAM.r, hw));
        for (int k = 0; k < 3; k++) {
            EV *e = k == 0 ? &L[i] : (k == 1 ? &R[i] : &C[i]);
            e->s = e->t = 0;
            e->r = cl[i][0]; e->g = cl[i][1]; e->b = cl[i][2];
            e->a = (k == 2 ? cl[i][3] : cl[i][3] * 0.35f) * alpha;
        }
    }
    for (int i = 0; i < 4; i++) {
        eng_tri(&L[i], &C[i], &C[i + 1], -1, E_TRANS | E_EMIT | E_NOCULL);
        eng_tri(&L[i], &C[i + 1], &L[i + 1], -1, E_TRANS | E_EMIT | E_NOCULL);
        eng_tri(&C[i], &R[i], &R[i + 1], -1, E_TRANS | E_EMIT | E_NOCULL);
        eng_tri(&C[i], &R[i + 1], &C[i + 1], -1, E_TRANS | E_EMIT | E_NOCULL);
    }
}

/* ================= 2D ================= */

unsigned short col565(int r, int g, int b) {
    r = r < 0 ? 0 : (r > 255 ? 255 : r);
    g = g < 0 ? 0 : (g > 255 ? 255 : g);
    b = b < 0 ? 0 : (b > 255 ? 255 : b);
    return (unsigned short)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
}
unsigned short col4444(int r, int g, int b, int a) {
    r = r < 0 ? 0 : (r > 255 ? 255 : r);
    g = g < 0 ? 0 : (g > 255 ? 255 : g);
    b = b < 0 ? 0 : (b > 255 ? 255 : b);
    a = a < 0 ? 0 : (a > 255 ? 255 : a);
    return (unsigned short)(((r >> 4) << 12) | ((g >> 4) << 8) | ((b >> 4) << 4) | (a >> 4));
}

static inline void put(Canvas *c, int x, int y, int r, int g, int b, int a) {
    if (x < 0 || y < 0 || x >= c->w || y >= c->h || a <= 0) return;
    unsigned short *d = &c->px[y * c->w + x];
    if (c->fmt == 0) {
        if (a >= 255) { *d = col565(r, g, b); return; }
        int dr = ((*d >> 11) & 31) << 3, dg = ((*d >> 5) & 63) << 2, db = (*d & 31) << 3;
        *d = col565(dr + ((r - dr) * a >> 8), dg + ((g - dg) * a >> 8), db + ((b - db) * a >> 8));
    } else {
        int da = (*d & 15) * 17;
        if (a >= 255 || da == 0) { *d = col4444(r, g, b, a); return; }
        int dr = (*d >> 12) * 17, dg = ((*d >> 8) & 15) * 17, db = ((*d >> 4) & 15) * 17;
        int oa = a + (da * (255 - a) >> 8);
        if (oa < 1) oa = 1;
        int or_ = (r * a + (dr * da * (255 - a) >> 8)) / oa;
        int og = (g * a + (dg * da * (255 - a) >> 8)) / oa;
        int ob = (b * a + (db * da * (255 - a) >> 8)) / oa;
        *d = col4444(or_, og, ob, oa);
    }
}

void cv_fill(Canvas *c, int x, int y, int w, int h, int r, int g, int b, int a) {
    int x0 = x < 0 ? 0 : x, y0 = y < 0 ? 0 : y, x1 = x + w > c->w ? c->w : x + w, y1 = y + h > c->h ? c->h : y + h;
    if (a >= 255) {
        unsigned short v = c->fmt == 0 ? col565(r, g, b) : col4444(r, g, b, 255);
        for (int yy = y0; yy < y1; yy++)
            for (int xx = x0; xx < x1; xx++) c->px[yy * c->w + xx] = v;
        return;
    }
    for (int yy = y0; yy < y1; yy++)
        for (int xx = x0; xx < x1; xx++) put(c, xx, yy, r, g, b, a);
}

void cv_round(Canvas *c, int x, int y, int w, int h, int rad, int r, int g, int b, int a) {
    if (rad * 2 > h) rad = h / 2;
    if (rad * 2 > w) rad = w / 2;
    for (int yy = 0; yy < h; yy++) {
        int inset = 0;
        float cov = 1;
        int dy = yy < rad ? rad - yy : (yy >= h - rad ? yy - (h - rad - 1) : 0);
        if (dy) {
            float fx = sqrtf((float)(rad * rad) - (float)((dy - 0.5f) * (dy - 0.5f)));
            inset = rad - (int)fx;
            cov = fx - (int)fx;
        }
        if (inset > 0 && inset <= w / 2) {
            put(c, x + inset - 1, y + yy, r, g, b, (int)(a * cov));
            put(c, x + w - inset, y + yy, r, g, b, (int)(a * cov));
        }
        cv_fill(c, x + inset, y + yy, w - inset * 2, 1, r, g, b, a);
    }
}

void cv_frame(Canvas *c, int x, int y, int w, int h, int r, int g, int b, int a) {
    cv_fill(c, x, y, w, 1, r, g, b, a);
    cv_fill(c, x, y + h - 1, w, 1, r, g, b, a);
    cv_fill(c, x, y + 1, 1, h - 2, r, g, b, a);
    cv_fill(c, x + w - 1, y + 1, 1, h - 2, r, g, b, a);
}

void cv_line(Canvas *c, int x0, int y0, int x1, int y1, int r, int g, int b, int a) {
    int dx = abs(x1 - x0), dy = -abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx + dy;
    for (int n = 0; n < 2000; n++) {
        put(c, x0, y0, r, g, b, a);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}

void cv_circle(Canvas *c, int cx, int cy, int rad, int r, int g, int b, int a) {
    for (int y = -rad - 1; y <= rad + 1; y++)
        for (int x = -rad - 1; x <= rad + 1; x++) {
            float d = sqrtf((float)(x * x + y * y)) - rad;
            if (d > 0.5f) continue;
            float cov = d < -0.5f ? 1 : 0.5f - d;
            put(c, cx + x, cy + y, r, g, b, (int)(a * cov));
        }
}

int text_width(const char *s, int big) {
    const unsigned char *adv = big ? fontB_adv : fontS_adv;
    int w = 0;
    for (; *s; s++) {
        int ch = (unsigned char)*s;
        if (ch < 32 || ch > 126) ch = '?';
        w += adv[ch - 32];
    }
    return w;
}

void cv_text(Canvas *c, int x, int y, const char *s, int big, int r, int g, int b, int a) {
    const unsigned char *px = big ? fontB_px : fontS_px, *gw = big ? fontB_w : fontS_w, *adv = big ? fontB_adv : fontS_adv;
    const unsigned short *off = big ? fontB_off : fontS_off;
    int H = big ? FONT_B_H : FONT_S_H;
    for (; *s; s++) {
        int ch = (unsigned char)*s;
        if (ch < 32 || ch > 126) ch = '?';
        int i = ch - 32;
        const unsigned char *g0 = px + off[i];
        int w = gw[i];
        for (int yy = 0; yy < H; yy++)
            for (int xx = 0; xx < w; xx++) {
                int v = g0[yy * w + xx];
                if (v) put(c, x + xx, y + yy, r, g, b, a * v / 15);
            }
        x += adv[i];
    }
}
void cv_text_c(Canvas *c, int cx, int y, const char *s, int big, int r, int g, int b, int a) {
    cv_text(c, cx - text_width(s, big) / 2, y, s, big, r, g, b, a);
}
void cv_text_sh(Canvas *c, int x, int y, const char *s, int big, int r, int g, int b) {
    cv_text(c, x + 1, y + 1, s, big, 0, 0, 0, 170);
    cv_text(c, x, y, s, big, r, g, b, 255);
}
int cv_wrap(Canvas *c, int x, int y, int w, const char *s, int big, int r, int g, int b, int a) {
    char line[128];
    int lines = 0, H = big ? FONT_B_H - 3 : FONT_S_H - 1;
    while (*s) {
        int n = 0, lastSpace = -1;
        while (s[n] && n < 127) {
            line[n] = s[n];
            line[n + 1] = 0;
            if (s[n] == ' ') lastSpace = n;
            if (text_width(line, big) > w) break;
            n++;
        }
        if (s[n] && lastSpace > 0) n = lastSpace;
        if (n == 0) n = 1;
        memcpy(line, s, n);
        line[n] = 0;
        if (c) cv_text(c, x, y + lines * H, line, big, r, g, b, a);
        lines++;
        s += n;
        while (*s == ' ') s++;
    }
    return lines;
}

/* little vector icons */
void cv_icon(Canvas *c, int x, int y, int sz, int icon, int r, int g, int b, int a) {
    int cx = x + sz / 2, cy = y + sz / 2, k = sz / 8;
    switch (icon) {
    case IC_SUCTION:
        cv_fill(c, cx - k / 2, y + k, k, sz / 2, 200, 205, 215, a);
        cv_round(c, cx - sz * 3 / 8, cy, sz * 3 / 4, sz * 3 / 8, sz / 6, 70, 130, 240, a);
        break;
    case IC_PRY:
        cv_fill(c, cx - k / 2, y + k, k + 1, sz / 2, 255, 140, 40, a);
        for (int i = 0; i < sz / 3; i++) cv_fill(c, cx - (sz / 3 - i) / 2, cy + i, sz / 3 - i, 1, 255, 160, 60, a);
        break;
    case IC_SCREW:
        cv_round(c, cx - k, y + k, k * 2, sz / 2, k, 230, 60, 50, a);
        cv_fill(c, cx - 1, y + k + sz / 2, 2, sz / 3, 210, 214, 220, a);
        break;
    case IC_TWEEZ:
        cv_line(c, cx - 1, y + k, cx - k * 2, y + sz - k, 210, 214, 220, a);
        cv_line(c, cx, y + k, cx - k, y + sz - k, 210, 214, 220, a);
        cv_line(c, cx + 1, y + k, cx + k * 2, y + sz - k, 210, 214, 220, a);
        cv_line(c, cx + 2, y + k, cx + k * 2 + 1, y + sz - k, 210, 214, 220, a);
        break;
    case IC_TESTER:
        cv_round(c, cx - k * 2, y + k, k * 4, sz / 2, k, 40, 40, 46, a);
        cv_fill(c, cx - k, y + k * 2, k * 2, k * 2, 120, 230, 140, a);
        cv_fill(c, cx - 1, y + k + sz / 2, 2, sz / 3, 230, 190, 80, a);
        break;
    case IC_P_SCREEN:
        cv_round(c, cx - sz * 5 / 16, y + k / 2, sz * 5 / 8, sz - k, k, 30, 32, 40, a);
        cv_round(c, cx - sz * 4 / 16, y + k, sz / 2, sz - k * 2, k / 2 + 1, 90, 170, 255, a);
        cv_line(c, cx - k, cy - k, cx + k / 2, cy + k, 255, 255, 255, a);
        break;
    case IC_P_BATT:
        cv_round(c, x + k, y + k * 2, sz - k * 2, sz - k * 4, k, 60, 200, 90, a);
        cv_fill(c, x + sz - k, cy - k / 2 - 1, k / 2 + 1, k + 2, 60, 200, 90, a);
        cv_fill(c, x + k * 2, y + k * 3, (sz - k * 4) * 2 / 3, sz - k * 6, 230, 255, 230, a);
        break;
    case IC_P_PORT:
        cv_round(c, x + k, cy - k * 2, sz - k * 2, k * 4, k * 2 - 1, 120, 125, 140, a);
        cv_round(c, x + k * 2, cy - k, sz - k * 4, k * 2, k, 30, 32, 40, a);
        break;
    case IC_P_CAM:
        cv_round(c, x + k, y + k * 2, sz - k * 2, sz - k * 4, k, 40, 42, 50, a);
        cv_circle(c, cx, cy, sz / 4, 120, 160, 255, a);
        cv_circle(c, cx, cy, sz / 8, 20, 20, 40, a);
        break;
    case IC_P_SPK:
        cv_round(c, x + k, y + k * 3, sz - k * 2, sz - k * 6, k, 60, 62, 72, a);
        for (int i = 0; i < 4; i++) cv_fill(c, x + k * 2 + i * k * 3 / 2, cy - 1, k, 2, 200, 200, 210, a);
        break;
    case IC_BAG:
        cv_round(c, x + k, y + k * 3, sz - k * 2, sz - k * 4, k * 2, r, g, b, a);
        cv_frame(c, cx - k * 2, y + k, k * 4, k * 3, r, g, b, a);
        break;
    case IC_GUN:
        /* side view of a chunky pistol */
        cv_round(c, x + k, y + k * 2, sz - k * 2, k * 2 + 1, k / 2 + 1, r, g, b, a);
        cv_round(c, x + k * 2, y + k * 3, k * 2 + 1, sz / 2, k / 2 + 1, r, g, b, a);
        cv_frame(c, x + k * 4, y + k * 4, k * 2, k * 2, r, g, b, a);
        break;
    case IC_PART:
        cv_round(c, x + k, y + k * 2, sz - k * 2, sz - k * 4, k, 206, 160, 104, a);
        cv_fill(c, x + k, cy - 1, sz - k * 2, 2, 150, 110, 70, a);
        cv_text_c(c, cx, cy - 7, "+", 0, 255, 255, 255, a);
        break;
    case IC_CLOSE:
        cv_round(c, cx - k * 2, y + k, k * 4, sz - k * 2, k, 40, 44, 60, a);
        cv_line(c, cx - k, cy, cx, cy + k, 120, 230, 140, a);
        cv_line(c, cx, cy + k, cx + k + 2, cy - k - 1, 120, 230, 140, a);
        break;
    case IC_EXIT:
        cv_fill(c, x + k, cy - 1, sz - k * 3, 3, r, g, b, a);
        cv_line(c, x + k, cy, x + k * 3, cy - k * 2, r, g, b, a);
        cv_line(c, x + k, cy, x + k * 3, cy + k * 2, r, g, b, a);
        break;
    case IC_COIN:
        cv_circle(c, cx, cy, sz / 2 - 1, 255, 196, 40, a);
        cv_circle(c, cx, cy, sz / 2 - 3, 255, 220, 90, a);
        break;
    case IC_STAR:
        for (int i = 0; i < 5; i++) {
            float a0 = -1.5708f + i * 1.2566f;
            cv_line(c, cx, cy, cx + (int)(cosf(a0) * sz / 2), cy + (int)(sinf(a0) * sz / 2), r, g, b, a);
        }
        cv_circle(c, cx, cy, sz / 4, r, g, b, a);
        break;
    case IC_PHONE:
        cv_round(c, cx - sz / 4, y + 1, sz / 2, sz - 2, k, 40, 44, 60, a);
        cv_fill(c, cx - sz / 4 + 2, y + 3, sz / 2 - 4, sz - 7, 110, 170, 255, a);
        break;
    case IC_FIRE:
        cv_circle(c, cx, cy + k, sz / 3, 255, 120, 30, a);
        cv_circle(c, cx, cy - k, sz / 5, 255, 180, 60, a);
        cv_circle(c, cx, cy + k * 2, sz / 6, 255, 230, 120, a);
        break;
    case IC_BOX:
        cv_round(c, x + 1, y + k, sz - 2, sz - k * 2, 2, 206, 160, 104, a);
        cv_fill(c, cx - k / 2, y + k, k, sz - k * 2, 230, 200, 150, a);
        break;
    case IC_CLOCK:
        cv_circle(c, cx, cy, sz / 2 - 1, r, g, b, a);
        cv_circle(c, cx, cy, sz / 2 - 3, 30, 34, 44, a);
        cv_line(c, cx, cy, cx, cy - sz / 3, r, g, b, a);
        cv_line(c, cx, cy, cx + sz / 4, cy, r, g, b, a);
        break;
    }
}

V3 cam_eye(void) { return CAM.eye; }
