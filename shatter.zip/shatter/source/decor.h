/* SUPERHOT - furniture, cars, buildings and the shells of special places */
#ifndef DECOR_H
#define DECOR_H
#include "game.h"
/* draw a box of one of the furniture kinds; returns 0 if the kind is not furniture */
int decor_box(const Game *g, const Box *b, int idx);
/* the parts of a level's setting that are not boxes (ceilings, windows, markings) */
void decor_shell(const Game *g);
/* a server rack (a dark box in the server room) */
void decor_rack(const Game *g, const Box *b);
#endif
