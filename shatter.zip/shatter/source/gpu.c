/* SUPERHOT - hardware 3D (3DS GPU via citro3d), with optional 2x2 anti-aliasing.
 * The engine hands over lit triangles; they are sorted by texture, uploaded and drawn at
 * 400x240 (and in stereo 3D), then the full-resolution text/UI layer is drawn on top. */
#include <3ds.h>
#include <citro3d.h>
#include <string.h>
#include <stdlib.h>
#include "engine.h"
#include "gpu.h"
extern int hud_same;   /* (ui.c) the overlay is exactly as it was last frame */

extern const u8 vshader_shbin[];
extern const size_t vshader_shbin_size;

#define MAX_TRIS 24000
#define MAX_TTRIS 12000
#define GROUPS (TEX_COUNT + 1) /* textures, then untextured */
#define G_FLAT TEX_COUNT

/* anti-aliasing: draw at twice the size each way, and let the display transfer shrink it
 * (every screen pixel is the average of four), which smooths all the edges */
#define AA_TRANSFER_FLAGS                                                                       \
    (GX_TRANSFER_FLIP_VERT(0) | GX_TRANSFER_OUT_TILED(0) | GX_TRANSFER_RAW_COPY(0) |             \
     GX_TRANSFER_IN_FORMAT(GX_TRANSFER_FMT_RGBA8) | GX_TRANSFER_OUT_FORMAT(GX_TRANSFER_FMT_RGB565) | \
     GX_TRANSFER_SCALING(GX_TRANSFER_SCALE_XY))

#define DISPLAY_TRANSFER_FLAGS                                                                  \
    (GX_TRANSFER_FLIP_VERT(0) | GX_TRANSFER_OUT_TILED(0) | GX_TRANSFER_RAW_COPY(0) |             \
     GX_TRANSFER_IN_FORMAT(GX_TRANSFER_FMT_RGBA8) | GX_TRANSFER_OUT_FORMAT(GX_TRANSFER_FMT_RGB565) | \
     GX_TRANSFER_SCALING(GX_TRANSFER_SCALE_NO))

static DVLB_s *dvlb;
static shaderProgram_s prog;
static int uProj, uMV;
static C3D_RenderTarget *tgtL, *tgtR, *tgtAA;
static int aaWanted = 1, aaLinked;
static C3D_Tex texs[TEX_COUNT], whiteTex, hudTex;
static GVert *tstage;              /* see-through triangles, CPU-side, in emit order */
static unsigned char *tstageGrp;
static int ntri, nttri;
static GVert *vbuf[2], *tbuf[2];   /* GPU-side, sorted by texture */
static int frameIdx;
static GVert *hquad;
static unsigned short hudPrev[HW * HH];
static unsigned short *hudTiled;
static int ready;
static int grpStart[GROUPS], grpCount[GROUPS], tgrpStart[GROUPS], tgrpCount[GROUPS];
/* Solid triangles go straight into the GPU's buffer as they are made (no staging copy, no sort):
 * each stretch that uses one texture becomes one draw. Depth testing makes the order irrelevant. */
#define MAX_RUNS 4096
static int runStart[MAX_RUNS], runCount[MAX_RUNS], runGrp[MAX_RUNS], nrun;
static GVert *vfill;               /* the buffer being filled this frame */

/* 3DS textures are 8x8 tiles in Z-order. With t = 1 at the top, the first row in memory
 * shows at the top (checked on a real 2DS). */
static unsigned morton(unsigned x, unsigned y) {
    return (x & 1) | ((y & 1) << 1) | ((x & 2) << 1) | ((y & 2) << 2) | ((x & 4) << 2) | ((y & 4) << 3);
}
static void tile16(const unsigned short *src, int sw, int sh, unsigned short *dst, int w, int h) {
    /* where each pixel of the HUD lands in the tiled texture, worked out once */
    static unsigned *lut;
    static int lw, lh, lW;
    if (!lut || lw != sw || lh != sh || lW != w) {
        free(lut);
        lut = (unsigned *)malloc(sizeof(unsigned) * sw * sh);
        lw = sw; lh = sh; lW = w;
        if (lut)
            for (int y = 0; y < sh; y++)
                for (int x = 0; x < sw; x++) lut[y * sw + x] = ((y >> 3) * (w >> 3) + (x >> 3)) * 64 + morton(x & 7, y & 7);
        memset(dst, 0, w * h * 2);   /* the part outside the HUD stays clear */
    }
    if (!lut) {
        memset(dst, 0, w * h * 2);
        for (int y = 0; y < sh; y++)
            for (int x = 0; x < sw; x++) dst[((y >> 3) * (w >> 3) + (x >> 3)) * 64 + morton(x & 7, y & 7)] = src[y * sw + x];
        return;
    }
    int n = sw * sh;
    for (int i = 0; i < n; i++) dst[lut[i]] = src[i];
}

static void sink(const GVert *v, int tex, int trans) {
    int grp = (tex >= 0 && tex < TEX_COUNT) ? tex : G_FLAT;
    if (trans) {
        if (nttri >= MAX_TTRIS) return;
        memcpy(&tstage[nttri * 3], v, sizeof(GVert) * 3);
        tstageGrp[nttri++] = (unsigned char)grp;
    } else {
        if (ntri >= MAX_TRIS || !vfill) return;
        if (nrun == 0 || runGrp[nrun - 1] != grp) {
            if (nrun >= MAX_RUNS) return;
            runStart[nrun] = ntri * 3; runCount[nrun] = 0; runGrp[nrun] = grp; nrun++;
        }
        memcpy(&vfill[ntri * 3], v, sizeof(GVert) * 3);
        runCount[nrun - 1] += 3;
        ntri++;
    }
}

/* the same, but hands out the space so the engine writes the vertices in place (no copy) */
static GVert *alloc_tri(int tex, int trans) {
    int grp = (tex >= 0 && tex < TEX_COUNT) ? tex : G_FLAT;
    if (trans) {
        if (nttri >= MAX_TTRIS) return NULL;
        tstageGrp[nttri] = (unsigned char)grp;
        return &tstage[3 * nttri++];
    }
    if (ntri >= MAX_TRIS || !vfill) return NULL;
    if (nrun == 0 || runGrp[nrun - 1] != grp) {
        if (nrun >= MAX_RUNS) return NULL;
        runStart[nrun] = ntri * 3; runCount[nrun] = 0; runGrp[nrun] = grp; nrun++;
    }
    runCount[nrun - 1] += 3;
    return &vfill[3 * ntri++];
}

static int gpu_init_inner(void) {
    if (!C3D_Init(C3D_DEFAULT_CMDBUF_SIZE * 2)) return 0;
    tgtL = C3D_RenderTargetCreate(240, 400, GPU_RB_RGBA8, GPU_RB_DEPTH24_STENCIL8);
    tgtR = C3D_RenderTargetCreate(240, 400, GPU_RB_RGBA8, GPU_RB_DEPTH24_STENCIL8);
    if (!tgtL || !tgtR) return 0;
    C3D_RenderTargetSetOutput(tgtL, GFX_TOP, GFX_LEFT, DISPLAY_TRANSFER_FLAGS);
    C3D_RenderTargetSetOutput(tgtR, GFX_TOP, GFX_RIGHT, DISPLAY_TRANSFER_FLAGS);
    /* the big target for anti-aliasing (only used without stereo 3D, to fit in video memory).
     * If there is no room for it, we simply draw without anti-aliasing. */
    tgtAA = C3D_RenderTargetCreate(480, 800, GPU_RB_RGBA8, GPU_RB_DEPTH24_STENCIL8);

    dvlb = DVLB_ParseFile((u32 *)vshader_shbin, (u32)vshader_shbin_size);
    if (!dvlb) return 0;
    shaderProgramInit(&prog);
    shaderProgramSetVsh(&prog, &dvlb->DVLE[0]);
    C3D_BindProgram(&prog);
    uProj = shaderInstanceGetUniformLocation(prog.vertexShader, "projection");
    uMV = shaderInstanceGetUniformLocation(prog.vertexShader, "modelView");

    C3D_AttrInfo *ai = C3D_GetAttrInfo();
    AttrInfo_Init(ai);
    AttrInfo_AddLoader(ai, 0, GPU_FLOAT, 3); /* position */
    AttrInfo_AddLoader(ai, 1, GPU_FLOAT, 2); /* texcoord */
    AttrInfo_AddLoader(ai, 2, GPU_FLOAT, 4); /* lit colour + alpha */

    unsigned short *tl = (unsigned short *)linearAlloc(TEX * TEX * 2);
    if (!tl) return 0;
    for (int i = 0; i < TEX_COUNT; i++) {
        tile16(tex565 + i * TEX * TEX, TEX, TEX, tl, TEX, TEX);
        if (!C3D_TexInit(&texs[i], TEX, TEX, GPU_RGB565)) return 0;
        C3D_TexUpload(&texs[i], tl);
        C3D_TexSetFilter(&texs[i], GPU_LINEAR, GPU_LINEAR);
        C3D_TexSetWrap(&texs[i], GPU_REPEAT, GPU_REPEAT);
    }
    unsigned short white[64];
    for (int i = 0; i < 64; i++) white[i] = 0xFFFF;
    tile16(white, 8, 8, tl, 8, 8);
    if (!C3D_TexInit(&whiteTex, 8, 8, GPU_RGB565)) return 0;
    C3D_TexUpload(&whiteTex, tl);
    linearFree(tl);

    tstage = (GVert *)malloc(sizeof(GVert) * 3 * MAX_TTRIS);
    tstageGrp = (unsigned char *)malloc(MAX_TTRIS);
    for (int i = 0; i < 2; i++) {
        vbuf[i] = (GVert *)linearAlloc(sizeof(GVert) * 3 * MAX_TRIS);
        tbuf[i] = (GVert *)linearAlloc(sizeof(GVert) * 3 * MAX_TTRIS);
    }
    if (!tstage || !tstageGrp || !vbuf[0] || !vbuf[1] || !tbuf[0] || !tbuf[1]) return 0;

    if (!C3D_TexInit(&hudTex, 512, 256, GPU_RGBA4)) return 0;
    C3D_TexSetFilter(&hudTex, GPU_NEAREST, GPU_NEAREST);
    C3D_TexSetWrap(&hudTex, GPU_CLAMP_TO_EDGE, GPU_CLAMP_TO_EDGE);
    hudTiled = (unsigned short *)linearAlloc(512 * 256 * 2);
    hquad = (GVert *)linearAlloc(sizeof(GVert) * 6);
    if (!hudTiled || !hquad) return 0;
    float s1 = HW / 512.0f, t0 = 1.0f - HH / 256.0f;
    GVert q[6] = {
        {0, 0, 0.5f, 0, t0, 1, 1, 1, 1}, {400, 0, 0.5f, s1, t0, 1, 1, 1, 1}, {400, 240, 0.5f, s1, 1, 1, 1, 1, 1},
        {0, 0, 0.5f, 0, t0, 1, 1, 1, 1}, {400, 240, 0.5f, s1, 1, 1, 1, 1, 1}, {0, 240, 0.5f, 0, 1, 1, 1, 1, 1},
    };
    memcpy(hquad, q, sizeof(q));
    GSPGPU_FlushDataCache(hquad, sizeof(q));
    memset(hudPrev, 0xFF, sizeof(hudPrev));

    C3D_CullFace(GPU_CULL_NONE); /* back faces are removed on the CPU */
    eng_set_gpu_sink(sink);
    eng_set_gpu_alloc(alloc_tri);
    ready = 1;
    return 1;
}

int gpu_init(void) {
    if (gpu_init_inner()) return 1;
    ready = 0;
    C3D_Fini();
    return 0;
}

static void set_view(C3D_Mtx *m, const Cam *c) {
    float ex = c->eye.x, ey = c->eye.y, ez = c->eye.z;
    Mtx_Identity(m);
    m->r[0].x = c->r.x; m->r[0].y = c->r.y; m->r[0].z = c->r.z;
    m->r[0].w = -(c->r.x * ex + c->r.y * ey + c->r.z * ez);
    m->r[1].x = c->u.x; m->r[1].y = c->u.y; m->r[1].z = c->u.z;
    m->r[1].w = -(c->u.x * ex + c->u.y * ey + c->u.z * ez);
    m->r[2].x = -c->f.x; m->r[2].y = -c->f.y; m->r[2].z = -c->f.z;
    m->r[2].w = (c->f.x * ex + c->f.y * ey + c->f.z * ez);
    m->r[3].x = 0; m->r[3].y = 0; m->r[3].z = 0; m->r[3].w = 1;
}

static void tev_scene(void) {
    C3D_TexEnv *e0 = C3D_GetTexEnv(0);
    C3D_TexEnvInit(e0);
    C3D_TexEnvSrc(e0, C3D_RGB, GPU_TEXTURE0, GPU_PRIMARY_COLOR, GPU_PRIMARY_COLOR);
    C3D_TexEnvFunc(e0, C3D_RGB, GPU_MODULATE);
    C3D_TexEnvSrc(e0, C3D_Alpha, GPU_PRIMARY_COLOR, GPU_PRIMARY_COLOR, GPU_PRIMARY_COLOR);
    C3D_TexEnvFunc(e0, C3D_Alpha, GPU_REPLACE);
    C3D_TexEnvInit(C3D_GetTexEnv(1));
    C3D_TexEnvInit(C3D_GetTexEnv(2));
}

static void tev_hud(void) {
    C3D_TexEnv *e0 = C3D_GetTexEnv(0);
    C3D_TexEnvInit(e0);
    C3D_TexEnvSrc(e0, C3D_Both, GPU_TEXTURE0, GPU_PRIMARY_COLOR, GPU_PRIMARY_COLOR);
    C3D_TexEnvFunc(e0, C3D_Both, GPU_REPLACE);
    C3D_TexEnvInit(C3D_GetTexEnv(1));
    C3D_TexEnvInit(C3D_GetTexEnv(2));
}

static Cam frameCam;
static int hudOn;
static float frameFocalScale;

static void draw_groups(GVert *buf, int *start, int *count) {
    C3D_BufInfo *bi = C3D_GetBufInfo();
    BufInfo_Init(bi);
    BufInfo_Add(bi, buf, sizeof(GVert), 3, 0x210);
    for (int gi = 0; gi < GROUPS; gi++) {
        if (!count[gi]) continue;
        C3D_TexBind(0, gi < TEX_COUNT ? &texs[gi] : &whiteTex);
        C3D_DrawArrays(GPU_TRIANGLES, start[gi], count[gi]);
    }
}

static void draw_eye(C3D_RenderTarget *t, float iod, unsigned clear) {
    C3D_RenderTargetClear(t, C3D_CLEAR_ALL, clear, 0);
    C3D_FrameDrawOn(t);
    C3D_Mtx proj, view;
    const float fovx = 0.7428f * frameFocalScale; /* matches the software renderer's view */
    if (iod == 0) Mtx_PerspTilt(&proj, fovx, 400.0f / 240.0f, 0.04f, 160.0f, false);
    else Mtx_PerspStereoTilt(&proj, fovx, 400.0f / 240.0f, 0.04f, 160.0f, iod, 3.0f, false);
    set_view(&view, &frameCam);
    C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, uProj, &proj);
    C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, uMV, &view);
    tev_scene();
    C3D_DepthTest(true, GPU_GREATER, GPU_WRITE_ALL);
    C3D_AlphaBlend(GPU_BLEND_ADD, GPU_BLEND_ADD, GPU_ONE, GPU_ZERO, GPU_ONE, GPU_ZERO);
    {
        /* the solid world, one draw per run of a texture */
        C3D_BufInfo *bi = C3D_GetBufInfo();
        BufInfo_Init(bi);
        BufInfo_Add(bi, vbuf[frameIdx], sizeof(GVert), 3, 0x210);
        int bound = -1;
        for (int r = 0; r < nrun; r++) {
            if (!runCount[r]) continue;
            if (runGrp[r] != bound) { C3D_TexBind(0, runGrp[r] < TEX_COUNT ? &texs[runGrp[r]] : &whiteTex); bound = runGrp[r]; }
            C3D_DrawArrays(GPU_TRIANGLES, runStart[r], runCount[r]);
        }
    }
    if (nttri) {
        C3D_DepthTest(true, GPU_GREATER, GPU_WRITE_COLOR);
        C3D_AlphaBlend(GPU_BLEND_ADD, GPU_BLEND_ADD, GPU_SRC_ALPHA, GPU_ONE_MINUS_SRC_ALPHA, GPU_ONE, GPU_ONE_MINUS_SRC_ALPHA);
        draw_groups(tbuf[frameIdx], tgrpStart, tgrpCount);
    }
    if (hudOn) {
        C3D_Mtx ortho, ident;
        Mtx_OrthoTilt(&ortho, 0.0f, 400.0f, 0.0f, 240.0f, 100.0f, -100.0f, false);
        Mtx_Identity(&ident);
        C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, uProj, &ortho);
        C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, uMV, &ident);
        tev_hud();
        C3D_DepthTest(false, GPU_ALWAYS, GPU_WRITE_COLOR);
        C3D_AlphaBlend(GPU_BLEND_ADD, GPU_BLEND_ADD, GPU_SRC_ALPHA, GPU_ONE_MINUS_SRC_ALPHA, GPU_SRC_ALPHA, GPU_ONE_MINUS_SRC_ALPHA);
        C3D_TexBind(0, &hudTex);
        C3D_BufInfo *bi = C3D_GetBufInfo();
        BufInfo_Init(bi);
        BufInfo_Add(bi, hquad, sizeof(GVert), 3, 0x210);
        C3D_DrawArrays(GPU_TRIANGLES, 0, 6);
    }
}

static void sort_into(GVert *src, unsigned char *grp, int n, GVert *dst, int *start, int *count) {
    memset(count, 0, sizeof(int) * GROUPS);
    for (int i = 0; i < n; i++) count[grp[i]] += 3;
    int at = 0;
    for (int gi = 0; gi < GROUPS; gi++) { start[gi] = at; at += count[gi]; }
    int fill[GROUPS];
    memcpy(fill, start, sizeof(fill));
    for (int i = 0; i < n; i++) {
        memcpy(&dst[fill[grp[i]]], &src[i * 3], sizeof(GVert) * 3);
        fill[grp[i]] += 3;
    }
    if (at) GSPGPU_FlushDataCache(dst, at * sizeof(GVert));
}

void gpu_set_aa(int on) { aaWanted = on; }

void gpu_frame(void (*build)(void *), void *ctx, const Cam *cam, const unsigned short *hud, int hasHud,
               unsigned clearRGB, float slider) {
    if (!ready) return;
    ntri = nttri = 0;
    nrun = 0;
    /* fill the buffer the GPU is not still reading from the last frame */
    frameIdx ^= 1;
    vfill = vbuf[frameIdx];
    eng_begin(cam, 1);
    if (build) build(ctx);
    frameCam = *cam;
    frameFocalScale = 1.0f;
    if (ntri) GSPGPU_FlushDataCache(vfill, ntri * 3 * sizeof(GVert));
    sort_into(tstage, tstageGrp, nttri, tbuf[frameIdx], tgrpStart, tgrpCount);
    hudOn = hasHud;
    if (hasHud && !hud_same && memcmp(hud, hudPrev, sizeof(hudPrev))) {
        memcpy(hudPrev, hud, sizeof(hudPrev));
        tile16(hud, HW, HH, hudTiled, 512, 256);
        C3D_TexUpload(&hudTex, hudTiled);
    }
    unsigned clear = ((clearRGB >> 16) & 255) << 24 | ((clearRGB >> 8) & 255) << 16 | (clearRGB & 255) << 8 | 0xFF;
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    if ((slider > 0.02f || !aaWanted || !tgtAA) && aaLinked) {
        /* back to the normal-size targets */
        C3D_RenderTargetSetOutput(tgtL, GFX_TOP, GFX_LEFT, DISPLAY_TRANSFER_FLAGS); /* replaces the AA link */
        aaLinked = 0;
    }
    if (slider > 0.02f) {
        float iod = slider * 0.04f;
        draw_eye(tgtL, -iod, clear);
        draw_eye(tgtR, iod, clear);
    } else if (aaWanted && tgtAA) {
        /* the output is linked per frame: the AA target and the plain left target take turns */
        if (!aaLinked) C3D_RenderTargetSetOutput(tgtAA, GFX_TOP, GFX_LEFT, AA_TRANSFER_FLAGS); /* replaces tgtL */
        draw_eye(tgtAA, 0, clear);
        aaLinked = 1;
    } else {
        draw_eye(tgtL, 0, clear);
    }
    C3D_FrameEnd(0);
}

void gpu_exit(void) {
    if (!ready) return;
    if (tgtAA) C3D_RenderTargetDelete(tgtAA);
    C3D_RenderTargetDelete(tgtL);
    C3D_RenderTargetDelete(tgtR);
    for (int i = 0; i < TEX_COUNT; i++) C3D_TexDelete(&texs[i]);
    C3D_TexDelete(&whiteTex);
    C3D_TexDelete(&hudTex);
    shaderProgramFree(&prog);
    DVLB_Free(dvlb);
    C3D_Fini();
    ready = 0;
}
