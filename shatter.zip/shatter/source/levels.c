/* SUPERHOT - the levels.
 * Units are metres. You start facing +z (yaw 90 degrees). Walls are 3.2 m tall. */
#include "game.h"

#define WH 3.2f
#define T 0.3f
/* four walls round a room */
#define ROOM(a, b, c, d) {a - T, b - T, c + T, b, WH, BOX_WALL}, {a - T, d, c + T, d + T, WH, BOX_WALL}, \
                         {a - T, b, a, d, WH, BOX_WALL}, {c, b, c + T, d, WH, BOX_WALL}
#define A (PI * 0.5f)    /* facing +z */
#define D (-PI * 0.5f)   /* facing -z (towards you) */

/* ---- 00: tutorial. The enemies are added by the tutorial script in game.c ---- */
static const Box b0[] = {ROOM(-4, -2, 4, 14), {-4, 6.8f, -1.6f, 7.2f, WH, BOX_WALL}, {1.6f, 6.8f, 4, 7.2f, WH, BOX_WALL}};

/* building fronts all round instead of walls (outdoor levels) */
#define FACADES(a, b, c, d) {a - T, b - T, c + T, b, 12, BOX_FACADE}, {a - T, d, c + T, d + T, 12, BOX_FACADE}, \
                            {a - T, b, a, d, 12, BOX_FACADE}, {c, b, c + T, d, 12, BOX_FACADE}
/* shorthands: a plant in a pot, a sofa, a parked car */
#define PLANT(x, z, h) {(x) - 0.28f, (z) - 0.28f, (x) + 0.28f, (z) + 0.28f, h, BOX_PLANT}
#define POLE(x, z, h, d) {(x) - 0.06f, (z) - 0.06f, (x) + 0.06f, (z) + 0.06f, h, BOX_POLE, d}

/* ---- 01: a hotel lobby. three of them, your fists ---- */
static const Box b1[] = {ROOM(-5, -2, 5, 10), {-1.2f, 4.0f, 1.2f, 4.6f, 1.05f, BOX_PROP},
                         {-4.95f, 0.2f, -4.15f, 2.8f, 0.75f, BOX_SOFA, 2}, {4.15f, 0.2f, 4.95f, 2.8f, 0.75f, BOX_SOFA, 3},
                         {-3.5f, 0.9f, -2.8f, 2.1f, 0.42f, BOX_PROP}, {2.8f, 0.9f, 3.5f, 2.1f, 0.42f, BOX_PROP},
                         {-4.1f, 9.55f, -1.3f, 10, 2.1f, BOX_SHELF, 1},
                         PLANT(-4.6f, 9.6f, 1.6f), PLANT(4.6f, 9.6f, 1.6f), PLANT(1.75f, 4.3f, 1.2f), PLANT(-4.6f, -1.6f, 1.4f)};
static const EnemyDef e1[] = {{-3, 7.5f, D, 0, 0}, {0, 8.5f, D, 0, 0}, {3, 7.5f, D, 0, 0}};

/* ---- 02: a meeting room. a gun on the table, two shooters ---- */
static const Box b2[] = {ROOM(-4, -2, 4, 16), {-0.8f, 1.2f, 0.8f, 2.0f, 0.95f, BOX_PROP},
                         {-2.6f, 7.0f, -1.8f, 7.8f, WH, BOX_PILLAR}, {1.8f, 7.0f, 2.6f, 7.8f, WH, BOX_PILLAR},
                         {-0.75f, 9.4f, 0.75f, 12.2f, 0.75f, BOX_PROP},
                         {3.55f, 3.0f, 4, 6.0f, 2.0f, BOX_SHELF, 3}, {3.55f, 9.0f, 4, 12.0f, 2.0f, BOX_SHELF, 3},
                         PLANT(3.55f, -1.55f, 1.3f), PLANT(-3.55f, 15.55f, 1.5f), PLANT(3.55f, 15.55f, 1.5f)};
static const EnemyDef e2[] = {{-2, 13.5f, D, 1, 0}, {2, 13.5f, D, 1, 0}};
static const GunDef g2[] = {{0, 1.6f}};

/* ---- 03: a train carriage. they keep coming down the aisle ---- */
#define SEATS(z0, z1) {-1.6f, z0, -1.05f, z1, 0.5f, BOX_SOFA, 2}, {1.05f, z0, 1.6f, z1, 0.5f, BOX_SOFA, 3}
static const Box b3[] = {ROOM(-1.6f, -2, 1.6f, 26), SEATS(-1.9f, 0.8f), SEATS(2.4f, 8.0f), SEATS(9.6f, 15.2f), SEATS(16.8f, 22.4f), SEATS(24.0f, 25.9f),
                         POLE(0, 5.2f, 2.4f, 0), POLE(0, 12.4f, 2.4f, 0), POLE(0, 19.6f, 2.4f, 0)};
static const EnemyDef e3[] = {{0, 6.4f, D, 0, 0}, {0.6f, 12, D, WP_SMG, 0}, {-0.5f, 16, D, WP_BAT, 1.0f}, {0, 23, D, WP_SHOTGUN, 0}, {0.5f, 24, D, 0, 4.0f}};
static const GunDef g3[] = {{0.6f, 2.5f}};

/* ---- 04: the bar ---- */
static const Box b4[] = {ROOM(-6, -2, 6, 12), {-4.5f, 8.0f, 1.5f, 8.8f, 1.1f, BOX_PROP}, {-4.5f, 8.8f, -3.7f, 11.0f, 1.1f, BOX_PROP},
                         {-4.5f, 11.5f, 1.5f, 12.0f, 2.2f, BOX_SHELF, 1},
                         {-3.0f, 3.0f, -2.3f, 3.7f, WH, BOX_PILLAR}, {2.3f, 3.0f, 3.0f, 3.7f, WH, BOX_PILLAR},
                         {3.4f, 6.0f, 4.6f, 7.2f, 0.75f, BOX_PROP}, {-5.4f, 3.4f, -4.4f, 4.4f, 0.75f, BOX_PROP},
                         {5.3f, 0.6f, 6.0f, 3.4f, 0.8f, BOX_SOFA, 3},
                         PLANT(5.5f, 11.4f, 1.6f), PLANT(-5.6f, -1.6f, 1.4f), PLANT(5.6f, -1.6f, 1.4f)};
static const EnemyDef e4[] = {{-1.5f, 10.5f, D, 1, 0}, {4.5f, 10, D, WP_BAT, 0}, {-5, 6, 0, 0, 0}, {4.4f, 2.8f, PI, 1, 0}, {0, 11, D, WP_SHOTGUN, 3.0f}};
static const GunDef g4[] = {{-1.0f, 1.5f}, {4.0f, 6.6f}, {0.6f, 8.4f, WP_BAT}};

/* ---- 05: elevator doors open on a lobby full of them ---- */
static const Box b5[] = {ROOM(-5, -2, 5, 12), {-5, 1.8f, -1.2f, 2.1f, WH, BOX_WALL}, {1.2f, 1.8f, 5, 2.1f, WH, BOX_WALL},
                         {-1.6f, -2, -1.2f, 1.8f, WH, BOX_WALL}, {1.2f, -2, 1.6f, 1.8f, WH, BOX_WALL},
                         {-3.5f, 6.0f, -2.5f, 7.0f, WH, BOX_PILLAR}, {2.5f, 6.0f, 3.5f, 7.0f, WH, BOX_PILLAR},
                         {-4.95f, 3.2f, -4.15f, 5.6f, 0.75f, BOX_SOFA, 2}, {-0.9f, 9.2f, 0.9f, 9.9f, 0.42f, BOX_PROP},
                         PLANT(-4.6f, 11.5f, 1.6f), PLANT(4.6f, 11.5f, 1.6f), PLANT(4.6f, 2.5f, 1.3f)};
static const EnemyDef e5[] = {{-1.5f, 4.0f, D, 1, 0}, {1.5f, 4.5f, D, 0, 0}, {0, 8.0f, D, WP_SHOTGUN, 0}, {-4, 10, D, 0, 3}, {4, 10, D, 1, 5}};
static const GunDef g5[] = {{0, 0.4f}};

/* ---- 06: an open-plan office ---- */
#define DESKS(x0, x1, z0) {x0, z0, x1, z0 + 1.0f, 0.75f, BOX_DESK, 1}, {x0, z0 + 1.0f, x1, z0 + 1.06f, 1.25f, BOX_PART}
static const Box b6[] = {ROOM(-7, -2, 7, 14),
                         DESKS(-5.5f, -3.5f, 3), DESKS(-1, 1, 3), DESKS(3.5f, 5.5f, 3),
                         DESKS(-5.5f, -3.5f, 7), DESKS(-1, 1, 7), DESKS(3.5f, 5.5f, 7),
                         {-7, 10.5f, -2, 11, 2.0f, BOX_SHELF, 1}, {2, 10.5f, 7, 11, 2.0f, BOX_SHELF, 1},
                         PLANT(-6.6f, -1.6f, 1.5f), PLANT(6.6f, -1.6f, 1.5f), PLANT(6.6f, 13.6f, 1.6f), PLANT(-1.6f, 10.75f, 1.3f)};
static const EnemyDef e6[] = {{-4.5f, 5.5f, D, 0, 0}, {0, 9, D, WP_SHOTGUN, 0}, {4.5f, 5.5f, D, WP_BAT, 0}, {-3, 12.5f, D, 1, 0},
                              {3, 12.5f, D, 1, 2}, {0, 13, D, 0, 6}, {-6, 12.5f, D, WP_SMG, 9}};
static const GunDef g6[] = {{0, 3.5f}, {-4.5f, 7.5f}};

/* ---- 07: an underground car park ---- */
static const Box b7[] = {ROOM(-8, -2, 8, 16),
                         {-5, 3, -4, 4, WH, BOX_PILLAR}, {4, 3, 5, 4, WH, BOX_PILLAR}, {-0.5f, 6, 0.5f, 7, WH, BOX_PILLAR},
                         {-5, 9, -4, 10, WH, BOX_PILLAR}, {4, 9, 5, 10, WH, BOX_PILLAR}, {-0.5f, 12, 0.5f, 13, WH, BOX_PILLAR},
                         {-7.9f, 4.35f, -3.7f, 6.15f, 1.4f, BOX_CAR, 2}, {-7.9f, 11.85f, -3.7f, 13.65f, 1.4f, BOX_CAR, 2},
                         {3.7f, 6.85f, 7.9f, 8.65f, 1.4f, BOX_CAR, 3}, {3.7f, -0.65f, 7.9f, 1.15f, 1.4f, BOX_CAR, 3},
                         {6.6f, 14.6f, 7.8f, 15.8f, 1.0f, BOX_CRATE}};
static const EnemyDef e7[] = {{-2.5f, 6, D, 1, 0}, {4.5f, 5.5f, D, WP_SHOTGUN, 0}, {0, 10, D, WP_BAT, 0}, {-6, 14.6f, D, 0, 2},
                              {6, 13.6f, D, 1, 3}, {0, 15, D, WP_SMG, 7}, {-7, 7.6f, 0, 0, 9}, {7, 10.8f, PI, 0, 9}};
static const GunDef g7[] = {{-2.5f, 1.0f}, {2.4f, 2.2f, WP_BAT}};

/* ---- 08: a street. everyone, all at once ---- */
static const Box b8[] = {FACADES(-10, -2, 10, 20),
                         {-8.2f, 2.5f, -6.4f, 6.7f, 1.4f, BOX_CAR, 0}, {-8.2f, 12.0f, -6.4f, 16.2f, 1.4f, BOX_CAR, 1},
                         {6.4f, 4.6f, 8.2f, 8.8f, 1.4f, BOX_CAR, 1}, {-2.6f, 10.2f, 1.6f, 12.0f, 1.4f, BOX_CAR, 2},
                         {8.7f, 15.0f, 9.9f, 16.8f, 1.25f, BOX_CRATE},
                         POLE(-8.9f, 1, 4.6f, 0), POLE(-8.9f, 7.5f, 4.6f, 0), POLE(-8.9f, 17, 4.6f, 0), POLE(8.9f, 3, 4.6f, 0), POLE(8.9f, 12.5f, 4.6f, 0),
                         PLANT(-9.2f, 4.5f, 3.6f), PLANT(-9.2f, 13, 3.8f), PLANT(9.2f, 7.5f, 3.6f), PLANT(9.2f, 0.4f, 3.7f)};
static const EnemyDef e8[] = {{-5, 8, D, WP_BAT, 0}, {5, 8, D, 0, 0}, {0, 14, D, WP_SMG, 0},
                              {-8, 18, D, WP_SHOTGUN, 3}, {8, 18, D, 1, 3}, {-9, 10, 0, 0, 5}, {9, 10, PI, WP_KATANA, 5},
                              {0, 19, D, WP_SMG, 9}, {-3, 19, D, 0, 11}, {3, 19, D, 0, 11}, {0, 18, D, 1, 14}};
static const GunDef g8[] = {{-4, 1.0f}, {4, 1.0f, WP_SHOTGUN}};

/* ---- 09: the stairwell landing ---- */
static const Box b9[] = {ROOM(-4, -2, 4, 18), {-4, 5, 0.8f, 5.4f, WH, BOX_WALL}, {-0.8f, 11, 4, 11.4f, WH, BOX_WALL},
                         {-4, 6.2f, -2.8f, 10.4f, 1.6f, BOX_STAIRS, 0}, {3.0f, 12.0f, 4, 16.2f, 1.6f, BOX_STAIRS, 1},
                         {2.2f, 2.5f, 3.4f, 3.7f, 0.9f, BOX_PROP}, {-3.4f, 14, -2.2f, 15.2f, 0.9f, BOX_PROP},
                         PLANT(3.6f, -1.6f, 1.3f), PLANT(-3.6f, 17.6f, 1.4f)};
static const EnemyDef e9[] = {{2.5f, 8, D, WP_SHOTGUN, 0}, {-2.0f, 8.5f, D, 0, 0}, {-2.5f, 16.6f, D, 1, 0}, {2.4f, 16.6f, D, 0, 2}, {0, 17, D, 1, 6}};
static const GunDef g9[] = {{2.8f, 3.1f}};

/* ---- 10: the server room (something is wrong) ---- */
static const Box b10[] = {ROOM(-6, -2, 6, 16),
                          {-5, 3, -4, 13, 2.2f, BOX_DARK}, {-2, 3, -1, 13, 2.2f, BOX_DARK}, {1, 3, 2, 13, 2.2f, BOX_DARK}, {4, 3, 5, 13, 2.2f, BOX_DARK},
                          {-6, 0.2f, -5.2f, 1.8f, 1.9f, BOX_CRATE, 2}, {5.2f, 0.2f, 6, 1.8f, 1.9f, BOX_CRATE, 3}};
static const EnemyDef e10[] = {{-2.9f, 8, D, WP_KATANA, 0}, {2.9f, 8, D, 0, 0}, {0, 14.5f, D, WP_SMG, 0}, {-5.5f, 14.5f, D, 1, 2}, {5.5f, 14.5f, D, 1, 2},
                               {-2.9f, 14, D, WP_KATANA, 6}, {2.9f, 14, D, WP_BAT, 6}};
static const GunDef g10[] = {{0, 1.5f}, {-3.0f, 1.0f, WP_KATANA}};

/* ---- 11: a crossroads between four buildings ---- */
static const Box b11[] = {FACADES(-9, -2, 9, 18),
                          {-9, -2, -5, 4.8f, 12, BOX_FACADE}, {5, -2, 9, 4.8f, 12, BOX_FACADE},
                          {-9, 14.2f, -5, 18, 12, BOX_FACADE}, {5, 14.2f, 9, 18, 12, BOX_FACADE},
                          {1.6f, -1.2f, 3.4f, 3.0f, 1.4f, BOX_CAR, 0}, {-7.6f, 10.6f, -3.4f, 12.4f, 1.4f, BOX_CAR, 2},
                          POLE(-3.7f, 6.1f, 3.6f, 1), POLE(3.7f, 13.9f, 3.6f, 1), POLE(-3.7f, 1.0f, 4.6f, 0), POLE(3.7f, 16.4f, 4.6f, 0),
                          PLANT(-4.3f, -0.6f, 3.6f), PLANT(4.3f, 2.2f, 3.7f), PLANT(-4.3f, 17.4f, 3.6f), PLANT(4.3f, 17.4f, 3.8f)};
static const EnemyDef e11[] = {{-6, 8.5f, 0, WP_SMG, 0}, {6, 8.5f, PI, 1, 0}, {0, 15, D, 0, 0}, {-4.2f, 16, D, 0, 3}, {4.2f, 16, D, 0, 3},
                               {-8, 8, 0, 1, 7}, {8, 11, PI, 1, 9}, {0, 17, D, 1, 11}};
static const GunDef g11[] = {{-1, 2}, {1.5f, 9, WP_SHOTGUN}};

/* ---- 12: the gallery ---- */
#define PED(x, z) {(x) - 0.3f, (z) - 0.3f, (x) + 0.3f, (z) + 0.3f, 1.0f, BOX_PEDESTAL}
static const Box b12[] = {ROOM(-7, -2, 7, 20), {-7, 6, -3, 6.4f, 2.6f, BOX_WALL}, {3, 6, 7, 6.4f, 2.6f, BOX_WALL},
                          {-1, 10, 1, 12, WH, BOX_PILLAR}, {-7, 14, -3, 14.4f, 2.6f, BOX_WALL}, {3, 14, 7, 14.4f, 2.6f, BOX_WALL},
                          PED(-4.3f, 2.7f), PED(4.3f, 2.7f), PED(-2.2f, 9.3f), PED(2.2f, 12.7f), PED(-4.0f, 17.3f), PED(4.0f, 17.3f),
                          {-0.9f, 3.8f, 0.9f, 4.3f, 0.46f, BOX_SOFA, 0}};
static const EnemyDef e12[] = {{-5, 9, D, 1, 0}, {5, 9, D, 1, 0}, {0, 16, D, WP_SHOTGUN, 0}, {-5, 18, D, WP_KATANA, 1}, {5, 18, D, WP_KATANA, 1},
                               {0, 19, D, 1, 5}, {-6, 3, 0, 0, 8}, {6, 3, PI, 0, 8}};
static const GunDef g12[] = {{-2, 1}, {2, 1}, {0, 4.05f, WP_KATANA}};

/* ---- 13: the box ---- */
static const Box b13[] = {ROOM(-5, -5, 5, 5), {-1, -1, 1, 1, WH, BOX_PILLAR}};
static const EnemyDef e13[] = {{-4, 4, D, WP_BAT, 0}, {4, 4, D, WP_KATANA, 0}, {-4, -4, A, 1, 0}, {4, -4, A, 1, 0},
                               {0, 4.5f, D, 1, 4}, {-4.5f, 0, 0, 0, 5}, {4.5f, 0, PI, 0, 5}, {4.2f, -4.5f, A, 1, 8}};
static const GunDef g13[] = {{0, -2.5f}};

/* ---- 14: the long dark ---- */
static const Box b14[] = {ROOM(-2, -2, 2, 34), {-2, 8, -0.8f, 8.6f, WH, BOX_DARK}, {0.8f, 15, 2, 15.6f, WH, BOX_DARK},
                          {-2, 22, -0.8f, 22.6f, WH, BOX_DARK}, {0.8f, 28, 2, 28.6f, WH, BOX_DARK}};
static const EnemyDef e14[] = {{0, 6, D, 0, 0}, {1, 12, D, WP_SMG, 0}, {-1, 18, D, 1, 0}, {0, 25, D, 0, 0}, {1, 31, D, 1, 0},
                               {-1, 33, D, 1, 4}, {0, 32, D, 0, 6}, {0, 33, D, 1, 10}};
static const GunDef g14[] = {{0.8f, 2}};

/* ---- 15: the penthouse. everyone, again. this is where it ends ---- */
static const Box b15[] = {ROOM(-11, -2, 11, 22),
                          {-7, 5, -3, 5.6f, 1.0f, BOX_PROP}, {3, 5, 7, 5.6f, 1.0f, BOX_PROP}, {-1, 9, 1, 11, WH, BOX_DARK},
                          {-9, 13, -7, 15, WH, BOX_PILLAR}, {7, 13, 9, 15, WH, BOX_PILLAR}, {-4, 18, 4, 18.6f, 1.0f, BOX_PROP},
                          {-10.95f, 3.6f, -10.15f, 6.8f, 0.75f, BOX_SOFA, 2}, {10.15f, 15.6f, 10.95f, 18.8f, 0.75f, BOX_SOFA, 3},
                          {-3.0f, 21.5f, 3.0f, 22, 2.1f, BOX_SHELF, 1},
                          PLANT(-10.6f, 21.6f, 1.7f), PLANT(10.6f, 21.6f, 1.7f), PLANT(-10.6f, -1.6f, 1.5f), PLANT(10.6f, -1.6f, 1.5f)};
static const EnemyDef e15[] = {{-5, 9, D, WP_SHOTGUN, 0}, {5, 9, D, WP_SMG, 0}, {0, 15, D, WP_KATANA, 0}, {-3, 20, D, 1, 0}, {3, 20, D, 1, 0},
                               {-10, 10, 0, 0, 3}, {10, 10, PI, 0, 3}, {0, 21, D, 1, 6}, {-8, 20, D, 0, 8}, {8, 20, D, 0, 8},
                               {-10, 1, 0, 1, 11}, {10, 1, PI, 1, 11}, {0, 21, D, 1, 14}, {0, 20, D, 0, 16}};
static const GunDef g15[] = {{-5, 1, WP_SHOTGUN}, {5, 1, WP_SMG}, {0, 1.5f, WP_KATANA}};

/* ================= the second ten: after the machine is no longer yours ================= */

/* ---- 16: a back alley ---- */
static const Box b16[] = {FACADES(-4, -2, 4, 30),
                          {1.0f, 8, 2.8f, 12.2f, 1.4f, BOX_CAR, 0}, {-2.8f, 18, -1.0f, 22.2f, 1.4f, BOX_CAR, 1},
                          {-3.9f, 5, -2.7f, 6.8f, 1.25f, BOX_CRATE}, {2.7f, 15, 3.9f, 16.8f, 1.25f, BOX_CRATE}, {-3.9f, 25, -2.7f, 26.8f, 1.25f, BOX_CRATE},
                          POLE(-3.4f, 3, 4.6f, 0), POLE(3.4f, 6.5f, 4.6f, 0), POLE(-3.4f, 13, 4.6f, 0), POLE(3.4f, 22, 4.6f, 0), POLE(-3.4f, 29, 4.6f, 0)};
static const EnemyDef e16[] = {{0, 7, D, WP_BAT, 0}, {-1.5f, 14, D, 1, 0}, {1.5f, 17, D, 0, 0}, {0, 24, D, WP_SMG, 0},
                               {-1, 28, D, WP_SHOTGUN, 2}, {1, 29, D, 1, 5}, {0, 29, D, WP_KATANA, 8}};
static const GunDef g16[] = {{0.5f, 2}, {-3.2f, 9.5f, WP_BAT}};

/* ---- 17: the library ---- */
#define SHELVES(z) {-6, z, -1.2f, (z) + 0.45f, 2.0f, BOX_SHELF, 1}, {1.2f, z, 6, (z) + 0.45f, 2.0f, BOX_SHELF, 1}, \
                   {-6, (z) + 0.45f, -1.2f, (z) + 0.9f, 2.0f, BOX_SHELF, 0}, {1.2f, (z) + 0.45f, 6, (z) + 0.9f, 2.0f, BOX_SHELF, 0}
static const Box b17[] = {ROOM(-7, -2, 7, 20), SHELVES(4), SHELVES(9), SHELVES(14),
                          {-4, 6.3f, -2, 7.3f, 0.75f, BOX_PROP}, {2, 6.3f, 4, 7.3f, 0.75f, BOX_PROP}, {-1, 11.3f, 1, 12.3f, 0.75f, BOX_PROP},
                          PLANT(-6.6f, -1.6f, 1.5f), PLANT(6.6f, -1.6f, 1.5f), PLANT(6.6f, 19.6f, 1.6f), PLANT(-6.6f, 19.6f, 1.6f)};
static const EnemyDef e17[] = {{0, 7, D, 0, 0}, {-5, 11.5f, D, 1, 0}, {5, 11.5f, D, 0, 0}, {0, 16.5f, D, WP_SMG, 0},
                               {-3, 18.5f, D, WP_KATANA, 0}, {3, 18.5f, D, 1, 3}, {-6.5f, 6.5f, 0, WP_BAT, 5}};
static const GunDef g17[] = {{0, 1.5f}, {-3, 6.8f, WP_SHOTGUN}};

/* ---- 18: the loading dock ---- */
static const Box b18[] = {ROOM(-9, -2, 9, 20),
                          {-6, 3, -4.8f, 4.2f, 1.2f, BOX_CRATE}, {-4.8f, 3, -3.6f, 4.2f, 0.9f, BOX_CRATE}, {3, 5, 4.2f, 6.2f, 1.2f, BOX_CRATE}, {4.2f, 5, 5.4f, 6.2f, 1.2f, BOX_CRATE},
                          {-1, 9, 1.2f, 10.2f, 1.5f, BOX_CRATE}, {-7, 12, -5.8f, 13.2f, 1.2f, BOX_CRATE}, {5, 13, 6.2f, 14.2f, 1.0f, BOX_CRATE},
                          {-3, 15, -2, 16, WH, BOX_PILLAR}, {2, 15, 3, 16, WH, BOX_PILLAR}, {-8.8f, 16, -4.6f, 17.8f, 1.4f, BOX_CAR, 2}};
static const EnemyDef e18[] = {{0, 7, D, 1, 0}, {-5, 8, D, 0, 0}, {6, 9, D, WP_SHOTGUN, 0}, {0, 13, D, WP_BAT, 0},
                               {-3, 18.5f, D, WP_SMG, 0}, {4, 18, D, 1, 3}, {-8, 6, 0, 0, 5}, {8, 2, PI, WP_KATANA, 8}};
static const GunDef g18[] = {{-2, 1.5f}, {4.8f, 5.6f, WP_SMG}};

/* ---- 19: the metro, a carriage that does not end ---- */
static const Box b19[] = {ROOM(-1.6f, -2, 1.6f, 40), SEATS(-1.9f, 0.8f), SEATS(2.4f, 8.0f), SEATS(9.6f, 15.2f), SEATS(16.8f, 22.4f),
                          SEATS(24.0f, 29.6f), SEATS(31.2f, 36.8f), SEATS(38.4f, 39.9f),
                          POLE(0, 5.2f, 2.4f, 0), POLE(0, 12.4f, 2.4f, 0), POLE(0, 19.6f, 2.4f, 0), POLE(0, 26.8f, 2.4f, 0), POLE(0, 34, 2.4f, 0)};
static const EnemyDef e19[] = {{0, 6.2f, D, 0, 0}, {0.5f, 11, D, WP_SMG, 0}, {-0.5f, 14, D, 0, 1}, {0, 21, D, WP_SHOTGUN, 0},
                               {0.4f, 27.8f, D, WP_BAT, 0}, {0, 33, D, 1, 0}, {-0.4f, 37, D, WP_KATANA, 3}, {0, 39, D, WP_SMG, 6}};
static const GunDef g19[] = {{0.6f, 2.5f}, {-0.5f, 17.5f, WP_SHOTGUN}};

/* ---- 20: the cafe ---- */
#define TABLE(x, z) {(x) - 0.4f, (z) - 0.4f, (x) + 0.4f, (z) + 0.4f, 0.75f, BOX_PROP}
static const Box b20[] = {ROOM(-7, -2, 7, 14), {-5, 10, 3, 10.8f, 1.1f, BOX_PROP}, {-5, 13.5f, 3, 14, 2.2f, BOX_SHELF, 1},
                          TABLE(-4.5f, 3), TABLE(-1.5f, 3), TABLE(1.5f, 3), TABLE(4.5f, 3),
                          TABLE(-4.5f, 6.5f), TABLE(-1.5f, 6.5f), TABLE(1.5f, 6.5f), TABLE(4.5f, 6.5f),
                          {6.3f, 0.6f, 7, 3.4f, 0.8f, BOX_SOFA, 3}, {6.3f, 4.8f, 7, 7.6f, 0.8f, BOX_SOFA, 3},
                          PLANT(-6.6f, -1.6f, 1.5f), PLANT(6.6f, 13.6f, 1.6f), PLANT(-6.6f, 9.5f, 1.4f)};
static const EnemyDef e20[] = {{0, 8.5f, D, WP_SHOTGUN, 0}, {-3, 8.5f, D, 0, 0}, {3, 8.5f, D, WP_BAT, 0}, {-6, 5, 0, 1, 0},
                               {5.5f, 12, D, WP_SMG, 0}, {0, 12.5f, D, WP_KATANA, 2}, {-6, 12, D, 0, 4}};
static const GunDef g20[] = {{0, 1.5f}, {-1.5f, 3, WP_SMG}};

/* ---- 21: the archive, a maze of machines ---- */
static const Box b21[] = {ROOM(-8, -2, 8, 20),
                          {-6, 2, -5, 8, 2.2f, BOX_DARK}, {-6, 10, -5, 17, 2.2f, BOX_DARK}, {-2.5f, 4, -1.5f, 12, 2.2f, BOX_DARK}, {1.5f, 4, 2.5f, 12, 2.2f, BOX_DARK},
                          {5, 2, 6, 8, 2.2f, BOX_DARK}, {5, 10, 6, 17, 2.2f, BOX_DARK}, {-1.5f, 15, 1.5f, 16, 2.2f, BOX_DARK},
                          {-8, 0, -7.2f, 1.6f, 1.9f, BOX_CRATE, 2}, {7.2f, 18, 8, 19.6f, 1.9f, BOX_CRATE, 3}};
static const EnemyDef e21[] = {{-3.7f, 8, D, 1, 0}, {3.7f, 8, D, 1, 0}, {0, 13, D, WP_SMG, 0}, {-7, 13, D, WP_KATANA, 0},
                               {7, 13, D, WP_BAT, 0}, {0, 18.5f, D, WP_SHOTGUN, 0}, {-3.7f, 18.5f, D, 0, 3}, {3.7f, 18.5f, D, 0, 5}};
static const GunDef g21[] = {{0, 1.5f}, {-3.7f, 1.5f, WP_KATANA}};

/* ---- 22: the plaza ---- */
static const Box b22[] = {FACADES(-12, -2, 12, 22),
                          {-7, 8, -4, 11, 4.0f, BOX_FACADE}, {4, 8, 7, 11, 4.0f, BOX_FACADE},
                          PLANT(-9, 4, 3.6f), PLANT(9, 4, 3.7f), PLANT(-9, 16, 3.8f), PLANT(9, 16, 3.6f),
                          {-2, 14, 2, 14.45f, 0.46f, BOX_SOFA, 0}, {-11.5f, 12, -9.7f, 16.2f, 1.4f, BOX_CAR, 0}, {9.7f, 1, 11.5f, 5.2f, 1.4f, BOX_CAR, 1},
                          POLE(-3, 6.5f, 4.6f, 0), POLE(3, 6.5f, 4.6f, 0), POLE(-3, 17.5f, 4.6f, 0), POLE(3, 17.5f, 4.6f, 0)};
static const EnemyDef e22[] = {{0, 10, D, WP_SMG, 0}, {-5.5f, 13, D, 1, 0}, {5.5f, 13, D, WP_SHOTGUN, 0}, {-10, 8, 0, WP_BAT, 0},
                               {10, 8, PI, 0, 0}, {0, 19, D, 1, 2}, {-8, 20, D, WP_KATANA, 4}, {8, 20, D, WP_SMG, 6}, {0, 21, D, WP_SHOTGUN, 9}};
static const GunDef g22[] = {{-1, 1.5f}, {1.5f, 1.5f, WP_SHOTGUN}, {0, 14.2f, WP_BAT}};

/* ---- 23: floor after floor ---- */
static const Box b23[] = {ROOM(-5, -2, 5, 24), {-5, 6, 1.5f, 6.4f, WH, BOX_WALL}, {-1.5f, 12, 5, 12.4f, WH, BOX_WALL}, {-5, 18, 1.5f, 18.4f, WH, BOX_WALL},
                          {3.2f, 1, 5, 5.4f, 1.6f, BOX_STAIRS, 0}, {-5, 7.4f, -3.2f, 11.6f, 1.6f, BOX_STAIRS, 0},
                          {3.2f, 13.4f, 5, 17.6f, 1.6f, BOX_STAIRS, 0}, {-5, 19.4f, -3.2f, 23.6f, 1.6f, BOX_STAIRS, 0},
                          {-4, 2, -3, 3, 0.9f, BOX_PROP}, PLANT(4.6f, -1.6f, 1.3f)};
static const EnemyDef e23[] = {{-2, 4, D, 1, 0}, {3.5f, 9, D, 0, 0}, {-1, 10, D, WP_SHOTGUN, 0}, {-3, 15, D, WP_BAT, 0},
                               {2, 16, D, WP_SMG, 0}, {0, 21, D, WP_KATANA, 0}, {3, 22.5f, D, 1, 3}, {-1, 23, D, 0, 5}};
static const GunDef g23[] = {{-3.5f, 2.5f}, {0, 8, WP_SMG}};

/* ---- 24: the museum ---- */
static const Box b24[] = {ROOM(-8, -2, 8, 26), {-8, 7, -3, 7.4f, 2.6f, BOX_WALL}, {3, 7, 8, 7.4f, 2.6f, BOX_WALL}, {-2, 13, 2, 13.4f, 2.6f, BOX_WALL},
                          {-8, 19, -4, 19.4f, 2.6f, BOX_WALL}, {4, 19, 8, 19.4f, 2.6f, BOX_WALL},
                          PED(-5, 3), PED(5, 3), PED(0, 5), PED(-5, 10.5f), PED(5, 10.5f), PED(-3, 16), PED(3, 16), PED(0, 22), PED(-6, 23), PED(6, 23),
                          {-1, 9.8f, 1, 10.25f, 0.46f, BOX_SOFA, 0}};
static const EnemyDef e24[] = {{0, 8.5f, D, 1, 0}, {-6.5f, 11, D, 0, 0}, {6, 13, D, WP_SHOTGUN, 0}, {0, 16, D, WP_KATANA, 0},
                               {-5, 21, D, WP_SMG, 0}, {5, 21, D, WP_BAT, 0}, {0, 24.5f, D, 1, 2}, {-7, 25, D, 0, 4}, {7, 25, D, WP_SMG, 6}};
static const GunDef g24[] = {{0, 1.5f}, {-1.5f, 1.5f, WP_KATANA}};

/* ---- 25: this is where it ends ---- */
static const Box b25[] = {ROOM(-12, -2, 12, 26), {-6.5f, 5.5f, -5.5f, 6.5f, WH, BOX_PILLAR}, {5.5f, 5.5f, 6.5f, 6.5f, WH, BOX_PILLAR},
                          {-6.5f, 13.5f, -5.5f, 14.5f, WH, BOX_PILLAR}, {5.5f, 13.5f, 6.5f, 14.5f, WH, BOX_PILLAR},
                          {-6.5f, 21.5f, -5.5f, 22.5f, WH, BOX_PILLAR}, {5.5f, 21.5f, 6.5f, 22.5f, WH, BOX_PILLAR},
                          {-0.5f, 9.5f, 0.5f, 10.5f, WH, BOX_DARK}, {-0.5f, 17.5f, 0.5f, 18.5f, WH, BOX_DARK}};
static const EnemyDef e25[] = {{-3, 8, D, 1, 0}, {3, 8, D, WP_SHOTGUN, 0}, {0, 14, D, WP_KATANA, 0}, {-9, 12, 0, WP_SMG, 0}, {9, 12, PI, WP_BAT, 0},
                               {-3, 20, D, 1, 2}, {3, 20, D, WP_SMG, 2}, {0, 24, D, WP_SHOTGUN, 4}, {-10, 22, D, 0, 6}, {10, 22, D, WP_KATANA, 6},
                               {-11, 2, 0, 1, 9}, {11, 2, PI, WP_SMG, 9}, {0, 25, D, WP_BAT, 12}, {0, 24.5f, D, 1, 14}};
static const GunDef g25[] = {{-3, 1, WP_SHOTGUN}, {3, 1, WP_SMG}, {0, 2, WP_KATANA}};

#define N(a) (int)(sizeof(a) / sizeof(a[0]))
const Level levels[] = {
    {"00TUTORIAL.lvl", "TUTORIAL", "learn to move,|punch and shoot|before anything|else.", 0, 0, A, -4, -2, 4, 14, N(b0), b0, 0, 0, 0, 0, 1, TH_WHITE},
    {"01KICK.lvl", "KICK", "a quiet lobby.|three of them.|use your fists.", 0, 0, A, -5, -2, 5, 10, N(b1), b1, N(e1), e1, 0, 0, 0, TH_LOBBY},
    {"02DUEL.lvl", "DUEL", "a pistol on|the table.|two shooters.", 0, 0, A, -4, -2, 4, 16, N(b2), b2, N(e2), e2, N(g2), g2, 0, TH_OFFICE},
    {"03TRAIN.lvl", "TRAIN", "the last carriage.|they keep coming|down the aisle.", 0, 0, A, -1.6f, -2, 1.6f, 26, N(b3), b3, N(e3), e3, N(g3), g3, 0, TH_TRAIN},
    {"04BAR.lvl", "BAR", "last orders.", 0, 0, A, -6, -2, 6, 12, N(b4), b4, N(e4), e4, N(g4), g4, 0, TH_BAR},
    {"05ELEVATOR.lvl", "ELEVATOR", "the doors open.|they are waiting.", 0, -0.5f, A, -5, -2, 5, 12, N(b5), b5, N(e5), e5, N(g5), g5, 0, TH_ELEVATOR},
    {"06OFFICE.lvl", "OFFICE", "nine to five.|then some.", 0, 0, A, -7, -2, 7, 14, N(b6), b6, N(e6), e6, N(g6), g6, 0, TH_OFFICE},
    {"07GARAGE.lvl", "GARAGE", "level minus two.|use the cars.|watch the sides.", 0, 0, A, -8, -2, 8, 16, N(b7), b7, N(e7), e7, N(g7), g7, 0, TH_GARAGE},
    {"08STREET.lvl", "STREET", "everyone.|all at once.|good luck.", 0, 0, A, -10, -2, 10, 20, N(b8), b8, N(e8), e8, N(g8), g8, 0, TH_STREET},
    {"09LANDING.lvl", "LANDING", "the stairwell.|they come from|both floors.", 0, 0, A, -4, -2, 4, 18, N(b9), b9, N(e9), e9, N(g9), g9, 0, TH_STAIRS},
    {"10SERVERS.lvl", "SERVERS", "the machines hum.|something is|listening.", 0, 0, A, -6, -2, 6, 16, N(b10), b10, N(e10), e10, N(g10), g10, 0, TH_SERVERS},
    {"11CROSSING.lvl", "CROSSING", "four ways in.|no way out.", 0, 0, A, -9, -2, 9, 18, N(b11), b11, N(e11), e11, N(g11), g11, 0, TH_STREET},
    {"12GALLERY.lvl", "GALLERY", "dont look away|from the screen.", 0, 0, A, -7, -2, 7, 20, N(b12), b12, N(e12), e12, N(g12), g12, 0, TH_GALLERY},
    {"13BOX.lvl", "BOX", "you are in the|box. you were|always in the box.", 0, -3.2f, A, -5, -5, 5, 5, N(b13), b13, N(e13), e13, N(g13), g13, 0, TH_WHITE},
    {"14DARK.lvl", "DARK", "keep walking.|keep walking.|keep walking.", 0, 0, A, -2, -2, 2, 34, N(b14), b14, N(e14), e14, N(g14), g14, 0, TH_WHITE},
    {"15PENTHOUSE.lvl", "PENTHOUSE", "the top floor.|nobody is coming|to help you.", 0, 0, A, -11, -2, 11, 22, N(b15), b15, N(e15), e15, N(g15), g15, 0, TH_LOBBY},
    {"16ALLEY.lvl", "ALLEY", "the back way out.|it is not a|way out.", 0, 0, A, -4, -2, 4, 30, N(b16), b16, N(e16), e16, N(g16), g16, 0, TH_STREET},
    {"17LIBRARY.lvl", "LIBRARY", "quiet please.", 0, 0, A, -7, -2, 7, 20, N(b17), b17, N(e17), e17, N(g17), g17, 0, TH_LOBBY},
    {"18LOADING.lvl", "LOADING", "crates and cover.|they come round|the sides.", 0, 0, A, -9, -2, 9, 20, N(b18), b18, N(e18), e18, N(g18), g18, 0, TH_GARAGE},
    {"19METRO.lvl", "METRO", "the carriage|goes on and on.", 0, 0, A, -1.6f, -2, 1.6f, 40, N(b19), b19, N(e19), e19, N(g19), g19, 0, TH_TRAIN},
    {"20CAFE.lvl", "CAFE", "a table for one.", 0, 0, A, -7, -2, 7, 14, N(b20), b20, N(e20), e20, N(g20), g20, 0, TH_BAR},
    {"21ARCHIVE.lvl", "ARCHIVE", "everything you|ever typed is|kept in here.", 0, 0, A, -8, -2, 8, 20, N(b21), b21, N(e21), e21, N(g21), g21, 0, TH_SERVERS},
    {"22PLAZA.lvl", "PLAZA", "open ground.|nowhere to hide.", 0, 0, A, -12, -2, 12, 22, N(b22), b22, N(e22), e22, N(g22), g22, 0, TH_STREET},
    {"23FLOORS.lvl", "FLOORS", "up. and up.|and up.", 0, 0, A, -5, -2, 5, 24, N(b23), b23, N(e23), e23, N(g23), g23, 0, TH_STAIRS},
    {"24MUSEUM.lvl", "MUSEUM", "you are one|of the exhibits.", 0, 0, A, -8, -2, 8, 26, N(b24), b24, N(e24), e24, N(g24), g24, 0, TH_GALLERY},
    {"25END.lvl", "END", "there is no|friend. there is|only the game.", 0, 0, A, -12, -2, 12, 26, N(b25), b25, N(e25), e25, N(g25), g25, 0, TH_WHITE},
};
const int levelCount = N(levels);
