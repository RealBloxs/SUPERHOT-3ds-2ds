/* SUPERHOT - game logic. Time only moves when you move. */
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "game.h"

#define EYE 1.6f
#define WALK_SPEED 3.3f
#define TURN_SPEED 2.6f
#define PLAYER_R 0.3f
#define ENEMY_R 0.3f
#define PUNCH_REACH 1.45f
#define ENEMY_BULLET_SPEED 8.0f
#define PLAYER_BULLET_SPEED 24.0f
#define SLOWEST 0.035f          /* time never quite stops */

float frand(Game *g) {
    g->rng = g->rng * 1664525u + 1013904223u;
    return ((g->rng >> 8) & 0xFFFFFF) / 16777216.0f;
}
static float frange(Game *g, float a, float b) { return a + (b - a) * frand(g); }
static float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static float wrapf(float a) { while (a > PI) a -= 2 * PI; while (a < -PI) a += 2 * PI; return a; }

static V3 eye_of(const Game *g) { return v3(g->pl.pos.x, EYE, g->pl.pos.z); }
static V3 fwd_of(const Game *g) {
    return v3(cosf(g->pl.yaw) * cosf(g->pl.pitch), -sinf(g->pl.pitch), sinf(g->pl.yaw) * cosf(g->pl.pitch));
}
static float pan_of(const Game *g, V3 p) {
    V3 d = vsub(p, g->pl.pos);
    float r = -sinf(g->pl.yaw) * d.x + cosf(g->pl.yaw) * d.z; /* right component */
    float l = vlen(d);
    return l > 0.01f ? clampf(r / l, -1, 1) : 0;
}
static float gain_of(const Game *g, V3 p, float range) {
    float d = vlen(vsub(p, g->pl.pos));
    return clampf(1 - d / range, 0, 1);
}

/* ================= collision ================= */

int box_is_surface(const Box *b) {
    return b->kind != BOX_WALL && b->kind != BOX_FACADE && b->kind != BOX_POLE && b->kind != BOX_PLANT && b->h < 1.6f;
}

int blocked(const Game *g, float x, float z, float r) {
    const Level *L = &levels[g->level];
    if (x < L->x0 + r || x > L->x1 - r || z < L->z0 + r || z > L->z1 - r) return 1;
    for (int i = 0; i < g->nbox; i++) {
        const Box *b = &g->box[i];
        if (x > b->x0 - r && x < b->x1 + r && z > b->z0 - r && z < b->z1 + r) return 1;
    }
    return 0;
}

/* first wall a segment runs into (2D boxes with a height); t in 0..1 */
int seg_hits_wall(const Game *g, V3 a, V3 b, float *tHit) {
    float best = 2;
    const Level *L = &levels[g->level];
    for (int i = -1; i < g->nbox; i++) {
        Box bx;
        if (i < 0) { bx.x0 = L->x0; bx.x1 = L->x1; bx.z0 = L->z0; bx.z1 = L->z1; bx.h = 99; } else bx = g->box[i];
        float t0 = 0, t1 = 1;
        float lo[3] = {bx.x0, 0, bx.z0}, hi[3] = {bx.x1, bx.h, bx.z1};
        float pa[3] = {a.x, a.y, a.z}, d[3] = {b.x - a.x, b.y - a.y, b.z - a.z};
        int inside = i < 0;
        int ok = 1;
        for (int k = 0; k < 3 && ok; k++) {
            if (fabsf(d[k]) < 1e-6f) { if (pa[k] < lo[k] || pa[k] > hi[k]) ok = 0; continue; }
            float u0 = (lo[k] - pa[k]) / d[k], u1 = (hi[k] - pa[k]) / d[k];
            if (u0 > u1) { float s = u0; u0 = u1; u1 = s; }
            if (u0 > t0) t0 = u0;
            if (u1 < t1) t1 = u1;
            if (t0 > t1) ok = 0;
        }
        if (inside) {
            /* the room itself: we hit when we leave it, or go below the floor */
            float tx = 2;
            for (int k = 0; k < 3; k += 2) {
                if (d[k] > 1e-6f) { float u = (hi[k] - pa[k]) / d[k]; if (u < tx) tx = u; }
                if (d[k] < -1e-6f) { float u = (lo[k] - pa[k]) / d[k]; if (u < tx) tx = u; }
            }
            if (d[1] < -1e-6f) { float u = (0 - pa[1]) / d[1]; if (u < tx) tx = u; }
            if (tx >= 0 && tx <= 1 && tx < best) best = tx;
            continue;
        }
        if (ok && t0 >= 0 && t0 <= 1 && t0 < best) best = t0;
    }
    if (best <= 1) { if (tHit) *tHit = best; return 1; }
    return 0;
}

static int line_of_sight(const Game *g, V3 a, V3 b) { return !seg_hits_wall(g, a, b, NULL); }

/* ================= bodies, poses, shattering ================= */

void pose_of_enemy(const Enemy *e, Pose *p) {
    memset(p, 0, sizeof(*p));
    p->pos = e->pos;
    p->yaw = e->yaw;
    p->walk = e->walk;
    p->walkAmt = e->walkAmt;
    p->aim = e->aim * e->aim * (3 - 2 * e->aim);     /* raise and lower the gun smoothly */
    p->armed = WP_IS_GUN(e->armed);
    p->weapon = e->armed;
    p->kick = e->kick;
    p->lean = 0.1f * e->walkAmt;
    if (e->state == EN_PUNCH) {
        /* pull the fist back, then throw it */
        float t = e->punchT;
        p->windup = t < 0.45f ? t / 0.45f : fmaxf(0, 1 - (t - 0.45f) / 0.12f);
        p->punch = t < 0.45f ? 0 : (t < 0.6f ? (t - 0.45f) / 0.15f : fmaxf(0, 1 - (t - 0.6f) * 2.5f));
        /* ease in and out, so the swing accelerates and settles instead of snapping */
        p->windup = p->windup * p->windup * (3 - 2 * p->windup);
        p->punch = p->punch * p->punch * (3 - 2 * p->punch);
    }
}

/* the 10 rigid parts of the glass man; meshes are stored relative to their joints */
static void hold_weapon(const Pose *p, Xf out[BODY_PARTS]);
void pose_parts(const Pose *p, Xf out[BODY_PARTS]) {
    const float *J[BODY_PARTS];
    for (int k = 0; k < BODY_PARTS; k++) J[k] = meshes[k].joint;
    Xf root = xf_at(p->pos, p->yaw, 1);
    float s = sinf(p->walk), c = cosf(p->walk);
    float w = p->walkAmt;
    /* the body rises twice per stride and sways side to side */
    float bob = (0.5f - 0.5f * cosf(2 * p->walk)) * 0.035f * w;
    Xf hips = root;
    hips.t = xf_point(&root, v3(0.025f * s * w, bob, 0));
    /* chest: lean into the walk, twist against the legs, wind up and throw the punch, rock back from recoil */
    Xf torso;
    {
        Xf a, b, cc, t1, t2;
        xf_rot(&a, v3(1, 0, 0), p->lean + 0.12f * p->punch - 0.12f * p->windup - 0.08f * p->kick);
        float blade = (p->weapon == WP_SHOTGUN || p->weapon == WP_SMG) ? -(0.3f + 0.15f * p->aim) : 0;   /* turn side-on behind a long gun */
        xf_rot(&b, v3(0, 1, 0), 0.12f * s * w + 0.45f * p->windup - 0.55f * p->punch + blade);
        xf_rot(&cc, v3(0, 0, 1), 0.04f * s * w);
        xf_mul(&t1, &b, &a);
        xf_mul(&t2, &t1, &cc);
        t2.t = v3(J[M_TORSO][0], J[M_TORSO][1], J[M_TORSO][2]);
        xf_mul(&torso, &hips, &t2);
    }
    out[M_TORSO] = torso;
    #define CHILD(par, k, from, axis, ang) do { Xf l; xf_rot(&l, axis, ang); \
        l.t = v3(J[k][0] - J[from][0], J[k][1] - J[from][1], J[k][2] - J[from][2]); xf_mul(&out[k], &par, &l); } while (0)
    CHILD(torso, M_HEAD, M_TORSO, v3(1, 0, 0), -0.05f - 0.04f * (0.5f - 0.5f * cosf(2 * p->walk)) * w);
    /* arms swing against the legs; the right one (UARM_R) punches or holds the gun out */
    float swing = 0.5f * s * w;
    float rUp, rFore;
    if (p->armed && p->aim > 0.05f) {
        rUp = -1.5f * p->aim - 0.35f * p->kick + swing * (1 - p->aim);
        rFore = -0.05f - 0.25f * p->kick;
    } else if (p->armed) {
        rUp = -0.3f + swing * 0.4f; rFore = -0.85f;
    } else {
        rUp = swing + 0.75f * p->windup - 1.55f * p->punch;
        rFore = -0.3f - 0.3f * w - 1.4f * p->windup + 1.2f * p->punch;
        if (rFore > -0.05f) rFore = -0.05f;
    }
    /* the guard hand comes up when fighting */
    float guard = p->windup > p->punch ? p->windup : p->punch;
    float lUp = -swing - 0.6f * guard, lFore = -0.35f - 0.35f * w - 1.0f * guard;
    CHILD(torso, M_UARM_L, M_TORSO, v3(1, 0, 0), lUp);
    CHILD(out[M_UARM_L], M_FARM_L, M_UARM_L, v3(1, 0, 0), lFore);
    CHILD(torso, M_UARM_R, M_TORSO, v3(1, 0, 0), rUp);
    CHILD(out[M_UARM_R], M_FARM_R, M_UARM_R, v3(1, 0, 0), rFore);
    /* legs: thigh swings, the knee bends as the foot comes forward */
    float th = 0.55f * s * w;
    float kneeL = (0.15f + 0.85f * fmaxf(0, -c)) * w * 0.95f, kneeR = (0.15f + 0.85f * fmaxf(0, c)) * w * 0.95f;
    Xf hipsJ;
    {
        Xf l; xf_ident(&l); l.t = v3(J[M_TORSO][0], J[M_TORSO][1], J[M_TORSO][2]);
        xf_mul(&hipsJ, &hips, &l);
    }
    CHILD(hipsJ, M_THIGH_L, M_TORSO, v3(1, 0, 0), -th);
    CHILD(out[M_THIGH_L], M_SHIN_L, M_THIGH_L, v3(1, 0, 0), kneeL);
    CHILD(hipsJ, M_THIGH_R, M_TORSO, v3(1, 0, 0), th);
    CHILD(out[M_THIGH_R], M_SHIN_R, M_THIGH_R, v3(1, 0, 0), kneeR);
    #undef CHILD
    hold_weapon(p, out);
}

/* ---- holding things with both hands ----
 * An arm is two bones. Given where the hand must be, the elbow is found by the law of cosines and
 * bends towards a "pole" (down and out, like a real elbow), and each bone is turned to point
 * along its new direction, twisted so the forearm folds the way a real one does. */

/* rotation taking an orthonormal rest frame (d0, side s0) onto (d1, s1) */
static void frame_rot(V3 d0, V3 s0, V3 d1, V3 s1, float m[9]) {
    V3 e1 = vnorm(d0), e2 = vnorm(vsub(s0, vmul(e1, vdot(e1, s0)))), e3 = vcross(e1, e2);
    V3 f1 = vnorm(d1), f2 = vsub(s1, vmul(f1, vdot(f1, s1)));
    if (vlen(f2) < 1e-4f) f2 = fabsf(f1.y) < 0.9f ? v3(0, 1, 0) : v3(1, 0, 0), f2 = vsub(f2, vmul(f1, vdot(f1, f2)));
    f2 = vnorm(f2);
    V3 f3 = vcross(f1, f2);
    float E[3][3] = {{e1.x, e1.y, e1.z}, {e2.x, e2.y, e2.z}, {e3.x, e3.y, e3.z}};
    float F[3][3] = {{f1.x, f1.y, f1.z}, {f2.x, f2.y, f2.z}, {f3.x, f3.y, f3.z}};
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) m[i * 3 + j] = F[0][i] * E[0][j] + F[1][i] * E[1][j] + F[2][i] * E[2][j];
}

/* the fist, in each forearm's own space (measured from the model) */
static V3 grip_of(int fore) { return fore == M_FARM_L ? v3(GRIP_L_X, GRIP_L_Y, GRIP_L_Z) : v3(GRIP_R_X, GRIP_R_Y, GRIP_R_Z); }

static void ik_arm(Xf out[BODY_PARTS], int up, int fore, V3 hand, V3 pole) {
    const float *JT = meshes[M_TORSO].joint, *JU = meshes[up].joint, *JF = meshes[fore].joint;
    const Xf *T = &out[M_TORSO];
    float s = T->s;
    V3 S = xf_point(T, v3(JU[0] - JT[0], JU[1] - JT[1], JU[2] - JT[2]));
    V3 restU = v3(JF[0] - JU[0], JF[1] - JU[1], JF[2] - JU[2]);
    V3 gp = grip_of(fore);
    float a = vlen(restU) * s, b = vlen(gp) * s;
    V3 d = vsub(hand, S);
    float dl = vlen(d);
    float lo = fabsf(a - b) + 0.01f, hi = (a + b) * 0.995f;
    if (dl < lo) dl = lo;
    if (dl > hi) dl = hi;            /* out of reach: the arm straightens towards it */
    V3 u = vnorm(d);
    V3 v = vsub(pole, vmul(u, vdot(pole, u)));
    v = vlen(v) > 1e-4f ? vnorm(v) : vnorm(vcross(u, v3(1, 0, 0)));
    float ca = (a * a + dl * dl - b * b) / (2 * a * dl);
    ca = ca > 1 ? 1 : (ca < -1 ? -1 : ca);
    float sa = sqrtf(1 - ca * ca);
    V3 E = vadd(S, vadd(vmul(u, a * ca), vmul(v, a * sa)));
    V3 H = vadd(S, vmul(u, dl));
    /* the forearm folds towards the hand: that is the arm's front (+z in the model) */
    V3 dU = vnorm(vsub(E, S)), fold = vsub(vsub(H, S), vmul(dU, vdot(vsub(H, S), dU)));
    if (vlen(fold) < 1e-4f) fold = vmul(v, -1);
    Xf X;
    xf_ident(&X);
    frame_rot(restU, v3(0, 0, 1), dU, fold, X.m);
    X.t = S; X.s = s;
    out[up] = X;
    V3 dF = vnorm(vsub(H, E));
    xf_ident(&X);
    frame_rot(gp, v3(0, 0, 1), dF, fold, X.m);
    X.t = E; X.s = s;
    out[fore] = X;
}

/* a weapon frame: grip at pos, barrel/blade along dir, its top towards hint */
static Xf weapon_frame(V3 pos, V3 dir, V3 hint) {
    Xf x;
    xf_ident(&x);
    V3 z = vnorm(dir);
    if (fabsf(vdot(z, vnorm(hint))) > 0.95f) hint = fabsf(z.y) < 0.9f ? v3(0, 1, 0) : v3(1, 0, 0);
    V3 xa = vnorm(vcross(hint, z)), y = vcross(z, xa);
    x.m[0] = xa.x; x.m[3] = xa.y; x.m[6] = xa.z;
    x.m[1] = y.x;  x.m[4] = y.y;  x.m[7] = y.z;
    x.m[2] = z.x;  x.m[5] = z.y;  x.m[8] = z.z;
    x.t = pos;
    return x;
}

/* where each hand goes on a weapon (in its own space): the shooting hand, then the other */
static V3 grip_main(int kind) {
    switch (kind) {
    case WP_SHOTGUN: return v3(0, -0.05f, -0.035f);
    case WP_SMG: return v3(0, -0.05f, -0.045f);
    case WP_KATANA: return v3(0, 0, 0.03f);
    case WP_BAT: return v3(0, 0, 0.06f);
    default: return v3(0, -0.04f, -0.008f);
    }
}
static V3 grip_off(int kind) {
    switch (kind) {
    case WP_SHOTGUN: return v3(0, -0.012f, 0.29f);       /* on the pump */
    case WP_SMG: return v3(0, -0.02f, 0.14f);            /* under the barrel */
    case WP_KATANA: return v3(0, 0, -0.1f);              /* lower on the handle */
    case WP_BAT: return v3(0, 0, -0.08f);
    default: return v3(0, -0.065f, -0.002f);             /* cupping the pistol grip */
    }
}
static float smooth01(float t) { t = t < 0 ? 0 : (t > 1 ? 1 : t); return t * t * (3 - 2 * t); }

Xf pose_weapon(const Pose *p, const Xf parts[BODY_PARTS]) {
    Xf root = xf_at(p->pos, p->yaw, 1);
    V3 f = xf_dir(&root, v3(0, 0, 1)), r = xf_dir(&root, v3(-1, 0, 0)), up = v3(0, 1, 0);
    const float *JT = meshes[M_TORSO].joint, *JS = meshes[M_UARM_L].joint;
    V3 Sg = xf_point(&parts[M_TORSO], v3(JS[0] - JT[0], JS[1] - JT[1], JS[2] - JT[2]));   /* shooting shoulder */
    V3 C = vadd(p->pos, v3(0, 1.3f, 0));
    float bob = sinf(2 * p->walk) * 0.015f * p->walkAmt;
    int k = p->weapon;
    V3 G, dir, hint = up;
    if (WP_IS_MELEE(k)) {
        /* ready at the side, pulled back over the shoulder, then swung across */
        V3 G0 = vadd(C, vadd(vmul(f, 0.34f), vadd(vmul(up, -0.2f + bob), vmul(r, 0.08f))));
        V3 D0 = vnorm(vadd(vmul(up, 1.0f), vadd(vmul(f, 0.65f), vmul(r, 0.1f))));
        V3 G1 = vadd(Sg, vadd(vmul(up, 0.1f), vadd(vmul(f, 0.06f), vmul(r, -0.05f))));
        V3 D1 = vnorm(vadd(vmul(up, 0.55f), vadd(vmul(f, -0.75f), vmul(r, 0.25f))));
        V3 G2 = vadd(C, vadd(vmul(f, 0.42f), vadd(vmul(up, -0.12f), vmul(r, -0.22f))));
        V3 D2 = vnorm(vadd(vmul(f, 0.9f), vadd(vmul(r, -0.6f), vmul(up, -0.3f))));
        G = vlerp(G0, G1, p->windup); dir = vnorm(vlerp(D0, D1, p->windup));
        G = vlerp(G, G2, p->punch); dir = vnorm(vlerp(dir, D2, p->punch));
        hint = vnorm(vadd(f, vmul(up, 0.3f)));
    } else {
        float a = p->aim;
        V3 Ga, Da, Gl, Dl;
        if (k == WP_SHOTGUN || k == WP_SMG) {
            /* stock tucked into the shoulder, both eyes down the barrel; or carried low across the body */
            Ga = vadd(Sg, vadd(vmul(f, k == WP_SMG ? 0.26f : 0.3f), vadd(vmul(up, -0.07f), vmul(r, -0.06f))));
            Da = f;
            Gl = vadd(Sg, vadd(vmul(f, 0.22f), vadd(vmul(up, -0.34f + bob), vmul(r, -0.08f))));
            Dl = vnorm(vadd(vmul(f, 0.7f), vadd(vmul(up, -0.5f), vmul(r, -0.35f))));
        } else {
            /* pistol: both arms out in front, or held low and ready */
            Ga = vadd(C, vadd(vmul(f, 0.44f), vadd(vmul(up, 0.08f), vmul(r, 0.03f))));
            Da = f;
            Gl = vadd(C, vadd(vmul(f, 0.33f), vadd(vmul(up, -0.2f + bob), vmul(r, 0.05f))));
            Dl = vnorm(vadd(vmul(f, 0.75f), vmul(up, -0.65f)));
        }
        G = vlerp(Gl, Ga, a);
        dir = vnorm(vlerp(Dl, Da, a));
        /* a hit with the gun: drawn back to the chest, then driven forward */
        G = vadd(G, vadd(vmul(f, -0.14f * p->windup + 0.34f * p->punch), vmul(up, 0.08f * p->windup - 0.04f * p->punch)));
        dir = vnorm(vadd(dir, vmul(up, 0.35f * p->windup - 0.2f * p->punch)));
        /* recoil: the gun jumps back and its nose kicks up */
        float kk = smooth01(p->kick);
        G = vsub(G, vmul(dir, 0.06f * kk));
        dir = vnorm(vadd(dir, vmul(up, 0.3f * kk)));
    }
    return weapon_frame(G, dir, hint);
}

/* put both hands on whatever the pose holds */
static void hold_weapon(const Pose *p, Xf out[BODY_PARTS]) {
    if (p->weapon <= WP_NONE || p->weapon == WP_PROP) return;
    Xf W = pose_weapon(p, out);
    Xf root = xf_at(p->pos, p->yaw, 1);
    V3 r = xf_dir(&root, v3(-1, 0, 0)), f = xf_dir(&root, v3(0, 0, 1));
    V3 down = v3(0, -1, 0);
    ik_arm(out, M_UARM_L, M_FARM_L, xf_point(&W, grip_main(p->weapon)), vadd(down, vadd(vmul(r, 0.7f), vmul(f, -0.2f))));
    ik_arm(out, M_UARM_R, M_FARM_R, xf_point(&W, grip_off(p->weapon)), vadd(down, vadd(vmul(r, -0.7f), vmul(f, -0.2f))));
}

/* where the gun sits in the right hand */
Xf hand_gun(const Xf parts[BODY_PARTS]) {
    Xf l;
    xf_rot(&l, v3(1, 0, 0), PI * 0.5f);
    l.t = grip_of(M_FARM_R);
    Xf r; xf_mul(&r, &parts[M_FARM_R], &l);
    return r;
}

static void add_dust(Game *g, V3 p, V3 v, float size) {
    for (int i = 0; i < MAX_DUST; i++) {
        Dust *d = &g->dust[i];
        if (d->active) continue;
        d->active = 1; d->pos = p; d->vel = v; d->life = 1; d->size = size;
        return;
    }
}

/* ---- breaking glass ----
 * The triangles are sorted along a space-filling curve so neighbours end up next to each other,
 * then cut into pieces: tiny splinters where the hit lands, mid-size shards around it, and big
 * chunks further away that mostly just drop. Everything tumbles in (slowed) time and the pieces
 * stay where they land. */

static void add_spark(Game *g, V3 p, V3 v, float size, float life, const float col[3], int flash) {
    Spark *s = &g->spark[g->sparkNext];
    g->sparkNext = (g->sparkNext + 1) % MAX_SPARKS;
    s->active = 1; s->flash = flash; s->pos = p; s->vel = v; s->size = size; s->life = life;
    s->spin = frand(g) * 6.28f;
    s->col[0] = col[0]; s->col[1] = col[1]; s->col[2] = col[2];
}

static unsigned spread10(unsigned x) {
    x &= 1023;
    x = (x | (x << 16)) & 0x030000FF;
    x = (x | (x << 8)) & 0x0300F00F;
    x = (x | (x << 4)) & 0x030C30C3;
    x = (x | (x << 2)) & 0x09249249;
    return x;
}
static unsigned *sortKey;
static int by_key(const void *a, const void *b) {
    unsigned ka = sortKey[*(const int *)a], kb = sortKey[*(const int *)b];
    return ka < kb ? -1 : (ka > kb);
}

/* split triangles along their longest edge until no edge is longer than maxLen */
static int subdivide(const V3 *in, int nt, V3 *out, int maxOut, float maxLen) {
    int n = 0;
    for (int t = 0; t < nt && n < maxOut; t++) {
        /* a small stack per source triangle */
        V3 st[64][3];
        int sp = 0;
        st[sp][0] = in[t * 3]; st[sp][1] = in[t * 3 + 1]; st[sp][2] = in[t * 3 + 2]; sp++;
        while (sp > 0 && n < maxOut) {
            sp--;
            V3 a = st[sp][0], b = st[sp][1], c = st[sp][2];
            float lab = vlen(vsub(b, a)), lbc = vlen(vsub(c, b)), lca = vlen(vsub(a, c));
            float m = fmaxf(lab, fmaxf(lbc, lca));
            if (m <= maxLen || sp >= 62) { out[n * 3] = a; out[n * 3 + 1] = b; out[n * 3 + 2] = c; n++; continue; }
            if (m == lab) { V3 h = vmul(vadd(a, b), 0.5f); V3 t1[3] = {a, h, c}, t2[3] = {h, b, c}; memcpy(st[sp++], t1, sizeof t1); memcpy(st[sp++], t2, sizeof t2); }
            else if (m == lbc) { V3 h = vmul(vadd(b, c), 0.5f); V3 t1[3] = {a, b, h}, t2[3] = {a, h, c}; memcpy(st[sp++], t1, sizeof t1); memcpy(st[sp++], t2, sizeof t2); }
            else { V3 h = vmul(vadd(c, a), 0.5f); V3 t1[3] = {a, b, h}, t2[3] = {h, b, c}; memcpy(st[sp++], t1, sizeof t1); memcpy(st[sp++], t2, sizeof t2); }
        }
    }
    return n;
}

static void shatter_tris_raw(Game *g, const V3 *w, int ntri, const float col[3], V3 hitDir, V3 hitPoint, float force);
static void shatter_tris(Game *g, const V3 *w, int ntri, const float col[3], V3 hitDir, V3 hitPoint, float force) {
    static V3 sub[4096 * 3];
    int n = ntri;
    const V3 *src = w;
    if (g->setShatter == SHATTER_REAL) {
        n = subdivide(w, ntri, sub, 4096, 0.16f);
        src = sub;
    }
    shatter_tris_raw(g, src, n, col, hitDir, hitPoint, force);
}

static void shatter_tris_raw(Game *g, const V3 *w, int ntri, const float col[3], V3 hitDir, V3 hitPoint, float force) {
    static int order[4096];
    static unsigned key[4096];
    if (ntri > 4096) ntri = 4096;
    if (ntri <= 0) return;
    int mode = g->setShatter;
    if (mode == SHATTER_OFF) ntri = 0;   /* settings: no pieces, just the flash and the glitter */
    /* spatial order */
    V3 lo = w[0];
    for (int i = 0; i < ntri * 3; i++) { if (w[i].x < lo.x) lo.x = w[i].x; if (w[i].y < lo.y) lo.y = w[i].y; if (w[i].z < lo.z) lo.z = w[i].z; }
    for (int t = 0; t < ntri; t++) {
        V3 c = vmul(vadd(vadd(w[t * 3], w[t * 3 + 1]), w[t * 3 + 2]), 1.0f / 3);
        unsigned qx = (unsigned)((c.x - lo.x) / 0.025f), qy = (unsigned)((c.y - lo.y) / 0.025f), qz = (unsigned)((c.z - lo.z) / 0.025f);
        key[t] = spread10(qx) | (spread10(qy) << 1) | (spread10(qz) << 2);
        order[t] = t;
    }
    sortKey = key;
    qsort(order, ntri, sizeof(int), by_key);
    V3 hd = vnorm(v3(hitDir.x, 0, hitDir.z));
    int t0 = 0;
    while (t0 < ntri) {
        /* how far this piece is from the hit decides its size and how hard it flies */
        int first = order[t0];
        V3 c0 = vmul(vadd(vadd(w[first * 3], w[first * 3 + 1]), w[first * 3 + 2]), 1.0f / 3);
        float dist = vlen(vsub(c0, hitPoint));
        int per;
        if (mode == SHATTER_SIMPLE) per = 4 + (int)(frand(g) * 4);
        else if (dist < 0.22f) per = 1 + (int)(frand(g) * 2);
        else if (dist < 0.55f) per = 2 + (int)(frand(g) * 3);
        else per = 3 + (int)(frand(g) * 4);
        int nt = ntri - t0 < per ? ntri - t0 : per;
        if (g->shardTriNext + SHARD_MAX_TRIS > MAX_SHARD_TRIS) g->shardTriNext = 0;
        Shard *s = &g->sh[g->shardNext];
        g->shardNext = (g->shardNext + 1) % MAX_SHARDS;
        V3 cen = v3(0, 0, 0);
        for (int k = 0; k < nt; k++)
            for (int v = 0; v < 3; v++) cen = vadd(cen, w[order[t0 + k] * 3 + v]);
        cen = vmul(cen, 1.0f / (nt * 3));
        float *dst = g->shardTri + g->shardTriNext * 9;
        V3 nsum = v3(0, 0, 0);
        float area = 0;
        for (int k = 0; k < nt; k++) {
            const V3 *tv = &w[order[t0 + k] * 3];
            V3 fn = vcross(vsub(tv[1], tv[0]), vsub(tv[2], tv[0]));
            nsum = vadd(nsum, fn);
            area += vlen(fn) * 0.5f;
            for (int v = 0; v < 3; v++) {
                V3 o = vsub(tv[v], cen);
                dst[(k * 3 + v) * 3] = o.x; dst[(k * 3 + v) * 3 + 1] = o.y; dst[(k * 3 + v) * 3 + 2] = o.z;
            }
        }
        int total = nt;
        if (mode == SHATTER_REAL) {
            /* solid chunks: close the broken piece off with faces running in to a point inside it,
             * one for every outside edge of the piece (edges shared inside it are skipped) */
            float nl = vlen(nsum);
            V3 inward = nl > 1e-9f ? vmul(nsum, -1 / nl) : v3(0, -1, 0);
            float depth = clampf(0.6f * sqrtf(area), 0.012f, 0.055f);
            V3 apex = vmul(inward, depth);
            for (int k = 0; k < nt && total < SHARD_MAX_TRIS; k++)
                for (int e = 0; e < 3 && total < SHARD_MAX_TRIS; e++) {
                    const float *A = dst + (k * 3 + e) * 3, *B = dst + (k * 3 + (e + 1) % 3) * 3;
                    int shared = 0;
                    for (int k2 = 0; k2 < nt && !shared; k2++) {
                        if (k2 == k) continue;
                        for (int e2 = 0; e2 < 3; e2++) {
                            const float *C = dst + (k2 * 3 + e2) * 3, *D = dst + (k2 * 3 + (e2 + 1) % 3) * 3;
                            if (C[0] == B[0] && C[1] == B[1] && C[2] == B[2] && D[0] == A[0] && D[1] == A[1] && D[2] == A[2]) { shared = 1; break; }
                        }
                    }
                    if (shared) continue;
                    float *o = dst + total * 9;
                    o[0] = B[0]; o[1] = B[1]; o[2] = B[2];
                    o[3] = A[0]; o[4] = A[1]; o[5] = A[2];
                    o[6] = apex.x; o[7] = apex.y; o[8] = apex.z;
                    total++;
                }
        }
        float rad = 0;
        for (int i = 0; i < total * 3; i++) { float l = sqrtf(dst[i * 3] * dst[i * 3] + dst[i * 3 + 1] * dst[i * 3 + 1] + dst[i * 3 + 2] * dst[i * 3 + 2]); if (l > rad) rad = l; }
        s->active = 1; s->rest = 0;
        s->t0 = g->shardTriNext;
        s->nt = total;
        s->rad = rad;
        g->shardTriNext += total;
        s->c = cen;
        V3 away = vsub(cen, hitPoint);
        float d = vlen(away);
        away = d > 0.01f ? vmul(away, 1.0f / d) : v3(0, 1, 0);
        float burst = force * (d < 0.22f ? frange(g, 3.0f, 5.5f) : d < 0.55f ? frange(g, 1.4f, 2.6f) : frange(g, 0.25f, 0.9f));
        s->vel = vadd(vadd(vmul(away, burst), vmul(hd, burst * 0.6f)),
                      v3(frange(g, -0.4f, 0.4f), frange(g, 0.1f, 0.9f) * force * (d < 0.55f ? 1 : 0.4f), frange(g, -0.4f, 0.4f)));
        s->axis = vnorm(v3(frange(g, -1, 1), frange(g, -1, 1), frange(g, -1, 1)));
        s->ang = 0;
        s->angV = (nt <= 2 ? frange(g, 10, 22) : nt <= 5 ? frange(g, 5, 11) : frange(g, 1.5f, 5)) * (frand(g) < 0.5f ? -1 : 1);
        s->life = mode == SHATTER_SIMPLE ? frange(g, 4, 7) : frange(g, 22, 30);
        float sh = frange(g, 0.85f, 1.15f);
        for (int q = 0; q < 3; q++) s->col[q] = clampf(col[q] * sh, 0, 1);
        t0 += nt;
    }
    /* glitter and a flash at the point of impact */
    static const float white[3] = {1, 1, 1};
    add_spark(g, hitPoint, v3(0, 0, 0), 0.55f * force + 0.15f, 0.16f, white, 1);
    int ns = (int)((mode == SHATTER_OFF ? 90 : 36) * force) + 8;
    for (int i = 0; i < ns; i++) {
        V3 v = vnorm(v3(frange(g, -1, 1), frange(g, -0.6f, 1), frange(g, -1, 1)));
        v = vadd(vmul(v, frange(g, 1.5f, 6.5f) * force), vmul(hd, frange(g, 0.5f, 3) * force));
        const float *c = frand(g) < 0.3f ? white : col;
        add_spark(g, hitPoint, v, frange(g, 0.008f, 0.026f), frange(g, 0.6f, 1.6f), c, 0);
    }
}

/* first person only: curl the open hands into fists (shorten the fingers, bulk up the knuckles) */
int skinFists;
static V3 fist(int bone, V3 l) {
    if (!skinFists || (bone != M_FARM_L && bone != M_FARM_R) || l.y > -0.25f) return l;
    float t = -0.25f - l.y;
    l.y = -0.25f - t * 0.42f;
    l.x *= 1.25f; l.z = l.z * 1.35f + t * 0.25f;
    return l;
}

/* bend the smooth body mesh to a pose: every vertex follows two bones */
/* a few triangles of the model join a hand to a thigh (the arms hang against the legs in its rest pose);
 * they stretch into flaps once the arm moves, so they are left out */
int body_tri_bridge(int lod, int t) {
    static unsigned char mask[BODY_LODS][8192 / 8 + 1];
    static int ready[BODY_LODS];
    if (!ready[lod]) {
        const Body *B = &bodies[lod];
        for (int i = 0; i < B->nt && i < 8192; i++) {
            int arm = 0, leg = 0, tor = 0, farm = 0, side = 0;
            for (int k = 0; k < 3; k++) {
                int v = B->idx[i * 3 + k];
                int b = B->w[v] >= 128 ? B->bone[v * 2] : B->bone[v * 2 + 1];
                arm |= b >= M_UARM_L && b <= M_FARM_R;
                leg |= b >= M_THIGH_L && b <= M_SHIN_R;
                tor |= b == M_TORSO;
                farm |= b == M_FARM_L || b == M_FARM_R;
                if (b == M_UARM_L || b == M_FARM_L) side |= 1;
                if (b == M_UARM_R || b == M_FARM_R) side |= 2;
            }
            if ((arm && leg) || (farm && tor) || side == 3) mask[lod][i >> 3] |= (unsigned char)(1 << (i & 7));
        }
        ready[lod] = 1;
    }
    return t < 8192 && (mask[lod][t >> 3] >> (t & 7)) & 1;
}

int body_skin(int lod, const Xf parts[BODY_PARTS], V3 *pos, V3 *nrm) {
    const Body *B = &bodies[lod];
    for (int i = 0; i < B->nv; i++) {
        V3 v = v3(B->v[i * 3], B->v[i * 3 + 1], B->v[i * 3 + 2]);
        int b0 = B->bone[i * 2], b1 = B->bone[i * 2 + 1];
        float w = B->w[i] * (1.0f / 255);
        const float *j0 = meshes[b0].joint, *j1 = meshes[b1].joint;
        V3 p0 = xf_point(&parts[b0], fist(b0, v3(v.x - j0[0], v.y - j0[1], v.z - j0[2])));
        if (w > 0.995f) pos[i] = p0;
        else {
            V3 p1 = xf_point(&parts[b1], fist(b1, v3(v.x - j1[0], v.y - j1[1], v.z - j1[2])));
            pos[i] = vadd(vmul(p0, w), vmul(p1, 1 - w));
        }
        if (nrm) {
            V3 n = v3(B->n[i * 3] / 127.0f, B->n[i * 3 + 1] / 127.0f, B->n[i * 3 + 2] / 127.0f);
            V3 n0 = xf_dir(&parts[b0], n);
            if (w < 0.995f) n0 = vadd(vmul(n0, w), vmul(xf_dir(&parts[b1], n), 1 - w));
            float l = vlen(n0);
            nrm[i] = l > 1e-6f ? vmul(n0, 1 / l) : v3(0, 1, 0);
        }
    }
    return B->nv;
}

/* break a posed body into flying glass shards: small pieces, a few triangles each */
void shatter_body(Game *g, const Pose *p, const float col[3], V3 hitDir, V3 hitPoint) {
    static V3 pos[4096];
    static V3 w[4096 * 3];
    Xf parts[BODY_PARTS];
    pose_parts(p, parts);
    const Body *B = &bodies[BODY_LODS - 1];
    body_skin(BODY_LODS - 1, parts, pos, NULL);
    int n = 0;
    for (int t = 0; t < B->nt && n + 3 <= 4096 * 3; t++) {
        if (body_tri_bridge(BODY_LODS - 1, t)) continue;
        for (int k = 0; k < 3; k++) w[n++] = pos[B->idx[t * 3 + k]];
    }
    shatter_tris(g, w, n / 3, col, hitDir, hitPoint, 1);
    for (int i = 0; i < 6; i++) add_dust(g, hitPoint, v3(frange(g, -1, 1), frange(g, 0, 1.5f), frange(g, -1, 1)), 0.12f);
}

static const float RED[3] = {0.92f, 0.12f, 0.08f};
static const float BLACK[3] = {0.08f, 0.08f, 0.09f};

/* ---- black glass props ---- */

void prop_xf(const Prop *p, Xf *x) { *x = xf_at(p->pos, p->yaw, 1); }

/* a faceted prism ring from radius r0 at y0 to r1 at y1 */
static int ring(V3 *o, int n, int max, const Xf *x, int sides, float r0, float y0, float r1, float y1, int capTop) {
    for (int i = 0; i < sides && n + 12 <= max; i++) {
        float a0 = 2 * PI * i / sides, a1 = 2 * PI * (i + 1) / sides;
        V3 A = xf_point(x, v3(cosf(a0) * r0, y0, sinf(a0) * r0)), B = xf_point(x, v3(cosf(a1) * r0, y0, sinf(a1) * r0));
        V3 C = xf_point(x, v3(cosf(a1) * r1, y1, sinf(a1) * r1)), D = xf_point(x, v3(cosf(a0) * r1, y1, sinf(a0) * r1));
        o[n++] = A; o[n++] = C; o[n++] = B;
        o[n++] = A; o[n++] = D; o[n++] = C;
        if (capTop) { o[n++] = xf_point(x, v3(0, y1, 0)); o[n++] = C; o[n++] = D; }
    }
    return n;
}

/* an axis-aligned box in a prop's own space, as 12 triangles */
static int pbox(V3 *o, int n, int max, const Xf *x, V3 lo, V3 hi) {
    static const int F[6][4] = {{0, 2, 3, 1}, {4, 5, 7, 6}, {0, 1, 5, 4}, {2, 6, 7, 3}, {0, 4, 6, 2}, {1, 3, 7, 5}};
    V3 P[8];
    for (int i = 0; i < 8; i++) P[i] = xf_point(x, v3(i & 1 ? hi.x : lo.x, i & 2 ? hi.y : lo.y, i & 4 ? hi.z : lo.z));
    for (int f = 0; f < 6 && n + 6 <= max; f++) {
        o[n++] = P[F[f][0]]; o[n++] = P[F[f][1]]; o[n++] = P[F[f][2]];
        o[n++] = P[F[f][0]]; o[n++] = P[F[f][2]]; o[n++] = P[F[f][3]];
    }
    return n;
}

static int prop_shape(int kind, float r, float h, const Xf *xp, V3 *o, int max) {
    Xf x = *xp;
    int n = 0;
    switch (kind) {
    case PR_BOTTLE:
        n = ring(o, n, max, &x, 7, r, 0, r, h * 0.6f, 0);
        n = ring(o, n, max, &x, 7, r, h * 0.6f, r * 0.35f, h * 0.78f, 0);
        n = ring(o, n, max, &x, 7, r * 0.35f, h * 0.78f, r * 0.3f, h, 1);
        break;
    case PR_VASE:
        n = ring(o, n, max, &x, 8, r * 0.6f, 0, r, h * 0.45f, 0);
        n = ring(o, n, max, &x, 8, r, h * 0.45f, r * 0.45f, h * 0.85f, 0);
        n = ring(o, n, max, &x, 8, r * 0.45f, h * 0.85f, r * 0.6f, h, 1);
        break;
    case PR_MONITOR:
        /* a flat screen on a stand, facing along the prop's +z */
        n = pbox(o, n, max, &x, v3(-0.09f, 0, -0.07f), v3(0.09f, 0.012f, 0.07f));
        n = pbox(o, n, max, &x, v3(-0.02f, 0.012f, -0.02f), v3(0.02f, 0.16f, 0.0f));
        n = pbox(o, n, max, &x, v3(-0.26f, 0.12f, 0.0f), v3(0.26f, 0.42f, 0.03f));
        break;
    case PR_WINEGLASS:
        /* foot, stem, a bowl that opens out and narrows a little at the rim */
        n = ring(o, n, max, &x, 8, r * 0.75f, 0, r * 0.75f, 0.006f, 1);
        n = ring(o, n, max, &x, 5, 0.006f, 0.006f, 0.006f, h * 0.42f, 0);
        n = ring(o, n, max, &x, 8, 0.006f, h * 0.42f, r, h * 0.72f, 0);
        n = ring(o, n, max, &x, 8, r, h * 0.72f, r * 0.85f, h, 0);
        break;
    case PR_CAN:
        n = ring(o, n, max, &x, 8, r * 0.88f, 0, r, 0.012f, 0);
        n = ring(o, n, max, &x, 8, r, 0.012f, r, h - 0.012f, 0);
        n = ring(o, n, max, &x, 8, r, h - 0.012f, r * 0.85f, h, 1);
        break;
    case PR_TUMBLER:
        n = ring(o, n, max, &x, 8, r * 0.82f, 0, r * 0.82f, 0.012f, 1);
        n = ring(o, n, max, &x, 8, r * 0.82f, 0.012f, r, h, 0);
        break;
    case PR_ASHTRAY:
        n = ring(o, n, max, &x, 8, r, 0, r * 1.04f, h, 0);
        n = ring(o, n, max, &x, 8, r * 1.04f, h, r * 0.7f, h, 0);
        n = ring(o, n, max, &x, 8, r * 0.7f, h, r * 0.6f, h * 0.35f, 1);
        break;
    case PR_PHONE:
        n = pbox(o, n, max, &x, v3(-r * 0.5f, 0, -r), v3(r * 0.5f, h, r));
        break;
    case PR_PLATE:
        n = ring(o, n, max, &x, 10, r * 0.6f, 0, r, h, 0);
        n = ring(o, n, max, &x, 10, r, h, r * 0.62f, h * 0.5f, 1);
        break;
    case PR_MUG:
        n = ring(o, n, max, &x, 7, r, 0, r * 1.05f, h, 1);
        n = pbox(o, n, max, &x, v3(r * 0.9f, h * 0.25f, -0.008f), v3(r * 1.6f, h * 0.75f, 0.008f));
        break;
    default:
        n = ring(o, n, max, &x, 4, r, 0, r, h, 1);
        break;
    }
    return n / 3;
}

int prop_tris(const Prop *p, V3 *o, int max) {
    Xf x;
    prop_xf(p, &x);
    return prop_shape(p->kind, p->r, p->h, &x, o, max);
}

/* ================= weapons =================
 * Each is built in the pistol's own space: grip at the origin, barrel or blade along +z, up is +y.
 * The pistol is the uploaded model; the rest are put together from simple pieces. All black glass. */

/* a faceted tube along z at height y */
static int zcyl(V3 *o, int n, int max, const Xf *x, int sides, float r0, float z0, float r1, float z1, float y, int caps) {
    for (int i = 0; i < sides && n + 12 <= max; i++) {
        float a0 = 2 * PI * i / sides, a1 = 2 * PI * (i + 1) / sides;
        V3 A = xf_point(x, v3(cosf(a0) * r0, y + sinf(a0) * r0, z0)), B = xf_point(x, v3(cosf(a1) * r0, y + sinf(a1) * r0, z0));
        V3 C = xf_point(x, v3(cosf(a1) * r1, y + sinf(a1) * r1, z1)), D = xf_point(x, v3(cosf(a0) * r1, y + sinf(a0) * r1, z1));
        o[n++] = A; o[n++] = B; o[n++] = C;
        o[n++] = A; o[n++] = C; o[n++] = D;
        if (caps) {
            o[n++] = xf_point(x, v3(0, y, z1)); o[n++] = D; o[n++] = C;
            o[n++] = xf_point(x, v3(0, y, z0)); o[n++] = B; o[n++] = A;
        }
    }
    return n;
}

/* a bar along z with its four long edges bevelled off (an octagon in section), capped at both ends:
 * smoothed, it reads as a rounded, machined part */
static int oprism(V3 *o, int n, int max, const Xf *x, V3 lo, V3 hi, float c) {
    float hx = (hi.x - lo.x) * 0.5f, hy = (hi.y - lo.y) * 0.5f, cx = (hi.x + lo.x) * 0.5f, cy = (hi.y + lo.y) * 0.5f;
    if (c > hx * 0.9f) c = hx * 0.9f;
    if (c > hy * 0.9f) c = hy * 0.9f;
    float px[8] = {hx - c, hx, hx, hx - c, -hx + c, -hx, -hx, -hx + c};
    float py[8] = {hy, hy - c, -hy + c, -hy, -hy, -hy + c, hy - c, hy};
    V3 A[8], B[8];
    for (int i = 0; i < 8; i++) { A[i] = xf_point(x, v3(cx + px[i], cy + py[i], lo.z)); B[i] = xf_point(x, v3(cx + px[i], cy + py[i], hi.z)); }
    for (int i = 0; i < 8 && n + 6 <= max; i++) {
        int j = (i + 1) & 7;
        o[n++] = A[i]; o[n++] = B[j]; o[n++] = A[j];
        o[n++] = A[i]; o[n++] = B[i]; o[n++] = B[j];
    }
    V3 ca = xf_point(x, v3(cx, cy, lo.z)), cb = xf_point(x, v3(cx, cy, hi.z));
    for (int i = 0; i < 8 && n + 6 <= max; i++) {
        int j = (i + 1) & 7;
        o[n++] = ca; o[n++] = A[i]; o[n++] = A[j];
        o[n++] = cb; o[n++] = B[j]; o[n++] = B[i];
    }
    return n;
}
/* the same along y (grips, magazines) */
static int oprism_y(V3 *o, int n, int max, const Xf *x, V3 lo, V3 hi, float c, float rake) {
    Xf r, l;
    xf_rot(&l, v3(1, 0, 0), PI * 0.5f + rake);   /* local z of the bar runs down y */
    l.t = v3((lo.x + hi.x) * 0.5f, hi.y, (lo.z + hi.z) * 0.5f);
    xf_mul(&r, x, &l);
    float hz = (hi.z - lo.z) * 0.5f, hx = (hi.x - lo.x) * 0.5f;
    return oprism(o, n, max, &r, v3(-hx, -hz, 0), v3(hx, hz, hi.y - lo.y), c);
}

int weapon_ammo(int kind) {
    switch (kind) {
    case WP_PISTOL: return GUN_AMMO;
    case WP_SHOTGUN: return 2;
    case WP_SMG: return 12;
    default: return 0;
    }
}

const char *weapon_name(int kind) {
    static const char *nm[WP_KINDS] = {"fists", "pistol", "shotgun", "smg", "katana", "bat", "bottle"};
    return kind >= 0 && kind < WP_KINDS ? nm[kind] : "?";
}

V3 weapon_muzzle(int kind) {
    switch (kind) {
    case WP_SHOTGUN: return v3(0, 0.03f, 0.67f);
    case WP_SMG: return v3(0, 0.03f, 0.28f);
    default: return v3(0, GUN_MUZZLE_Y, GUN_MUZZLE_Z);
    }
}

/* swords and bats are held point up and forward, not level like a gun */
Xf weapon_hold(Xf hand, int kind) {
    if (!WP_IS_MELEE(kind) && kind != WP_PROP) return hand;
    Xf l, r;
    if (kind == WP_PROP) { xf_ident(&l); l.t = v3(0, -0.04f, 0.04f); }
    else { xf_rot(&l, v3(1, 0, 0), -1.05f); l.t = v3(0, 0, 0.02f); }
    xf_mul(&r, &hand, &l);
    return r;
}

int weapon_tris(int kind, int sub, float pr, float ph, const Xf *x, V3 *o, int max) {
    int n = 0;
    switch (kind) {
    case WP_SHOTGUN:
        n = oprism(o, n, max, x, v3(-0.022f, -0.012f, -0.07f), v3(0.022f, 0.052f, 0.17f), 0.009f);       /* receiver */
        n = zcyl(o, n, max, x, 10, 0.016f, 0.17f, 0.015f, 0.67f, 0.03f, 1);                               /* barrel */
        n = zcyl(o, n, max, x, 10, 0.017f, 0.655f, 0.017f, 0.672f, 0.03f, 1);                             /* muzzle ring */
        n = zcyl(o, n, max, x, 10, 0.013f, 0.17f, 0.013f, 0.56f, 0.0f, 1);                                /* tube under it */
        n = oprism(o, n, max, x, v3(-0.026f, -0.026f, 0.25f), v3(0.026f, 0.018f, 0.45f), 0.012f);        /* pump */
        n = oprism_y(o, n, max, x, v3(-0.016f, -0.105f, -0.075f), v3(0.016f, -0.01f, -0.035f), 0.007f, -0.35f);  /* grip, raked back */
        n = oprism(o, n, max, x, v3(-0.019f, -0.05f, -0.43f), v3(0.019f, 0.03f, -0.07f), 0.009f);         /* stock */
        n = oprism(o, n, max, x, v3(-0.022f, -0.085f, -0.45f), v3(0.022f, 0.035f, -0.43f), 0.008f);      /* butt pad */
        n = oprism(o, n, max, x, v3(-0.004f, -0.035f, -0.04f), v3(0.004f, -0.012f, 0.03f), 0.002f);      /* trigger guard */
        break;
    case WP_SMG:
        n = oprism(o, n, max, x, v3(-0.022f, -0.006f, -0.11f), v3(0.022f, 0.062f, 0.18f), 0.01f);        /* body */
        n = zcyl(o, n, max, x, 10, 0.012f, 0.18f, 0.012f, 0.29f, 0.03f, 1);                               /* barrel */
        n = zcyl(o, n, max, x, 10, 0.016f, 0.25f, 0.016f, 0.29f, 0.03f, 1);                               /* muzzle */
        n = oprism_y(o, n, max, x, v3(-0.012f, -0.21f, 0.03f), v3(0.012f, -0.006f, 0.075f), 0.005f, 0.12f);   /* magazine */
        n = oprism_y(o, n, max, x, v3(-0.016f, -0.105f, -0.075f), v3(0.016f, -0.006f, -0.035f), 0.007f, -0.3f);  /* grip */
        n = oprism(o, n, max, x, v3(-0.007f, 0.062f, -0.07f), v3(0.007f, 0.078f, 0.14f), 0.003f);        /* sight rail */
        n = oprism(o, n, max, x, v3(-0.013f, 0.004f, -0.26f), v3(0.013f, 0.022f, -0.11f), 0.005f);       /* folded stock */
        n = oprism(o, n, max, x, v3(-0.004f, -0.035f, -0.03f), v3(0.004f, -0.012f, 0.03f), 0.002f);
        break;
    case WP_KATANA:
        n = zcyl(o, n, max, x, 10, 0.016f, -0.17f, 0.017f, 0.1f, 0, 1);                                    /* wrapped handle */
        n = zcyl(o, n, max, x, 10, 0.019f, -0.185f, 0.019f, -0.17f, 0, 1);                                 /* pommel cap */
        n = zcyl(o, n, max, x, 12, 0.047f, 0.1f, 0.047f, 0.116f, 0, 1);                                    /* guard */
        n = zcyl(o, n, max, x, 10, 0.02f, 0.116f, 0.018f, 0.135f, 0, 1);                                   /* collar */
        if (n + 8 * 6 * 2 <= max) {
            /* the blade: a thin lens in section, the back thicker than the edge, slightly curved */
            const int S = 8;
            for (int i = 0; i < S; i++) {
                float z0 = 0.135f + 0.74f * i / S, z1 = 0.135f + 0.74f * (i + 1) / S;
                float c0 = 0.012f * (z0 - 0.135f) * (z0 - 0.135f) * 2.2f, c1 = 0.012f * (z1 - 0.135f) * (z1 - 0.135f) * 2.2f;
                float w0 = 0.017f - 0.004f * i / S, w1 = 0.017f - 0.004f * (i + 1) / S;
                V3 back0 = xf_point(x, v3(0, w0 + c0, z0)), back1 = xf_point(x, v3(0, w1 + c1, z1));
                V3 edge0 = xf_point(x, v3(0, -w0 + c0, z0)), edge1 = xf_point(x, v3(0, -w1 + c1, z1));
                V3 l0 = xf_point(x, v3(-0.0045f, c0 + w0 * 0.4f, z0)), l1 = xf_point(x, v3(-0.0045f, c1 + w1 * 0.4f, z1));
                V3 r0 = xf_point(x, v3(0.0045f, c0 + w0 * 0.4f, z0)), r1 = xf_point(x, v3(0.0045f, c1 + w1 * 0.4f, z1));
                o[n++] = back0; o[n++] = l0; o[n++] = l1;   o[n++] = back0; o[n++] = l1; o[n++] = back1;
                o[n++] = l0; o[n++] = edge0; o[n++] = edge1; o[n++] = l0; o[n++] = edge1; o[n++] = l1;
                o[n++] = r0; o[n++] = back0; o[n++] = back1; o[n++] = r0; o[n++] = back1; o[n++] = r1;
                o[n++] = edge0; o[n++] = r0; o[n++] = r1;   o[n++] = edge0; o[n++] = r1; o[n++] = edge1;
            }
            /* the point */
            float zt = 0.875f, ct = 0.012f * (zt - 0.135f) * (zt - 0.135f) * 2.2f, wt = 0.013f;
            V3 b = xf_point(x, v3(0, wt + ct, zt)), e = xf_point(x, v3(0, -wt + ct, zt));
            V3 l = xf_point(x, v3(-0.0045f, ct + wt * 0.4f, zt)), r = xf_point(x, v3(0.0045f, ct + wt * 0.4f, zt));
            V3 t = xf_point(x, v3(0, ct + wt * 0.7f, 0.95f));
            o[n++] = b; o[n++] = l; o[n++] = t;  o[n++] = l; o[n++] = e; o[n++] = t;
            o[n++] = r; o[n++] = b; o[n++] = t;  o[n++] = e; o[n++] = r; o[n++] = t;
        }
        break;
    case WP_BAT: {
        /* a turned profile: knob, thin handle swelling into the barrel, a rounded end */
        static const float pz[] = {-0.185f, -0.175f, -0.155f, -0.14f, 0.1f, 0.25f, 0.4f, 0.52f, 0.68f, 0.73f, 0.75f, 0.758f};
        static const float pr[] = {0.012f, 0.027f, 0.027f, 0.016f, 0.017f, 0.021f, 0.03f, 0.036f, 0.037f, 0.034f, 0.025f, 0.008f};
        for (int i = 0; i + 1 < (int)(sizeof pz / sizeof pz[0]); i++) n = zcyl(o, n, max, x, 10, pr[i], pz[i], pr[i + 1], pz[i + 1], 0, i == 0 || i + 2 == (int)(sizeof pz / sizeof pz[0]));
        break;
    }
    case WP_PROP: {
        Xf l, r2;
        xf_ident(&l);
        l.t = v3(0, -ph * 0.4f, 0);
        xf_mul(&r2, x, &l);
        n = prop_shape(sub, pr, ph, &r2, o, max) * 3;
        break;
    }
    default: {
        const Mesh *M = &meshes[M_GUN];
        for (int t = 0; t < M->nt && n + 3 <= max; t++)
            for (int v = 0; v < 3; v++) {
                const float *q = M->v + (t * 3 + v) * 3;
                o[n++] = xf_point(x, v3(q[0], q[1], q[2]));
            }
        break;
    }
    }
    return n / 3;
}

static void break_prop(Game *g, Prop *p, V3 dir, V3 at) {
    if (!p->active) return;
    V3 w[300];
    int nt = prop_tris(p, w, 300);
    shatter_tris(g, w, nt, BLACK, dir, at, 0.7f);
    p->active = 0;
    audio_play_rate(SFX_BREAK, 0.75f * (0.4f + 0.6f * gain_of(g, at, 25)), pan_of(g, at), 0.9f + 0.25f * frand(g));
}

/* black glass things standing on every table */
static void place_props(Game *g) {
    g->nprop = 0;
    memset(g->prop, 0, sizeof(g->prop));
    for (int b = 0; b < g->nbox && g->nprop < MAX_PROPS; b++) {
        const Box *bx = &g->box[b];
        if (bx->kind != BOX_PROP && bx->kind != BOX_DESK && bx->kind != BOX_PEDESTAL) continue;
        int th = levels[g->level].theme;
        float lx = bx->x1 - bx->x0, lz = bx->z1 - bx->z0;
        int along = lx > lz;
        float len = along ? lx : lz;
        /* a bar counter is crowded with drinks; desks hold a screen and a few things; tables a little of everything */
        int barTop = th == TH_BAR && bx->kind == BOX_PROP && bx->h > 1.0f;
        float spacing = barTop ? 0.42f : bx->kind == BOX_DESK ? 0.45f : 0.6f;
        int n = (int)(len / spacing);
        if (n < 1) n = 1;
        if (n > 12) n = 12;
        if (bx->kind == BOX_PEDESTAL) n = 1;
        for (int i = 0; i < n && g->nprop < MAX_PROPS; i++) {
            unsigned hsh = (unsigned)(b * 131 + i * 17 + g->level * 7);
            hsh = hsh * 2654435761u;
            int mid = i == n / 2;
            if (((hsh >> 7) & 3) == 0 && bx->kind != BOX_PEDESTAL && !(bx->kind == BOX_DESK && mid)) continue;   /* leave some gaps */
            Prop *p = &g->prop[g->nprop++];
            p->active = 1;
            static const int barK[] = {PR_BOTTLE, PR_WINEGLASS, PR_TUMBLER, PR_WINEGLASS, PR_CAN, PR_BOTTLE, PR_ASHTRAY, PR_TUMBLER};
            static const int deskK[] = {PR_MUG, PR_PHONE, PR_CAN, PR_MUG, PR_TUMBLER, PR_PHONE};
            static const int lowK[] = {PR_VASE, PR_MUG, PR_PLATE, PR_WINEGLASS, PR_ASHTRAY, PR_PHONE, PR_TUMBLER, PR_BOX};
            static const int tableK[] = {PR_BOTTLE, PR_BOX, PR_VASE, PR_CAN, PR_TUMBLER, PR_WINEGLASS, PR_PLATE, PR_BOTTLE};
            unsigned pick = hsh >> 11;
            if (bx->kind == BOX_PEDESTAL) p->kind = (pick & 1) ? PR_VASE : PR_BOX;
            else if (bx->kind == BOX_DESK || th == TH_OFFICE || th == TH_SERVERS) p->kind = mid ? PR_MONITOR : deskK[pick % 6];
            else if (barTop) p->kind = barK[pick % 8];
            else if (bx->h < 0.6f) p->kind = lowK[pick % 8];
            else p->kind = tableK[pick % 8];
            float f = (i + 0.5f) / n, side = ((hsh >> 15) & 255) / 255.0f - 0.5f;
            if (bx->kind == BOX_PEDESTAL) side = 0;
            float x = along ? bx->x0 + lx * f : (bx->x0 + bx->x1) * 0.5f + side * lx * 0.4f;
            float z = along ? (bx->z0 + bx->z1) * 0.5f + side * lz * 0.4f : bx->z0 + lz * f;
            /* keep clear of a gun lying on the same table */
            const Level *L = &levels[g->level];
            int clash = 0;
            for (int q = 0; q < L->ngun; q++) if (fabsf(L->gun[q].x - x) < 0.35f && fabsf(L->gun[q].z - z) < 0.35f) clash = 1;
            if (clash) { g->nprop--; continue; }
            p->pos = v3(x, bx->h, z);
            p->yaw = ((hsh >> 3) & 63) * 0.1f;
            if (p->kind == PR_MONITOR) {
                p->r = 0.27f; p->h = 0.42f;
                float base = -PI * 0.5f;
                if (bx->kind == BOX_DESK) {
                    /* screens sit at the back of a desk, facing whoever sits at the front */
                    static const float yaws[4] = {PI * 0.5f, -PI * 0.5f, 0, PI};
                    static const float fx[4] = {0, 0, 1, -1}, fz[4] = {1, -1, 0, 0};
                    int d = bx->dir & 3;
                    base = yaws[d];
                    float depth = (d < 2 ? lz : lx) * 0.5f - 0.2f;
                    if (depth < 0) depth = 0;
                    p->pos.x = (d < 2 ? p->pos.x : (bx->x0 + bx->x1) * 0.5f) - fx[d] * depth;
                    p->pos.z = (d < 2 ? (bx->z0 + bx->z1) * 0.5f : p->pos.z) - fz[d] * depth;
                }
                p->yaw = base + (((hsh >> 3) & 7) - 3.5f) * 0.05f;
            }
            else if (p->kind == PR_MUG) { p->r = 0.04f; p->h = 0.09f; }
            else if (p->kind == PR_WINEGLASS) { p->r = 0.042f; p->h = 0.19f; }
            else if (p->kind == PR_CAN) { p->r = 0.033f; p->h = 0.122f; }
            else if (p->kind == PR_TUMBLER) { p->r = 0.04f; p->h = 0.1f; }
            else if (p->kind == PR_ASHTRAY) { p->r = 0.065f; p->h = 0.03f; }
            else if (p->kind == PR_PHONE) { p->r = 0.075f; p->h = 0.011f; }
            else if (p->kind == PR_PLATE) { p->r = 0.12f; p->h = 0.02f; }
            else if (p->kind == PR_BOTTLE) { p->r = 0.045f; p->h = 0.32f; }
            else if (p->kind == PR_VASE) { p->r = 0.09f; p->h = 0.3f; }
            else { p->r = 0.11f; p->h = 0.16f + ((hsh >> 21) & 3) * 0.04f; }
        }
    }
}

/* a gun on the floor or in the air */
void pickup_xf(const Game *g, const Pickup *k, Xf *x) {
    (void)g;
    int kind = k->kind ? k->kind : WP_PISTOL;
    Xf base = xf_at(k->pos, k->yaw, kind == WP_PISTOL ? 1.25f : 1.0f), s, r;
    if (k->flying) {
        xf_rot(&s, v3(1, 0, 0), k->spin);
    } else {
        /* lying on its side, resting on its widest part */
        static const float lift[WP_KINDS] = {0.02f, 0.02f, 0.03f, 0.025f, 0.047f, 0.037f, 0.0f};
        xf_rot(&s, v3(0, 0, 1), PI * 0.5f);
        s.t = v3(0, lift[kind], 0);
    }
    xf_mul(&r, &base, &s);
    *x = r;
}

static void break_pickup(Game *g, Pickup *k, V3 dir) {
    static V3 w[600 * 3];
    Xf x;
    pickup_xf(g, k, &x);
    int nt = weapon_tris(k->kind ? k->kind : WP_PISTOL, k->sub, k->r, k->h, &x, w, 600 * 3);
    shatter_tris(g, w, nt, BLACK, dir, k->pos, 0.6f);
    k->active = 0;
    audio_play_rate(SFX_BREAK, 0.7f * (0.4f + 0.6f * gain_of(g, k->pos, 25)), pan_of(g, k->pos), 1.1f);
}

/* ---- spent shells ---- */
static void eject_casing(Game *g, V3 at, V3 right, float yaw) {
    for (int i = 0; i < MAX_CASINGS; i++) {
        Casing *c = &g->cas[i];
        if (c->active) continue;
        c->active = 1;
        c->pos = at;
        c->vel = vadd(vmul(right, frange(g, 1.4f, 2.2f)), v3(0, frange(g, 1.8f, 2.6f), 0));
        c->ang = 0;
        c->angV = frange(g, 15, 25);
        c->life = 4;
        c->yaw = yaw;
        return;
    }
}

static void update_casings(Game *g, float dt) {
    for (int i = 0; i < MAX_CASINGS; i++) {
        Casing *c = &g->cas[i];
        if (!c->active) continue;
        c->life -= dt;
        if (c->life <= 0) { c->active = 0; continue; }
        c->vel.y -= 9.8f * dt;
        c->pos = vadd(c->pos, vmul(c->vel, dt));
        c->ang += c->angV * dt;
        if (c->pos.y < 0.01f) {
            c->pos.y = 0.01f;
            if (c->vel.y < -0.8f) audio_play_rate(SFX_KEY, 0.25f * gain_of(g, c->pos, 8), pan_of(g, c->pos), 1.8f);
            c->vel.y = -c->vel.y * 0.35f;
            c->vel.x *= 0.5f; c->vel.z *= 0.5f;
            c->angV *= 0.5f;
        }
    }
}

static void kill_enemy(Game *g, Enemy *e, V3 dir, V3 at) {
    if (!e->alive) return;
    Pose p;
    pose_of_enemy(e, &p);
    if (e->armed) {
        /* their gun goes flying: you can grab it */
        Xf parts[BODY_PARTS];
        pose_parts(&p, parts);
        Xf gx = pose_weapon(&p, parts);
        for (int i = 0; i < MAX_PICKUPS; i++) {
            Pickup *k = &g->pk[i];
            if (k->active) continue;
            memset(k, 0, sizeof(*k));
            k->active = 1; k->flying = 1; k->kind = e->armed; k->ammo = weapon_ammo(e->armed);
            k->pos = gx.t;
            k->vel = v3(dir.x * 1.2f + frange(g, -0.6f, 0.6f), 2.6f, dir.z * 1.2f + frange(g, -0.6f, 0.6f));
            k->yaw = e->yaw;
            k->spinV = frange(g, 6, 10);
            break;
        }
    }
    shatter_body(g, &p, RED, dir, at);
    e->alive = 0;
    audio_play(SFX_SHATTER, 0.9f * (0.4f + 0.6f * gain_of(g, at, 25)), pan_of(g, at));
}

static void player_dies(Game *g, V3 dir, int how) {
    if (g->mode != MODE_PLAY) return;
    g->mode = MODE_DEAD;
    g->modeT = 0;
    g->killedBy = how;
    g->deathPos = g->pl.pos;
    g->deathYaw = g->pl.yaw;
    g->deathDir = dir;
    Pose p;
    memset(&p, 0, sizeof(p));
    p.pos = g->pl.pos;
    p.yaw = g->pl.yaw;
    p.armed = g->pl.hasGun && WP_IS_GUN(g->pl.weapon);
    p.aim = p.armed ? 1 : 0;
    p.weapon = g->pl.hasGun ? g->pl.weapon : WP_NONE;
    p.walkAmt = g->pl.moveAmt;
    p.walk = g->pl.bob;
    (void)p;   /* you see the moment from your own eyes, so your own pieces are not drawn in your face */
    audio_play(SFX_DEATH, 1, 0);
    audio_play(SFX_SHATTER, 1, 0);
}

/* ================= replays: every input of a run, played back exactly ================= */

typedef struct { unsigned short held, pressed; signed char sx, sy; unsigned short tx, ty; unsigned char dtms; } RFrame;
#define MAX_RFRAMES (60 * 60 * 5)   /* five minutes */
static RFrame rec[MAX_RFRAMES];
static int recN, recOver;
#define REPLAY_MAGIC 0x52504c32u /* RPL2 */
typedef struct { unsigned magic; int level, frames, serial; float secs; int look; } ReplayHead;

static void replay_path(const Game *g, int slot, char *out, int max) { snprintf(out, max, "%sreplay%02d.rpl", g->replayDir, slot + 1); }

void replays_scan(Game *g) {
    for (int i = 0; i < MAX_REPLAYS; i++) {
        ReplayInfo *r = &g->replays[i];
        memset(r, 0, sizeof(*r));
        char p[128];
        replay_path(g, i, p, sizeof p);
        FILE *f = fopen(p, "rb");
        if (!f) continue;
        ReplayHead h;
        if (fread(&h, sizeof h, 1, f) == 1 && h.magic == REPLAY_MAGIC && h.level >= 0 && h.level < levelCount && h.frames > 0 && h.frames <= MAX_RFRAMES) {
            r->exists = 1; r->level = h.level; r->serial = h.serial; r->secs = h.secs;
        }
        fclose(f);
    }
}

static int replay_save(Game *g) {
    if (recOver || recN <= 0 || !g->replayDir[0]) return -1;
    replays_scan(g);
    int slot = -1, maxSerial = 0, oldest = 0;
    for (int i = 0; i < MAX_REPLAYS; i++) {
        if (g->replays[i].exists) { if (g->replays[i].serial > maxSerial) maxSerial = g->replays[i].serial; }
        else if (slot < 0) slot = i;
    }
    if (slot < 0) {
        /* the folder is full: write over the oldest one */
        for (int i = 1; i < MAX_REPLAYS; i++) if (g->replays[i].serial < g->replays[oldest].serial) oldest = i;
        slot = oldest;
    }
    char p[128];
    replay_path(g, slot, p, sizeof p);
    FILE *f = fopen(p, "wb");
    if (!f) return -1;
    ReplayHead h = {REPLAY_MAGIC, g->level, recN, maxSerial + 1, g->levelT, g->setLook};
    int ok = fwrite(&h, sizeof h, 1, f) == 1 && fwrite(rec, sizeof(RFrame), recN, f) == (size_t)recN;
    fclose(f);
    replays_scan(g);
    return ok ? slot : -1;
}

/* ================= levels ================= */

static Enemy *add_enemy(Game *g, float x, float z, float yaw, int armed, float delay) {
    if (g->nen >= MAX_ENEMIES) return NULL;
    Enemy *e = &g->en[g->nen++];
    memset(e, 0, sizeof(*e));
    e->alive = 1;
    e->armed = armed;
    e->pos = v3(x, 0, z);
    e->yaw = yaw;
    e->delay = delay;
    e->appear = delay > 0 ? 0 : 1;
    e->shootT = frange(g, 1.3f, 2.4f);
    e->speed = frange(g, 1.35f, 1.7f);
    e->walk = frange(g, 0, 6);
    return e;
}

static Pickup *add_gun(Game *g, float x, float z, int kind) {
    for (int i = 0; i < MAX_PICKUPS; i++) {
        Pickup *k = &g->pk[i];
        if (k->active) continue;
        memset(k, 0, sizeof(*k));
        if (kind <= WP_NONE || kind >= WP_PROP) kind = WP_PISTOL;
        k->active = 1; k->kind = kind; k->ammo = weapon_ammo(kind);
        float y = 0.03f;
        /* on a table? sit on top of it */
        for (int b = 0; b < g->nbox; b++) {
            const Box *bx = &g->box[b];
            if (x > bx->x0 && x < bx->x1 && z > bx->z0 && z < bx->z1) y = bx->h + 0.03f;
        }
        k->pos = v3(x, y, z);
        k->yaw = frange(g, 0, 6.28f);
        k->rest = y;
        return k;
    }
    return NULL;
}

float loadWipeT = 1.72f;   /* the wipe: 0.45 s building + five dives */

static void say(Game *g, const char *s, float t) {
    snprintf(g->msg, sizeof g->msg, "%s", s);
    g->msgT = t;
}

void start_level(Game *g, int lv) {
    if (lv < 0 || lv >= levelCount) lv = 0;
    const Level *L = &levels[lv];
    g->level = lv;
    g->nbox = L->nbox < 64 ? L->nbox : 64;
    memcpy(g->box, L->box, sizeof(Box) * g->nbox);
    memset(g->en, 0, sizeof(g->en));
    memset(g->bul, 0, sizeof(g->bul));
    memset(g->pk, 0, sizeof(g->pk));
    memset(g->sh, 0, sizeof(g->sh));
    memset(g->dust, 0, sizeof(g->dust));
    memset(g->spark, 0, sizeof(g->spark));
    g->shardNext = g->shardTriNext = 0;
    memset(g->cas, 0, sizeof(g->cas));
    g->nen = 0;
    /* same start every time, so a replay plays out exactly the same */
    g->rng = 0x9E3779B9u ^ (unsigned)(lv * 7919 + 1);
    g->actT = 0; g->flashT = 0; g->touchLook = 0;
    g->level = lv;
    place_props(g);
    recN = 0; recOver = 0;
    g->replaySaved = 0;
    g->replaying = 0;
    g->story = 0;
    for (int i = 0; i < L->nen; i++) add_enemy(g, L->en[i].x, L->en[i].z, L->en[i].yaw, L->en[i].armed, L->en[i].delay);
    for (int i = 0; i < L->ngun; i++) add_gun(g, L->gun[i].x, L->gun[i].z, L->gun[i].kind);
    memset(&g->pl, 0, sizeof(g->pl));
    g->pl.pos = v3(L->px, 0, L->pz);
    g->pl.yaw = L->pyaw;
    g->ts = SLOWEST;
    g->gtime = 0;
    g->levelT = 0;
    g->tutStage = 0;
    g->tutT = 0;
    g->mode = MODE_PLAY;
    g->modeT = 0;
    if (L->tutorial) {
        add_enemy(g, 0, 10.5f, -PI * 0.5f, 0, 0);
        say(g, "TIME MOVES ONLY WHEN YOU MOVE", 99);
    } else say(g, L->title, 1.6f);
    audio_play(SFX_FLASH, 0.6f, 0);
}

int level_unlocked(const Game *g, int lv) {
    if (lv <= 0) return 1;
    return ((g->completed >> (lv - 1)) & 1) || ((g->completed >> lv) & 1);
}

static int enemies_left(const Game *g) {
    int n = 0;
    for (int i = 0; i < g->nen; i++) n += g->en[i].alive;
    return n;
}

/* the tutorial: punch one, then a gun appears, then two shooters */
static void tutorial(Game *g, float dt) {
    g->tutT += dt;
    Enemy *e0 = &g->en[0];
    switch (g->tutStage) {
    case 0:
        if (e0->alive && vlen(vsub(e0->pos, g->pl.pos)) < 3.2f) { g->tutStage = 1; say(g, "PUNCH IT  [R]", 99); }
        if (!e0->alive) g->tutStage = 1;
        break;
    case 1:
        if (!e0->alive) {
            g->tutStage = 2;
            V3 f = v3(cosf(g->pl.yaw), 0, sinf(g->pl.yaw));
            float x = clampf(g->pl.pos.x + f.x * 1.6f, -3.4f, 3.4f), z = clampf(g->pl.pos.z + f.z * 1.6f, -1.4f, 6.2f);
            add_gun(g, x, z, WP_PISTOL);
            say(g, "A GUN. GRAB IT  [L]", 99);
        }
        break;
    case 2:
        if (g->pl.hasGun) {
            g->tutStage = 3;
            add_enemy(g, -2.2f, 12.8f, -PI * 0.5f, 1, 0.6f);
            add_enemy(g, 2.2f, 12.8f, -PI * 0.5f, 1, 1.2f);
            say(g, "SHOOT THEM  [R]", 3.5f);
            g->tutT = 0;
        }
        break;
    case 3:
        if (g->tutT > 3.6f && g->msgT <= 0) say(g, "STAND STILL TO SLOW THE BULLETS", 3.5f);
        if (g->tutT > 7.5f) { g->tutStage = 4; say(g, "OUT OF AMMO? THROW IT  [L]", 3.0f); }
        break;
    }
}

/* ================= the player ================= */

static void player_punch(Game *g) {
    Player *P = &g->pl;
    if (P->punchT > 0) return;
    P->punchT = 0.32f;
    P->punchSide ^= 1;
    g->actT = 0.32f;
    audio_play(SFX_SWING, 0.6f, P->punchSide ? 0.3f : -0.3f);
    V3 e = eye_of(g), f = fwd_of(g);
    int best = -1;
    float bd = PUNCH_REACH;
    for (int i = 0; i < g->nen; i++) {
        Enemy *n = &g->en[i];
        if (!n->alive || n->delay > 0) continue;
        V3 d = vsub(v3(n->pos.x, 1.2f, n->pos.z), e);
        float l = vlen(d);
        if (l > bd) continue;
        if (vdot(vmul(d, 1.0f / l), f) < 0.55f) continue;
        bd = l; best = i;
    }
    if (best >= 0) {
        Enemy *n = &g->en[best];
        audio_play(SFX_PUNCH, 1, 0);
        kill_enemy(g, n, v3(f.x, 0, f.z), v3(n->pos.x, 1.3f, n->pos.z));
        return;
    }
    /* nobody in reach: maybe a bottle */
    for (int i = 0; i < g->nprop; i++) {
        Prop *p = &g->prop[i];
        if (!p->active) continue;
        V3 c = v3(p->pos.x, p->pos.y + p->h * 0.5f, p->pos.z);
        V3 d = vsub(c, e);
        float l = vlen(d);
        if (l > PUNCH_REACH || vdot(vmul(d, 1.0f / l), f) < 0.7f) continue;
        audio_play(SFX_PUNCH, 0.6f, 0);
        break_prop(g, p, f, c);
        return;
    }
}

static void fire_bullet(Game *g, V3 from, V3 dir, float speed, int fromPlayer) {
    for (int i = 0; i < MAX_BULLETS; i++) {
        Bullet *b = &g->bul[i];
        if (b->active) continue;
        b->active = 1;
        b->fromPlayer = fromPlayer;
        b->pos = b->start = from;
        b->vel = vmul(vnorm(dir), speed);
        b->life = 6;
        b->whizzed = 0;
        return;
    }
}

/* where your eyes are and where they look (head bob included); the camera uses this too */
void player_view(const Game *g, V3 *eye, float *yaw, float *pitch) {
    const Player *P = &g->pl;
    float stepY = -fabsf(sinf(P->bob)) * 0.035f * P->moveAmt;
    *eye = v3(P->pos.x, 1.6f + stepY + 0.015f * P->moveAmt, P->pos.z);
    *yaw = P->yaw + sinf(P->bob) * 0.006f * P->moveAmt;
    *pitch = P->pitch - P->kick * 0.05f;
}

/* your own body, posed for first person: the same glass man as the enemies, in black.
 * Only the arms get drawn, so it looks like any first-person game, but they are his arms. */
static void fp_arm(const Xf *torso, int up, int fore, float raise, float inward, float bend, Xf out[BODY_PARTS]) {
    const float *JT = meshes[M_TORSO].joint, *JU = meshes[up].joint, *JF = meshes[fore].joint;
    Xf ry, rx, l, f;
    xf_rot(&ry, v3(0, 1, 0), inward);
    xf_rot(&rx, v3(1, 0, 0), raise);
    xf_mul(&l, &ry, &rx);
    l.t = v3(JU[0] - JT[0], JU[1] - JT[1], JU[2] - JT[2]);
    xf_mul(&out[up], torso, &l);
    xf_rot(&f, v3(1, 0, 0), bend);
    f.t = v3(JF[0] - JU[0], JF[1] - JU[1], JF[2] - JU[2]);
    xf_mul(&out[fore], &out[up], &f);
}

static float lerpf(float a, float b, float t) { return a + (b - a) * t; }
#ifndef FP_RAISE
#define FP_RAISE (-1.2f)
#define FP_IN 0.22f
#define FP_BEND (-0.9f)
#endif

static void fp_parts_fk(const Game *g, Xf out[BODY_PARTS]) {
    const Player *P = &g->pl;
    V3 eye; float yaw, pitch;
    player_view(g, &eye, &yaw, &pitch);
    Xf view = xf_at(eye, yaw, 1), pr, vv, sh, root;
    xf_rot(&pr, v3(1, 0, 0), pitch);
    xf_mul(&vv, &view, &pr);
    xf_ident(&sh);
    /* with a long gun you lean into it, shoulders forward */
    int longGun = P->hasGun && (P->weapon == WP_SHOTGUN || P->weapon == WP_SMG);
    float lean = longGun ? 0.19f * (1 - (P->grabT > 0 ? smooth01(P->grabT / 0.3f) : 0)) : 0;
    /* put the body so its shoulders sit just below and behind your eyes, whatever the model's proportions */
    {
        const float *JS = meshes[M_UARM_L].joint;
        sh.t = v3(0, -(JS[1] + 0.156f), -0.15f + 0.008f - JS[2] + lean);
    }
    xf_mul(&root, &vv, &sh);
    const float *J[BODY_PARTS];
    for (int k = 0; k < BODY_PARTS; k++) J[k] = meshes[k].joint;
    Xf t; xf_ident(&t); t.t = v3(J[M_TORSO][0], J[M_TORSO][1], J[M_TORSO][2]);
    xf_mul(&out[M_TORSO], &root, &t);
    for (int k = 1; k < BODY_PARTS; k++) {
        Xf l; xf_ident(&l);
        l.t = v3(J[k][0] - J[M_TORSO][0], J[k][1] - J[M_TORSO][1], J[k][2] - J[M_TORSO][2]);
        xf_mul(&out[k], &out[M_TORSO], &l);
    }
    /* animation inputs */
    float punch = 0;
    if (P->punchT > 0) { float u = 1 - P->punchT / 0.32f; punch = u < 0.35f ? u / 0.35f : 1 - (u - 0.35f) / 0.65f; punch = punch * punch * (3 - 2 * punch); }
    float grab = P->grabT > 0 ? sinf((1 - P->grabT / 0.3f) * PI) : 0;
    float thr = P->throwT > 0 ? 1 - P->throwT / 0.3f : 0;
    float breathe = sinf(g->time * 1.7f) * 0.012f;
    float walkSwing = sinf(P->bob * 0.5f) * 0.35f * P->moveAmt;
    float lp = P->punchSide ? punch : 0, rp = P->punchSide ? 0 : punch;
    /* your right arm is the -x one (UARM_L / FARM_L) */
    float rRaise, rIn, rBend;
    int gun = P->hasGun && WP_IS_GUN(P->weapon);
    if (P->hasGun && WP_IS_MELEE(P->weapon)) {
        /* a sword or bat held up by the shoulder; R sweeps it across in front of you */
        float sw = punch, up = P->grabT > 0 ? P->grabT / 0.3f : 0;
        rRaise = lerpf(-0.95f + walkSwing * 0.2f, -1.35f, sw) + 0.6f * up + P->swayY * 2 + breathe;
        rIn = lerpf(-0.05f, 0.6f, sw) + P->swayX * 2;
        rBend = lerpf(-0.75f, -0.15f, sw);
        if (thr > 0) { rRaise = lerpf(-2.6f, -1.45f, thr); rBend = lerpf(-0.7f, -0.05f, thr); rIn = 0.15f; }
    } else if (P->hasGun && P->weapon == WP_PROP) {
        /* a bottle held ready to throw */
        float up = P->grabT > 0 ? P->grabT / 0.3f : 0;
        rRaise = lerpf(-1.3f, -1.6f, punch) + 0.5f * up + P->swayY * 2 + breathe; rIn = lerpf(0.16f, 0.24f, punch) + P->swayX * 2; rBend = lerpf(-0.3f, -0.02f, punch);
    } else if (gun) {
        float k = P->kick, up = P->grabT > 0 ? P->grabT / 0.3f : 0;
        rRaise = -1.36f - 0.2f * k + 0.7f * up + P->swayY * 2 + breathe;
        rIn = 0.17f + P->swayX * 2;
        rBend = -0.1f - 0.12f * k;
    } else {
        /* arms hang relaxed and swing as you walk; a punch whips the fist up and out */
        rRaise = lerpf(-0.18f + walkSwing, -1.56f, rp); rIn = lerpf(0.06f, 0.2f, rp); rBend = lerpf(-0.28f, -0.04f, rp);
        rRaise = lerpf(rRaise, -0.72f, grab); rBend = lerpf(rBend, -0.35f, grab);
        if (thr > 0) { rRaise = lerpf(-2.6f, -1.45f, thr); rBend = lerpf(-0.7f, -0.05f, thr); rIn = 0.15f; }
        rRaise += breathe * (1 - rp);
    }
    float lRaise, lIn, lBend;
    if (P->hasGun && !gun) {
        lRaise = -0.2f - walkSwing; lIn = -0.06f; lBend = -0.3f;
    } else if (P->hasGun) {
        /* the free hand stays down out of sight, and comes up to punch */
        lRaise = lerpf(-0.25f, -1.56f, punch); lIn = lerpf(-0.1f, -0.2f, punch); lBend = lerpf(-0.25f, -0.04f, punch);
    } else {
        lRaise = lerpf(-0.18f - walkSwing, -1.56f, lp); lIn = lerpf(-0.06f, -0.2f, lp); lBend = lerpf(-0.28f, -0.04f, lp);
        lRaise += breathe * (1 - lp);
    }
    fp_arm(&out[M_TORSO], M_UARM_L, M_FARM_L, rRaise, rIn, rBend, out);
    fp_arm(&out[M_TORSO], M_UARM_R, M_FARM_R, lRaise, lIn, lBend, out);
}

/* the pistol in your right hand */
/* the weapon as the arms hold it (melee, bottles): it follows the right forearm */
static Xf fp_weapon_fk(const Game *g, const Xf parts[BODY_PARTS]) {
    Xf l;
    xf_rot(&l, v3(1, 0, 0), PI * 0.5f);
    l.t = grip_of(M_FARM_L);
    Xf r; xf_mul(&r, &parts[M_FARM_L], &l);
    if (!g->pl.hasGun) return r;
    if (WP_IS_MELEE(g->pl.weapon)) {
        /* in your own hand the blade leans out to the right and back over the shoulder, and rolls through the swing */
        float sw = 0;
        if (g->pl.punchT > 0) { float u = 1 - g->pl.punchT / 0.32f; sw = u < 0.35f ? u / 0.35f : 1 - (u - 0.35f) / 0.65f; sw = smooth01(sw); }
        Xf a, b, c, t;
        xf_rot(&a, v3(0, 0, 1), -0.55f + 1.4f * sw);
        xf_rot(&b, v3(1, 0, 0), -0.75f + 0.9f * sw);
        xf_mul(&t, &r, &a);
        xf_mul(&c, &t, &b);
        return c;
    }
    return weapon_hold(r, g->pl.weapon);
}

/* a gun held up in front of your eyes with both hands, lined up on the crosshair */
static Xf fp_gun_view(const Game *g) {
    const Player *P = &g->pl;
    V3 eye; float yaw, pitch;
    player_view(g, &eye, &yaw, &pitch);
    Xf view = xf_at(eye, yaw, 1), pr, vv;
    xf_rot(&pr, v3(1, 0, 0), pitch);
    xf_mul(&vv, &view, &pr);
    V3 f = xf_dir(&vv, v3(0, 0, 1)), u = xf_dir(&vv, v3(0, 1, 0)), r = xf_dir(&vv, v3(-1, 0, 0));
    int k = P->weapon;
    float fw = 0.46f, rt = 0.085f, dn = 0.085f;
    if (k == WP_SHOTGUN) { fw = 0.27f; rt = 0.07f; dn = 0.1f; }
    else if (k == WP_SMG) { fw = 0.34f; rt = 0.08f; dn = 0.09f; }
    /* breathing, the step of your walk, and the gun lagging behind your turns */
    float breathe = sinf(g->time * 1.7f) * 0.004f;
    float bx = cosf(P->bob * 0.5f) * 0.012f * P->moveAmt, by = -fabsf(sinf(P->bob * 0.5f)) * 0.012f * P->moveAmt;
    float up = P->grabT > 0 ? smooth01(P->grabT / 0.3f) : 0;
    V3 G = vadd(eye, vadd(vmul(f, fw), vadd(vmul(r, rt + bx - P->swayX * 1.5f), vmul(u, -dn + breathe + by + P->swayY * 1.5f - 0.3f * up))));
    V3 dir = vnorm(vsub(vadd(eye, vmul(f, 12)), G));
    float kk = smooth01(P->kick);
    G = vsub(G, vmul(dir, 0.07f * kk));
    dir = vnorm(vadd(dir, vmul(u, 0.25f * kk + 0.4f * up)));
    /* hitting someone with it: a short hard jab forward, nose dipping */
    if (P->punchT > 0) {
        float t = 1 - P->punchT / 0.32f, j = t < 0.35f ? t / 0.35f : 1 - (t - 0.35f) / 0.65f;
        j = smooth01(j);
        int lg = k == WP_SHOTGUN || k == WP_SMG;
        G = vadd(G, vadd(vmul(f, (lg ? 0.14f : 0.2f) * j), vmul(u, (lg ? 0.02f : -0.03f) * j)));
        dir = vnorm(vadd(dir, vmul(u, (lg ? 0.08f : -0.3f) * j)));
    }
    return weapon_frame(G, dir, u);
}

Xf player_gun_xf(const Game *g) {
    if (g->pl.hasGun && WP_IS_GUN(g->pl.weapon)) return fp_gun_view(g);
    Xf parts[BODY_PARTS];
    fp_parts_fk(g, parts);
    return fp_weapon_fk(g, parts);
}

/* your arms: posed, then both hands put on a gun or a sword handle */
void player_fp_parts(const Game *g, Xf out[BODY_PARTS]) {
    const Player *P = &g->pl;
    fp_parts_fk(g, out);
    if (!P->hasGun || P->weapon == WP_PROP) return;
    Xf W = WP_IS_GUN(P->weapon) ? fp_gun_view(g) : fp_weapon_fk(g, out);
    V3 eye; float yaw, pitch;
    player_view(g, &eye, &yaw, &pitch);
    Xf view = xf_at(eye, yaw, 1);
    V3 r = xf_dir(&view, v3(-1, 0, 0)), down = v3(0, -1, 0);
    if (WP_IS_GUN(P->weapon)) ik_arm(out, M_UARM_L, M_FARM_L, xf_point(&W, grip_main(P->weapon)), vadd(down, vmul(r, 0.8f)));
    ik_arm(out, M_UARM_R, M_FARM_R, xf_point(&W, grip_off(P->weapon)), vadd(down, vmul(r, -0.8f)));
}

static V3 player_muzzle(const Game *g) {
    Xf gx = player_gun_xf(g);
    V3 m = weapon_muzzle(g->pl.hasGun ? g->pl.weapon : WP_PISTOL);
    m.z += 0.02f;
    return xf_point(&gx, m);
}

static void player_shoot(Game *g) {
    Player *P = &g->pl;
    if (P->shootT > 0) return;
    g->actT = 0.35f;
    if (P->ammo <= 0) { audio_play(SFX_NOAMMO, 0.9f, 0); P->shootT = 0.25f; g->noAmmoT = 1.4f; return; }
    P->ammo--;
    if (P->ammo == 0) g->noAmmoT = 1.4f;   /* that was the last one */
    int kind = P->weapon;
    P->shootT = kind == WP_SMG ? 0.11f : kind == WP_SHOTGUN ? 0.6f : 0.38f;
    P->kick = 1;
    g->flashT = 0.06f;
    V3 e = eye_of(g), f = fwd_of(g);
    /* aim where the crosshair points (the first wall, man or bottle on that line), from the muzzle */
    float t = 1;
    seg_hits_wall(g, e, vadd(e, vmul(f, 40)), &t);
    float best = t * 40;
    for (int i = 0; i < g->nen; i++) {
        const Enemy *n = &g->en[i];
        if (!n->alive || n->delay > 0) continue;
        V3 d = vsub(v3(n->pos.x, 0, n->pos.z), v3(e.x, 0, e.z));
        float along = (d.x * f.x + d.z * f.z) / fmaxf(1e-4f, f.x * f.x + f.z * f.z);
        if (along <= 0) continue;
        V3 p = vadd(e, vmul(f, along));
        float dx = p.x - n->pos.x, dz = p.z - n->pos.z;
        if (dx * dx + dz * dz < 0.3f * 0.3f && p.y > 0.1f && p.y < 1.85f && along < best) best = along;
    }
    for (int i = 0; i < g->nprop; i++) {
        const Prop *pr = &g->prop[i];
        if (!pr->active) continue;
        V3 d = vsub(pr->pos, e);
        float along = vdot(d, f);
        if (along <= 0) continue;
        V3 p = vadd(e, vmul(f, along));
        float dx = p.x - pr->pos.x, dz = p.z - pr->pos.z;
        if (dx * dx + dz * dz < (pr->r + 0.05f) * (pr->r + 0.05f) && p.y > pr->pos.y - 0.05f && p.y < pr->pos.y + pr->h + 0.05f && along < best) best = along;
    }
    for (int i = 0; i < MAX_PICKUPS; i++) {
        const Pickup *k = &g->pk[i];
        if (!k->active) continue;
        V3 d = vsub(k->pos, e);
        float along = vdot(d, f);
        if (along <= 0) continue;
        V3 cl = vsub(vadd(e, vmul(f, along)), k->pos);
        if (vdot(cl, cl) < 0.15f * 0.15f && along < best) best = along;
    }
    V3 target = vadd(e, vmul(f, best));
    V3 m = player_muzzle(g);
    if (kind == WP_SHOTGUN) {
        /* a spread of pellets round the crosshair */
        V3 d = vnorm(vsub(target, m)), r = vnorm(vcross(d, v3(0, 1, 0))), u = vcross(r, d);
        for (int k = 0; k < 6; k++) {
            float a = k * 1.047f + frange(g, -0.3f, 0.3f), sp = k == 0 ? 0 : frange(g, 0.035f, 0.075f);
            fire_bullet(g, m, vadd(d, vadd(vmul(r, cosf(a) * sp), vmul(u, sinf(a) * sp))), PLAYER_BULLET_SPEED, 1);
        }
        P->kick = 1;
        audio_play(SFX_SHOTGUN, 1, 0.1f);
    } else {
        V3 d = vsub(target, m);
        if (kind == WP_SMG) d = vadd(vnorm(d), v3(frange(g, -0.012f, 0.012f), frange(g, -0.01f, 0.012f), frange(g, -0.012f, 0.012f)));
        fire_bullet(g, m, d, PLAYER_BULLET_SPEED, 1);
        if (kind == WP_SMG) { P->kick = 0.55f; audio_play_rate(SFX_SMG, 0.85f, 0.1f, 0.95f + 0.1f * frand(g)); }
        else audio_play(SFX_SHOT, 1, 0.1f);
    }
    P->slide = 1;
    V3 r = vnorm(v3(-f.z, 0, f.x));
    eject_casing(g, vadd(vsub(m, vmul(f, 0.22f)), v3(0, 0.03f, 0)), r, P->yaw);
}

static int grab_gun(Game *g) {
    Player *P = &g->pl;
    V3 e = eye_of(g), f = fwd_of(g);
    int best = -1;
    float bd = 2.4f;
    for (int i = 0; i < MAX_PICKUPS; i++) {
        Pickup *k = &g->pk[i];
        if (!k->active || (k->flying && k->thrown)) continue;
        V3 d = vsub(k->pos, e);
        float l = vlen(d);
        float near = vlen(vsub(v3(k->pos.x, 0, k->pos.z), P->pos));
        if (l > bd) continue;
        if (near > 1.1f && vdot(vmul(d, 1.0f / l), f) < 0.8f) continue;
        bd = l; best = i;
    }
    if (best < 0) {
        /* no weapon in reach: pick up a bottle, a vase, a mug off the table to throw */
        float pd = 1.9f;
        int bp = -1;
        for (int i = 0; i < g->nprop; i++) {
            const Prop *p = &g->prop[i];
            if (!p->active) continue;
            V3 d = vsub(v3(p->pos.x, p->pos.y + p->h * 0.5f, p->pos.z), e);
            float l = vlen(d);
            if (l > pd || vdot(vmul(d, 1.0f / l), f) < 0.6f) continue;
            pd = l; bp = i;
        }
        if (bp < 0) return 0;
        Prop *p = &g->prop[bp];
        P->hasGun = 1; P->ammo = 0; P->weapon = WP_PROP; P->sub = p->kind; P->heldR = p->r; P->heldH = p->h;
        p->active = 0;
        P->grabT = 0.3f;
        g->actT = 0.3f;
        audio_play(SFX_PICKUP, 0.7f, 0);
        return 1;
    }
    Pickup *k = &g->pk[best];
    P->hasGun = 1;
    P->ammo = k->ammo;
    P->weapon = k->kind ? k->kind : WP_PISTOL;
    P->sub = k->sub; P->heldR = k->r; P->heldH = k->h;
    k->active = 0;
    P->grabT = 0.3f;
    g->actT = 0.3f;
    audio_play(SFX_PICKUP, 0.9f, 0);
    return 1;
}

static void throw_gun(Game *g) {
    Player *P = &g->pl;
    if (!P->hasGun) return;
    for (int i = 0; i < MAX_PICKUPS; i++) {
        Pickup *k = &g->pk[i];
        if (k->active) continue;
        memset(k, 0, sizeof(*k));
        V3 f = fwd_of(g);
        k->active = 1; k->flying = 1; k->thrown = 1; k->ammo = P->ammo;
        k->kind = P->weapon; k->sub = P->sub; k->r = P->heldR; k->h = P->heldH;
        if (P->weapon == WP_PROP || WP_IS_MELEE(P->weapon)) { Xf hx = player_gun_xf(g); k->pos = hx.t; }
        else k->pos = player_muzzle(g);
        k->vel = vadd(vmul(f, 13), v3(0, 1.2f, 0));
        k->yaw = P->yaw;
        k->spinV = 16;
        break;
    }
    P->hasGun = 0;
    P->ammo = 0;
    P->weapon = WP_NONE;
    P->throwT = 0.3f;
    g->actT = 0.3f;
    audio_play(SFX_THROW, 0.8f, 0);
}

/* someone close enough to hit, right in front of you? */
static int enemy_in_reach(const Game *g) {
    V3 e = eye_of(g), f = fwd_of(g);
    for (int i = 0; i < g->nen; i++) {
        const Enemy *n = &g->en[i];
        if (!n->alive || n->delay > 0) continue;
        V3 d = vsub(v3(n->pos.x, 1.2f, n->pos.z), e);
        float l = vlen(d);
        if (l < PUNCH_REACH && vdot(vmul(d, 1.0f / l), f) > 0.55f) return 1;
    }
    return 0;
}

/* holding a gun or a bottle, you can still hit someone with it: the gun jabs forward, the bottle smashes on them */
static void player_bash(Game *g) {
    Player *P = &g->pl;
    if (P->punchT > 0) return;
    if (P->weapon == WP_PROP) {
        /* smash it over them: it breaks too */
        int had = enemy_in_reach(g);
        player_punch(g);
        if (had) {
            P->hasGun = 0; P->weapon = WP_NONE;
            Xf hx = player_gun_xf(g);
            Pickup tmp; memset(&tmp, 0, sizeof tmp);
            tmp.active = 1; tmp.flying = 1; tmp.kind = WP_PROP; tmp.sub = P->sub; tmp.r = P->heldR; tmp.h = P->heldH; tmp.pos = hx.t;
            break_pickup(g, &tmp, fwd_of(g));
        }
        return;
    }
    player_punch(g);
}

/* a sword or bat: longer reach than a fist, and the sword cuts bullets out of the air */
static void melee_swing(Game *g) {
    Player *P = &g->pl;
    if (P->punchT > 0) return;
    P->punchT = 0.32f;
    g->actT = 0.32f;
    if (P->weapon == WP_KATANA) audio_play(SFX_SLICE, 0.85f, 0.2f);
    else audio_play_rate(SFX_SWING, 0.8f, 0.2f, 0.75f);
    V3 e = eye_of(g), f = fwd_of(g);
    float reach = P->weapon == WP_KATANA ? 2.1f : 1.9f;
    int hit = 0;
    for (int i = 0; i < g->nen; i++) {
        Enemy *n = &g->en[i];
        if (!n->alive || n->delay > 0) continue;
        V3 d = vsub(v3(n->pos.x, 1.2f, n->pos.z), e);
        float l = vlen(d);
        if (l > reach || vdot(vmul(d, 1.0f / l), f) < 0.5f) continue;
        kill_enemy(g, n, v3(f.x, 0, f.z), v3(n->pos.x, 1.3f, n->pos.z));
        hit = 1;
    }
    if (hit) audio_play(SFX_PUNCH, 1, 0);
    for (int i = 0; i < g->nprop; i++) {
        Prop *p = &g->prop[i];
        if (!p->active) continue;
        V3 c = v3(p->pos.x, p->pos.y + p->h * 0.5f, p->pos.z);
        V3 d = vsub(c, e);
        float l = vlen(d);
        if (l > reach || vdot(vmul(d, 1.0f / l), f) < 0.6f) continue;
        break_prop(g, p, f, c);
    }
    if (P->weapon == WP_KATANA) {
        for (int i = 0; i < MAX_BULLETS; i++) {
            Bullet *b = &g->bul[i];
            if (!b->active || b->fromPlayer) continue;
            V3 d = vsub(b->pos, e);
            float l = vlen(d);
            if (l > 2.3f || vdot(vmul(d, 1.0f / (l + 1e-4f)), f) < 0.35f) continue;
            /* sliced in two: a burst of sparks where it was */
            static const float sc[3] = {1.0f, 0.95f, 0.85f};
            for (int k = 0; k < 6; k++) add_spark(g, b->pos, v3(frange(g, -1.5f, 1.5f), frange(g, -0.5f, 1.5f), frange(g, -1.5f, 1.5f)), 0.02f, 0.4f, sc, k == 0);
            b->active = 0;
            audio_play_rate(SFX_RICOCHET, 0.8f, 0, 1.4f);
        }
    }
}

static void update_player(Game *g, const Input *in, float dt) {
    Player *P = &g->pl;
    if (P->hasGun && P->weapon == WP_NONE) P->weapon = WP_PISTOL;
    /* turning: ABXY or the d-pad, or drag on the touch screen */
    float turn = 0, look = 0;
    if (in->held & (BTN_Y | BTN_DLEFT)) turn -= 1;
    if (in->held & (BTN_A | BTN_DRIGHT)) turn += 1;
    if (in->held & (BTN_X | BTN_DUP)) look -= 1;
    if (in->held & (BTN_B | BTN_DDOWN)) look += 1;
    int lk = g->replaying ? g->replayLook : g->setLook;
    float ls = 0.6f + 0.4f * (lk ? lk : 2);
    P->yaw += turn * TURN_SPEED * ls * dt;
    P->pitch += look * 1.8f * ls * dt;
    float touchMove = 0;
    if (in->held & BTN_TOUCH) {
        if (g->touchLook) {
            float dx = (float)(in->tx - g->lastTx), dy = (float)(in->ty - g->lastTy);
            P->yaw += dx * 0.0075f;
            P->pitch += dy * 0.0075f;
            touchMove = (fabsf(dx) + fabsf(dy)) * 0.15f;
        }
        g->touchLook = 1;
        g->lastTx = in->tx; g->lastTy = in->ty;
    } else g->touchLook = 0;
    P->pitch = clampf(P->pitch, -1.2f, 1.2f);
    P->yaw = wrapf(P->yaw);
    /* walking: up/down forward, left/right sidestep */
    float fx = cosf(P->yaw), fz = sinf(P->yaw);
    float mx = (fx * in->sy - fz * in->sx), mz = (fz * in->sy + fx * in->sx);
    float ml = sqrtf(mx * mx + mz * mz);
    if (ml > 1) { mx /= ml; mz /= ml; ml = 1; }
    float nx = P->pos.x + mx * WALK_SPEED * dt, nz = P->pos.z + mz * WALK_SPEED * dt;
    if (!blocked(g, nx, P->pos.z, PLAYER_R)) P->pos.x = nx;
    if (!blocked(g, P->pos.x, nz, PLAYER_R)) P->pos.z = nz;
    float prevBob = P->bob;
    P->bob += ml * dt * 9;
    if (sinf(prevBob) < 0 && sinf(P->bob) >= 0 && ml > 0.2f) audio_play(SFX_STEP, 0.25f, 0);
    P->moveAmt = clampf(ml + fabsf(turn) * 0.55f + fabsf(look) * 0.4f + touchMove, 0, 1);
    /* actions */
    if (P->punchT > 0) P->punchT -= dt;
    if (P->shootT > 0) P->shootT -= dt;
    if (P->throwT > 0) P->throwT -= dt;
    if (P->grabT > 0) P->grabT -= dt;
    if (P->kick > 0) P->kick = fmaxf(0, P->kick - dt * 6);
    if (P->slide > 0) P->slide = fmaxf(0, P->slide - dt * 9);
    /* the gun trails behind your turns a little, then settles */
    P->swayX += (-turn * 0.04f - P->swayX) * clampf(dt * 8, 0, 1);
    P->swayY += (look * 0.03f - P->swayY) * clampf(dt * 8, 0, 1);
    if (in->pressed & (BTN_R | BTN_ZR)) {
        if (!P->hasGun) player_punch(g);
        else if (WP_IS_MELEE(P->weapon)) melee_swing(g);
        else if (enemy_in_reach(g)) player_bash(g);
        else if (P->weapon == WP_PROP) throw_gun(g);
        else player_shoot(g);
    } else if ((in->held & (BTN_R | BTN_ZR)) && P->hasGun && P->weapon == WP_SMG && P->ammo > 0 && P->shootT <= 0) {
        player_shoot(g);   /* hold R: the submachine gun keeps firing */
    }
    if (in->pressed & (BTN_L | BTN_ZL)) {
        if (P->hasGun) throw_gun(g);
        else if (!grab_gun(g)) { /* nothing near: a quick jab helps nobody */ }
    }
}

/* ================= enemies ================= */

static void steer(Game *g, Enemy *e, V3 target, float speed, float dt) {
    V3 d = vsub(target, e->pos);
    d.y = 0;
    float l = vlen(d);
    if (l < 0.01f) return;
    float want = atan2f(d.z, d.x);
    /* try straight at it, then more and more to the sides */
    static const float tries[7] = {0, 0.5f, -0.5f, 1.0f, -1.0f, 1.6f, -1.6f};
    for (int k = 0; k < 7; k++) {
        float a = want + tries[k];
        float nx = e->pos.x + cosf(a) * speed * dt, nz = e->pos.z + sinf(a) * speed * dt;
        int hit = blocked(g, nx, nz, ENEMY_R);
        for (int o = 0; o < g->nen && !hit; o++) {
            const Enemy *b = &g->en[o];
            if (b == e || !b->alive || b->delay > 0) continue;
            float ox = nx - b->pos.x, oz = nz - b->pos.z;
            if (ox * ox + oz * oz < 0.5f * 0.5f && (ox * ox + oz * oz) < ((e->pos.x - b->pos.x) * (e->pos.x - b->pos.x) + (e->pos.z - b->pos.z) * (e->pos.z - b->pos.z))) hit = 1;
        }
        if (!hit) {
            e->pos.x = nx; e->pos.z = nz;
            e->yaw += wrapf(a - e->yaw) * clampf(dt * 8, 0, 1);
            e->walkAmt += (1 - e->walkAmt) * clampf(dt * 6, 0, 1);
            e->walk += speed * dt * 5.2f;
            return;
        }
    }
    e->walkAmt *= 1 - clampf(dt * 6, 0, 1);
}

static void update_enemies(Game *g, float dt) {
    V3 pe = eye_of(g);
    for (int i = 0; i < g->nen; i++) {
        Enemy *e = &g->en[i];
        if (!e->alive) continue;
        if (e->delay > 0) { e->delay -= dt; if (e->delay <= 0) audio_play(SFX_KEY, 0.4f, pan_of(g, e->pos)); continue; }
        if (e->appear < 1) e->appear = fminf(1, e->appear + dt * 2.5f);
        e->t += dt;
        if (e->kick > 0) e->kick = fmaxf(0, e->kick - dt * 4);
        if (e->flashT > 0) e->flashT -= dt;
        V3 d = vsub(g->pl.pos, e->pos);
        d.y = 0;
        float dist = vlen(d);
        float face = atan2f(d.z, d.x);
        V3 head = v3(e->pos.x, 1.5f, e->pos.z);
        int sees = line_of_sight(g, head, pe);
        int melee = WP_IS_MELEE(e->armed);
        /* up close, a man with a gun hits you with it instead */
        if (WP_IS_GUN(e->armed) && e->state != EN_PUNCH && dist < 1.25f && sees) { e->state = EN_PUNCH; e->punchT = 0; e->punchHit = 0; }
        if (WP_IS_GUN(e->armed) && e->state != EN_PUNCH) {
            if (dist > 7.5f || !sees) {
                e->aim = fmaxf(0, e->aim - dt * 3);
                steer(g, e, g->pl.pos, e->speed, dt);
            } else {
                e->walkAmt *= 1 - clampf(dt * 6, 0, 1);
                e->yaw += wrapf(face - e->yaw) * clampf(dt * 6, 0, 1);
                e->aim = fminf(1, e->aim + dt * 2.5f);
                if (dist > 3.0f && e->aim > 0.5f && fabsf(wrapf(face - e->yaw)) < 0.3f) {
                    /* creep sideways a bit so they're not sitting ducks */
                    float side = sinf(e->t * 0.7f + i) > 0 ? 1 : -1;
                    float sx = e->pos.x - sinf(e->yaw) * side * 0.6f * dt, sz = e->pos.z + cosf(e->yaw) * side * 0.6f * dt;
                    if (!blocked(g, sx, sz, ENEMY_R)) { e->pos.x = sx; e->pos.z = sz; }
                }
                e->shootT -= dt;
                if (e->shootT <= 0 && e->aim > 0.9f) {
                    Pose p; pose_of_enemy(e, &p);
                    Xf parts[BODY_PARTS]; pose_parts(&p, parts);
                    Xf gx = pose_weapon(&p, parts);
                    V3 muzzle = xf_point(&gx, weapon_muzzle(e->armed));
                    V3 aimAt = v3(g->pl.pos.x + frange(g, -0.25f, 0.25f), frange(g, 1.0f, 1.55f), g->pl.pos.z + frange(g, -0.25f, 0.25f));
                    if (e->armed == WP_SHOTGUN) {
                        /* a spread you have to step out of */
                        V3 d = vnorm(vsub(aimAt, muzzle)), r = vnorm(vcross(d, v3(0, 1, 0))), u = vcross(r, d);
                        for (int k = 0; k < 5; k++) {
                            float a = k * 1.257f + frange(g, -0.3f, 0.3f), sp = k == 0 ? 0 : frange(g, 0.05f, 0.09f);
                            fire_bullet(g, muzzle, vadd(d, vadd(vmul(r, cosf(a) * sp), vmul(u, sinf(a) * sp))), ENEMY_BULLET_SPEED, 0);
                        }
                    } else fire_bullet(g, muzzle, vsub(aimAt, muzzle), ENEMY_BULLET_SPEED, 0);
                    add_dust(g, muzzle, v3(0, 0.3f, 0), 0.08f);
                    e->kick = 1;
                    e->flashT = 0.08f;
                    eject_casing(g, xf_point(&gx, v3(0, 0.03f, 0.06f)), vnorm(v3(sinf(e->yaw), 0, -cosf(e->yaw))), e->yaw);
                    audio_play(SFX_ENEMY_SHOT, 0.5f + 0.5f * gain_of(g, e->pos, 20), pan_of(g, e->pos));
                    if (e->armed == WP_SMG) {
                        /* three quick shots, then a pause */
                        if (e->burst <= 0) e->burst = 3;
                        e->burst--;
                        e->shootT = e->burst > 0 ? 0.13f : frange(g, 1.8f, 2.6f);
                    } else e->shootT = e->armed == WP_SHOTGUN ? frange(g, 2.4f, 3.2f) : frange(g, 1.6f, 2.4f);
                }
            }
        } else {
            if (e->state != EN_PUNCH) {
                e->punch = fmaxf(0, e->punch - dt * 3);
                if (dist < (melee ? 1.7f : 1.25f) && sees) { e->state = EN_PUNCH; e->punchT = 0; e->punchHit = 0; }
                else steer(g, e, g->pl.pos, e->speed * 1.1f, dt);
            } else {
                e->punchT += dt;
                e->yaw += wrapf(face - e->yaw) * clampf(dt * 5, 0, 1);
                e->walkAmt *= 1 - clampf(dt * 6, 0, 1);
                /* wind up, swing, recover */
                if (e->punchT < 0.45f) e->punch = e->punchT / 0.45f * 0.35f;
                else if (e->punchT < 0.6f) e->punch = 0.35f + (e->punchT - 0.45f) / 0.15f * 0.65f;
                else e->punch = fmaxf(0, 1 - (e->punchT - 0.6f) * 2.5f);
                if (!e->punchHit && e->punchT >= 0.58f) {
                    e->punchHit = 1;
                    audio_play(SFX_SWING, 0.5f, pan_of(g, e->pos));
                    if (dist < (melee ? 2.0f : 1.5f) && fabsf(wrapf(face - e->yaw)) < 0.7f) { audio_play(SFX_PUNCH, 1, 0); player_dies(g, vmul(d, 1.0f / (dist + 0.01f)), 1); return; }
                }
                if (e->punchT > 1.0f) e->state = EN_CHASE;
            }
        }
    }
}

/* ================= bullets, thrown guns, shards ================= */

static void update_bullets(Game *g, float dt) {
    for (int i = 0; i < MAX_BULLETS; i++) {
        Bullet *b = &g->bul[i];
        if (!b->active) continue;
        b->life -= dt;
        if (b->life <= 0) { b->active = 0; continue; }
        V3 np = vadd(b->pos, vmul(b->vel, dt));
        float tw;
        int wall = seg_hits_wall(g, b->pos, np, &tw);
        float tEnd = wall ? tw : 1;
        V3 seg = vsub(np, b->pos);
        /* people: a capsule round each body */
        float bestT = tEnd;
        int hitEn = -1, hitPl = 0;
        for (int k = 0; k < g->nen; k++) {
            Enemy *e = &g->en[k];
            if (!e->alive || e->delay > 0) continue;
            V3 rel = vsub(b->pos, e->pos);
            float a2 = seg.x * seg.x + seg.z * seg.z;
            float t = a2 > 1e-8f ? -(rel.x * seg.x + rel.z * seg.z) / a2 : 0;
            t = clampf(t, 0, 1);
            float cx = rel.x + seg.x * t, cz = rel.z + seg.z * t, cy = b->pos.y + seg.y * t;
            if (cx * cx + cz * cz < 0.26f * 0.26f && cy > 0.1f && cy < 1.8f && t < bestT) {
                /* don't shoot yourself in the hand when the bullet has just left */
                if (!b->fromPlayer && vlen(vsub(b->start, e->pos)) < 0.8f && vlen(vsub(b->pos, b->start)) < 0.9f) continue;
                bestT = t; hitEn = k;
            }
        }
        if (!b->fromPlayer && g->mode == MODE_PLAY) {
            V3 rel = vsub(b->pos, g->pl.pos);
            float a2 = seg.x * seg.x + seg.z * seg.z;
            float t = a2 > 1e-8f ? clampf(-(rel.x * seg.x + rel.z * seg.z) / a2, 0, 1) : 0;
            float cx = rel.x + seg.x * t, cz = rel.z + seg.z * t, cy = b->pos.y + seg.y * t;
            float r2 = cx * cx + cz * cz;
            if (r2 < 0.24f * 0.24f && cy > 0.1f && cy < 1.85f && t < bestT) { bestT = t; hitPl = 1; hitEn = -1; }
            /* a near miss whizzes past */
            if (!b->whizzed && r2 < 1.0f && cy > 0.8f) { b->whizzed = 1; audio_play(SFX_WHIZ, 0.6f, pan_of(g, b->pos)); }
        }
        /* black glass on the tables, and guns lying about */
        int hitProp = -1, hitGun = -1;
        for (int k = 0; k < g->nprop; k++) {
            Prop *p = &g->prop[k];
            if (!p->active) continue;
            V3 rel = vsub(b->pos, p->pos);
            float a2 = seg.x * seg.x + seg.z * seg.z;
            float t = a2 > 1e-8f ? clampf(-(rel.x * seg.x + rel.z * seg.z) / a2, 0, 1) : 0;
            float cx = rel.x + seg.x * t, cz = rel.z + seg.z * t, cy = rel.y + seg.y * t;
            float rr = p->r + 0.03f;
            if (cx * cx + cz * cz < rr * rr && cy > 0 && cy < p->h && t < bestT) { bestT = t; hitProp = k; hitEn = -1; hitPl = 0; }
        }
        for (int k = 0; k < MAX_PICKUPS; k++) {
            /* guns are black glass too: lying on the floor or flying through the air, a bullet breaks them */
            Pickup *q = &g->pk[k];
            if (!q->active) continue;
            V3 rel = vsub(b->pos, q->pos);
            float a2 = vdot(seg, seg);
            float t = a2 > 1e-8f ? clampf(-vdot(rel, seg) / a2, 0, 1) : 0;
            V3 cl = vadd(rel, vmul(seg, t));
            if (vdot(cl, cl) < 0.13f * 0.13f && t < bestT) { bestT = t; hitGun = k; hitProp = -1; hitEn = -1; hitPl = 0; }
        }
        V3 at = vadd(b->pos, vmul(seg, bestT));
        if (hitProp >= 0) { b->active = 0; break_prop(g, &g->prop[hitProp], vnorm(b->vel), at); continue; }
        if (hitGun >= 0) { b->active = 0; break_pickup(g, &g->pk[hitGun], vnorm(b->vel)); continue; }
        if (hitPl) { b->active = 0; player_dies(g, vnorm(b->vel), 0); return; }
        if (hitEn >= 0) { b->active = 0; kill_enemy(g, &g->en[hitEn], vnorm(b->vel), at); continue; }
        if (wall) {
            b->active = 0;
            for (int k = 0; k < 4; k++) add_dust(g, at, v3(frange(g, -0.8f, 0.8f), frange(g, 0, 1.2f), frange(g, -0.8f, 0.8f)), 0.07f);
            audio_play(SFX_RICOCHET, 0.35f * gain_of(g, at, 20), pan_of(g, at));
            continue;
        }
        b->pos = np;
    }
}

static void update_pickups(Game *g, float dt) {
    for (int i = 0; i < MAX_PICKUPS; i++) {
        Pickup *k = &g->pk[i];
        if (!k->active || !k->flying) continue;
        V3 np = vadd(k->pos, vmul(k->vel, dt));
        k->vel.y -= 9.8f * dt;
        k->spin += k->spinV * dt;
        /* a thrown gun breaks whoever it hits */
        if (k->thrown) {
            for (int e = 0; e < g->nen; e++) {
                Enemy *n = &g->en[e];
                if (!n->alive || n->delay > 0) continue;
                float dx = np.x - n->pos.x, dz = np.z - n->pos.z;
                if (dx * dx + dz * dz < 0.35f * 0.35f && np.y > 0.2f && np.y < 1.9f) {
                    kill_enemy(g, n, vnorm(v3(k->vel.x, 0, k->vel.z)), np);
                    audio_play(SFX_PUNCH, 0.7f, pan_of(g, np));
                    if (k->kind == WP_PROP) { k->pos = np; break_pickup(g, k, vnorm(k->vel)); break; }
                    k->vel = v3(-k->vel.x * 0.2f, 1.5f, -k->vel.z * 0.2f);
                    k->thrown = 0;
                    np = k->pos;
                    break;
                }
            }
        }
        if (k->thrown) {
            for (int q = 0; q < g->nprop; q++) {
                Prop *p = &g->prop[q];
                if (!p->active) continue;
                float dx = np.x - p->pos.x, dz = np.z - p->pos.z;
                if (dx * dx + dz * dz < (p->r + 0.08f) * (p->r + 0.08f) && np.y > p->pos.y - 0.05f && np.y < p->pos.y + p->h + 0.05f)
                    break_prop(g, p, vnorm(v3(k->vel.x, 0, k->vel.z)), np);
            }
        }
        if (!k->active) continue;
        if (blocked(g, np.x, np.z, 0.05f) && np.y < 3.2f) {
            if (k->kind == WP_PROP) { break_pickup(g, k, vnorm(k->vel)); continue; }
            k->vel.x *= -0.3f; k->vel.z *= -0.3f;
            k->thrown = 0;
            np.x = k->pos.x; np.z = k->pos.z;
            audio_play(SFX_RICOCHET, 0.3f * gain_of(g, np, 15), pan_of(g, np));
        }
        float floorY = 0.03f;
        for (int b = 0; b < g->nbox; b++) {
            const Box *bx = &g->box[b];
            if (np.x > bx->x0 && np.x < bx->x1 && np.z > bx->z0 && np.z < bx->z1 && k->pos.y >= bx->h) floorY = bx->h + 0.03f;
        }
        if (np.y <= floorY) {
            np.y = floorY;
            if (k->kind == WP_PROP) { k->pos = np; break_pickup(g, k, vnorm(k->vel)); continue; }   /* glass on the floor */
            if (fabsf(k->vel.y) > 1.5f) { k->vel.y = -k->vel.y * 0.3f; k->vel.x *= 0.5f; k->vel.z *= 0.5f; }
            else { k->flying = 0; k->thrown = 0; k->rest = floorY; k->yaw += k->spin; k->spin = 0; }
        }
        k->pos = np;
    }
}

static void update_shards(Game *g, float dt) {
    if (g->tinkT > 0) g->tinkT -= dt;
    for (int i = 0; i < MAX_SHARDS; i++) {
        Shard *s = &g->sh[i];
        if (!s->active) continue;
        s->life -= dt;
        if (s->life <= 0) { s->active = 0; continue; }
        if (s->rest) continue;
        s->vel.y -= 9.8f * dt;
        V3 np = vadd(s->c, vmul(s->vel, dt));
        s->ang += s->angV * dt;
        /* walls: bounce back off them */
        if (blocked(g, np.x, s->c.z, 0.02f)) { s->vel.x *= -0.35f; np.x = s->c.x; s->angV *= 0.7f; }
        if (blocked(g, s->c.x, np.z, 0.02f)) { s->vel.z *= -0.35f; np.z = s->c.z; s->angV *= 0.7f; }
        /* tables and the floor */
        float floorY = 0.012f;
        for (int b = 0; b < g->nbox; b++) {
            const Box *bx = &g->box[b];
            if (box_is_surface(bx) && np.x > bx->x0 && np.x < bx->x1 && np.z > bx->z0 && np.z < bx->z1 && s->c.y >= bx->h) floorY = bx->h + 0.012f;
        }
        float lift = s->rad * 0.35f;
        if (np.y - lift < floorY) {
            np.y = floorY + lift;
            if (s->vel.y < -0.6f) {
                /* glass on a hard floor: a bounce and a tinkle */
                if (g->tinkT <= 0) {
                    float d = vlen(vsub(np, g->pl.pos));
                    float gain = (0.15f + 0.5f * fminf(1, -s->vel.y / 4)) * clampf(1 - d / 14, 0, 1);
                    audio_play_rate(SFX_TINK, gain, 0, 0.8f + 0.6f * frand(g) + (s->nt < 4 ? 0.4f : 0));
                    g->tinkT = 0.035f;
                }
                s->vel.y = -s->vel.y * 0.25f;
                s->vel.x *= 0.5f; s->vel.z *= 0.5f;
                s->angV *= 0.45f;
            } else {
                /* skid to a stop, then settle so the lowest corner rests on the floor */
                s->vel.y = 0;
                s->vel.x *= 1 - clampf(dt * 6, 0, 1); s->vel.z *= 1 - clampf(dt * 6, 0, 1);
                s->angV *= 1 - clampf(dt * 8, 0, 1);
                if (s->vel.x * s->vel.x + s->vel.z * s->vel.z < 0.0025f) {
                    s->rest = 1; s->vel = v3(0, 0, 0);
                    Xf x; xf_rot(&x, s->axis, s->ang);
                    const float *q = g->shardTri + s->t0 * 9;
                    float mn = 0;
                    for (int v = 0; v < s->nt * 3; v++) { V3 p = xf_point(&x, v3(q[v * 3], q[v * 3 + 1], q[v * 3 + 2])); if (p.y < mn) mn = p.y; }
                    /* turn it so its broad face lies on the floor, like real fragments do */
                    V3 ns = v3(0, 0, 0);
                    for (int k = 0; k < s->nt; k++) {
                        const float *t3 = q + k * 9;
                        V3 a = v3(t3[0], t3[1], t3[2]), b = v3(t3[3], t3[4], t3[5]), c = v3(t3[6], t3[7], t3[8]);
                        ns = vadd(ns, vcross(vsub(b, a), vsub(c, a)));
                    }
                    if (vlen(ns) > 1e-9f) {
                        V3 n = vnorm(xf_dir(&x, ns));
                        V3 up = v3(0, n.y >= 0 ? 1 : -1, 0);
                        V3 ax = vcross(n, up);
                        float sa = vlen(ax), ca = vdot(n, up);
                        if (sa > 1e-4f) {
                            Xf r, m;
                            xf_rot(&r, vmul(ax, 1 / sa), atan2f(sa, ca));
                            xf_mul(&m, &r, &x);
                            /* back to axis-angle */
                            float tr = m.m[0] + m.m[4] + m.m[8];
                            float ang = acosf(clampf((tr - 1) * 0.5f, -1, 1));
                            V3 a2 = v3(m.m[7] - m.m[5], m.m[2] - m.m[6], m.m[3] - m.m[1]);
                            float al = vlen(a2);
                            if (al > 1e-5f) { s->axis = vmul(a2, 1 / al); s->ang = ang; x = m; }
                        }
                    }
                    mn = 0;
                    for (int v = 0; v < s->nt * 3; v++) { V3 p = xf_point(&x, v3(q[v * 3], q[v * 3 + 1], q[v * 3 + 2])); if (p.y < mn) mn = p.y; }
                    np.y = floorY - mn;
                }
            }
        }
        s->c = np;
    }
    for (int i = 0; i < MAX_SPARKS; i++) {
        Spark *p = &g->spark[i];
        if (!p->active) continue;
        p->life -= dt;
        if (p->life <= 0) { p->active = 0; continue; }
        if (p->flash) continue;
        p->vel.y -= 9.8f * dt;
        p->vel = vmul(p->vel, 1 - clampf(dt * 1.2f, 0, 1));
        p->pos = vadd(p->pos, vmul(p->vel, dt));
        p->spin += dt * 20;
        if (p->pos.y < 0.005f) { p->pos.y = 0.005f; p->vel = vmul(p->vel, 0.3f); p->vel.y = 0; }
    }
    for (int i = 0; i < MAX_DUST; i++) {
        Dust *d = &g->dust[i];
        if (!d->active) continue;
        d->life -= dt * 1.6f;
        d->pos = vadd(d->pos, vmul(d->vel, dt));
        d->vel = vmul(d->vel, 1 - clampf(dt * 2, 0, 1));
        if (d->life <= 0) d->active = 0;
    }
}


/* ================= the story: chats with your friend ================= */

static const ChatLine c0[] = {
    {CH_FRIEND, "you awake? i found something"},
    {CH_YOU, "barely. what is it"},
    {CH_FRIEND, "a game. not out anywhere. a guy on a board leaked it"},
    {CH_YOU, "leaked from where"},
    {CH_FRIEND, "doesnt matter. time only moves when you move. thats the whole trick"},
    {CH_YOU, "sounds like a gimmick"},
    {CH_FRIEND, "its not. trust me. sending the files now"},
    {CH_SYSTEM, "[ file received: " EXE_NAME " ]"},
    {CH_FRIEND, "run the tutorial first. then tell me what you think"},
};
static const ChatLine c1[] = {
    {CH_YOU, "ok i get it now"},
    {CH_FRIEND, "told you"},
    {CH_YOU, "i stood still and the bullet just hung there"},
    {CH_FRIEND, "keep going. the levels get better"},
};
static const ChatLine c2[] = {
    {CH_YOU, "how many levels are there"},
    {CH_FRIEND, "no idea. the file list keeps getting longer"},
    {CH_YOU, "thats not how files work"},
    {CH_FRIEND, "lol. just play"},
};
static const ChatLine c3[] = {
    {CH_YOU, "my menus are glitching. letters keep swapping"},
    {CH_FRIEND, "probably your old drive"},
    {CH_YOU, "it only happens after i clear a level"},
    {CH_FRIEND, "huh"},
    {CH_FRIEND, "keep playing. i want to know what happens at the end"},
};
static const ChatLine c4[] = {
    {CH_YOU, "i think the game is doing something to my computer"},
    {CH_FRIEND, "what do you mean"},
    {CH_YOU, "files i never made. the clock runs backwards"},
    {CH_FRIEND, "unplug it"},
    {CH_YOU, "i tried. it wont turn off"},
    {CH_SYSTEM, "[ connection unstable ]"},
    {CH_FRIEND, "who is this"},
    {CH_YOU, "its me??"},
};
static const ChatLine c5[] = {
    {CH_SPAM, "hey are you there"},
    {CH_SYSTEM, "[ message could not be delivered ]"},
    {CH_SPAM, "please answer"},
};
static const ChatLine c6[] = {
    {CH_SPAM, "something took over my keyboard"},
    {CH_SPAM, "i cant type what i"},
    {CH_SYSTEM, "[ friend is typing... ]"},
    {CH_SYSTEM, "[ friend stopped typing ]"},
};
static const ChatLine c7[] = {
    {CH_SPAM, "call me. dont use the"},
    {CH_SPAM, "help"},
    {CH_SPAM, "help"},
    {CH_SYSTEM, "[ user is offline ]"},
};
static const ChatLine c8[] = {
    {CH_FRIEND, WORD_A " " WORD_B},
    {CH_SPAM, "who are you"},
    {CH_FRIEND, WORD_A " " WORD_B " " WORD_A " " WORD_B},
    {CH_SPAM, "stop"},
};
static const ChatLine c9[] = {
    {CH_SPAM, "i"},
    {CH_SPAM, "am"},
    {CH_SPAM, "still"},
    {CH_SPAM, "here"},
    {CH_SYSTEM, "[ there is no one here ]"},
};
static const ChatLine c10[] = {
    {CH_SYSTEM, "[ 10 new files found in levels.ult ]"},
    {CH_SPAM, "there are more levels now"},
    {CH_SPAM, "i never downloaded these"},
    {CH_FRIEND, WORD_A},
};
static const ChatLine c11[] = {
    {CH_SPAM, "if anyone reads this"},
    {CH_SPAM, "do not run the file"},
    {CH_SYSTEM, "[ message deleted ]"},
};
static const ChatLine c12[] = {
    {CH_FRIEND, WORD_A " " WORD_B},
    {CH_SPAM, "is that you in there"},
    {CH_FRIEND, "keep playing"},
    {CH_SPAM, "is that"},
    {CH_SYSTEM, "[ friend has left the chat ]"},
};
static const ChatLine c13[] = {
    {CH_SYSTEM, "[ camera turned on ]"},
    {CH_SPAM, "turn it off"},
    {CH_SYSTEM, "[ camera turned on ]"},
    {CH_SPAM, "please"},
};
static const ChatLine c14[] = {
    {CH_SPAM, "one more"},
    {CH_SYSTEM, "[ the last file is ready ]"},
    {CH_FRIEND, WORD_A " " WORD_B " " WORD_A " " WORD_B},
};
#define NL(a) (int)(sizeof(a) / sizeof(a[0]))
const ChatScript chats[] = {
    {"intro", NL(c0), c0}, {"after tutorial", NL(c1), c1}, {"after 03", NL(c2), c2}, {"after 06", NL(c3), c3},
    {"after 09", NL(c4), c4}, {"after 10", NL(c5), c5}, {"after 11", NL(c6), c6}, {"after 12", NL(c7), c7},
    {"after 13", NL(c8), c8}, {"after 14", NL(c9), c9}, {"after 16", NL(c10), c10}, {"after 18", NL(c11), c11},
    {"after 20", NL(c12), c12}, {"after 22", NL(c13), c13}, {"after 24", NL(c14), c14},
};
const int chatCount = NL(chats);

/* which chat follows clearing a level for the first time (-1: none, 99: the end) */
static int chat_after(int lv) {
    switch (lv) {
    case 0: return 1;
    case 3: return 2;
    case 6: return 3;
    case 9: return 4;
    case 10: return 5;
    case 11: return 6;
    case 12: return 7;
    case 13: return 8;
    case 14: return 9;
    case 16: return 10;
    case 18: return 11;
    case 20: return 12;
    case 22: return 13;
    case 24: return 14;
    case 25: return 99;
    }
    return -1;
}

int levels_done(const Game *g) {
    int n = 0;
    for (int i = 0; i < levelCount; i++) n += (g->completed >> i) & 1;
    return n;
}

/* the more you play, the worse your computer gets; from level 10 on it belongs to the game */
float corruption(const Game *g) {
    int n = levels_done(g);
    if (n <= 3) return 0;
    float c = (n - 3) / 12.0f;
    return c > 1 ? 1 : c;
}

static const char SPAM[] = WORD_A " " WORD_B " ";

int chat_typed_text(const Game *g, int line, int chars, char *out, int max) {
    (void)g;
    const ChatScript *S = &chats[g->chatId];
    if (line < 0 || line >= S->n || max < 2) { out[0] = 0; return 0; }
    const ChatLine *L = &S->line[line];
    int n = 0;
    if (L->who == CH_SPAM) {
        /* you start to type what you meant, then the keyboard stops being yours */
        int real = (int)strlen(L->text);
        int keep = real < 5 ? real : 5;
        int total = keep + 48;
        if (chars > total) chars = total;
        for (int i = 0; i < chars && n < max - 1; i++) {
            if (i < keep) out[n++] = L->text[i];
            else out[n++] = SPAM[(i - keep) % (int)(sizeof(SPAM) - 1)];
        }
        out[n] = 0;
        return total;
    }
    int len = (int)strlen(L->text);
    if (chars > len) chars = len;
    for (int i = 0; i < chars && n < max - 1; i++) out[n++] = L->text[i];
    out[n] = 0;
    return len;
}

static void chat_open(Game *g, int id) {
    if (id < 0 || id >= chatCount) id = 0;
    g->mode = MODE_CHAT;
    g->modeT = 0;
    g->chatId = id;
    g->chatLine = 0;
    g->chatChars = 0;
    g->chatT = 0;
    g->chatDone = 0;
    if (id > g->lastChat) { g->lastChat = id; g->saveDirty = 1; }
}

static void chat_leave(Game *g);

static void update_chat(Game *g, const Input *in, float dt) {
    const ChatScript *S = &chats[g->chatId];
    g->chatT += dt;
    unsigned typeKeys = BTN_A | BTN_B | BTN_X | BTN_Y | BTN_L | BTN_R | BTN_ZL | BTN_ZR | BTN_DUP | BTN_DDOWN | BTN_DLEFT | BTN_DRIGHT | BTN_TOUCH;
    if (g->chatLine >= S->n) {
        g->chatDone = 1;
        if ((in->pressed & BTN_START) || (g->chatT > 0.4f && (in->pressed & (BTN_A | BTN_TOUCH)))) { audio_play(SFX_BEEP, 0.6f, 0); chat_leave(g); }
        return;
    }
    if (in->pressed & BTN_START) { audio_play(SFX_BEEP, 0.5f, 0); chat_leave(g); return; } /* leave chat */
    const ChatLine *L = &S->line[g->chatLine];
    if (L->who == CH_YOU || L->who == CH_SPAM) {
        char tmp[96];
        int total = chat_typed_text(g, g->chatLine, 0, tmp, sizeof tmp);
        if (in->pressed & typeKeys) {
            if (g->chatChars >= total) {
                /* sent */
                g->chatLine++; g->chatChars = 0; g->chatT = 0;
                audio_play(SFX_BEEP, 0.4f, 0);
            } else {
                /* every key press types a few letters, whatever you press */
                g->chatChars += L->who == CH_SPAM ? 6 : 3;
                if (g->chatChars > total) g->chatChars = total;
                audio_play_rate(SFX_KEY, 0.5f, 0, 0.9f + 0.2f * frand(g));
            }
        }
        /* the hacked keyboard keeps going on its own */
        if (L->who == CH_SPAM && g->chatChars > 5 && g->chatChars < total && g->chatT > 0.06f) {
            g->chatT = 0; g->chatChars++;
            if ((g->chatChars & 3) == 0) audio_play_rate(SFX_KEY, 0.35f, 0, 1.3f);
        }
    } else {
        /* your friend (or the system) answers after a moment */
        float wait = L->who == CH_SYSTEM ? 1.1f : 0.9f + 0.025f * (float)strlen(L->text);
        if (g->chatT >= wait) {
            g->chatLine++; g->chatChars = 0; g->chatT = 0;
            audio_play(L->who == CH_SYSTEM ? SFX_EMPTY : SFX_PICKUP, 0.5f, 0);
        }
    }
}

/* ================= saving progress ================= */

#define SAVE_MAGIC 0x53485434u /* SHT4: room for 32 levels */
typedef struct { unsigned magic; int completed; float best[32]; int lastChat, introSeen; int quality, glow, crt, look; } Save;
typedef struct { unsigned magic; int completed; float best[16]; int lastChat, introSeen; int quality, glow, crt, look; } SaveV3;

int game_save_bytes(const Game *g, unsigned char *buf, int max) {
    Save s;
    memset(&s, 0, sizeof(s));
    s.magic = SAVE_MAGIC;
    s.completed = g->completed;
    memcpy(s.best, g->best, sizeof(s.best));
    s.lastChat = g->lastChat;
    s.introSeen = g->introSeen;
    s.quality = g->setQuality | (g->setAA ? 0 : 2) | (g->setShatter << 2); s.glow = g->setGlow; s.crt = g->setCrt; s.look = g->setLook;
    if (max < (int)sizeof(s)) return 0;
    memcpy(buf, &s, sizeof(s));
    return sizeof(s);
}

int game_load_bytes(Game *g, const unsigned char *buf, int n) {
    Save s;
    memset(&s, 0, sizeof s);
    unsigned magic = 0;
    if (n < 4) return 0;
    memcpy(&magic, buf, 4);
    if (magic == 0x53485432u || magic == 0x53485433u) {
        /* older saves had 16 levels (and before that, no settings) */
        SaveV3 o;
        memset(&o, 0, sizeof o);
        int need = magic == 0x53485432u ? (int)(sizeof(SaveV3) - 4 * sizeof(int)) : (int)sizeof(SaveV3);
        if (n < need) return 0;
        memcpy(&o, buf, need);
        if (magic == 0x53485432u) { o.quality = 1; o.glow = 1; o.crt = 1; o.look = 2; }
        s.completed = o.completed & 0xFFFF;
        memcpy(s.best, o.best, sizeof o.best);
        s.lastChat = o.lastChat; s.introSeen = o.introSeen; s.quality = o.quality; s.glow = o.glow; s.crt = o.crt; s.look = o.look;
    } else {
        if (n < (int)sizeof(s) || magic != SAVE_MAGIC) return 0;
        memcpy(&s, buf, sizeof(s));
    }
    g->completed = s.completed;
    memcpy(g->best, s.best, sizeof(s.best));
    g->lastChat = s.lastChat >= 0 && s.lastChat < chatCount ? s.lastChat : 0;
    g->introSeen = s.introSeen;
    g->setQuality = s.quality & 1; g->setAA = !(s.quality & 2); g->setShatter = (s.quality >> 2) % 3; g->setGlow = s.glow & 1; g->setCrt = s.crt & 1;
    g->setLook = s.look >= 1 && s.look <= 3 ? s.look : 2;
    return 1;
}

/* ================= main update ================= */

void game_boot(Game *g, unsigned seed) {
    int gpu = g->gpu;
    char dir[80];
    memcpy(dir, g->replayDir, sizeof dir);
    memset(g, 0, sizeof(*g));
    g->gpu = gpu;
    memcpy(g->replayDir, dir, sizeof dir);
    g->rng = seed ? seed : 1;
    g->mode = MODE_BOOT;
    g->level = 0;
    g->menuSel = 1;
    g->ts = 1;
    g->pendingChat = -1;
    g->setQuality = 1; g->setAA = 1; g->setGlow = 1; g->setCrt = 1; g->setLook = 2;
}

/* ---- the file commander ---- */

const char *setting_text(const Game *g, int s, int value_only) {
    static char b[48];
    static const char *names[SET_COUNT] = {"graphics.cfg", "antialias.cfg", "shatter.cfg", "glow.cfg", "crt.cfg", "look.cfg"};
    const char *v = "";
    static const char *speed[4] = {"", "SLOW", "NORMAL", "FAST"};
    switch (s) {
    case SET_QUALITY: v = g->setQuality ? "HIGH" : "LOW"; break;
    case SET_AA: v = g->setAA ? "ON" : "OFF"; break;
    case SET_SHATTER: v = g->setShatter == SHATTER_REAL ? "REAL" : (g->setShatter == SHATTER_SIMPLE ? "SIMPLE" : "OFF"); break;
    case SET_GLOW: v = g->setGlow ? "ON" : "OFF"; break;
    case SET_CRT: v = g->setCrt ? "ON" : "OFF"; break;
    default: v = speed[g->setLook < 1 ? 1 : (g->setLook > 3 ? 3 : g->setLook)]; break;
    }
    if (value_only) return v;
    snprintf(b, sizeof b, "%s", names[s]);
    return b;
}

static void setting_toggle(Game *g, int s) {
    switch (s) {
    case SET_QUALITY: g->setQuality ^= 1; break;
    case SET_AA: g->setAA ^= 1; break;
    case SET_SHATTER: g->setShatter = (g->setShatter + 1) % 3; break;
    case SET_GLOW: g->setGlow ^= 1; break;
    case SET_CRT: g->setCrt ^= 1; break;
    default: g->setLook = g->setLook % 3 + 1; break;
    }
    g->saveDirty = 1;
}

int menu_rows(const Game *g) {
    if (g->menuDir == DIR_ROOT) return 6;
    if (g->menuDir == DIR_SETTINGS) return 1 + SET_COUNT;
    if (g->menuDir == DIR_LEVELS) return 1 + levels_done(g);
    int n = 1;
    for (int i = 0; i < MAX_REPLAYS; i++) n += g->replays[i].exists;
    return n;
}

int menu_row(const Game *g, int r, int *arg) {
    if (arg) *arg = 0;
    if (r <= 0) return ROW_UP;
    if (g->menuDir == DIR_ROOT) {
        static const int k[6] = {ROW_UP, ROW_EXE, ROW_LEVELS, ROW_REPLAYS, ROW_SETTINGS, ROW_CHAT};
        return r < 6 ? k[r] : ROW_UP;
    }
    if (g->menuDir == DIR_SETTINGS) { if (arg) *arg = r - 1; return r - 1 < SET_COUNT ? ROW_SET : ROW_UP; }
    int n = 0;
    if (g->menuDir == DIR_LEVELS) {
        for (int i = 0; i < levelCount; i++)
            if ((g->completed >> i) & 1) { if (++n == r) { if (arg) *arg = i; return ROW_LEVEL; } }
        return ROW_UP;
    }
    for (int i = 0; i < MAX_REPLAYS; i++)
        if (g->replays[i].exists) { if (++n == r) { if (arg) *arg = i; return ROW_REPLAY; } }
    return ROW_UP;
}

static void menu_go(Game *g) {
    g->mode = MODE_MENU;
    g->modeT = 0;
    g->story = 0;
    g->replaying = 0;
    int rows = menu_rows(g);
    if (g->menuSel < 0 || g->menuSel >= rows) g->menuSel = rows > 1 ? 1 : 0;
}

static void open_dir(Game *g, int dir, int sel) {
    g->menuDir = dir;
    if (dir == DIR_REPLAYS) replays_scan(g);
    g->menuSel = sel;
    menu_go(g);
}

/* story mode: the first level you have not beaten, or the tutorial again once all are done */
static int story_level(const Game *g) {
    for (int i = 0; i < levelCount; i++) if (!((g->completed >> i) & 1)) return i;
    return 0;
}

static void story_next(Game *g, int lv) {
    if (lv >= levelCount) { open_dir(g, DIR_ROOT, 1); return; }
    start_level(g, lv);
    g->story = 1;
}

/* leaving a chat: in story mode the next level starts straight away */
static void chat_leave(Game *g) {
    if (g->story) { story_next(g, g->storyNext); return; }
    open_dir(g, DIR_ROOT, 5);
}

static int replay_start(Game *g, int slot) {
    char p[128];
    replay_path(g, slot, p, sizeof p);
    FILE *f = fopen(p, "rb");
    if (!f) return 0;
    ReplayHead h;
    int ok = fread(&h, sizeof h, 1, f) == 1 && h.magic == REPLAY_MAGIC && h.frames > 0 && h.frames <= MAX_RFRAMES && h.level >= 0 && h.level < levelCount;
    if (ok) ok = fread(rec, sizeof(RFrame), h.frames, f) == (size_t)h.frames;
    fclose(f);
    if (!ok) return 0;
    start_level(g, h.level);
    recN = h.frames;   /* start_level cleared it: the loaded frames are what we play back */
    g->replaying = 1;
    g->replayFrame = 0;
    g->replayLen = h.frames;
    g->replaySlot = slot;
    g->replayLook = h.look >= 1 && h.look <= 3 ? h.look : 2;
    g->msgT = 0;
    return 1;
}

void game_update(Game *g, const Input *inLive, float dt) {
    if (g->mode != MODE_PLAY && g->mode != MODE_DEAD) audio_set_time(1);
    Input in = *inLive;
    /* fixed steps for the numbers that feed the game, so a replay repeats a run exactly */
    if (dt > 0.05f) dt = 0.05f;
    if (dt < 0.001f) dt = 0.001f;
    dt = roundf(dt * 1000) / 1000;
    in.sx = roundf(clampf(in.sx, -1, 1) * 127) / 127;
    in.sy = roundf(clampf(in.sy, -1, 1) * 127) / 127;
    g->time += dt;
    g->modeT += dt;
    if (g->replayMsgT > 0) g->replayMsgT -= dt;
    switch (g->mode) {
    case MODE_BOOT:
        audio_loop(LOOP_HUM, 0.35f, 0);
        audio_loop(LOOP_DRONE, 0, 0);
        audio_loop(LOOP_RUSH, 0, 0);
        if ((int)(g->modeT * 30) != (int)((g->modeT - dt) * 30) && g->modeT < 2.2f) audio_play(SFX_KEY, 0.25f, 0);
        if (g->modeT > 5.5f || (g->modeT > 0.3f && (in.pressed & (BTN_A | BTN_START | BTN_TOUCH)))) {
            audio_play(SFX_BEEP, 0.6f, 0);
            if (!g->introSeen) {
                /* first time: the friend sends you the game, then it starts */
                g->introSeen = 1; g->saveDirty = 1;
                chat_open(g, 0);
                g->story = 1; g->storyNext = 0;
            } else open_dir(g, DIR_ROOT, 1);
        }
        return;
    case MODE_CHAT:
        audio_loop(LOOP_HUM, 0.3f, 0);
        audio_loop(LOOP_DRONE, corruption(g) * 0.3f, 0);
        audio_loop(LOOP_RUSH, 0, 0);
        update_chat(g, &in, dt);
        return;
    case MODE_HACK:
        /* the ending: the game has the whole machine now */
        audio_loop(LOOP_DRONE, 0.5f, 0);
        audio_loop(LOOP_HUM, 0.2f, 0);
        audio_loop(LOOP_RUSH, 0, 0);
        {
            int c = (int)(g->modeT / 0.3f);
            if (c != g->flashCount && g->modeT < 9) { g->flashCount = c; audio_play_rate(SFX_FLASH, 0.6f, 0, 0.8f + 0.4f * frand(g)); }
        }
        if (g->modeT > 10 && (in.pressed & (BTN_A | BTN_START | BTN_TOUCH))) { audio_play(SFX_BEEP, 0.6f, 0); open_dir(g, DIR_ROOT, 1); }
        return;
    case MODE_MENU: {
        audio_loop(LOOP_HUM, 0.35f, 0);
        audio_loop(LOOP_DRONE, 0, 0);
        audio_loop(LOOP_RUSH, 0, 0);
        int rows = menu_rows(g);
        int mv = 0;
        if (in.pressed & (BTN_DUP | BTN_X)) mv = -1;
        if (in.pressed & BTN_DDOWN) mv = 1;
        static float rep;
        if (in.sy > 0.6f || in.sy < -0.6f) { rep -= dt; if (rep <= 0) { mv = in.sy > 0 ? -1 : 1; rep = 0.18f; } } else rep = 0;
        if (mv) { g->menuSel = (g->menuSel + mv + rows) % rows; audio_play(SFX_KEY, 0.5f, 0); }
        int choose = (in.pressed & (BTN_A | BTN_START)) != 0;
        if (in.pressed & BTN_TOUCH) {
            int r = ui_menu_row(in.ty);
            if (r >= 0 && r < rows) {
                if (r == g->menuSel) choose = 1;
                else { g->menuSel = r; audio_play(SFX_KEY, 0.5f, 0); }
            }
        }
        /* B goes up a folder */
        static const int backRow[4] = {1, 2, 3, 4};
        if ((in.pressed & BTN_B) && g->menuDir != DIR_ROOT) { audio_play(SFX_BEEP, 0.5f, 0); open_dir(g, DIR_ROOT, backRow[g->menuDir]); return; }
        /* left and right change a setting too */
        if (g->menuDir == DIR_SETTINGS && (in.pressed & (BTN_DLEFT | BTN_DRIGHT)) && g->menuSel > 0) { setting_toggle(g, g->menuSel - 1); audio_play(SFX_KEY, 0.6f, 0); return; }
        if (!choose) return;
        int arg, kind = menu_row(g, g->menuSel, &arg);
        audio_play(SFX_BEEP, 0.6f, 0);
        switch (kind) {
        case ROW_UP:
            if (g->menuDir == DIR_ROOT) { g->mode = MODE_BOOT; g->modeT = 0; }
            else open_dir(g, DIR_ROOT, backRow[g->menuDir]);
            break;
        case ROW_SETTINGS: open_dir(g, DIR_SETTINGS, 1); break;
        case ROW_SET: setting_toggle(g, arg); break;
        case ROW_EXE: story_next(g, story_level(g)); break;
        case ROW_LEVELS: open_dir(g, DIR_LEVELS, levels_done(g) > 0 ? 1 : 0); break;
        case ROW_REPLAYS: open_dir(g, DIR_REPLAYS, 1); break;
        case ROW_CHAT: chat_open(g, g->lastChat); g->story = 0; break;
        case ROW_LEVEL: start_level(g, arg); g->story = 0; break;
        case ROW_REPLAY:
            if (!replay_start(g, arg)) { audio_play(SFX_EMPTY, 0.6f, 0); replays_scan(g); }
            break;
        }
        return;
    }
    case MODE_WIN:
        /* flash the two words until you press A; X keeps a replay of the run */
        audio_loop(LOOP_DRONE, 0, 0);
        audio_loop(LOOP_RUSH, 0, 0);
        {
            int c = (int)(g->modeT / 0.42f);
            if (c != g->flashCount) {
                /* each word is shouted as it flashes up */
                g->flashCount = c;
                audio_play(SFX_FLASH, 0.55f, 0);
                if (c < 8) audio_play(c & 1 ? SFX_WORD_B : SFX_WORD_A, 1, 0);
            }
        }
        if (!g->replaying && !g->replaySaved && (in.pressed & BTN_X)) {
            int slot = replay_save(g);
            g->replaySaved = 1;
            snprintf(g->replayMsg, sizeof g->replayMsg, slot >= 0 ? "REPLAY SAVED: replay%02d.rpl" : "COULD NOT SAVE THE REPLAY", slot + 1);
            g->replayMsgT = 2.5f;
            audio_play(slot >= 0 ? SFX_PICKUP : SFX_EMPTY, 0.7f, 0);
        }
        if (g->modeT > 0.6f && (in.pressed & (BTN_A | BTN_START | BTN_TOUCH))) {
            audio_play(SFX_BEEP, 0.7f, 0);
            if (g->replaying) { open_dir(g, DIR_REPLAYS, g->menuSel); return; }
            int next = g->level + 1;
            int pc = g->pendingChat;
            g->pendingChat = -1;
            if (pc == 99) { g->mode = MODE_HACK; g->modeT = 0; g->flashCount = -1; g->story = 0; }
            else if (pc >= 0) { int st = g->story; chat_open(g, pc); g->story = st; g->storyNext = next; }
            else if (g->story) story_next(g, next);
            else open_dir(g, DIR_LEVELS, g->menuSel);
        }
        return;
    case MODE_PAUSE:
        audio_loop(LOOP_DRONE, 0.05f, 0);
        audio_loop(LOOP_RUSH, 0, 0);
        if (in.pressed & (BTN_DUP | BTN_X)) g->pauseSel = (g->pauseSel + 2) % 3;
        if (in.pressed & (BTN_DDOWN | BTN_B)) g->pauseSel = (g->pauseSel + 1) % 3;
        {
            int pick = (in.pressed & BTN_A) != 0;
            if (in.pressed & BTN_TOUCH) { int r = (in.ty - 62) / 48; if (r >= 0 && r < 3) { g->pauseSel = r; pick = 1; } }
            if (in.pressed & BTN_START) { g->mode = MODE_PLAY; return; }
            if (pick) {
                audio_play(SFX_BEEP, 0.6f, 0);
                if (g->pauseSel == 0) g->mode = MODE_PLAY;
                else if (g->pauseSel == 1) { int st = g->story; start_level(g, g->level); g->story = st; }
                else open_dir(g, DIR_ROOT, 1);
            }
        }
        return;
    case MODE_DEAD:
        /* time stops dead on the frame you were hit */
        g->ts += (0.0f - g->ts) * clampf(dt * 10, 0, 1);
        audio_set_time(g->ts);
        update_shards(g, dt * g->ts);
        update_casings(g, dt * g->ts);
        update_bullets(g, dt * g->ts * 0.5f);
        audio_loop(LOOP_DRONE, 0.25f, 0);
        audio_loop(LOOP_RUSH, 0, 0);
        if (g->replaying) { if (g->modeT > 2.0f) open_dir(g, DIR_REPLAYS, 1); return; }
        /* restart right away with a button, or it restarts by itself a moment later */
        if ((g->modeT > 0.6f && (in.pressed & (BTN_A | BTN_R | BTN_START | BTN_TOUCH))) || g->modeT > 2.2f) {
            int st = g->story;
            start_level(g, g->level);
            g->story = st;
        }
        return;
    default:
        break;
    }
    /* ---- playing ---- */
    /* the level is still building itself from pixels: nothing moves yet, not even a replay */
    if (g->modeT < loadWipeT) { audio_loop(LOOP_RUSH, 0, 0); return; }
    if (g->replaying) {
        /* B or START stops watching; otherwise the recorded buttons drive the game */
        if (in.pressed & (BTN_B | BTN_START)) { audio_play(SFX_BEEP, 0.5f, 0); open_dir(g, DIR_REPLAYS, 1); return; }
        if (g->replayFrame >= g->replayLen) { open_dir(g, DIR_REPLAYS, 1); return; }
        const RFrame *f = &rec[g->replayFrame++];
        in.held = f->held; in.pressed = f->pressed; in.released = 0;
        in.sx = f->sx / 127.0f; in.sy = f->sy / 127.0f; in.tx = f->tx; in.ty = f->ty;
        dt = f->dtms / 1000.0f;
    } else {
        if (in.pressed & BTN_START) { g->mode = MODE_PAUSE; g->pauseSel = 0; audio_play(SFX_BEEP, 0.5f, 0); return; }
        if (in.pressed & BTN_SELECT) { int st = g->story; start_level(g, g->level); g->story = st; return; }
        if (recN < MAX_RFRAMES) {
            RFrame *f = &rec[recN++];
            f->held = (unsigned short)in.held; f->pressed = (unsigned short)in.pressed;
            f->sx = (signed char)roundf(in.sx * 127); f->sy = (signed char)roundf(in.sy * 127);
            f->tx = (unsigned short)in.tx; f->ty = (unsigned short)in.ty;
            f->dtms = (unsigned char)roundf(dt * 1000);
        } else recOver = 1;
    }
    g->levelT += dt;
    update_player(g, &in, dt);
    /* time follows you */
    if (g->actT > 0) g->actT -= dt;
    g->tsTarget = SLOWEST + (1 - SLOWEST) * g->pl.moveAmt;
    if (g->actT > 0) g->tsTarget = 1;
    float rate = g->tsTarget > g->ts ? 10.0f : 6.0f;
    g->ts += (g->tsTarget - g->ts) * clampf(dt * rate, 0, 1);
    audio_set_time(g->ts);
    float gdt = dt * g->ts;
    if (g->noAmmoT > 0) g->noAmmoT -= dt;
    g->gtime += gdt;
    audio_loop(LOOP_DRONE, 0.35f * (1 - g->ts) + 0.08f, 0);
    audio_loop(LOOP_RUSH, 0.4f * g->ts, 0);
    audio_loop(LOOP_HUM, 0, 0);
    if (g->msgT > 0 && g->msgT < 90) g->msgT -= dt;
    if (g->flashT > 0) g->flashT -= dt;
    update_enemies(g, gdt);
    if (g->mode != MODE_PLAY) return;
    update_bullets(g, gdt);
    if (g->mode != MODE_PLAY) return;
    update_pickups(g, gdt);
    update_shards(g, gdt);
    update_casings(g, gdt);
    if (levels[g->level].tutorial) tutorial(g, gdt);
    /* cleared? */
    int done = enemies_left(g) == 0 && (!levels[g->level].tutorial || g->tutStage >= 3);
    if (done) {
        g->mode = MODE_WIN;
        g->modeT = 0;
        g->flashCount = -1;
        if (g->replaying) return;
        g->pendingChat = (g->completed >> g->level) & 1 ? -1 : chat_after(g->level);
        g->completed |= 1 << g->level;
        if (g->best[g->level] <= 0 || g->levelT < g->best[g->level]) g->best[g->level] = g->levelT;
        g->saveDirty = 1;
    }
}
