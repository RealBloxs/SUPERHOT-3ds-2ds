/* FIX IT SHOP - small 3D engine shared by the game and both renderers.
 * Geometry is lit per vertex on the CPU, then either sent to the 3DS GPU (citro3d)
 * or drawn by the software rasterizer (backup). */
#ifndef ENGINE_H
#define ENGINE_H

#include "assets.h"

#define RW 200 /* software renderer resolution (scaled 2x to the 400x240 top screen) */
#define RH 120
#define HW 400 /* full-resolution text/UI layer on the top screen */
#define HH 240
#define BW 320 /* bottom screen */
#define BH 240

typedef struct { float x, y, z; } V3;
static inline V3 v3(float x, float y, float z) { V3 r = {x, y, z}; return r; }
static inline V3 vadd(V3 a, V3 b) { return v3(a.x + b.x, a.y + b.y, a.z + b.z); }
static inline V3 vsub(V3 a, V3 b) { return v3(a.x - b.x, a.y - b.y, a.z - b.z); }
static inline V3 vmul(V3 a, float s) { return v3(a.x * s, a.y * s, a.z * s); }
static inline float vdot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline V3 vcross(V3 a, V3 b) { return v3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
float vlen(V3 a);
V3 vnorm(V3 a);
V3 vlerp(V3 a, V3 b, float t);

/* a rigid transform: p' = R*(s*p) + t (R rows) */
typedef struct { float m[9]; V3 t; float s; } Xf;
void xf_ident(Xf *x);
void xf_rot(Xf *x, V3 axis, float ang);           /* rotation only, about the origin */
void xf_ypr(Xf *x, float yaw, float pitch, float roll); /* yaw about y, then pitch about x, roll about z */
void xf_mul(Xf *out, const Xf *parent, const Xf *child); /* out = parent * child */
V3 xf_point(const Xf *x, V3 p);
V3 xf_dir(const Xf *x, V3 d);
Xf xf_at(V3 pos, float yaw, float scale);          /* common case: placed, turned about y */

/* camera: forward f, right r, up u; yaw 0 looks along +x, pitch + looks down */
typedef struct { V3 eye, r, u, f; float focal; } Cam;
void cam_look(Cam *c, V3 eye, float yaw, float pitch);
void cam_look_at(Cam *c, V3 eye, V3 target);

/* lighting environment (filled by the game each frame) */
#define MAX_LIGHTS 6
typedef struct {
    V3 sunDir;              /* direction the light travels (normalized) */
    float sun[3], sky[3], ground[3];
    int n;
    V3 lp[MAX_LIGHTS];
    float lc[MAX_LIGHTS][3];
    float lr[MAX_LIGHTS];   /* radius */
    float fog[3];
    float fogNear, fogFar;
} Lights;
extern Lights LT;
void light_vertex(V3 p, V3 n, const float alb[3], float out[3]);

/* emission */
typedef struct { V3 p; float s, t; float r, g, b, a; } EV;
enum { E_TRANS = 1, E_EMIT = 2, E_NOCULL = 4, E_UNLIT = 8 };
void eng_begin(const Cam *c, int gpu);           /* start a 3D frame (sw: clears the 200x120 buffer) */
void eng_tri(const EV *a, const EV *b, const EV *c, int tex, int flags);
extern int engTris;

/* drawing helpers */
/* a lit, textured quad a-b-c-d (counter-clockwise seen from the front) */
void draw_quad(V3 a, V3 b, V3 c, V3 d, int tex, float u0, float v0, float u1, float v1, const float col[3], int flags);
/* textured box: floor/walls; uv repeat per metre */
void draw_box_tex(V3 lo, V3 hi, int tex, float rep, const float col[3], int faces);
enum { BX_PX = 1, BX_NX = 2, BX_PY = 4, BX_NY = 8, BX_PZ = 16, BX_NZ = 32, BX_ALL = 63 };
void draw_billboard(V3 p, float w, float h, const float col[3], float alpha, int flags); /* camera-facing quad (soft disc if alpha < 1) */
void draw_flame(V3 p, float w, float h, float phase, float alpha);
void draw_blob(V3 p, float rx, float rz, float alpha);
void draw_blob_col(V3 p, float rx, float rz, float alpha, const float col[3]);
int eng_visible(V3 centre, float radius);
V3 cam_eye(void);                               /* where the current frame is seen from */

/* software path output */
extern unsigned short swTop[RW * RH];
/* GPU path: the engine hands triangles to this sink */
typedef struct { float x, y, z, s, t, r, g, b, a; } GVert;
typedef void (*GpuSink)(const GVert *v3, int tex, int trans);
void eng_set_gpu_sink(GpuSink s);

/* 2D drawing on RGB565 (bottom screen) and RGBA4444 (top text layer) buffers */
typedef struct { unsigned short *px; int w, h, fmt; } Canvas; /* fmt 0 = RGB565, 1 = RGBA4444 */
unsigned short col565(int r, int g, int b);
unsigned short col4444(int r, int g, int b, int a);
void cv_fill(Canvas *c, int x, int y, int w, int h, int r, int g, int b, int a);
void cv_round(Canvas *c, int x, int y, int w, int h, int rad, int r, int g, int b, int a);
void cv_frame(Canvas *c, int x, int y, int w, int h, int r, int g, int b, int a);
void cv_line(Canvas *c, int x0, int y0, int x1, int y1, int r, int g, int b, int a);
void cv_circle(Canvas *c, int cx, int cy, int rad, int r, int g, int b, int a);
int text_width(const char *s, int big);
void cv_text(Canvas *c, int x, int y, const char *s, int big, int r, int g, int b, int a);
void cv_text_c(Canvas *c, int cx, int y, const char *s, int big, int r, int g, int b, int a); /* centred */
void cv_text_sh(Canvas *c, int x, int y, const char *s, int big, int r, int g, int b); /* with shadow */
int cv_wrap(Canvas *c, int x, int y, int w, const char *s, int big, int r, int g, int b, int a); /* returns lines */
void cv_icon(Canvas *c, int x, int y, int size, int icon, int r, int g, int b, int a);
enum { IC_SUCTION, IC_PRY, IC_SCREW, IC_TWEEZ, IC_TESTER, IC_PART, IC_CLOSE, IC_EXIT, IC_COIN, IC_STAR, IC_PHONE, IC_FIRE, IC_BOX, IC_CLOCK, IC_GUN, IC_P_SCREEN, IC_P_BATT, IC_P_PORT, IC_P_CAM, IC_P_SPK, IC_BAG, IC_COUNT };

#endif
