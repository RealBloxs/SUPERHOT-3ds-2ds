"""cia/banner.wav: a deep hit and breaking glass, for the HOME menu banner."""
import os, wave
import numpy as np
R = 22050
rng = np.random.RandomState(3)
t = np.arange(int(R * 2.2)) / R
x = np.sin(2 * np.pi * (70 - 25 * t) * t) * np.exp(-t * 5) * 0.8
x += rng.randn(len(t)) * np.exp(-t * 35) * 0.5
for _ in range(60):
    t0 = rng.rand() ** 2 * 1.4
    f = 2500 + rng.rand() * 6000
    m = t >= t0
    tt = t[m] - t0
    x[m] += np.sin(2 * np.pi * f * tt) * np.exp(-tt * (25 + rng.rand() * 40)) * (0.1 + rng.rand() * 0.25) * np.exp(-t0)
x /= np.abs(x).max() * 1.1
pcm = (x * 32000).astype('<i2')
with wave.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'cia', 'banner.wav'), 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(R); w.writeframes(pcm.tobytes())
print('banner.wav written')
