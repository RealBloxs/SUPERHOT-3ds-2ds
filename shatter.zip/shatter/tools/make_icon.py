"""Makes cia/icon.png (48x48) and cia/banner.png (256x128) from a host render: a red and a black
glass crystal bursting in a white room (original art, no characters).
Run: gcc ... host_test.c ... -o /tmp/sht && /tmp/sht thumb && python3 make_icon.py"""
import os
from PIL import Image, ImageDraw, ImageFont, ImageFilter
HERE = os.path.dirname(os.path.abspath(__file__))
CIA = os.path.join(HERE, '..', 'cia')
src = Image.open('/tmp/sh_thumb.ppm').crop((0, 0, 400, 240)).convert('RGB')
font = lambda s: ImageFont.truetype(os.path.join(HERE, 'Anton.ttf'), s)

# icon: the breaking man, close up
ic = src.crop((150, 30, 330, 210)).resize((48, 48), Image.LANCZOS)
d = ImageDraw.Draw(ic)
d.rectangle((0, 0, 47, 47), outline=(20, 20, 24))
ic.save(os.path.join(CIA, 'icon.png'))

# banner: the scene with the title across the bottom
bn = src.crop((40, 10, 400, 190)).resize((256, 128), Image.LANCZOS)
over = Image.new('RGBA', bn.size, (0, 0, 0, 0))
od = ImageDraw.Draw(over)
od.rectangle((0, 86, 256, 128), fill=(10, 10, 12, 215))
f = font(30)
t = 'Superhot'
w = od.textlength(t, font=f)
od.text(((256 - w) / 2, 87), t, font=f, fill=(255, 255, 255, 255))
bn = Image.alpha_composite(bn.convert('RGBA'), over).convert('RGB')
bn.save(os.path.join(CIA, 'banner.png'))
print('icon and banner written')
