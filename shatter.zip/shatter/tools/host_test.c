/* Host harness: runs SUPERHOT on a PC, renders what the 3DS GPU would draw plus both
 * UI layers, writes PPM previews and runs scripted scenarios as tests.
 * build: gcc -O2 -I../source host_test.c ../source/{engine,levels,world,ui,audio,assets,models}.c -lm */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/stat.h>
#include "../source/game.c"
#include "../source/assets.h"

/* the scene is rasterized at 2x each way and averaged down, like the GPU's anti-aliasing */
#define SS 2
#define W (400 * SS)
#define H (240 * SS)
#define OW 400
#define OH 240
static float cr[W * H], cg[W * H], cb[W * H], zb[W * H];
static float orr[OW * OH], og[OW * OH], ob[OW * OH];
static Cam CAM;
static float FOC;
static unsigned short hud[HW * HH], bot[BW * BH];
static int fails;

typedef struct { float x, y, z, s, t, r, g, b, a; } CV; /* clip: x,y screen; z = 1/w */
static GVert *opq, *trn;
static int nopq, ntrn;
static int *opqTex, *trnTex;

static void sink_fn(const GVert *v, int tex, int trans) {
    if (trans) { if (ntrn >= 16000) return; memcpy(&trn[ntrn * 3], v, sizeof(GVert) * 3); trnTex[ntrn++] = tex; }
    else { if (nopq >= 30000) return; memcpy(&opq[nopq * 3], v, sizeof(GVert) * 3); opqTex[nopq++] = tex; }
}

static void sample(int tex, float s, float t, float out[3]) {
    if (tex < 0 || tex >= TEX_COUNT) { out[0] = out[1] = out[2] = 1; return; }
    float x = s * TEX - 0.5f, y = (1 - t) * TEX - 0.5f; /* GPU: t = 1 is the first (top) row */
    int x0 = (int)floorf(x), y0 = (int)floorf(y);
    float fx = x - x0, fy = y - y0;
    float acc[3] = {0, 0, 0};
    for (int k = 0; k < 4; k++) {
        int xx = (x0 + (k & 1)) & (TEX - 1), yy = (y0 + (k >> 1)) & (TEX - 1);
        float w = ((k & 1) ? fx : 1 - fx) * ((k >> 1) ? fy : 1 - fy);
        unsigned short p = tex565[tex * TEX * TEX + yy * TEX + xx];
        acc[0] += w * ((p >> 11) & 31) / 31.0f;
        acc[1] += w * ((p >> 5) & 63) / 63.0f;
        acc[2] += w * (p & 31) / 31.0f;
    }
    memcpy(out, acc, sizeof(acc));
}

static void clip_raster(const GVert *v, int tex, int trans);

static void raster(CV *p, int tex, int trans) {
    float minx = fminf(p[0].x, fminf(p[1].x, p[2].x)), maxx = fmaxf(p[0].x, fmaxf(p[1].x, p[2].x));
    float miny = fminf(p[0].y, fminf(p[1].y, p[2].y)), maxy = fmaxf(p[0].y, fmaxf(p[1].y, p[2].y));
    int x0 = (int)fmaxf(0, floorf(minx)), x1 = (int)fminf(W - 1, ceilf(maxx));
    int y0 = (int)fmaxf(0, floorf(miny)), y1 = (int)fminf(H - 1, ceilf(maxy));
    float area = (p[1].x - p[0].x) * (p[2].y - p[0].y) - (p[2].x - p[0].x) * (p[1].y - p[0].y);
    if (fabsf(area) < 1e-6f) return;
    for (int y = y0; y <= y1; y++)
        for (int x = x0; x <= x1; x++) {
            float px = x + 0.5f, py = y + 0.5f;
            float w0 = ((p[1].x - px) * (p[2].y - py) - (p[2].x - px) * (p[1].y - py)) / area;
            float w1 = ((p[2].x - px) * (p[0].y - py) - (p[0].x - px) * (p[2].y - py)) / area;
            float w2 = 1 - w0 - w1;
            if (w0 < 0 || w1 < 0 || w2 < 0) continue;
            float iz = w0 * p[0].z + w1 * p[1].z + w2 * p[2].z;
            int i = y * W + x;
            if (iz <= zb[i]) continue;
            float q0 = w0 * p[0].z / iz, q1 = w1 * p[1].z / iz, q2 = w2 * p[2].z / iz;
            float s = q0 * p[0].s + q1 * p[1].s + q2 * p[2].s, t = q0 * p[0].t + q1 * p[1].t + q2 * p[2].t;
            float tc[3];
            sample(tex, s, t, tc);
            float r = (q0 * p[0].r + q1 * p[1].r + q2 * p[2].r) * tc[0];
            float g = (q0 * p[0].g + q1 * p[1].g + q2 * p[2].g) * tc[1];
            float b = (q0 * p[0].b + q1 * p[1].b + q2 * p[2].b) * tc[2];
            if (trans) {
                float a = q0 * p[0].a + q1 * p[1].a + q2 * p[2].a;
                cr[i] += (r - cr[i]) * a; cg[i] += (g - cg[i]) * a; cb[i] += (b - cb[i]) * a;
            } else {
                cr[i] = r; cg[i] = g; cb[i] = b; zb[i] = iz;
            }
        }
}

static void clip_raster(const GVert *v, int tex, int trans) {
    /* camera space */
    float cx[3], cy[3], cz[3];
    for (int i = 0; i < 3; i++) {
        V3 d = v3(v[i].x - CAM.eye.x, v[i].y - CAM.eye.y, v[i].z - CAM.eye.z);
        cx[i] = vdot(d, CAM.r); cy[i] = vdot(d, CAM.u); cz[i] = vdot(d, CAM.f);
    }
    /* clip against near plane */
    const float N = 0.04f;
    float poly[4][9];
    int n = 0;
    for (int i = 0; i < 3; i++) {
        int j = (i + 1) % 3;
        int ii = cz[i] >= N, jj = cz[j] >= N;
        if (ii) { float *o = poly[n++]; o[0] = cx[i]; o[1] = cy[i]; o[2] = cz[i]; o[3] = v[i].s; o[4] = v[i].t; o[5] = v[i].r; o[6] = v[i].g; o[7] = v[i].b; o[8] = v[i].a; }
        if (ii != jj) {
            float k = (N - cz[i]) / (cz[j] - cz[i]);
            float *o = poly[n++];
            o[0] = cx[i] + (cx[j] - cx[i]) * k; o[1] = cy[i] + (cy[j] - cy[i]) * k; o[2] = N;
            o[3] = v[i].s + (v[j].s - v[i].s) * k; o[4] = v[i].t + (v[j].t - v[i].t) * k;
            o[5] = v[i].r + (v[j].r - v[i].r) * k; o[6] = v[i].g + (v[j].g - v[i].g) * k; o[7] = v[i].b + (v[j].b - v[i].b) * k;
            o[8] = v[i].a + (v[j].a - v[i].a) * k;
        }
    }
    if (n < 3) return;
    CV p[4];
    for (int i = 0; i < n; i++) {
        float iz = 1.0f / poly[i][2];
        p[i].x = W / 2 + poly[i][0] * FOC * iz;
        p[i].y = H / 2 - poly[i][1] * FOC * iz;
        p[i].z = iz;
        p[i].s = poly[i][3]; p[i].t = poly[i][4];
        p[i].r = poly[i][5]; p[i].g = poly[i][6]; p[i].b = poly[i][7]; p[i].a = poly[i][8];
    }
    CV t1[3] = {p[0], p[1], p[2]};
    raster(t1, tex, trans);
    if (n == 4) { CV t2[3] = {p[0], p[2], p[3]}; raster(t2, tex, trans); }
}

static void render_top(const Game *g) {
    world_lights(g);
    world_camera(g, &CAM);
    FOC = (H / 2.0f) / tanf(0.7428f / 2);
    unsigned cl = world_clear(g);
    for (int i = 0; i < W * H; i++) { cr[i] = ((cl >> 16) & 255) / 255.0f; cg[i] = ((cl >> 8) & 255) / 255.0f; cb[i] = (cl & 255) / 255.0f; zb[i] = 0; }
    nopq = ntrn = 0;
    eng_set_gpu_sink(sink_fn);
    eng_begin(&CAM, 1);
    world_build((void *)g);
    for (int i = 0; i < nopq; i++) clip_raster(&opq[i * 3], opqTex[i], 0);
    for (int i = 0; i < ntrn; i++) clip_raster(&trn[i * 3], trnTex[i], 1);
    for (int y = 0; y < OH; y++)
        for (int x = 0; x < OW; x++) {
            float r = 0, gg = 0, bb = 0;
            for (int dy = 0; dy < SS; dy++)
                for (int dx = 0; dx < SS; dx++) { int i = (y * SS + dy) * W + x * SS + dx; r += cr[i]; gg += cg[i]; bb += cb[i]; }
            int o = y * OW + x;
            orr[o] = r / (SS * SS); og[o] = gg / (SS * SS); ob[o] = bb / (SS * SS);
        }
    if (render_hud(g, hud) && !getenv("NOHUD"))
        for (int i = 0; i < OW * OH; i++) {
            unsigned short h = hud[i];
            float a = (h & 15) / 15.0f;
            orr[i] += (((h >> 12) & 15) / 15.0f - orr[i]) * a;
            og[i] += (((h >> 8) & 15) / 15.0f - og[i]) * a;
            ob[i] += (((h >> 4) & 15) / 15.0f - ob[i]) * a;
        }
    render_bottom(g, bot);
}

static void save_ppm(const char *name) {
    char path[256];
    snprintf(path, sizeof path, "/tmp/sh_%s.ppm", name);
    FILE *f = fopen(path, "wb");
    fprintf(f, "P6 %d %d 255\n", OW, OH + BH);
    for (int y = 0; y < OH + BH; y++)
        for (int x = 0; x < OW; x++) {
            unsigned char px[3] = {0, 0, 0};
            if (y < OH) {
                int i = y * OW + x;
                px[0] = (unsigned char)(fminf(1, fmaxf(0, orr[i])) * 255);
                px[1] = (unsigned char)(fminf(1, fmaxf(0, og[i])) * 255);
                px[2] = (unsigned char)(fminf(1, fmaxf(0, ob[i])) * 255);
            } else if (x >= 40 && x < 360) {
                unsigned short p = bot[(y - OH) * BW + x - 40];
                px[0] = ((p >> 11) & 31) * 255 / 31; px[1] = ((p >> 5) & 63) * 255 / 63; px[2] = (p & 31) * 255 / 31;
            } else px[0] = px[1] = px[2] = 20;
            fwrite(px, 1, 3, f);
        }
    fclose(f);
    printf("  wrote %s  (%d opaque, %d transparent tris)\n", path, nopq, ntrn);
}

/* ------------- scripting ------------- */
static Game G;
static Input IN;
static unsigned prevHeld;
static void step(Game *g, unsigned held, float sx, float sy, int tx, int ty, float secs) {
    int n = (int)(secs * 60 + 0.5f);
    if (n < 1) n = 1;
    for (int i = 0; i < n; i++) {
        IN.held = held;
        IN.pressed = held & ~prevHeld;
        IN.released = prevHeld & ~held;
        prevHeld = held;
        IN.sx = sx; IN.sy = sy; IN.tx = tx; IN.ty = ty;
        game_update(g, &IN, 1.0f / 60);
        g->saveDirty = 0;
    }
}
static void tap(Game *g, unsigned btn) { step(g, 0, 0, 0, 0, 0, 1.0f / 60); step(g, btn, 0, 0, 0, 0, 1.0f / 60); step(g, 0, 0, 0, 0, 0, 0.05f); }
#define CHECK(c, msg) do { if (!(c)) { printf("  FAIL: %s\n", msg); fails++; } else printf("  ok: %s\n", msg); } while (0)

static void shot(Game *g, const char *name) { render_top(g); save_ppm(name); }

/* turn to look at a point */
static void face(Game *g, V3 p) {
    V3 e = v3(g->pl.pos.x, 1.6f, g->pl.pos.z);
    V3 d = vsub(p, e);
    g->pl.yaw = atan2f(d.z, d.x);
    g->pl.pitch = -atan2f(d.y, sqrtf(d.x * d.x + d.z * d.z));
}
static void walk_to(Game *g, float x, float z, float maxSecs) {
    for (int i = 0; i < maxSecs * 60 && g->mode == MODE_PLAY; i++) {
        float dx = x - g->pl.pos.x, dz = z - g->pl.pos.z, d = sqrtf(dx * dx + dz * dz);
        if (d < 0.1f) break;
        float fx = cosf(g->pl.yaw), fz = sinf(g->pl.yaw);
        float fwd = (dx * fx + dz * fz) / d, side = (dx * -fz + dz * fx) / d;
        step(g, 0, side, fwd, 0, 0, 1.0f / 60);
    }
}
static int alive(const Game *g) { int n = 0; for (int i = 0; i < g->nen; i++) n += g->en[i].alive; return n; }
static int nearest(const Game *g) {
    int b = -1; float bd = 1e9f;
    for (int i = 0; i < g->nen; i++) {
        const Enemy *e = &g->en[i];
        if (!e->alive || e->delay > 0) continue;
        float d = vlen(vsub(e->pos, g->pl.pos));
        if (d < bd) { bd = d; b = i; }
    }
    return b;
}
static int finite_state(const Game *g) {
    if (!isfinite(g->pl.pos.x) || !isfinite(g->pl.pos.z) || !isfinite(g->ts)) return 0;
    for (int i = 0; i < g->nen; i++) if (!isfinite(g->en[i].pos.x) || !isfinite(g->en[i].pos.z)) return 0;
    for (int i = 0; i < MAX_BULLETS; i++) if (g->bul[i].active && !isfinite(g->bul[i].pos.x)) return 0;
    return 1;
}

int main(int argc, char **argv) {
    (void)argc; (void)argv;
    opq = malloc(sizeof(GVert) * 3 * 30000); trn = malloc(sizeof(GVert) * 3 * 16000);
    opqTex = malloc(sizeof(int) * 30000); trnTex = malloc(sizeof(int) * 16000);
    audio_init();
    Game *g = &G;
    mkdir("/tmp/shrep", 0777);
    system("rm -f /tmp/shrep/*.rpl");
    strcpy(g->replayDir, "/tmp/shrep/");
    game_boot(g, 12345);
    if (argc > 1 && !strcmp(argv[1], "shadow")) {
        setenv("NOHUD", "1", 1);
        start_level(g, 6);
        g->msgT = 0;
        render_top(g);
        printf("opaque %d\n", nopq);
        g->setQuality = 0; render_top(g); printf("low %d\n", nopq);
        g->setQuality = 1;
        g->pl.pos = v3(0, 0, 1.2f); g->pl.pitch = 0.35f;
        shot(g, "shadow");
        g->pl.pos = v3(0.3f, 0, 4.7f); g->pl.pitch = 0.05f; g->pl.yaw = PI / 2;
        g->en[1].pos = v3(0, 0, 6.4f); g->en[1].walk = 1.2f; g->en[1].walkAmt = 1;
        shot(g, "closeup");
        /* glass close up: the table with bottles and the gun, and a man at arm's length */
        g->pl.punchT = 0;
        g->pl.pos = v3(0, 0, 2.3f); g->pl.yaw = PI / 2; g->pl.pitch = 0.75f;
        shot(g, "glass_table");
        g->pl.pos = v3(0, 0, 5.4f); g->pl.pitch = 0.0f; g->pl.hasGun = 1; g->pl.ammo = 3; g->pl.weapon = WP_PISTOL;
        shot(g, "glass_man");
        g->pl.hasGun = 0;
        g->pl.pos = v3(0.3f, 0, 4.7f); g->pl.pitch = 0.05f;
        g->pl.punchT = 0.2f; g->pl.punchSide = 0;
        shot(g, "punch_mid");
        g->pl.punchT = 0.2f; g->pl.punchSide = 1;
        shot(g, "punch_mid2");
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "maps")) {
        /* every level from where you start, and from inside it looking across */
        setenv("NOHUD", "1", 1);
        int only = argc > 2 ? atoi(argv[2]) : -1;
        if (argc > 3) g->setQuality = atoi(argv[3]);
        for (int lv = 0; lv < levelCount; lv++) {
            if (only >= 0 && lv != only) continue;
            start_level(g, lv);
            g->msgT = 0;
            for (int i = 0; i < g->nen; i++) if (g->en[i].delay > 0) { g->en[i].delay = 0; g->en[i].appear = 1; }
            step(g, 0, 0, 0, 0, 0, 0.05f);
            g->mode = MODE_PLAY;
            const Level *L = &levels[lv];
            char nm[40];
            g->pl.pitch = 0.0f;
            snprintf(nm, sizeof nm, "map%02d_a", lv); shot(g, nm);
            /* from a front corner looking diagonally across */
            float cx = L->x0 + (L->x1 - L->x0) * 0.82f, cz = L->z0 + (L->z1 - L->z0) * 0.35f;
            for (int k = 0; k < 40 && blocked(g, cx, cz, 0.3f); k++) { cx -= 0.25f; cz += 0.1f; }
            g->pl.pos = v3(cx, 0, cz);
            g->pl.yaw = atan2f(L->z1 - cz, (L->x0 + L->x1) * 0.5f - cx - (L->x1 - L->x0) * 0.2f);
            g->pl.pitch = 0.05f;
            snprintf(nm, sizeof nm, "map%02d_b", lv); shot(g, nm);
            /* from the far end looking back */
            cx = L->x0 + (L->x1 - L->x0) * 0.3f; cz = L->z1 - 1.2f;
            for (int k = 0; k < 40 && blocked(g, cx, cz, 0.3f); k++) { cx += 0.25f; cz -= 0.15f; }
            g->pl.pos = v3(cx, 0, cz);
            g->pl.yaw = -PI / 2 + 0.25f;
            g->pl.pitch = 0.08f;
            snprintf(nm, sizeof nm, "map%02d_c", lv); shot(g, nm);
        }
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "near")) {
        /* furniture close up */
        setenv("NOHUD", "1", 1);
        struct { int lv; float x, z, yaw, pitch; const char *nm; } V[] = {
            {7, -1.6f, 3.2f, PI * 0.85f, 0.25f, "near_car"}, {1, -2.0f, -0.6f, PI * 0.75f, 0.35f, "near_sofa"},
            {8, -6.0f, 9.0f, 2.3f, 0.25f, "near_tree"}, {6, -2.0f, 1.8f, PI * 0.4f, 0.4f, "near_desk"},
            {4, 0.0f, 6.6f, PI * 0.5f, 0.1f, "near_bar"}, {9, -1.2f, 12.6f, -PI * 0.5f - 0.45f, 0.1f, "near_stairs"},
            {3, 0.0f, 9.0f, PI * 0.5f, 0.0f, "near_train"}, {5, 0.0f, -1.2f, PI * 0.5f, 0.0f, "near_lift"},
            {12, 2.5f, 4.8f, PI * 0.15f, 0.1f, "near_art"}, {10, -3.0f, 2.0f, PI * 0.5f, 0.1f, "near_rack"},
            {11, 0.0f, 3.5f, PI * 0.5f, 0.15f, "near_cross"}, {15, 0, 1, PI * 0.5f, 0.05f, "near_end"},
            {4, -2.2f, 7.35f, PI * 0.5f, 0.5f, "near_drinks"}, {1, -3.15f, 0.2f, PI * 0.5f, 0.75f, "near_coffee"}};
        for (unsigned i = 0; i < sizeof V / sizeof V[0]; i++) {
            start_level(g, V[i].lv);
            g->msgT = 0;
            g->pl.pos = v3(V[i].x, 0, V[i].z); g->pl.yaw = V[i].yaw; g->pl.pitch = V[i].pitch;
            shot(g, V[i].nm);
        }
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "ikdbg")) {
        start_level(g, 1);
        g->pl.pos = v3(0, 0, 1.0f); g->pl.yaw = PI / 2; g->pl.pitch = 0.05f;
        g->pl.hasGun = 1; g->pl.weapon = WP_PISTOL;
        Xf parts[BODY_PARTS];
        player_fp_parts(g, parts);
        Xf GW = player_gun_xf(g);
        printf("gun at %.3f %.3f %.3f\n", GW.t.x, GW.t.y, GW.t.z);
        for (int k = M_UARM_L; k <= M_FARM_R; k++) {
            V3 h = xf_point(&parts[k], grip_of(k));
            printf("part %d joint %.3f %.3f %.3f  tip %.3f %.3f %.3f\n", k, parts[k].t.x, parts[k].t.y, parts[k].t.z, h.x, h.y, h.z);
        }
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "lineup")) {
        /* every weapon lying side by side on a table, close up */
        setenv("NOHUD", "1", 1);
        start_level(g, 2);
        g->msgT = 0;
        for (int i = 0; i < g->nen; i++) g->en[i].alive = 0;
        g->en[0].alive = 1; g->en[0].delay = 999;
        memset(g->pk, 0, sizeof g->pk);
        for (int i = 0; i < g->nprop; i++) g->prop[i].active = 0;
        int ks[5] = {WP_PISTOL, WP_SHOTGUN, WP_SMG, WP_KATANA, WP_BAT};
        for (int i = 0; i < 5; i++) {
            Pickup *k = &g->pk[i];
            k->active = 1; k->kind = ks[i]; k->yaw = -0.15f;
            k->pos = v3(-0.55f + 0.0f, 0.75f + 0.03f, 9.55f + i * 0.5f);
            k->rest = 0.78f;
        }
        g->pl.pos = v3(1.3f, 0, 10.3f); g->pl.yaw = PI; g->pl.pitch = 0.62f;
        shot(g, "lineup");
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "orient")) {
        /* is every weapon pointing the way its holder faces, and are the hands on the right ends? */
        start_level(g, 13);
        for (int k = WP_PISTOL; k <= WP_BAT; k++)
            for (int a = 0; a < 2; a++) {
                Enemy E; memset(&E, 0, sizeof E);
                E.alive = 1; E.armed = k; E.yaw = 0.7f; E.aim = a; E.pos = v3(0, 0, 0);
                Pose p; pose_of_enemy(&E, &p);
                Xf parts[BODY_PARTS]; pose_parts(&p, parts);
                Xf Wx = pose_weapon(&p, parts);
                V3 f = v3(cosf(E.yaw), 0, sinf(E.yaw));
                V3 tip = xf_point(&Wx, v3(0, 0, 0.5f)), grip = Wx.t;
                V3 hm = xf_point(&parts[M_FARM_L], grip_of(M_FARM_L)), ho = xf_point(&parts[M_FARM_R], grip_of(M_FARM_R));
                V3 up = xf_dir(&Wx, v3(0, 1, 0));
                printf("%-8s aim %d: forward %.2f  up %.2f  tip y %.2f  main hand off %.3f  other hand off %.3f\n", weapon_name(k), a,
                       vdot(vnorm(vsub(tip, grip)), f), up.y, tip.y,
                       vlen(vsub(hm, xf_point(&Wx, grip_main(k)))), vlen(vsub(ho, xf_point(&Wx, grip_off(k)))));
            }
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "pose")) {
        /* the five weapons held by red men: from the side and from the front, aiming and lowered, mid swing */
        setenv("NOHUD", "1", 1);
        float aimv = argc > 2 ? atof(argv[2]) : 1;
        float swing = argc > 3 ? atof(argv[3]) : 0;
        for (int view = 0; view < 2; view++) {
            start_level(g, 13);
            g->msgT = 0;
            for (int i = 0; i < g->nen; i++) g->en[i].alive = 0;
            g->nbox = 4;
            int ks[5] = {WP_PISTOL, WP_SHOTGUN, WP_SMG, WP_KATANA, WP_BAT};
            for (int i = 0; i < 5; i++) {
                Enemy *e = &g->en[i];
                e->alive = 1; e->delay = 0; e->appear = 1; e->armed = argc > 4 ? 0 : ks[i];
                if (argc > 4) { e->walk = i * 1.3f; e->walkAmt = i < 3 ? 1 : 0; }
                e->pos = v3(-3.2f + i * 1.6f, 0, 2.5f);
                e->yaw = view ? -PI / 2 : PI;
                e->aim = WP_IS_GUN(ks[i]) ? aimv : 0;
                if (swing > 0) { e->state = EN_PUNCH; e->punchT = swing; }
            }
            g->pl.pos = v3(0, 0, -3.2f); g->pl.yaw = PI / 2; g->pl.pitch = 0.08f;
            shot(g, view ? "pose_front" : "pose_side");
        }
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "held")) {
        /* each weapon in your hand, and a swing / shot frame */
        setenv("NOHUD", "1", 1);
        for (int k = WP_PISTOL; k <= WP_PROP; k++) {
            start_level(g, 1);
            g->msgT = 0;
            g->pl.pos = v3(0, 0, 1.0f); g->pl.yaw = PI / 2; g->pl.pitch = 0.05f;
            g->pl.hasGun = 1; g->pl.weapon = k; g->pl.ammo = weapon_ammo(k); g->pl.sub = PR_BOTTLE; g->pl.heldR = 0.045f; g->pl.heldH = 0.32f;
            char nm[32];
            snprintf(nm, sizeof nm, "held_%s", weapon_name(k)); shot(g, nm);
            if (WP_IS_MELEE(k)) { g->pl.punchT = 0.2f; snprintf(nm, sizeof nm, "held_%s_swing", weapon_name(k)); shot(g, nm); }
            else if (WP_IS_GUN(k)) {
                g->pl.kick = 1; g->flashT = 0.05f; snprintf(nm, sizeof nm, "held_%s_fire", weapon_name(k)); shot(g, nm);
                g->pl.kick = 0; g->flashT = 0; g->pl.punchT = 0.2f; snprintf(nm, sizeof nm, "held_%s_hit", weapon_name(k)); shot(g, nm); g->pl.punchT = 0;
            }
        }
        /* lying on the floor, and in enemy hands */
        start_level(g, 15);
        g->msgT = 0;
        for (int i = 0; i < g->nen; i++) g->en[i].alive = 0;
        int ks[5] = {WP_PISTOL, WP_SHOTGUN, WP_SMG, WP_KATANA, WP_BAT};
        for (int i = 0; i < 5; i++) {
            Enemy *e = &g->en[i];
            e->alive = 1; e->delay = 0; e->appear = 1; e->armed = ks[i]; e->pos = v3(-3.2f + i * 1.6f, 0, 6.0f); e->yaw = -PI / 2 + 0.5f;
            e->aim = WP_IS_GUN(ks[i]) ? 1 : 0;
        }
        g->pl.pos = v3(0, 0, 1.6f); g->pl.yaw = PI / 2; g->pl.pitch = 0.12f;
        shot(g, "held_enemies");
        g->pl.pitch = 0.75f; g->pl.pos = v3(0, 0, 0.2f);
        shot(g, "held_floor");
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "shatter")) {
        setenv("NOHUD", "1", 1);
        if (argc > 2) g->setShatter = atoi(argv[2]);
        start_level(g, 7);
        g->msgT = 0;
        Enemy *e = &g->en[2];
        e->pos = v3(0.0f, 0, 2.6f); e->yaw = -PI / 2; e->alive = 1; e->delay = 0; e->appear = 1; e->walkAmt = 0.6f; e->walk = 1;
        for (int i = 0; i < g->nen; i++) if (i != 2) g->en[i].alive = 0;
        g->pl.pos = v3(0.3f, 0, 0); g->pl.yaw = PI / 2; g->pl.pitch = 0.12f;
        shot(g, "shat0");
        kill_enemy(g, e, v3(0, 0, 1), v3(0.02f, 1.35f, 2.5f));
        float ts[4] = {0.04f, 0.18f, 0.6f, 3.0f};
        const char *nm[4] = {"shat1", "shat2", "shat3", "shat4"};
        float done = 0;
        for (int k = 0; k < 4; k++) {
            while (done < ts[k]) { update_shards(g, 0.01f); done += 0.01f; }
            shot(g, nm[k]);
        }
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "thumb")) {
        /* the game's icon and banner art: no characters, just two crystals bursting in a white room -
         * a red one and a black one - frozen the instant they break */
        setenv("NOHUD", "1", 1);
        start_level(g, 25);
        g->msgT = 0;
        for (int i = 0; i < g->nen; i++) g->en[i].alive = 0;
        g->en[0].alive = 1; g->en[0].delay = 999;
        memset(g->pk, 0, sizeof g->pk);
        float tshift = argc > 2 ? atof(argv[2]) : 0.09f;
        static V3 w[2000 * 3];
        static const float red[3] = {0.92f, 0.12f, 0.08f}, blk[3] = {0.08f, 0.08f, 0.09f};
        struct { V3 c; float r; const float *col; V3 hit; } C[2] = {
            {v3(-0.25f, 1.55f, 3.0f), 0.55f, red, v3(0.6f, 0.2f, -1)}, {v3(0.55f, 1.25f, 3.6f), 0.3f, blk, v3(-0.5f, 0.3f, -1)}};
        for (int k = 0; k < 2; k++) {
            /* a faceted crystal: a subdivided octahedron, pushed out to a lumpy sphere */
            int n = 0;
            V3 O[6] = {v3(1, 0, 0), v3(-1, 0, 0), v3(0, 1, 0), v3(0, -1, 0), v3(0, 0, 1), v3(0, 0, -1)};
            int F[8][3] = {{0, 2, 4}, {2, 1, 4}, {1, 3, 4}, {3, 0, 4}, {2, 0, 5}, {1, 2, 5}, {3, 1, 5}, {0, 3, 5}};
            for (int f = 0; f < 8; f++) {
                int S = 6;
                for (int i = 0; i < S; i++)
                    for (int j = 0; j < S - i; j++)
                        for (int up = 0; up < 2; up++) {
                            if (up && j == S - i - 1) continue;
                            float a[3][2] = {{(float)i, (float)j}, {(float)i + 1, (float)j}, {(float)i, (float)j + 1}};
                            if (up) { a[0][0] = i + 1; a[0][1] = j; a[1][0] = i + 1; a[1][1] = j + 1; a[2][0] = i; a[2][1] = j + 1; }
                            for (int c = 0; c < 3; c++) {
                                float u = a[c][0] / S, v = a[c][1] / S;
                                V3 p = vadd(vadd(vmul(O[F[f][0]], 1 - u - v), vmul(O[F[f][1]], u)), vmul(O[F[f][2]], v));
                                p = vnorm(p);
                                unsigned h = (unsigned)(p.x * 977 + p.y * 1931 + p.z * 3121 + 7) * 2654435761u;
                                float r = C[k].r * (0.88f + 0.24f * ((h >> 22) / 1023.0f));
                                w[n++] = vadd(C[k].c, vmul(p, r));
                            }
                        }
            }
            shatter_tris(g, w, n / 3, C[k].col, vnorm(C[k].hit), vadd(C[k].c, vmul(vnorm(C[k].hit), -C[k].r)), 1.4f);
        }
        float done = 0;
        while (done < tshift) { update_shards(g, 0.005f); done += 0.005f; }
        g->pl.pos = v3(0.15f, 0, 0.2f); g->pl.yaw = PI / 2; g->pl.pitch = -0.05f;
        g->mode = MODE_PLAY;
        shot(g, "thumb");
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "cover")) {
        /* cover art: a red man breaking apart, a black pistol, a red trail */
        setenv("NOHUD", "1", 1);
        start_level(g, 7);
        g->msgT = 0;
        g->nen = 2;
        g->en[0].pos = v3(0.15f, 0, 2.3f); g->en[0].yaw = -PI / 2; g->en[0].alive = 1; g->en[0].delay = 0; g->en[0].appear = 1; g->en[0].armed = 0;
        g->en[1].pos = v3(-1.3f, 0, 5.5f); g->en[1].yaw = -PI / 2 + 0.3f; g->en[1].alive = 1; g->en[1].delay = 0; g->en[1].appear = 1; g->en[1].armed = 1; g->en[1].aim = 1;
        Pose p; pose_of_enemy(&g->en[0], &p);
        static const float red[3] = {0.92f, 0.12f, 0.08f};
        shatter_body(g, &p, red, v3(0.3f, 0, 1), v3(0.05f, 1.25f, 2.2f));
        g->en[0].alive = 0;
        for (int i = 0; i < 6; i++) { update_shards(g, 0.012f); }
        Bullet *b = &g->bul[0];
        b->active = 1; b->start = v3(-1.1f, 1.45f, 5.1f); b->vel = v3(4.5f, -0.05f, -6.5f); b->pos = vadd(b->start, v3(1.6f, -0.01f, -2.3f)); b->life = 5;
        g->pl.hasGun = 1; g->pl.ammo = 3; g->pl.weapon = WP_PISTOL;
        g->pl.pos = v3(0, 0, 0); g->pl.yaw = PI / 2; g->pl.pitch = 0.06f;
        g->mode = MODE_PLAY;
        shot(g, "cover");
        return 0;
    }

    printf("boot and the intro chat\n");
    step(g, 0, 0, 0, 0, 0, 2.0f);
    shot(g, "01_boot");
    step(g, 0, 0, 0, 0, 0, 4.0f);
    CHECK(g->mode == MODE_CHAT && g->chatId == 0, "first boot opens the intro chat");
    for (int i = 0; i < 400 && !g->chatDone; i++) { tap(g, BTN_A); step(g, 0, 0, 0, 0, 0, 0.1f); if (i == 14) shot(g, "02_chat"); }
    CHECK(g->chatDone, "the intro chat can be typed through");
    tap(g, BTN_START);
    CHECK(g->mode == MODE_PLAY && g->level == 0 && g->story, "leaving the first chat starts the story with the tutorial");

    printf("tutorial\n");
    CHECK(!g->pl.hasGun, "you start without a gun");
    shot(g, "04_tutorial_start");
    float t0 = g->en[0].pos.z;
    step(g, 0, 0, 0, 0, 0, 2.0f);
    CHECK(fabsf(g->en[0].pos.z - t0) < 0.25f, "standing still, the enemy barely moves");
    for (int i = 0; i < 600 && g->tutStage < 1; i++) { face(g, v3(g->en[0].pos.x, 1.3f, g->en[0].pos.z)); step(g, 0, 0, 0.6f, 0, 0, 1.0f / 60); }
    CHECK(g->tutStage == 1, "the punch prompt shows when he gets close");
    shot(g, "05_punch_prompt");
    for (int i = 0; i < 300 && g->en[0].alive && g->mode == MODE_PLAY; i++) {
        face(g, v3(g->en[0].pos.x, 1.3f, g->en[0].pos.z));
        float d = vlen(vsub(g->en[0].pos, g->pl.pos));
        if (d < 1.2f) { tap(g, BTN_R); if (g->pl.punchT > 0.1f) shot(g, "05b_punching"); } else step(g, 0, 0, 0.7f, 0, 0, 1.0f / 60);
    }
    CHECK(!g->en[0].alive, "a punch shatters him");
    step(g, 0, 0, 0.3f, 0, 0, 0.25f);
    shot(g, "06_shatter");
    CHECK(g->tutStage == 2, "then a gun appears");
    int gi = -1;
    for (int i = 0; i < MAX_PICKUPS; i++) if (g->pk[i].active) gi = i;
    CHECK(gi >= 0, "the gun is on the floor");
    if (gi >= 0) {
        walk_to(g, g->pk[gi].pos.x, g->pk[gi].pos.z - 0.6f, 5);
        face(g, g->pk[gi].pos);
        shot(g, "07_gun_on_floor");
        tap(g, BTN_L);
    }
    CHECK(g->pl.hasGun && g->pl.ammo == GUN_AMMO, "L picks it up");
    step(g, 0, 0, 0, 0, 0, 0.4f);
    for (int i = 0; i < 2400 && g->mode == MODE_PLAY && (g->tutStage < 3 || alive(g)); i++) {
        int n = nearest(g);
        if (n >= 0) {
            face(g, v3(g->en[n].pos.x, 1.25f, g->en[n].pos.z));
            if (g->pl.shootT <= 0 && g->pl.ammo > 0) { tap(g, BTN_R); if (g->pl.ammo == 2) shot(g, "08_recoil"); }
            else if (g->pl.ammo == 0 && g->pl.hasGun) tap(g, BTN_L);
            else step(g, 0, 0.5f, 0, 0, 0, 1.0f / 60);
        } else step(g, 0, 0.4f, 0, 0, 0, 1.0f / 60);
        if (!g->pl.hasGun && n >= 0 && vlen(vsub(g->en[n].pos, g->pl.pos)) < 1.2f) tap(g, BTN_R);
        if (!g->pl.hasGun && n >= 0) step(g, 0, 0, 0.6f, 0, 0, 1.0f / 60);
    }
    printf("  tutorial ended in mode %d, alive %d\n", g->mode, alive(g));
    CHECK(g->mode == MODE_WIN, "clearing the tutorial wins");
    step(g, 0, 0, 0, 0, 0, 0.2f);
    shot(g, "09_flash_a");
    tap(g, BTN_X);
    CHECK(g->replaySaved && g->replays[0].exists, "X on the win screen saves a replay");
    step(g, 0, 0, 0, 0, 0, 0.42f);
    shot(g, "10_flash_b");
    step(g, 0, 0, 0, 0, 0, 2.0f);
    CHECK(g->mode == MODE_WIN, "the flash keeps going until A");
    tap(g, BTN_A);
    CHECK(g->mode == MODE_CHAT && g->chatId == 1, "then a story chat");
    tap(g, BTN_START);
    CHECK(g->mode == MODE_PLAY && g->level == 1 && g->story, "story mode goes straight on to level 1");

    printf("file commander\n");
    tap(g, BTN_START);
    g->pauseSel = 2; tap(g, BTN_A);
    CHECK(g->mode == MODE_MENU && g->menuDir == DIR_ROOT, "pause > file commander");
    CHECK(menu_rows(g) == 6, "root: /.., superhot.exe, levels.ult, replays, settings, chat.exe");
    shot(g, "03_menu");
    g->menuSel = 2; tap(g, BTN_A);
    CHECK(g->menuDir == DIR_LEVELS && menu_rows(g) == 2, "levels.ult lists the one beaten level");
    shot(g, "03b_levels");
    tap(g, BTN_B);
    g->menuSel = 3; tap(g, BTN_A);
    CHECK(g->menuDir == DIR_REPLAYS && menu_rows(g) == 2, "the replays folder holds the saved replay");
    shot(g, "03c_replays");
    g->menuSel = 1; tap(g, BTN_A);
    CHECK(g->mode == MODE_PLAY && g->replaying && g->level == 0, "opening it plays the replay");
    int guard = 0;
    while (g->mode == MODE_PLAY && guard++ < 60 * 300) { step(g, 0, 0, 0, 0, 0, 1.0f / 60); if (guard == 400) shot(g, "03d_replay_playing"); }
    printf("  replay ended in mode %d after %d frames\n", g->mode, guard);
    /* (the tutorial run above aimed by setting the view directly, so it can't repeat exactly;
     *  the exact-repeat test with real button presses is further down) */
    if (g->mode == MODE_WIN) tap(g, BTN_A);
    CHECK(g->mode == MODE_MENU && g->menuDir == DIR_REPLAYS, "when it ends you are back in the replays folder");
    tap(g, BTN_B);
    g->menuSel = 4; tap(g, BTN_A);
    CHECK(g->menuDir == DIR_SETTINGS && menu_rows(g) == 1 + SET_COUNT, "the settings folder");
    g->menuSel = 1;
    shot(g, "03e_settings");
    tap(g, BTN_A);
    CHECK(g->setQuality == 0, "A switches graphics to LOW");
    tap(g, BTN_DRIGHT);
    CHECK(g->setQuality == 1, "and right switches it back");
    tap(g, BTN_B);
    g->menuSel = 1; tap(g, BTN_A);
    CHECK(g->mode == MODE_PLAY && g->story && g->level == 1, "superhot.exe continues the story at level 1");

    printf("black glass breaks\n");
    start_level(g, 6);
    int pi = -1;
    float pd = 1e9f;
    for (int i = 0; i < g->nprop; i++) if (g->prop[i].active) { float d = vlen(vsub(g->prop[i].pos, g->pl.pos)); if (d < pd) { pd = d; pi = i; } }
    CHECK(pi >= 0, "there is black glass on the table");
    shot(g, "13_props");
    if (pi >= 0) {
        g->pl.hasGun = 1; g->pl.ammo = 3; g->pl.weapon = WP_PISTOL;
        face(g, vadd(g->prop[pi].pos, v3(0, g->prop[pi].h * 0.5f, 0)));
        tap(g, BTN_R);
        step(g, 0, 0, 0.2f, 0, 0, 0.5f);
        CHECK(!g->prop[pi].active, "a bullet shatters it");
        shot(g, "14_prop_shatter");
    }
    /* a gun on the floor, and one in the air: a bullet breaks both */
    start_level(g, 2);
    {
        int gk = -1;
        for (int i = 0; i < MAX_PICKUPS; i++) if (g->pk[i].active) gk = i;
        g->pl.hasGun = 1; g->pl.ammo = 3; g->pl.weapon = WP_PISTOL;
        if (gk >= 0) {
            face(g, g->pk[gk].pos);
            tap(g, BTN_R);
            step(g, 0, 0, 0.2f, 0, 0, 0.6f);
            CHECK(!g->pk[gk].active, "a bullet shatters a gun on the table");
        }
        Pickup *q = &g->pk[0];
        memset(q, 0, sizeof *q);
        q->active = 1; q->flying = 1; q->pos = v3(g->pl.pos.x, 1.4f, g->pl.pos.z + 3); q->vel = v3(0, 0.5f, 0); q->spinV = 3;
        face(g, q->pos);
        g->pl.shootT = 0;
        tap(g, BTN_R);
        for (int i = 0; i < 40 && q->active; i++) step(g, 0, 0, 0.2f, 0, 0, 1.0f / 60);
        CHECK(!q->active, "a bullet shatters a gun in the air");
    }
    printf("enemies shoot slow bullets with red trails\n");
    start_level(g, 2);
    for (int i = 0; i < 1500 && g->mode == MODE_PLAY; i++) {
        int any = 0;
        for (int k = 0; k < MAX_BULLETS; k++) any |= g->bul[k].active;
        if (any) break;
        step(g, 0, 0.3f, 0.0f, 0, 0, 1.0f / 60);
        face(g, v3(0, 1.4f, 13));
    }
    int bi = -1;
    for (int k = 0; k < MAX_BULLETS; k++) if (g->bul[k].active) bi = k;
    CHECK(bi >= 0, "an enemy fired");
    if (bi >= 0) {
        step(g, 0, 0, 0, 0, 0, 0.6f);
        V3 p0 = g->bul[bi].pos;
        step(g, 0, 0, 0, 0, 0, 1.0f);
        float still = vlen(vsub(g->bul[bi].pos, p0));
        printf("  bullet moved %.3f m in 1 s standing still\n", still);
        CHECK(still > 0.05f && still < 1.0f, "standing still, bullets crawl but do not stop");
        shot(g, "11_enemy_bullets");
        float oy = g->pl.yaw, op = g->pl.pitch;
        /* a bullet crossing in front, to see the trail from the side */
        Bullet *bb = &g->bul[(bi + 1) % MAX_BULLETS];
        bb->active = 1; bb->fromPlayer = 0; bb->start = v3(g->pl.pos.x + 3, 1.5f, g->pl.pos.z + 2.5f);
        bb->vel = v3(-8, 0, 0); bb->pos = vadd(bb->start, v3(-2.6f, 0, 0)); bb->life = 5;
        g->pl.hasGun = 1; g->pl.ammo = 2; g->pl.weapon = WP_PISTOL; g->flashT = 0.05f;
        face(g, v3(g->pl.pos.x, 1.5f, g->pl.pos.z + 5));
        shot(g, "11b_trail_side");
        bb->active = 0; g->pl.hasGun = 0; g->flashT = 0;
        g->pl.yaw = oy; g->pl.pitch = op;
    }
    printf("death and restart\n");
    for (int i = 0; i < 1200 && g->mode == MODE_PLAY; i++) step(g, 0, 0.5f, 0, 0, 0, 1.0f / 60);
    CHECK(g->mode == MODE_DEAD, "getting shot shatters you");
    step(g, 0, 0, 0, 0, 0, 0.5f);
    shot(g, "12_dead");
    step(g, 0, 0, 0, 0, 0, 1.0f);
    tap(g, BTN_A);
    CHECK(g->mode == MODE_PLAY && g->level == 2 && !g->pl.hasGun, "A restarts the level");

    printf("throwing: only you\n");
    start_level(g, 1);
    g->pl.hasGun = 1; g->pl.ammo = 0; g->pl.weapon = WP_PISTOL;
    face(g, v3(g->en[0].pos.x, 1.3f, g->en[0].pos.z));
    int before = alive(g);
    tap(g, BTN_L);
    for (int i = 0; i < 240; i++) step(g, 0, 0.2f, 0, 0, 0, 1.0f / 60);
    CHECK(!g->pl.hasGun, "L throws the gun");
    printf("  alive before %d after %d\n", before, alive(g));

    printf("weapons\n");
    {
        /* shotgun: one pull, a spread of pellets */
        start_level(g, 8);
        g->pl.hasGun = 1; g->pl.weapon = WP_SHOTGUN; g->pl.ammo = weapon_ammo(WP_SHOTGUN);
        face(g, v3(0, 1.4f, 10));
        tap(g, BTN_R);
        int nb = 0;
        for (int k = 0; k < MAX_BULLETS; k++) nb += g->bul[k].active && g->bul[k].fromPlayer;
        CHECK(nb >= 5 && g->pl.ammo == 1, "the shotgun fires a spread and uses one shell");
        shot(g, "40_shotgun");
        /* smg: hold R and it keeps firing */
        start_level(g, 8);
        g->pl.hasGun = 1; g->pl.weapon = WP_SMG; g->pl.ammo = weapon_ammo(WP_SMG);
        face(g, v3(0, 1.4f, 10));
        step(g, BTN_R, 0, 0, 0, 0, 0.8f);
        printf("  smg rounds left %d\n", g->pl.ammo);
        CHECK(g->pl.ammo <= weapon_ammo(WP_SMG) - 3, "holding R empties the submachine gun");
        shot(g, "41_smg");
        /* katana: reaches further than a fist, and cuts bullets */
        start_level(g, 10);
        for (int i = 0; i < g->nen; i++) g->en[i].alive = 0;
        Enemy *e = &g->en[0];
        e->alive = 1; e->delay = 0; e->appear = 1; e->armed = 0; e->pos = v3(g->pl.pos.x, 0, g->pl.pos.z + 1.8f); e->state = EN_CHASE;
        g->en[1].alive = 1; g->en[1].delay = 30;   /* someone still to come, so the level does not end */
        g->pl.hasGun = 1; g->pl.weapon = WP_KATANA; g->pl.ammo = 0;
        face(g, v3(e->pos.x, 1.3f, e->pos.z));
        shot(g, "42_katana_ready");
        tap(g, BTN_R);
        CHECK(!e->alive, "a katana swing breaks a man nearly two metres off");
        Bullet *b = &g->bul[0];
        memset(b, 0, sizeof *b);
        b->active = 1; b->pos = b->start = v3(g->pl.pos.x, 1.5f, g->pl.pos.z + 1.6f); b->vel = v3(0, 0, -0.2f); b->life = 5;
        g->pl.punchT = 0;
        step(g, 0, 0, 0, 0, 0, 0.1f);
        tap(g, BTN_R);
        CHECK(!b->active, "the katana cuts a bullet out of the air");
        g->pl.punchT = 0.16f;
        shot(g, "43_katana_swing");
        /* pick a bottle off a table and throw it */
        start_level(g, 4);
        int pi2 = -1; float pd2 = 1e9f;
        for (int i = 0; i < g->nprop; i++) if (g->prop[i].active) { float d = vlen(vsub(g->prop[i].pos, g->pl.pos)); if (d < pd2) { pd2 = d; pi2 = i; } }
        if (pi2 >= 0) {
            Prop *pr = &g->prop[pi2];
            g->pl.pos = v3(pr->pos.x, 0, pr->pos.z - 0.9f);
            if (blocked(g, g->pl.pos.x, g->pl.pos.z, 0.25f)) g->pl.pos = v3(pr->pos.x - 0.9f, 0, pr->pos.z);
            face(g, v3(pr->pos.x, pr->pos.y + pr->h * 0.5f, pr->pos.z));
            tap(g, BTN_L);
            CHECK(g->pl.hasGun && g->pl.weapon == WP_PROP && !pr->active, "L picks a bottle up off the table");
            shot(g, "44_bottle_held");
            face(g, v3(g->pl.pos.x, 1.0f, g->pl.pos.z + 6));
            tap(g, BTN_R);
            int fly = 0;
            for (int i = 0; i < MAX_PICKUPS; i++) fly += g->pk[i].active && g->pk[i].kind == WP_PROP;
            CHECK(!g->pl.hasGun, "R throws it");
            step(g, 0, 0.5f, 0, 0, 0, 2.0f);
            fly = 0;
            for (int i = 0; i < MAX_PICKUPS; i++) fly += g->pk[i].active && g->pk[i].kind == WP_PROP;
            CHECK(fly == 0, "a thrown bottle smashes when it lands");
        } else CHECK(0, "there is a bottle in the bar");
        /* a man with a bat reaches further than a fist */
        start_level(g, 13);
        for (int i = 0; i < g->nen; i++) g->en[i].alive = 0;
        e = &g->en[0];
        e->alive = 1; e->delay = 0; e->appear = 1; e->armed = WP_BAT; e->pos = v3(g->pl.pos.x, 0, g->pl.pos.z + 1.6f); e->state = EN_CHASE;
        e->yaw = -PI / 2;
        g->en[1].alive = 1; g->en[1].delay = 300;
        for (int i = 0; i < 3000 && g->mode == MODE_PLAY; i++) step(g, 0, 0, 0.0f, 0, 0, 1.0f / 60);
        CHECK(g->mode == MODE_DEAD, "a bat swung from 1.6 m away breaks you");
        /* holding a gun, R on someone right in front of you hits them with it (no shot fired) */
        start_level(g, 13);
        for (int i = 0; i < g->nen; i++) g->en[i].alive = 0;
        e = &g->en[0];
        e->alive = 1; e->delay = 0; e->appear = 1; e->armed = 0; e->pos = v3(g->pl.pos.x, 0, g->pl.pos.z + 1.0f); e->state = EN_CHASE;
        g->en[1].alive = 1; g->en[1].delay = 300;
        g->pl.hasGun = 1; g->pl.weapon = WP_PISTOL; g->pl.ammo = 3;
        face(g, v3(e->pos.x, 1.3f, e->pos.z));
        tap(g, BTN_R);
        CHECK(!e->alive && g->pl.ammo == 3, "up close, R hits them with the gun instead of shooting");
        /* and a man with a gun does the same to you */
        start_level(g, 13);
        for (int i = 0; i < g->nen; i++) g->en[i].alive = 0;
        e = &g->en[0];
        e->alive = 1; e->delay = 0; e->appear = 1; e->armed = WP_SHOTGUN; e->pos = v3(g->pl.pos.x, 0, g->pl.pos.z + 1.0f); e->state = EN_CHASE; e->yaw = -PI / 2;
        g->en[1].alive = 1; g->en[1].delay = 300;
        for (int i = 0; i < 3000 && g->mode == MODE_PLAY; i++) step(g, 0, 0, 0.0f, 0, 0, 1.0f / 60);
        CHECK(g->mode == MODE_DEAD && g->killedBy == 1, "a gunman right next to you hits you with his gun");
        /* every weapon builds its glass and can be shattered */
        start_level(g, 15);
        int okk = 1;
        for (int k = WP_PISTOL; k <= WP_BAT; k++) {
            static V3 w[600 * 3];
            Xf x = xf_at(v3(0, 1, 0), 0, 1);
            int nt = weapon_tris(k, 0, 0, 0, &x, w, 600 * 3);
            printf("  %s: %d triangles\n", weapon_name(k), nt);
            if (nt < 10) okk = 0;
        }
        CHECK(okk, "every weapon has a shape");
    }

    printf("all levels look right\n");
    for (int lv = 1; lv < levelCount; lv++) {
        start_level(g, lv);
        step(g, 0, 0, 0.2f, 0, 0, 0.5f);
        char nm[32];
        snprintf(nm, sizeof nm, "20_level%02d", lv);
        if (lv == 4 || lv == 6 || lv == 8 || lv == 10 || lv == 15) shot(g, nm);
        CHECK(!blocked(g, g->pl.pos.x, g->pl.pos.z, 0.25f), levels[lv].file);
        {
            const Level *L = &levels[lv];
            int ok = 1;
            for (int k = 0; k < L->nen; k++) {
                float sv = g->level; (void)sv;
                if (blocked(g, L->en[k].x, L->en[k].z, 0.3f)) { ok = 0; printf("  enemy %d of %s starts inside something\n", k, L->file); }
            }
            for (int k = 0; k < L->ngun; k++)
                for (int b = 0; b < g->nbox; b++) {
                    const Box *bx = &g->box[b];
                    if (L->gun[k].x > bx->x0 && L->gun[k].x < bx->x1 && L->gun[k].z > bx->z0 && L->gun[k].z < bx->z1 && !box_is_surface(bx)) { ok = 0; printf("  gun %d of %s is inside something\n", k, L->file); }
                }
            for (int a = 0; a < g->nbox; a++)
                for (int b = a + 1; b < g->nbox; b++) {
                    const Box *p = &g->box[a], *q = &g->box[b];
                    if (p->kind == BOX_WALL || q->kind == BOX_WALL || p->kind == BOX_FACADE || q->kind == BOX_FACADE) continue;
                    if (p->x0 < q->x1 - 0.01f && q->x0 < p->x1 - 0.01f && p->z0 < q->z1 - 0.01f && q->z0 < p->z1 - 0.01f) { ok = 0; printf("  boxes %d and %d of %s overlap\n", a, b, L->file); }
                }
            CHECK(ok, "everyone starts somewhere free, nothing overlaps");
            /* can every enemy walk to you? flood the floor from where you start */
            {
                static unsigned char seen[200][200];
                memset(seen, 0, sizeof seen);
                float cs = 0.25f;
                int nx = (int)((L->x1 - L->x0) / cs), nz = (int)((L->z1 - L->z0) / cs);
                if (nx > 200) nx = 200;
                if (nz > 200) nz = 200;
                static int qx[40000], qz[40000];
                int qh = 0, qt = 0;
                int sx = (int)((L->px - L->x0) / cs), sz = (int)((L->pz - L->z0) / cs);
                seen[sx][sz] = 1; qx[qt] = sx; qz[qt] = sz; qt++;
                while (qh < qt) {
                    int x = qx[qh], z = qz[qh]; qh++;
                    static const int dx[4] = {1, -1, 0, 0}, dz[4] = {0, 0, 1, -1};
                    for (int d = 0; d < 4; d++) {
                        int a = x + dx[d], b = z + dz[d];
                        if (a < 0 || b < 0 || a >= nx || b >= nz || seen[a][b]) continue;
                        if (blocked(g, L->x0 + (a + 0.5f) * cs, L->z0 + (b + 0.5f) * cs, 0.28f)) continue;
                        seen[a][b] = 1;
                        if (qt < 40000) { qx[qt] = a; qz[qt] = b; qt++; }
                    }
                }
                int reach = 1;
                for (int k = 0; k < L->nen; k++) {
                    int a = (int)((L->en[k].x - L->x0) / cs), b = (int)((L->en[k].z - L->z0) / cs), found = 0;
                    for (int u = -2; u <= 2 && !found; u++)
                        for (int v = -2; v <= 2 && !found; v++)
                            if (a + u >= 0 && b + v >= 0 && a + u < nx && b + v < nz && seen[a + u][b + v]) found = 1;
                    if (!found) { reach = 0; printf("  enemy %d of %s cannot reach you\n", k, L->file); }
                }
                CHECK(reach, "every enemy has a way to you");
            }
        }
    }

    printf("replays repeat runs exactly\n");
    {
        start_level(g, 6);
        unsigned r = 7;
        for (int i = 0; i < 300 && g->mode == MODE_PLAY; i++) {
            r = r * 1664525u + 1013904223u;
            step(g, (r >> 9) & (BTN_R | BTN_A | BTN_Y), ((int)((r >> 4) & 255) - 128) / 128.0f, 0.4f, 0, 0, 1.0f / 60);
        }
        V3 p1 = g->pl.pos; float y1 = g->pl.yaw; V3 e1 = g->en[1].pos; int a1 = alive(g);
        int slot = replay_save(g);
        CHECK(slot >= 0, "the run is written to a file");
        replay_start(g, slot);
        while (g->mode == MODE_PLAY && g->replayFrame < g->replayLen) step(g, 0, 0, 0, 0, 0, 1.0f / 60);
        printf("  live %.4f %.4f  replay %.4f %.4f\n", p1.x, p1.z, g->pl.pos.x, g->pl.pos.z);
        CHECK(p1.x == g->pl.pos.x && p1.z == g->pl.pos.z && y1 == g->pl.yaw && e1.x == g->en[1].pos.x && a1 == alive(g), "the replay ends exactly where the run did");
        char p[128]; replay_path(g, slot, p, sizeof p); remove(p);
    }

    printf("the computer gets corrupted\n");
    g->completed = (1 << 12) - 1;
    g->mode = MODE_MENU; g->menuDir = DIR_LEVELS; g->menuSel = 9;
    shot(g, "30_menu_corrupt");
    g->chatId = 6; g->mode = MODE_CHAT; g->chatLine = 0; g->chatChars = 0; g->chatDone = 0;
    for (int i = 0; i < 6; i++) tap(g, BTN_A);
    step(g, 0, 0, 0, 0, 0, 1.5f);
    shot(g, "31_chat_spam");
    for (int i = 0; i < 300 && !g->chatDone; i++) { tap(g, BTN_A); step(g, 0, 0, 0, 0, 0, 0.3f); }
    CHECK(g->chatDone, "the hacked chat finishes");
    start_level(g, 12);
    step(g, 0, 0, 0.5f, 0, 0, 1.0f);
    shot(g, "32_hacked_level");
    g->mode = MODE_BOOT; g->modeT = 0;
    step(g, 0, 0, 0, 0, 0, 3.0f);
    shot(g, "33_boot_corrupt");
    g->mode = MODE_HACK; g->modeT = 0;
    step(g, 0, 0, 0, 0, 0, 3.0f);
    shot(g, "34_hack");
    step(g, 0, 0, 0, 0, 0, 8.0f);
    shot(g, "35_hack_end");
    tap(g, BTN_A);
    CHECK(g->mode == MODE_MENU, "the ending returns to the menu");

    printf("save round trip\n");
    unsigned char buf[256];
    int n = game_save_bytes(g, buf, sizeof buf);
    Game h; memset(&h, 0, sizeof h);
    CHECK(game_load_bytes(&h, buf, n) && h.completed == g->completed && h.introSeen, "progress saves and loads");

    printf("drops, slow time, ammo, sound\n");
    {
        /* every armed man drops what he holds when he breaks */
        int okd = 1;
        for (int k = WP_PISTOL; k <= WP_BAT; k++) {
            start_level(g, 13);
            for (int i = 0; i < g->nen; i++) g->en[i].alive = 0;
            memset(g->pk, 0, sizeof g->pk);
            Enemy *e2 = &g->en[0];
            e2->alive = 1; e2->delay = 0; e2->appear = 1; e2->armed = k; e2->pos = v3(0, 0, 2); e2->state = EN_CHASE;
            g->en[1].alive = 1; g->en[1].delay = 300;
            kill_enemy(g, e2, v3(0, 0, 1), v3(0, 1.3f, 2));
            int found = -1;
            for (int i = 0; i < MAX_PICKUPS; i++) if (g->pk[i].active && g->pk[i].kind == k) found = i;
            for (int i = 0; i < 400 && found >= 0 && g->pk[found].flying; i++) update_pickups(g, 0.01f);
            if (found < 0 || g->pk[found].flying || g->pk[found].ammo != weapon_ammo(k)) { okd = 0; printf("  %s did not drop properly\n", weapon_name(k)); }
        }
        CHECK(okd, "every weapon falls out of a broken man's hands, loaded, and lands");
        /* standing still slows time right down; moving speeds it up */
        start_level(g, 2);
        step(g, 0, 0, 0, 0, 0, 1.0f);
        float still = g->ts;
        step(g, 0, 0, 1.0f, 0, 0, 0.5f);
        float moving = g->ts;
        printf("  time scale standing %.3f walking %.3f\n", still, moving);
        CHECK(still < 0.06f && moving > 0.9f, "standing still slows time to a crawl");
        /* empty gun: NO AMMO flashes */
        start_level(g, 2);
        g->pl.hasGun = 1; g->pl.weapon = WP_PISTOL; g->pl.ammo = 1;
        face(g, v3(0, 1.4f, 10));
        tap(g, BTN_R);
        CHECK(g->pl.ammo == 0 && g->noAmmoT > 0, "the last shot flashes NO AMMO");
        step(g, 0, 0, 0, 0, 0, 2.0f);
        g->pl.shootT = 0;
        tap(g, BTN_R);
        CHECK(g->noAmmoT > 0, "pulling the trigger on an empty gun flashes NO AMMO");
        { int keep = g->completed; g->completed = 0; g->noAmmoT = 1.4f - 0.05f; shot(g, "37_no_ammo"); g->completed = keep; }
        /* every sound was made and is clean */
        int clean = 1;
        for (int i = 0; i < SFX_COUNT; i++) if (!audio_sample_len(i)) { clean = 0; printf("  sound %d missing\n", i); }
        CHECK(clean, "every sound effect was synthesized");
    }

    printf("glass: one hit and you break\n");
    {
        start_level(g, 13);
        for (int i = 0; i < g->nen; i++) g->en[i].alive = 0;
        g->en[1].alive = 1; g->en[1].delay = 300;
        Bullet *b = &g->bul[0];
        memset(b, 0, sizeof *b);
        b->active = 1; b->pos = b->start = v3(g->pl.pos.x, 1.4f, g->pl.pos.z + 0.6f); b->vel = v3(0, 0, -3); b->life = 5;
        for (int i = 0; i < 600 && g->mode == MODE_PLAY; i++) step(g, 0, 0, 0, 0, 0, 1.0f / 60);
        CHECK(g->mode == MODE_DEAD, "a single bullet breaks you");
    }

    printf("26 levels in levels.ult\n");
    {
        CHECK(levelCount == 26, "there are 26 levels");
        g->completed = (1 << levelCount) - 1;
        g->mode = MODE_MENU; g->menuDir = DIR_LEVELS; g->menuSel = 0;
        CHECK(menu_rows(g) == 1 + levelCount, "levels.ult lists every beaten level");
        int a = -1; int kd = menu_row(g, levelCount, &a);
        CHECK(kd == ROW_LEVEL && a == levelCount - 1, "the last row is 25END");
        g->menuSel = levelCount;
        shot(g, "36_levels_folder");
        CHECK(chat_after(15) == -1 && chat_after(25) == 99, "the story now ends after level 25");
        int n2 = game_save_bytes(g, buf, sizeof buf);
        Game h2; memset(&h2, 0, sizeof h2);
        CHECK(game_load_bytes(&h2, buf, n2) && h2.completed == g->completed, "all 26 levels save and load");
        /* an old 16-level save still loads */
        SaveV3 o; memset(&o, 0, sizeof o); o.magic = 0x53485433u; o.completed = 0x7F; o.look = 2;
        Game h3; memset(&h3, 0, sizeof h3);
        CHECK(game_load_bytes(&h3, (unsigned char *)&o, sizeof o) && h3.completed == 0x7F, "an old save still loads");
    }

    printf("fuzz\n");
    unsigned r = 99;
    int bad = 0;
    for (int lv = 0; lv < levelCount; lv++) {
        start_level(g, lv);
        for (int i = 0; i < 2400; i++) {
            r = r * 1664525u + 1013904223u;
            unsigned held = (r >> 8) & (BTN_A | BTN_B | BTN_X | BTN_Y | BTN_L | BTN_R | BTN_DLEFT | BTN_DRIGHT);
            if (((r >> 20) & 63) == 0) held |= BTN_START;
            float sx = ((int)((r >> 4) & 255) - 128) / 128.0f, sy = ((int)((r >> 12) & 255) - 100) / 128.0f;
            step(g, held, sx, sy, (r >> 3) % 320, (r >> 11) % 240, 1.0f / 60);
            if (g->mode != MODE_PLAY && g->mode != MODE_DEAD && g->mode != MODE_PAUSE && g->mode != MODE_WIN) start_level(g, lv);
            if (!finite_state(g)) { bad++; break; }
            if ((i % 600) == 0) { render_top(g); }
        }
    }
    CHECK(bad == 0, "no NaNs or crashes in random play");
    printf("%s (%d failures)\n", fails ? "FAILED" : "ALL GOOD", fails);
    return fails != 0;
}
