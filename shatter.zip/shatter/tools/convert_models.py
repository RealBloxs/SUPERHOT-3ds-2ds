"""Turns the two uploaded models into C arrays for the 3DS.

  enemy  (superhot_enemy_stl.fbx): one static low-poly man. We stand him up (Y up, facing +Z),
         drop stray bits, cut him into rigid body parts around the joints (so the game can
         swing arms and legs), simplify each part, and store every part relative to its joint.
  pistol (pisrol.blend): muzzle along +Z, grip down, 20 cm long.

Everything is exported as flat-shaded triangles (one normal per face) for the faceted look.
Run with: python3 convert_models.py   (needs the 'bpy' module: pip install bpy)
"""
import bpy, bmesh, numpy as np, os, sys
from mathutils import Vector

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'source')
ENEMY = '/tmp/sh_in/enemy/source/superhot_enemy_stl.fbx'
PISTOL = '/tmp/sh_in/pistol/source/pisrol.blend'


def mesh_arrays(obj):
    dg = bpy.context.evaluated_depsgraph_get()
    ob = obj.evaluated_get(dg)
    m = ob.to_mesh()
    M = obj.matrix_world
    V = np.array([tuple(M @ v.co) for v in m.vertices], dtype=np.float64)
    m.calc_loop_triangles()
    T = np.array([tuple(t.vertices) for t in m.loop_triangles], dtype=np.int64)
    ob.to_mesh_clear()
    return V, T


def components(V, T):
    """label connected pieces (union-find over triangle edges)"""
    p = np.arange(len(V))
    def find(a):
        while p[a] != a:
            p[a] = p[p[a]]
            a = p[a]
        return a
    for a, b, c in T:
        for x, y in ((a, b), (b, c)):
            rx, ry = find(x), find(y)
            if rx != ry: p[rx] = ry
    return np.array([find(i) for i in range(len(V))])


def make_obj(name, V, T):
    me = bpy.data.meshes.new(name)
    me.from_pydata([tuple(v) for v in V], [], [tuple(t) for t in T])
    me.update()
    ob = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(ob)
    return ob


def simplify(V, T, target, name):
    """decimate to about `target` triangles; returns new (V, T)"""
    if len(T) <= target: return V, T
    ob = make_obj(name, V, T)
    bm = bmesh.new(); bm.from_mesh(ob.data)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
    bm.to_mesh(ob.data); bm.free()
    mod = ob.modifiers.new('dec', 'DECIMATE')
    mod.ratio = max(0.002, target / len(T))
    mod.use_collapse_triangulate = True
    V2, T2 = mesh_arrays(ob)
    bpy.data.objects.remove(ob)
    return V2, T2


def simplify_q(V, T, target):
    import fast_simplification
    if len(T) <= target: return V, T
    v2, f2 = fast_simplification.simplify(V.astype(np.float32), T.astype(np.int32), target_reduction=1 - target / len(T), agg=1)
    return v2.astype(np.float64), f2.astype(np.int64)


def flat(V, T):
    """triangle soup with face normals; drop slivers"""
    P = V[T]                                   # nt x 3 x 3
    N = np.cross(P[:, 1] - P[:, 0], P[:, 2] - P[:, 0])
    L = np.linalg.norm(N, axis=1)
    keep = L > 1e-9
    P, N, L = P[keep], N[keep], L[keep]
    N = N / L[:, None]
    return P, N


# ---------------------------------------------------------------- enemy
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=ENEMY)
src = [o for o in bpy.context.scene.objects if o.type == 'MESH'][0]
Vw, T = mesh_arrays(src)
# world x = up, world y = forward, world z = right  ->  game (X right, Y up, Z forward)
V = np.stack([Vw[:, 2], Vw[:, 0], Vw[:, 1]], axis=1)
# drop stray pieces: keep components that sit inside the body's box
lab = components(V, T)
sizes = {}
for l in lab: sizes[l] = sizes.get(l, 0) + 1
big = max(sizes, key=sizes.get)
core = V[lab == big]
lo, hi = core.min(0) - 0.05, core.max(0) + 0.05
inside = np.all((V >= lo) & (V <= hi), axis=1)
keepv = np.zeros(len(V), bool)
for l, n in sizes.items():
    sel = lab == l
    if inside[sel].all(): keepv |= sel
T = T[keepv[T].all(axis=1)]
print('enemy tris', len(T), 'kept components', sum(1 for l in sizes if inside[lab == l].all()))
# weld: the STL has every triangle separate
used = np.unique(T)
key = np.round(V[used] / 1e-4).astype(np.int64)
_, first, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
remap = -np.ones(len(V), np.int64); remap[used] = inv.ravel()
V, T = V[used][first], remap[T]
T = T[(T[:, 0] != T[:, 1]) & (T[:, 1] != T[:, 2]) & (T[:, 0] != T[:, 2])]
print('welded verts', len(V), 'tris', len(T))
keepv = np.ones(len(V), bool)
H0 = V[keepv][:, 1].min(); H = V[keepv][:, 1].max() - H0
V[:, 1] -= H0
# centre on the torso
chest = V[keepv & (V[:, 1] > 0.55 * H) & (V[:, 1] < 0.75 * H)]
tx = chest[:, 0]
body = chest[(tx > np.percentile(tx, 25)) & (tx < np.percentile(tx, 75))]
cx, cz = body[:, 0].mean(), body[:, 2].mean()
V[:, 0] -= cx; V[:, 2] -= cz
print('height %.3f' % H)

# joints (fractions of height measured from the mesh)
Y_NECK, Y_SHOULDER, Y_ELBOW, Y_HIP, Y_KNEE = 0.858 * H, 0.80 * H, 0.63 * H, 0.50 * H, 0.27 * H
# torso half-width at the waist: arms are outside it
waist = V[keepv & (V[:, 1] > 0.55 * H) & (V[:, 1] < 0.7 * H)]
# find the gap on each side: biggest empty stretch of x
def side_gap(xs, sign):
    xs = np.sort(xs * sign)
    xs = xs[xs > 0.03]
    d = np.diff(xs)
    i = int(np.argmax(d))
    return sign * (xs[i] + xs[i + 1]) / 2
ARM_L, ARM_R = side_gap(waist[:, 0], -1), side_gap(waist[:, 0], 1)
legs = V[keepv & (V[:, 1] < 0.4 * H) & (V[:, 1] > 0.1 * H)]
xs = np.sort(legs[:, 0]); d = np.diff(xs); i = int(np.argmax(d)); LEG_MID = (xs[i] + xs[i + 1]) / 2
print('arm cut x', ARM_L, ARM_R, 'leg split', LEG_MID)


SH_CUT = 0.19 * H / 1.805
# per-height cut between each arm and the body: the widest empty strip in that slice
def cut_table(sign):
    tab = []
    last = 0.17 * sign
    for k in range(60):
        y0 = 0.40 * H + (0.80 * H - 0.40 * H) * k / 60
        y1 = y0 + 0.4 * H / 60
        xs = V[(V[:, 1] >= y0) & (V[:, 1] < y1)][:, 0] * sign
        xs = np.sort(xs[(xs > 0.08) & (xs < 0.4)])
        if len(xs) > 2:
            d = np.diff(xs); i = int(np.argmax(d))
            if d[i] > 0.008: last = sign * (xs[i] + xs[i + 1]) / 2
        tab.append(last)
    return np.array(tab)
CUT_L, CUT_R = cut_table(-1), cut_table(1)
def cut_at(tab, yy):
    k = np.clip(((yy - 0.40 * H) / (0.4 * H) * 60).astype(int), 0, 59)
    return tab[k]
C = V[T].mean(axis=1)                           # triangle centroids
part = np.full(len(T), -1)
names = ['TORSO', 'HEAD', 'UARM_L', 'FARM_L', 'UARM_R', 'FARM_R', 'THIGH_L', 'SHIN_L', 'THIGH_R', 'SHIN_R']
x, y = C[:, 0], C[:, 1]
part[:] = 0
part[y > Y_NECK] = 1
isL = ((y < 0.80 * H) & (x < cut_at(CUT_L, y))) | ((y >= 0.80 * H) & (y < Y_NECK) & (x < -SH_CUT))
isR = ((y < 0.80 * H) & (x > cut_at(CUT_R, y))) | ((y >= 0.80 * H) & (y < Y_NECK) & (x > SH_CUT))
armzone = (y < Y_NECK) & (y > 0.3 * H)
part[armzone & isL & (y >= Y_ELBOW)] = 2
part[armzone & isL & (y < Y_ELBOW)] = 3
part[armzone & isR & (y >= Y_ELBOW)] = 4
part[armzone & isR & (y < Y_ELBOW)] = 5
legzone = (y < Y_HIP) & (part == 0)
part[legzone & (x < LEG_MID) & (y >= Y_KNEE)] = 6
part[legzone & (x < LEG_MID) & (y < Y_KNEE)] = 7
part[legzone & (x >= LEG_MID) & (y >= Y_KNEE)] = 8
part[legzone & (x >= LEG_MID) & (y < Y_KNEE)] = 9

def joint_of(k):
    sel = V[np.unique(T[part == k])]
    mx = sel[:, 0].mean(); mz = sel[:, 2].mean()
    if k == 1: return np.array([0.0, Y_NECK, mz])
    if k in (2, 4):
        top = sel[sel[:, 1] > Y_SHOULDER - 0.08]
        return np.array([top[:, 0].mean() if len(top) else mx, Y_SHOULDER, top[:, 2].mean() if len(top) else mz])
    if k in (3, 5):
        top = sel[sel[:, 1] > Y_ELBOW - 0.05]
        return np.array([top[:, 0].mean(), Y_ELBOW, top[:, 2].mean()])
    if k in (6, 8):
        top = sel[sel[:, 1] > Y_HIP - 0.08]
        return np.array([top[:, 0].mean(), Y_HIP, top[:, 2].mean()])
    if k in (7, 9):
        top = sel[sel[:, 1] > Y_KNEE - 0.05]
        return np.array([top[:, 0].mean(), Y_KNEE, top[:, 2].mean()])
    return np.array([0.0, Y_HIP, 0.0])

# ---- a skinned, smooth-shaded body (no rigid cuts, so no holes at the joints) ----
JOINTS = np.array([joint_of(k) for k in range(10)])
PARENT = [-1, 0, 0, 2, 0, 4, 0, 6, 0, 8]

def label_points(P):
    x, y = P[:, 0], P[:, 1]
    lab = np.zeros(len(P), int)
    lab[y > Y_NECK] = 1
    isL = ((y < 0.80 * H) & (x < cut_at(CUT_L, y))) | ((y >= 0.80 * H) & (y < Y_NECK) & (x < -SH_CUT))
    isR = ((y < 0.80 * H) & (x > cut_at(CUT_R, y))) | ((y >= 0.80 * H) & (y < Y_NECK) & (x > SH_CUT))
    armzone = (y < Y_NECK) & (y > 0.3 * H)
    lab[armzone & isL & (y >= Y_ELBOW)] = 2
    lab[armzone & isL & (y < Y_ELBOW)] = 3
    lab[armzone & isR & (y >= Y_ELBOW)] = 4
    lab[armzone & isR & (y < Y_ELBOW)] = 5
    legzone = (y < Y_HIP) & (lab == 0)
    lab[legzone & (x < LEG_MID) & (y >= Y_KNEE)] = 6
    lab[legzone & (x < LEG_MID) & (y < Y_KNEE)] = 7
    lab[legzone & (x >= LEG_MID) & (y >= Y_KNEE)] = 8
    lab[legzone & (x >= LEG_MID) & (y < Y_KNEE)] = 9
    return lab

def weights(P, lab):
    """two bones per vertex: blend across each joint so bends stay smooth"""
    b0 = lab.copy(); b1 = lab.copy(); w = np.ones(len(P))
    for c in range(1, 10):
        par = PARENT[c]
        j = JOINTS[c]
        B = 0.07 if c in (2, 4, 6, 8, 1) else 0.06
        t = (P[:, 1] - j[1]) if c == 1 else (j[1] - P[:, 1])     # how far into the child part
        R = 0.07 if c == 1 else (0.1 if c in (6, 8) else 0.08)
        near = np.hypot(P[:, 0] - j[0], P[:, 2] - j[2]) < R * 1.6
        # child side
        sel = (lab == c) & (t >= 0) & (t < B)
        wc = 0.5 + 0.5 * t[sel] / B
        b0[sel] = c; b1[sel] = par; w[sel] = wc
        # parent side, close to this joint
        sel = (lab == par) & (t < 0) & (t > -B) & near
        wc = 0.5 + 0.5 * t[sel] / B                             # < 0.5: mostly the parent
        upd = sel.copy()
        idx = np.where(sel)[0]
        better = (1 - wc) < w[idx]
        idx = idx[better]; wc = wc[better]
        b0[idx] = par; b1[idx] = c; w[idx] = 1 - wc
    return b0, b1, w

def smooth_normals(V, T):
    P = V[T]
    N = np.cross(P[:, 1] - P[:, 0], P[:, 2] - P[:, 0])
    VN = np.zeros_like(V)
    for k in range(3): np.add.at(VN, T[:, k], N)
    return VN / np.maximum(np.linalg.norm(VN, axis=1), 1e-12)[:, None]

def clean(V, T):
    T = T[(T[:, 0] != T[:, 1]) & (T[:, 1] != T[:, 2]) & (T[:, 0] != T[:, 2])]
    P = V[T]
    A = np.linalg.norm(np.cross(P[:, 1] - P[:, 0], P[:, 2] - P[:, 0]), axis=1)
    T = T[A > 1e-10]
    used = np.unique(T)
    remap = -np.ones(len(V), np.int64); remap[used] = np.arange(len(used))
    return V[used], remap[T]

LOD_TARGETS = [4200, 1500]
bodies = []
for target in LOD_TARGETS:
    Vl, Tl = simplify(V.copy(), T.copy(), target, 'BODY')
    Vl, Tl = clean(Vl, Tl)
    lab = label_points(Vl)
    b0, b1, w = weights(Vl, lab)
    Nl = smooth_normals(Vl, Tl)
    # sort triangles by part so the first-person arms can pick theirs out
    tl = np.array([np.bincount(lab[t], minlength=10).argmax() for t in Tl])
    order = np.argsort(tl, kind='stable')
    Tl, tl = Tl[order], tl[order]
    bodies.append((Vl, Nl, Tl, tl, b0, b1, w))
    print('LOD %d: %d verts %d tris' % (len(bodies) - 1, len(Vl), len(Tl)))

# per-part triangle soups from LOD0, relative to the joints (first-person arms, bounds)
parts = []
Vl, Nl, Tl, tl, b0, b1, w = bodies[0]
for k, nm in enumerate(names):
    sub = Tl[tl == k]
    P = Vl[sub] - JOINTS[k]
    N = Nl[sub]
    parts.append((nm, P, N, JOINTS[k]))
    print('%-8s tris %4d joint %s' % (nm, len(P), np.round(JOINTS[k], 3)))

# ---------------------------------------------------------------- pistol
bpy.ops.wm.read_factory_settings(use_empty=True)
with bpy.data.libraries.load(PISTOL) as (s, d): d.objects = s.objects
for o in d.objects: bpy.context.scene.collection.objects.link(o)
gun = [o for o in bpy.context.scene.objects if o.type == 'MESH'][0]
Vg, Tg = mesh_arrays(gun)
ext = Vg.max(0) - Vg.min(0)
order = np.argsort(ext)                          # thin, height, length
ax_len, ax_h, ax_t = order[2], order[1], order[0]
G = np.stack([Vg[:, ax_t], Vg[:, ax_h], Vg[:, ax_len]], axis=1)
G -= (G.max(0) + G.min(0)) / 2
# grip hangs down at the back: lowest points tell us which end is the back
low = G[G[:, 1] < G[:, 1].min() + 0.25 * (G[:, 1].max() - G[:, 1].min())]
if low[:, 2].mean() > 0: G[:, 2] *= -1; G[:, 0] *= -1   # rotate 180 so the muzzle is +Z
# up: the slide is the long flat part on top; the grip is below. If the grip is above, flip.
if (G[:, 1] > 0).sum() < (G[:, 1] < 0).sum() * 0.5: G[:, 1] *= -1; G[:, 0] *= -1
G *= 0.2 / (G[:, 2].max() - G[:, 2].min())
# hold point: top of the grip, just behind the trigger
grip = G[G[:, 1] < G[:, 1].min() + 0.4 * (G[:, 1].max() - G[:, 1].min())]
hold = np.array([0.0, G[:, 1].max() - 0.035, grip[:, 2].mean()])
G -= hold
Vg2, Tg2 = simplify(G, Tg, 520, 'GUN')
Pg, Nf = flat(Vg2, Tg2)
# corner normals: smooth across gentle bends, sharp across real edges
key = np.round(Pg.reshape(-1, 3) / 1e-4).astype(np.int64)
_, inv = np.unique(key, axis=0, return_inverse=True)
inv = inv.ravel()
Nc = np.repeat(Nf, 3, axis=0)
acc = np.zeros_like(Nc)
for i in range(len(Nc)):
    pass
groups = {}
for i, g in enumerate(inv): groups.setdefault(g, []).append(i)
for g, ids in groups.items():
    ids = np.array(ids)
    fn = Nc[ids]
    sim = fn @ fn.T > np.cos(np.radians(38))
    acc[ids] = sim.astype(float) @ fn
Ng = (acc / np.maximum(np.linalg.norm(acc, axis=1), 1e-12)[:, None]).reshape(-1, 3, 3)
muzzle = np.array([0.0, Pg[:, :, 1].max() - 0.012, Pg[:, :, 2].max()])
print('GUN tris', len(Pg), 'muzzle', np.round(muzzle, 3))
parts.append(('GUN', Pg, Ng, np.zeros(3)))

# ---------------------------------------------------------------- write C
def q(a): return ','.join('%.4f' % v for v in a.ravel())
def s8(a): return ','.join(map(str, np.clip(np.round(a * 127), -127, 127).astype(int).ravel()))
with open(os.path.join(OUT, 'models.h'), 'w') as f:
    f.write('/* Generated by tools/convert_models.py from the uploaded enemy and pistol models */\n')
    f.write('#ifndef MODELS_H\n#define MODELS_H\n\n')
    f.write('/* a triangle soup with a normal per corner, relative to its joint */\n')
    f.write('typedef struct { int nt; const float *v; const signed char *n; float joint[3]; float lo[3], hi[3]; } Mesh;\n')
    f.write('enum { %s, M_COUNT };\n' % ', '.join('M_' + p[0] for p in parts))
    f.write('#define BODY_PARTS 10\n#define BODY_HEIGHT %.3ff\n' % H)
    f.write('#define GUN_MUZZLE_Y %.4ff\n#define GUN_MUZZLE_Z %.4ff\n' % (muzzle[1], muzzle[2]))
    f.write('/* the middle of each fist, from its elbow joint */\n')
    f.write('#define GRIP_L_X 0.0f\n#define GRIP_L_Y (-0.26f)\n#define GRIP_L_Z 0.02f\n')
    f.write('#define GRIP_R_X 0.0f\n#define GRIP_R_Y (-0.26f)\n#define GRIP_R_Z 0.02f\n')
    f.write('extern const Mesh meshes[M_COUNT];\n\n')
    f.write('/* the whole man as one smooth skinned mesh: rest pose, two bones per vertex.\n'
            ' * bone0 gets weight w/255, bone1 the rest. Triangles are sorted by body part. */\n')
    f.write('typedef struct { int nv, nt; const float *v; const signed char *n; const unsigned char *bone; const unsigned char *w;\n'
            '                 const unsigned short *idx; unsigned short partStart[BODY_PARTS + 1]; } Body;\n')
    f.write('#define BODY_LODS %d\nextern const Body bodies[BODY_LODS];\n\n#endif\n' % len(bodies))
with open(os.path.join(OUT, 'models.c'), 'w') as f:
    f.write('/* Generated by tools/convert_models.py - do not edit */\n#include "models.h"\n\n')
    for nm, P, N, j in parts:
        f.write('static const float %s_v[%d] = {%s};\n' % (nm.lower(), P.size, q(P)))
        f.write('static const signed char %s_n[%d] = {%s};\n' % (nm.lower(), N.size, s8(N)))
    f.write('\nconst Mesh meshes[M_COUNT] = {\n')
    for nm, P, N, j in parts:
        lo = P.reshape(-1, 3).min(0); hi = P.reshape(-1, 3).max(0)
        f.write('    {%d, %s_v, %s_n, {%.4ff, %.4ff, %.4ff}, {%.4ff, %.4ff, %.4ff}, {%.4ff, %.4ff, %.4ff}},\n' % (len(P), nm.lower(), nm.lower(), *j, *lo, *hi))
    f.write('};\n\n')
    for i, (Vl, Nl, Tl, tl, b0, b1, w) in enumerate(bodies):
        f.write('static const float body%d_v[%d] = {%s};\n' % (i, Vl.size, q(Vl)))
        f.write('static const signed char body%d_n[%d] = {%s};\n' % (i, Nl.size, s8(Nl)))
        bb = np.stack([b0, b1], 1)
        f.write('static const unsigned char body%d_b[%d] = {%s};\n' % (i, bb.size, ','.join(map(str, bb.ravel()))))
        f.write('static const unsigned char body%d_w[%d] = {%s};\n' % (i, len(w), ','.join(str(int(round(x * 255))) for x in w)))
        f.write('static const unsigned short body%d_i[%d] = {%s};\n' % (i, Tl.size, ','.join(map(str, Tl.ravel()))))
    f.write('\nconst Body bodies[BODY_LODS] = {\n')
    for i, (Vl, Nl, Tl, tl, b0, b1, w) in enumerate(bodies):
        ps = [int(np.searchsorted(tl, k)) for k in range(11)]
        f.write('    {%d, %d, body%d_v, body%d_n, body%d_b, body%d_w, body%d_i, {%s}},\n' % (len(Vl), len(Tl), i, i, i, i, i, ','.join(map(str, ps))))
    f.write('};\n')
np.save('/tmp/sh_body0.npy', np.array([bodies[0][0], bodies[0][2], bodies[0][4]], dtype=object), allow_pickle=True)
