import numpy as np
from PIL import Image, ImageDraw
parts = np.load('/tmp/sh_parts.npy', allow_pickle=True)
cols = [(200,200,200),(240,80,80),(80,200,80),(40,120,40),(80,80,240),(40,40,140),(240,200,60),(160,120,20),(200,80,240),(120,40,160),(30,30,30)]
img = Image.new('RGB', (1500, 520), (255,255,255)); d = ImageDraw.Draw(img)
L = np.array([0.3, 0.5, 0.8]); L /= np.linalg.norm(L)
def draw(ox, view, scale=260, gun=False):
    tris = []
    for k, (nm, P, j) in enumerate(parts):
        if (nm == 'GUN') != gun: continue
        Q = P + j
        for t in Q:
            if view == 'front': xy = t[:, [0, 1]] * [1, -1]; depth = t[:, 2].mean()
            elif view == 'side': xy = t[:, [2, 1]] * [1, -1]; depth = -t[:, 0].mean()
            else: xy = t[:, [0, 2]]; depth = t[:, 1].mean()
            n = np.cross(t[1] - t[0], t[2] - t[0]); n /= np.linalg.norm(n) + 1e-9
            sh = 0.45 + 0.55 * max(0, n @ L)
            tris.append((depth, xy, tuple(int(c * sh) for c in cols[k])))
    tris.sort(key=lambda a: a[0])
    for _, xy, c in tris:
        pts = [(ox + p[0] * scale, 480 + p[1] * scale) if not gun else (ox + p[0] * scale, 260 + p[1] * scale) for p in xy]
        d.polygon(pts, fill=c)
draw(250, 'front'); draw(650, 'side'); draw(1050, 'top')
draw(1350, 'side', 1200, gun=True)
img.save('/tmp/parts.png')
