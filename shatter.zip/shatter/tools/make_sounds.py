"""Makes every sound in Superhot ahead of time and writes them into source/sounds.c.

All of them are synthesized here from scratch (noise, resonators, sine partials, a small room
reverb) - nothing is sampled from any other game. Doing it offline means the 3DS does not have
to build them when the game boots, and they can be far richer than what it could afford.

Run:  python3 tools/make_sounds.py      (needs numpy and scipy)
"""
import os
import numpy as np
from scipy import signal

R = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'source')


# ---------------------------------------------------------------- building blocks
def t_axis(dur):
    return np.arange(int(round(dur * R))) / R


def expdecay(t, tau, t0=0.0):
    e = np.exp(-np.maximum(t - t0, 0) / tau)
    e[t < t0] = 0
    return e


def bandpass(x, lo, hi, order=2):
    hi = min(hi, R / 2 * 0.95)
    sos = signal.butter(order, [lo, hi], btype='band', fs=R, output='sos')
    return signal.sosfilt(sos, x)


def lowpass(x, f, order=2):
    sos = signal.butter(order, min(f, R / 2 * 0.95), btype='low', fs=R, output='sos')
    return signal.sosfilt(sos, x)


def highpass(x, f, order=2):
    sos = signal.butter(order, f, btype='high', fs=R, output='sos')
    return signal.sosfilt(sos, x)


def modal(t, t0, freqs, amps, taus, rng=None, phase=True):
    """a struck object: a few decaying sine partials starting at t0"""
    out = np.zeros_like(t)
    i0 = int(t0 * R)
    if i0 >= len(t):
        return out
    tt = t[i0:] - t0
    for f, a, tau in zip(freqs, amps, taus):
        if f >= R / 2 * 0.97:
            continue
        ph = rng.uniform(0, 2 * np.pi) if (phase and rng is not None) else 0
        cut = min(len(tt), int(tau * 8 * R) + 1)
        seg = np.sin(2 * np.pi * f * tt[:cut] + ph) * np.exp(-tt[:cut] / tau) * a
        out[i0:i0 + cut] += seg
    return out


def comb(x, d, g):
    a = np.zeros(d + 1); a[0] = 1; a[d] = -g
    return signal.lfilter([1.0], a, x)


def allpass(x, d, g):
    b = np.zeros(d + 1); b[0] = -g; b[d] = 1
    a = np.zeros(d + 1); a[0] = 1; a[d] = -g
    return signal.lfilter(b, a, x)


def reverb(x, wet=0.2, size=1.0, damp=4500, tail=0.8, fb=None):
    """a small room (Schroeder: four combs, two all-passes), mixed under the dry sound"""
    pad = np.concatenate([x, np.zeros(int(tail * R))])
    combs = [1116, 1188, 1277, 1356]
    out = np.zeros_like(pad)
    for c in combs:
        d = max(8, int(c * size * R / 44100))
        out += comb(pad, d, fb if fb is not None else 0.78 + 0.05 * min(size, 1.5))
    out = lowpass(out, damp, 1)
    for d0 in (556, 341):
        out = allpass(out, max(4, int(d0 * size * R / 44100)), 0.5)
    out /= len(combs)
    return pad * (1 - wet * 0.5) + out * wet


def softclip(x, drive=1.5):
    return np.tanh(x * drive) / np.tanh(drive)


def norm(x, peak=0.95):
    m = np.max(np.abs(x)) + 1e-9
    return x / m * peak


def fade_out(x, sec=0.03):
    n = min(len(x), int(sec * R))
    x = x.copy()
    x[-n:] *= np.linspace(1, 0, n)
    return x


def trim(x, thresh=0.0008):
    idx = np.where(np.abs(x) > thresh * np.max(np.abs(x)))[0]
    if len(idx) == 0:
        return x
    return fade_out(x[:idx[-1] + int(0.02 * R)])


def noise(n, rng):
    return rng.standard_normal(n)


# ---------------------------------------------------------------- glass
def shatter(rng, size=1.0, dur=1.8, low=1.0, tail=1.0, crack=1.0):
    """glass breaking: a sharp crack, the dull knock of the blow, a spray of tiny ringing pieces
    and, a moment later, the pieces landing and skittering"""
    t = t_axis(dur)
    n = len(t)
    x = np.zeros(n)
    # the crack: a very short, very bright burst
    x += highpass(noise(n, rng), 2500) * expdecay(t, 0.0025) * 1.4 * crack
    x += bandpass(noise(n, rng), 900, 6000) * expdecay(t, 0.012) * 0.8 * crack
    # the knock of the blow itself
    x += bandpass(noise(n, rng), 120, 700) * expdecay(t, 0.035) * 0.9 * low
    x += np.sin(2 * np.pi * (95 + 40 * rng.random()) * t) * expdecay(t, 0.05) * 0.5 * low
    # the spray: many little pieces, most in the first instant
    count = int(140 * size)
    for i in range(count):
        tt = -np.log(1 - rng.random() * 0.999) * 0.07
        if tt > dur - 0.1:
            continue
        base = rng.uniform(2200, 9500)
        k = rng.integers(2, 4)
        freqs = [base * r for r in (1.0, rng.uniform(1.4, 1.75), rng.uniform(2.3, 2.9))[:k]]
        amp = (rng.random() ** 2) * np.exp(-tt / 0.35) * 0.55
        x += modal(t, tt, freqs, [amp, amp * 0.6, amp * 0.35], [rng.uniform(0.012, 0.07)] * 3, rng)
    # crunch: grainy noise riding on the first quarter second
    grains = (rng.random(n) < 0.035).astype(float) * rng.standard_normal(n)
    x += highpass(grains, 3000) * expdecay(t, 0.09) * 0.9 * size
    # pieces landing on the floor and skittering away
    land = int(55 * size * tail)
    for i in range(land):
        tt = rng.uniform(0.22, dur * 0.85) * (0.6 + 0.4 * rng.random())
        if tt > dur - 0.08:
            continue
        base = rng.uniform(2600, 8000)
        amp = (rng.random() ** 2.5) * 0.28 * np.exp(-(tt - 0.2) / (0.6 * tail + 0.1))
        x += modal(t, tt, [base, base * rng.uniform(1.5, 1.7)], [amp, amp * 0.5], [rng.uniform(0.008, 0.04)] * 2, rng)
    x = reverb(x, wet=0.16, size=0.8, damp=6000, tail=0.4)
    return trim(softclip(norm(x), 1.2))


def window_crash(rng):
    """a whole pane of window glass: a big crack, deep sheet-glass ringing, then a long rain of pieces"""
    t = t_axis(2.8)
    x = shatter(rng, size=1.7, dur=2.8, low=1.3, tail=1.6)
    x = np.pad(x, (0, max(0, len(t) - len(x))))[:len(t)]
    # the sheet itself rings low before it gives
    for i in range(8):
        f = rng.uniform(500, 2400)
        x += modal(t, rng.uniform(0, 0.02), [f, f * 1.47], [0.12, 0.06], [rng.uniform(0.08, 0.2)] * 2, rng)
    x = reverb(x, wet=0.22, size=1.1, damp=5000, tail=0.5)
    return trim(softclip(norm(x), 1.2))


def limb(rng):
    """a piece of a glass man breaking off: a hard crack and a short spray"""
    return shatter(rng, size=0.45, dur=0.8, low=0.6, tail=0.4, crack=1.4)


def thud(rng):
    """a glass body hitting the floor: a dull heavy knock with a rattle of loose pieces"""
    t = t_axis(0.6)
    n = len(t)
    f = 90 * np.exp(-t / 0.08) + 50
    ph = 2 * np.pi * np.cumsum(f) / R
    x = np.sin(ph) * expdecay(t, 0.09) * 1.0
    x += bandpass(noise(n, rng), 70, 500) * expdecay(t, 0.05) * 0.8
    for i in range(14):
        tt = rng.uniform(0.0, 0.18)
        base = rng.uniform(2000, 6500)
        x += modal(t, tt, [base, base * 1.6], [0.12, 0.05], [0.02, 0.015], rng)
    x = reverb(x, wet=0.15, size=0.7)
    return trim(norm(softclip(norm(x), 1.6)))


def tink(rng):
    t = t_axis(0.45)
    base = rng.uniform(2900, 3300)
    x = modal(t, 0, [base, base * 1.52, base * 2.24], [0.6, 0.35, 0.2], [0.12, 0.08, 0.05], rng)
    x += highpass(noise(len(t), rng), 4000) * expdecay(t, 0.002) * 0.4
    return trim(norm(reverb(x, 0.12, 0.6)))


def bottle(rng):
    """black glass on a table breaking: a smaller burst with a hollow ring"""
    x = shatter(rng, size=0.7, dur=1.2, low=0.7, tail=0.7)
    t = np.arange(len(x)) / R
    f = rng.uniform(650, 1100)
    x = x + modal(t, 0.002, [f, f * 2.03, f * 3.1], [0.2, 0.1, 0.05], [0.09, 0.06, 0.04], rng)
    return trim(norm(x))


# ---------------------------------------------------------------- guns
def gunshot(rng, boom=75, body=(200, 2200), bodytau=0.025, boomtau=0.09, mech=True, dist=False, verb=0.25, dur=1.1):
    t = t_axis(dur)
    n = len(t)
    x = noise(n, rng) * expdecay(t, 0.0018) * 2.0                      # the crack of the round
    x += bandpass(noise(n, rng), *body) * expdecay(t, bodytau) * 1.2    # the blast
    f = boom * (1 + 0.6 * np.exp(-t / 0.02))
    x += np.sin(2 * np.pi * np.cumsum(f) / R) * expdecay(t, boomtau) * 1.1   # the thump in your chest
    x = softclip(x, 2.2)
    if mech:
        # the slide snapping back: a few short metal clacks
        t0 = rng.uniform(0.03, 0.045)
        x += modal(t, t0, [2100, 3400, 5600, 7700], [0.18, 0.14, 0.1, 0.06], [0.02, 0.015, 0.01, 0.008], rng)
        x += modal(t, t0 + 0.035, [1800, 2900, 4800], [0.1, 0.08, 0.05], [0.015, 0.012, 0.01], rng)
    if dist:
        x = lowpass(x, 3200, 2)
        x = np.concatenate([np.zeros(int(0.012 * R)), x])[:n]
    x = reverb(x, wet=verb, size=1.2, damp=2800, tail=0.5, fb=0.7)
    return trim(norm(x), 0.002)


def pump(rng, t, t0):
    """a pump-action rack: slide back, then slammed forward"""
    x = np.zeros_like(t)
    n = len(t)
    fr = bandpass(noise(n, rng), 900, 3500) * (expdecay(t, 0.03, t0) * (t >= t0))
    x += fr * 0.25
    x += modal(t, t0 + 0.02, [1500, 2600, 4100, 6300], [0.3, 0.22, 0.14, 0.08], [0.03, 0.025, 0.02, 0.012], rng)
    t1 = t0 + 0.16
    x += bandpass(noise(n, rng), 700, 3000) * expdecay(t, 0.02, t1) * 0.25
    x += modal(t, t1 + 0.012, [1300, 2200, 3500, 5200], [0.4, 0.28, 0.18, 0.1], [0.035, 0.03, 0.02, 0.015], rng)
    x += np.sin(2 * np.pi * 180 * t) * expdecay(t, 0.03, t1 + 0.012) * 0.25
    return x


def shotgun(rng):
    x = gunshot(rng, boom=58, body=(150, 1600), bodytau=0.06, boomtau=0.16, mech=False, verb=0.3, dur=1.4)
    t = t_axis(1.4)
    x = np.pad(x, (0, max(0, len(t) - len(x))))[:len(t)]
    x = x * 0.95 + pump(rng, t, 0.45)
    return trim(norm(x))


def smg(rng):
    return gunshot(rng, boom=95, body=(300, 3000), bodytau=0.014, boomtau=0.04, mech=True, verb=0.15, dur=0.45)


def ricochet(rng):
    t = t_axis(0.6)
    n = len(t)
    x = highpass(noise(n, rng), 2000) * expdecay(t, 0.003) * 1.2
    f0, f1 = rng.uniform(2600, 3600), rng.uniform(1000, 1600)
    f = f1 + (f0 - f1) * np.exp(-t / 0.18)
    f *= 1 + 0.03 * np.sin(2 * np.pi * rng.uniform(25, 40) * t)
    x += np.sin(2 * np.pi * np.cumsum(f) / R) * expdecay(t, 0.16) * (1 - np.exp(-t / 0.01)) * 0.7
    x += bandpass(noise(n, rng), 1500, 5000) * expdecay(t, 0.08) * 0.15
    return trim(norm(reverb(x, 0.2, 0.9)))


def impact(rng):
    """a bullet into a wall: a dull hard knock and a little crumbling"""
    t = t_axis(0.45)
    n = len(t)
    x = bandpass(noise(n, rng), 250, 1600) * expdecay(t, 0.018) * 1.2
    x += np.sin(2 * np.pi * rng.uniform(120, 170) * t) * expdecay(t, 0.03) * 0.6
    x += highpass(noise(n, rng), 3000) * expdecay(t, 0.003) * 0.7
    for i in range(10):
        tt = rng.uniform(0.02, 0.25)
        x += bandpass(noise(n, rng), 1000, 6000) * expdecay(t, 0.004, tt) * rng.uniform(0.05, 0.2)
    return trim(norm(reverb(x, 0.18, 0.9)))


def deflect(rng):
    """a bullet cut out of the air by a blade: a hard metal ping that rings on"""
    t = t_axis(1.0)
    n = len(t)
    x = highpass(noise(n, rng), 3000) * expdecay(t, 0.003) * 1.0
    x += modal(t, 0.001, [3150, 4870, 7420, 9100], [0.5, 0.35, 0.22, 0.12], [0.35, 0.25, 0.15, 0.1], rng)
    x += bandpass(noise(n, rng), 1500, 6000) * np.exp(-((t - 0.06) / 0.05) ** 2) * 0.15
    return trim(norm(reverb(x, 0.25, 1.0)))


def casing(rng):
    """an empty case bouncing on the floor: a few bright little tinks, closer and closer together"""
    t = t_axis(0.55)
    x = np.zeros_like(t)
    tt, gap, amp = 0.0, rng.uniform(0.09, 0.13), 0.6
    base = rng.uniform(4800, 6200)
    while tt < 0.45 and amp > 0.04:
        x += modal(t, tt, [base, base * 1.53, base * 1.98], [amp, amp * 0.5, amp * 0.3], [0.03, 0.02, 0.015], rng)
        tt += gap
        gap *= 0.68
        amp *= 0.6
    return trim(norm(reverb(x, 0.1, 0.6)))


def empty(rng):
    t = t_axis(0.15)
    x = modal(t, 0, [2400, 4100, 6300], [0.6, 0.35, 0.2], [0.008, 0.006, 0.004], rng)
    x += np.sin(2 * np.pi * 320 * t) * expdecay(t, 0.01) * 0.3
    return trim(norm(x))


def noammo(rng):
    t = t_axis(0.45)
    x = empty(rng)
    x = np.pad(x, (0, len(t) - len(x)))
    for i, (f, t0) in enumerate(((330, 0.09), (247, 0.19))):
        e = ((t >= t0) & (t < t0 + 0.07)).astype(float)
        e = signal.lfilter([0.08], [1, -0.92], e)
        x += (np.sign(np.sin(2 * np.pi * f * t)) * 0.4 + np.sin(2 * np.pi * f * t) * 0.6) * e * 0.5
    return trim(norm(lowpass(x, 4000)))


def pickup(rng):
    t = t_axis(0.25)
    x = modal(t, 0.0, [1800, 3100, 4900], [0.5, 0.3, 0.2], [0.015, 0.012, 0.01], rng)
    x += modal(t, 0.07, [2300, 3800, 6000], [0.45, 0.3, 0.18], [0.018, 0.013, 0.01], rng)
    x += bandpass(noise(len(t), rng), 300, 2000) * expdecay(t, 0.02) * 0.2
    return trim(norm(x))


def catch(rng):
    t = t_axis(0.22)
    n = len(t)
    x = bandpass(noise(n, rng), 300, 2500) * expdecay(t, 0.015) * 0.9
    x += np.sin(2 * np.pi * 140 * t) * expdecay(t, 0.03) * 0.5
    x += modal(t, 0.02, [2600, 4300], [0.25, 0.15], [0.015, 0.01], rng)
    return trim(norm(x))


# ---------------------------------------------------------------- bodies and air
def punch(rng):
    t = t_axis(0.32)
    n = len(t)
    f = 70 + 60 * np.exp(-t / 0.02)
    x = np.sin(2 * np.pi * np.cumsum(f) / R) * expdecay(t, 0.05) * 1.0
    x += bandpass(noise(n, rng), 500, 3500) * expdecay(t, 0.012) * 0.8
    x += highpass(noise(n, rng), 3000) * expdecay(t, 0.002) * 0.5
    return trim(norm(reverb(softclip(norm(x), 1.8), 0.12, 0.7)))


def step(rng, heavy=False):
    t = t_axis(0.28 if heavy else 0.2)
    n = len(t)
    x = np.sin(2 * np.pi * (60 if heavy else 75) * t) * expdecay(t, 0.035 if heavy else 0.025) * 0.9
    x += bandpass(noise(n, rng), 150, 1400) * expdecay(t, 0.03) * (0.5 if heavy else 0.35)
    x += bandpass(noise(n, rng), 1500, 5000) * expdecay(t, 0.02, 0.01) * 0.08
    if heavy:
        base = rng.uniform(2500, 4200)
        x += modal(t, 0.004, [base, base * 1.6], [0.12, 0.05], [0.03, 0.02], rng)
    return trim(norm(x))


def whoosh(rng, dur=0.24, f0=400, f1=1800, f2=600, amp=1.0):
    """air: noise through a band-pass whose centre sweeps up and back down (a smooth state-variable filter)"""
    t = t_axis(dur)
    n = len(t)
    nz = noise(n, rng)
    out = np.zeros(n)
    low = band = 0.0
    q = 0.35
    for i in range(n):
        u = i / n
        fc = f0 + (f1 - f0) * (u * 2) if u < 0.5 else f1 + (f2 - f1) * (u - 0.5) * 2
        f = 2 * np.sin(np.pi * min(fc, R * 0.2) / R)
        high = nz[i] - low - q * band
        band += f * high
        low += f * band
        out[i] = band
    env = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 2
    return trim(norm(lowpass(out, max(f0, f1, f2) * 2.2) * env * amp))


def slice_(rng):
    t = t_axis(0.5)
    n = len(t)
    x = whoosh(rng, 0.18, 800, 4000, 2000)
    x = np.pad(x, (0, n - len(x)))
    x += highpass(noise(n, rng), 4000) * expdecay(t, 0.03, 0.06) * 0.5
    x += modal(t, 0.06, [2800, 5500, 8200], [0.25, 0.18, 0.1], [0.15, 0.1, 0.06], rng)
    return trim(norm(reverb(x, 0.15, 0.8)))


def throw(rng):
    x = whoosh(rng, 0.34, 300, 2500, 700)
    t = np.arange(len(x)) / R
    return trim(norm(x * (0.75 + 0.25 * np.sin(2 * np.pi * 14 * t))))


def whiz(rng):
    t = t_axis(0.3)
    n = len(t)
    f = 700 + 600 * np.exp(-t / 0.06)
    x = np.sin(2 * np.pi * np.cumsum(f) / R) * 0.35
    x += bandpass(noise(n, rng), 1500, 5500) * 0.8
    env = np.exp(-((t - 0.07) / 0.045) ** 2)
    return trim(norm(x * env))


# ---------------------------------------------------------------- the machine
def spawn(rng):
    """someone arriving: a glassy shimmer that rises into place"""
    t = t_axis(0.9)
    x = np.zeros_like(t)
    notes = [523.25, 659.25, 783.99, 1046.5, 1318.5]
    for i, f in enumerate(notes):
        x += modal(t, i * 0.045, [f * 2, f * 3.01, f * 4.2], [0.25, 0.12, 0.06], [0.35, 0.2, 0.12], rng)
    x += highpass(noise(len(t), rng), 5000) * np.clip(t / 0.25, 0, 1) * expdecay(t, 0.12, 0.25) * 0.15
    return trim(norm(reverb(x, 0.3, 1.2)))


def wipe(rng):
    """a level being built from pixels: a stream of digital blips over rising static"""
    t = t_axis(0.55)
    n = len(t)
    x = np.zeros(n)
    tt = 0.0
    scale = [440, 554, 659, 880, 1108, 1318, 1760]
    while tt < 0.45:
        d = rng.uniform(0.012, 0.026)
        f = scale[rng.integers(len(scale))] * (1 + 0.6 * tt)
        m = (t >= tt) & (t < tt + d * 0.8)
        x[m] += np.sign(np.sin(2 * np.pi * f * t[m])) * 0.22
        tt += d
    x = lowpass(x, 5000)
    x += bandpass(noise(n, rng), 2000, 8000) * np.clip(t / 0.45, 0, 1) ** 2 * 0.25 * (t < 0.47)
    x += modal(t, 0.46, [1200, 2400], [0.3, 0.15], [0.03, 0.02], rng)
    return trim(norm(x))


def dive(rng):
    t = t_axis(0.32)
    n = len(t)
    x = whoosh(rng, 0.3, 300, 3200, 3200)
    x = np.pad(x, (0, n - len(x)))
    f = 60 + 80 * t / 0.32
    x += np.sin(2 * np.pi * np.cumsum(f) / R) * np.sin(np.pi * t / 0.32) * 0.5
    return trim(norm(x))


def flash(rng):
    t = t_axis(0.55)
    x = np.zeros_like(t)
    for f in (523.25, 784, 1046.5):
        x += (np.sign(np.sin(2 * np.pi * f * t)) * 0.3 + np.sin(2 * np.pi * f * t) * 0.7) * expdecay(t, 0.12)
    x = lowpass(x, 5000)
    x += highpass(noise(len(t), rng), 6000) * expdecay(t, 0.05) * 0.3
    return trim(norm(reverb(x, 0.25, 1.0)))


def key(rng):
    t = t_axis(0.05)
    x = modal(t, 0, [2600, 5200], [0.6, 0.2], [0.006, 0.004], rng)
    x += highpass(noise(len(t), rng), 2000) * expdecay(t, 0.0015) * 0.5
    return trim(norm(x))


def beep(rng):
    t = t_axis(0.13)
    x = np.sin(2 * np.pi * 880 * t) * expdecay(t, 0.035) * (1 - np.exp(-t / 0.002))
    x += np.sin(2 * np.pi * 1760 * t) * expdecay(t, 0.02) * 0.2
    return trim(norm(x))


def death(rng):
    """you breaking: a deep blow, glass everywhere, and a ringing in your ears"""
    t = t_axis(2.4)
    n = len(t)
    f = 45 + 50 * np.exp(-t / 0.05)
    x = np.sin(2 * np.pi * np.cumsum(f) / R) * expdecay(t, 0.4) * 1.0
    x += bandpass(noise(n, rng), 60, 400) * expdecay(t, 0.15) * 0.7
    g = shatter(rng, size=1.3, dur=2.0, low=1.2, tail=1.0)
    x[:len(g)] += g * 0.8
    ring = np.sin(2 * np.pi * 3700 * t) * np.clip((t - 0.15) / 0.3, 0, 1) * expdecay(t, 0.9, 0.45) * 0.12
    x += ring
    return trim(norm(softclip(norm(x), 1.3)))


# ---------------------------------------------------------------- loops (seamless)
def loop_periodic(fn, dur):
    t = t_axis(dur)
    return fn(t)


def crossfade_loop(x, fade=0.4):
    """make a stretch of noise loop without a seam: fold its end over its start"""
    n = int(fade * R)
    y = x[:-n].copy()
    w = np.linspace(0, 1, n)
    y[:n] = x[:n] * w + x[-n:] * (1 - w)
    return y


def drone(rng):
    """time almost stopped: a dark, slowly breathing pad"""
    dur = 6.0
    t = t_axis(dur)
    x = np.zeros_like(t)
    # every frequency fits a whole number of times in the loop, so it joins up exactly
    for f, a in ((55.0, 0.5), (55.5, 0.4), (82.5, 0.3), (110.0, 0.15), (165.0, 0.08), (220.5, 0.05)):
        x += np.sin(2 * np.pi * f * t) * a
    breath = 0.7 + 0.3 * np.sin(2 * np.pi * t / dur)
    air = crossfade_loop(lowpass(rng.standard_normal(len(t) + int(0.4 * R)), 900), 0.4)[:len(t)] * 0.08
    x = lowpass(x * breath, 600) + air
    return norm(x, 0.8)


def rush(rng):
    """time running: air rushing past, a low rumble under it"""
    dur = 5.0
    extra = int(0.5 * R)
    nz = rng.standard_normal(int(dur * R) + extra)
    w = bandpass(nz, 300, 2500) * 0.6 + lowpass(nz, 120) * 1.2
    t = np.arange(len(w)) / R
    w *= 0.75 + 0.25 * np.sin(2 * np.pi * t * 0.6) * np.sin(2 * np.pi * t * 0.37)
    return norm(crossfade_loop(w, 0.5), 0.8)


def hum(rng):
    """the computer: mains hum, a whine and a little hiss"""
    dur = 4.0
    t = t_axis(dur)
    x = np.zeros_like(t)
    for h, a in ((1, 0.5), (2, 0.25), (3, 0.18), (5, 0.08), (7, 0.04)):
        x += np.sin(2 * np.pi * 60 * h * t) * a
    x += np.sin(2 * np.pi * 15750 / 2 * t) * 0.0  # (beyond our rate: left out)
    x += np.sin(2 * np.pi * 7875 * t) * 0.01
    hiss = crossfade_loop(highpass(rng.standard_normal(len(t) + int(0.3 * R)), 3000), 0.3)[:len(t)] * 0.05
    return norm(x * 0.6 + hiss, 0.6)


# ---------------------------------------------------------------- the list
# (id name in game.h, how many versions, maker, loudness 0..1)
SETS = [
    ('SFX_PUNCH', 3, punch, 0.95),
    ('SFX_SHATTER', 3, lambda r: shatter(r), 0.95),
    ('SFX_SHOT', 2, lambda r: gunshot(r), 0.95),
    ('SFX_EMPTY', 1, empty, 0.6),
    ('SFX_PICKUP', 2, pickup, 0.75),
    ('SFX_THROW', 2, throw, 0.7),
    ('SFX_STEP', 4, lambda r: step(r), 0.55),
    ('SFX_DEATH', 1, death, 1.0),
    ('SFX_KEY', 2, key, 0.5),
    ('SFX_BEEP', 1, beep, 0.45),
    ('SFX_FLASH', 1, flash, 0.6),
    ('SFX_WHIZ', 3, whiz, 0.7),
    ('SFX_RICOCHET', 3, ricochet, 0.7),
    ('SFX_SWING', 3, lambda r: whoosh(r), 0.6),
    ('SFX_ENEMY_SHOT', 2, lambda r: gunshot(r, dist=True, verb=0.4), 0.85),
    ('SFX_TINK', 2, tink, 0.6),
    ('SFX_SHOTGUN', 2, shotgun, 1.0),
    ('SFX_SMG', 3, smg, 0.85),
    ('SFX_SLICE', 2, slice_, 0.85),
    ('SFX_NOAMMO', 1, noammo, 0.7),
    ('SFX_BREAK', 3, bottle, 0.8),
    ('SFX_LIMB', 3, limb, 0.9),
    ('SFX_THUD', 2, thud, 0.9),
    ('SFX_WINDOW', 2, window_crash, 1.0),
    ('SFX_IMPACT', 3, impact, 0.6),
    ('SFX_DEFLECT', 2, deflect, 0.8),
    ('SFX_CASING', 3, casing, 0.45),
    ('SFX_ESTEP', 4, lambda r: step(r, heavy=True), 0.6),
    ('SFX_SPAWN', 1, spawn, 0.5),
    ('SFX_WIPE', 1, wipe, 0.55),
    ('SFX_DIVE', 1, dive, 0.6),
    ('SFX_CATCH', 1, catch, 0.7),
]
LOOPS = [('LOOP_DRONE', drone), ('LOOP_RUSH', rush), ('LOOP_HUM', hum)]


def to_i16(x, vol):
    x = np.clip(x * vol, -1, 1)
    return (x * 32000).astype(np.int16)


def emit(name, arr, f):
    f.write('static const short %s[%d] = {' % (name, len(arr)))
    for i in range(0, len(arr), 24):
        f.write(','.join(str(int(v)) for v in arr[i:i + 24]))
        f.write(',\n' if i + 24 < len(arr) else '')
    f.write('};\n')


def main():
    total = 0
    with open(os.path.join(OUT, 'sounds.c'), 'w') as f:
        f.write('/* generated by tools/make_sounds.py: every sound in the game, synthesized from scratch */\n')
        f.write('#include "game.h"\n#include "sounds.h"\n\n')
        table = []
        for si, (sid, nvar, maker, vol) in enumerate(SETS):
            names = []
            for v in range(nvar):
                rng = np.random.default_rng(1000 * si + 17 * v + 3)
                x = maker(rng)
                a = to_i16(x, vol)
                nm = 'snd_%s_%d' % (sid[4:].lower(), v)
                emit(nm, a, f)
                names.append((nm, len(a)))
                total += len(a)
            table.append((sid, names))
        loops = []
        for li, (lid, maker) in enumerate(LOOPS):
            rng = np.random.default_rng(777 + li)
            a = to_i16(maker(rng), 1.0)
            nm = 'snd_%s' % lid.lower()
            emit(nm, a, f)
            loops.append((lid, nm, len(a)))
            total += len(a)
        f.write('\nint snd_variants(int id, SndClip out[SND_MAX_VARIANTS]) {\n    switch (id) {\n')
        for sid, names in table:
            f.write('    case %s:\n' % sid)
            for k, (nm, ln) in enumerate(names):
                f.write('        out[%d].data = %s; out[%d].len = %d;\n' % (k, nm, k, ln))
            f.write('        return %d;\n' % len(names))
        f.write('    }\n    return 0;\n}\n\n')
        f.write('int snd_loop(int id, SndClip *out) {\n    switch (id) {\n')
        for lid, nm, ln in loops:
            f.write('    case %s: out->data = %s; out->len = %d; return 1;\n' % (lid, nm, ln))
        f.write('    }\n    return 0;\n}\n')
    with open(os.path.join(OUT, 'sounds.h'), 'w') as f:
        f.write('/* generated by tools/make_sounds.py */\n#ifndef SOUNDS_H\n#define SOUNDS_H\n')
        f.write('#define SND_MAX_VARIANTS 4\n')
        f.write('typedef struct { const short *data; int len; } SndClip;\n')
        f.write('/* the ready-made versions of a sound (returns how many; 0 = none) */\n')
        f.write('int snd_variants(int id, SndClip out[SND_MAX_VARIANTS]);\n')
        f.write('int snd_loop(int id, SndClip *out);\n#endif\n')
    print('sounds: %d sets, %.1f seconds, %.1f MB of samples' % (len(SETS), total / R, total * 2 / 1e6))


if __name__ == '__main__':
    main()
