# Superhot

A first-person shooter for the 2DS / 3DS where time only moves when you move. Everyone is made of glass, so one hit breaks anyone, you included.

## The computer

The game runs inside a fake old computer, Shatter-OS, on a curved CRT screen. The file commander shows:

| File | What it is |
|---|---|
| `superhot.exe` | story mode: plays the levels in order, with the chat between them |
| `levels.ult` | every level you have beaten; pick one to play it again |
| `replays` | your saved replays (press X on the win screen to keep one) |
| `settings` | graphics HIGH/LOW, glow on/off, curved screen on/off, look speed |
| `chat.exe` | the chat with your friend |

Replays are saved on the SD card in `sdmc:/3ds/shatter/replays/` (up to 12; the oldest gets replaced).

## How it plays

- Stand still and the world nearly stops. Bullets crawl through the air (they never fully stop), each with a red trail behind it.
- You start every level with your fists. Punch a red man and he shatters. If a red man punches you, or a bullet reaches you, you shatter and the level restarts.
- Guns lie on the floor and drop from the men who carry them. You can carry one gun with 3 shots. Only you can throw it, and a thrown gun breaks whoever it hits.
- Clear a level and the screen flashes SUPER / HOT in black and white until you press A.
- Black and red things are glass and break: the men, you, guns, bottles and vases on the tables. White things do not.
- Pick any cleared level again from the file commander.

## Controls

| Button | What it does |
|---|---|
| Circle pad | walk and sidestep |
| ABXY or D-pad | look around (you can also drag on the touch screen) |
| R / ZR | punch, or shoot when you have a gun |
| L / ZL | pick up a gun, or throw the one you hold |
| START | pause |
| SELECT | restart the level |

Hold L while the game starts to use the classic (software) renderer. On an Old 3DS, set `settings/graphics.cfg` to LOW if it runs slowly.

## Weapons

| Weapon | Use |
|---|---|
| fists | R punches. You always have them. |
| pistol | 3 shots, R fires. Out of ammo, NO AMMO flashes on screen: throw it or swap it |
| shotgun | 2 shells, R fires a spread of pellets |
| smg | 12 rounds, hold R to keep firing |
| katana | R swings; reaches about two metres and cuts bullets out of the air |
| bat | R swings; reaches a little less than the katana |
| bottles, vases, mugs | L picks one up off a table, R or L throws it. It smashes on whatever it hits |

L throws whatever you are holding, and anything you throw breaks a red man it hits. Enemies carry the same guns, swords and bats. Every weapon is black glass, so a bullet shatters it.

## Sound

Every sound is synthesized from scratch by `tools/make_sounds.py` (no recordings, nothing taken from another game) and built into the game as `source/sounds.c`; only the two shouted words are made by a small formant voice when the game starts. There are 32 sounds with up to four versions each, so repeats never sound identical: glass that cracks, rings and rains down in pieces (with separate sounds for a limb breaking off, a body hitting the floor and a window giving way), gunshots with the slide clacking and a room tail, a shotgun that racks after each shot, bullets knocking into walls, ricocheting and whizzing past, a ringing ping when the katana cuts one, heavy glassy enemy footsteps, shell casings tinkling on the floor, a shimmer as an enemy appears, digital blips and whooshes as a level builds itself, a low breathing drone while time is slow and rushing air while it runs. Everything happening in the world slows down and drops in pitch with time itself; menu sounds, the voice and the level wipe do not. To change a sound, edit the script and run it again.

## The levels

| | Level | Setting |
|---|---|---|
| 00 | TUTORIAL | plain white rooms |
| 01 | KICK | a hotel lobby: sofas, plants, a reception desk |
| 02 | DUEL | a meeting room with bookshelves |
| 03 | TRAIN | a train carriage, the city sliding past the windows (only while time moves) |
| 04 | BAR | a bar with bottles on the back shelf, stools and a booth |
| 05 | ELEVATOR | you start in the lift; the doors open on a lobby |
| 06 | OFFICE | rows of desks, screens, partitions and filing shelves |
| 07 | GARAGE | an underground car park: parked cars, painted bays, daylight through the openings |
| 08 | STREET | outdoors between buildings: cars, street lamps, trees |
| 09 | LANDING | a stairwell with two flights |
| 10 | SERVERS | rows of server racks with blinking lights |
| 11 | CROSSING | a crossroads: zebra crossings, traffic lights, four buildings |
| 12 | GALLERY | pedestals with black glass sculptures, pictures on display walls |
| 13-14 | BOX, DARK | the computer is no longer yours |
| 15 | PENTHOUSE | a top floor lounge: sofas, plants, long counters |
| 16 | ALLEY | a narrow back street with dumpsters and parked cars |
| 17 | LIBRARY | rows of bookshelves, reading tables |
| 18 | LOADING | a loading dock full of crates |
| 19 | METRO | a train carriage twice as long as the first |
| 20 | CAFE | small tables with drinks, a counter, booths |
| 21 | ARCHIVE | a maze of server racks |
| 22 | PLAZA | an open square with kiosks, trees and benches |
| 23 | FLOORS | a stairwell going up four flights |
| 24 | MUSEUM | display walls, pedestals with black glass sculptures |
| 25 | END | where it ends |

Everything white or grey is solid and never breaks; only black and red things are glass.

## The story

The game boots into a fake operating system, Shatter-OS. A friend messages you about a leaked game and sends you the file. Between levels the chat continues, and with every level you clear your computer gets more corrupted: letters swap, the clock runs backwards, the screens glitch. From level 10 on the machine belongs to the game, and ten new files appear in levels.ult that you never downloaded. When you try to message your friend, your keyboard only types the two words over and over. After level 25 the game takes over the whole screen.

In the chat, any button types your message a few letters at a time. Press again to send. START leaves the chat.

## Changing the two words

The flash words, the hacked chat spam and the .exe name all come from one line in `tools/make_assets.py`:

```python
FLASH_WORDS = ['SUPER', 'HOT']
```

Change it, run `python3 tools/make_assets.py` (needs Pillow and numpy), and rebuild.

## Changes

The current version is 1.0.7. See CHANGELOG.md for what changed in each update.

## Building

Push `shatter.zip` to a GitHub repo with the workflow in `.github/workflows/build.yml`. GitHub Actions builds the .3dsx and .cia and publishes a release with a QR code you can scan in FBI.

To test on a PC: `gcc -O2 -Isource tools/host_test.c source/{engine,levels,world,ui,audio,assets,models,decor}.c -lm -o host && ./host`. This runs the scripted tests and writes preview images to /tmp. `./host maps` renders every level from three angles, `./host near` shows the furniture up close.

## Credits

- Fonts: VT323 and Anton (SIL Open Font License, tools/FONTS-OFL.txt), Roboto Light (Apache 2.0, tools/Roboto-LICENSE.txt).
- The enemy and pistol models came from the files supplied for this project. Check their licences before you share the game.

