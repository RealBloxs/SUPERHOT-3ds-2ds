# Changes

## 1.0.6

- The enemy's head is back to exactly how the model has it. Up close, the game used to draw a simplified head with about a quarter of the model's triangles, which looked pointy. Now it uses all 3062 of the head's triangles.
- The arms bend where the model's arms actually are. Before, the game split arm from body by side-to-side position only, so strips of the arms stayed stuck to the chest and stretched into flaps when an arm moved. Now it follows the model's own surface from each hand up to the armpit, so each whole arm moves together.
- The enemies were facing backwards. Your model faces the other way from what the game expected, so every weapon was held behind them. They're turned around now, so they face what they aim at and lean into it.
- The enemies look like red glass instead of plastic: a deeper red core, light glowing through thin parts, pale edges, the room reflected in them, and a sharp highlight.
- Far-away enemies (past 7 m) still use the lighter model so the game runs smoothly.

## 1.0.5

- Less lag. Enemies are much cheaper to draw, fog is quicker, and the game sends triangles straight to the GPU. The graphics look the same.
- Enemies are smooth-shaded now, so you don't see the little flat faces on the model anymore.
- New death screen. The camera stays in your eyes, time freezes, there's a white flash and a glitch, and everything goes black and white. Press A, R or START to restart, or wait 2 seconds and it restarts by itself.
- New loading screen when you open superhot.exe, start a level or restart. Blue pixels build a tall rectangle with a black hole in it, then you dive into the hole five times, faster each time, until you're in the level.
