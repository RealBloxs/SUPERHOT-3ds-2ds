# Changes

## 1.0.5

- Less lag. Enemies are much cheaper to draw, fog is quicker, and the game sends triangles straight to the GPU. The graphics look the same.
- Enemies are smooth-shaded now, so you don't see the little flat faces on the model anymore.
- New death screen. The camera stays in your eyes, time freezes, there's a white flash and a glitch, and everything goes black and white. Press A, R or START to restart, or wait 2 seconds and it restarts by itself.
- New loading screen when you open superhot.exe, start a level or restart. Blue pixels build a tall rectangle with a black hole in it, then you dive into the hole five times, faster each time, until you're in the level.
